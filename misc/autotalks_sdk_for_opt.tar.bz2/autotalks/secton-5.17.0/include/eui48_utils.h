#ifndef _ATLK_EUI48_UTILS_H
#define _ATLK_EUI48_UTILS_H

#include <string.h>

#include <common/eui48.h>
#include <common.h>

#include <atlk/sdk.h>

/** Format argument list for eui48_t */
#define EUI48_FMT_ARGS(x)                   \
  (x).octets[0], (x).octets[1], (x).octets[2],    \
  (x).octets[3], (x).octets[4], (x).octets[5]

/** Return single octet */
#define EUI48_OCTET(x,i) (x).octets[(i)]

/* parasoft-begin-suppress BD-PB-UCMETH-4 "These function are only used in ref_src/ code that is excluded from MISRA build" */
/**
   Copy eui48 address

   @param[out] dst Copy of source EUI48 address
   @param[in] src EUI48 address to copy
*/
atlk_inline void
eui48_copy(eui48_t *dst_ptr, const eui48_t *src_ptr)
{
  atlk_memcpy(dst_ptr, src_ptr, EUI48_LEN);
}

/**
   Compare eui48 addresses

   @param[in] eui1 EUI48 address to compare
   @param[in] eui2 EUI48 address to compare

   @retval 1 EUI48 address are equal,
   @retval 0 EUI48 address are not equal
*/
atlk_inline int
eui48_match(const eui48_t *eui1_ptr, const eui48_t *eui2_ptr)
{
  return (int)(0 == memcmp((const uint8_t *)eui1_ptr, (const uint8_t *)eui2_ptr, EUI48_LEN));
}
/* parasoft-end-suppress BD-PB-UCMETH-4 "These function are only used in ref_src/ code that is excluded from MISRA build" */

#endif /* _ATLK_EUI48_UTILS_H */
