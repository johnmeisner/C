#ifndef _QUEUE_H
#define _QUEUE_H

#include <atlk/sdk.h>
#include <osal.h>
#include <common.h>

typedef void (*queue_item_destroy_callback_t)(void * ptr);

typedef struct queue_stats_st {
  size_t enqueue_cnt;
  size_t dequeue_cnt;
  size_t enqueue_fail_cnt;
  size_t dequeue_fail_cnt;
} queue_stats_t;

typedef struct queue_handler_st {
  uint32_t magic;
  uint32_t front;
  uint32_t rear;
  uintptr_t *queue_buffer;
  size_t queue_count;
  pthread_mutex_t queue_mutex;
  pthread_condattr_t cond_attr_full;
  pthread_condattr_t cond_attr_empty;
  pthread_cond_t cond_full;
  pthread_cond_t cond_empty;
  int is_full;
  int is_empty;
  int is_enqueue_enabled;
  int queue_destroy_in_progress;
  queue_stats_t stats;
  int32_t destroy_sync;
  queue_item_destroy_callback_t queue_item_destroy_callback;
} queue_handler_t;

#define QUEUE_HANDLER_INIT {   \
  .magic = 0,                  \
}


atlk_rc_t atlk_must_check
queue_init(queue_handler_t *queue_handler,
           uintptr_t *queue_buffer,
           size_t queue_count);

atlk_rc_t atlk_must_check
queue_enqueue_enable_flag_set(queue_handler_t *queue_handler,
                              int enabled);

atlk_rc_t atlk_must_check
queue_enqueue(queue_handler_t *queue_handler,
              uintptr_t ptr,
              const atlk_wait_t *wait_ptr);

atlk_rc_t atlk_must_check
queue_dequeue(queue_handler_t *queue_handler,
              uintptr_t *ptr,
              const atlk_wait_t *wait_ptr);

atlk_rc_t atlk_must_check
queue_stats_get(queue_handler_t *queue_handler,
                queue_stats_t *queue_stats_ptr);

atlk_rc_t atlk_must_check
queue_destroy(queue_handler_t *queue_handler);

atlk_rc_t atlk_must_check
queue_item_destroy_callback_set(queue_handler_t *queue_handler, queue_item_destroy_callback_t queue_item_destroy_callback);

/* return number of elements in queue or negative number on error */
int
queue_count_get(queue_handler_t *queue_handler);

/* locks the queue and returns element to dequeue, but does not dequeue it
   must call queue_unlock() or queue_drop_and_unlock() after that call */
atlk_rc_t
queue_lock_and_peek(queue_handler_t *queue_handler, uintptr_t *pptr);

/* drop last peeked at element and returns the next element to dequeue, but does not dequeue it */
atlk_rc_t
queue_drop_and_peek(queue_handler_t *queue_handler, uintptr_t *pptr);

/* unlock queue and dequeue element that was peeked at */
atlk_rc_t
queue_drop_and_unlock(queue_handler_t *queue_handler);

/* unlock queue and dequeue element */
atlk_rc_t
queue_unlock(queue_handler_t *queue_handler);

#endif /* _QUEUE_H */
