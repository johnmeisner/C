#ifndef _CORE_WDM_INTERNAL_H
#define _CORE_WDM_INTERNAL_H

#include <atlk/sdk.h>

#define WDM_DSP_VER_STR_MAX_LEN 64U

/**
   Initialize WDM module

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
 */
atlk_rc_t atlk_must_check
wdm_module_init(void);

#endif /* _CORE_WDM_INTERNAL_H */
