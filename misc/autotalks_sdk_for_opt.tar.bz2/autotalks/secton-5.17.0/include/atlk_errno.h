#ifndef _ATLK_ERRNO_H
#define _ATLK_ERRNO_H

#include <atlk/sdk.h>
#include <atlk_queue.h>
#include <time.h>

typedef struct atlk_errno_s {
   uint64_t timestamp;
   uint32_t error;
   uint32_t submodule;
} atlk_errno_t;

typedef struct atlk_errno_handler_s atlk_errno_handler_t;

/**
   @brief      Initialize error repository (atlk_errno_handler_t)

   @param[out] errno_handler_pptr  Pointer to pointer to the created error repository
   @param[in]  max_errors          Max number of errors to keep

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t
atlk_errno_create(atlk_errno_handler_t ** const errno_handler_pptr, const uint32_t max_errors);


/**
   @brief         Retrieve specific number of errors, in FIFO order

   @note          Retrieved errors are removed from the repository

   @param[in]     errno_handler_ptr  Pointer to the errno handler
   @param[out]    errors_array       Array to store retrieved errors
   @param[in/out] num_errors_ptr     IN  - Number of errors to retrieve
                                     OUT - Actual number of errors retrieved

   @retval        ATLK_OK if succeeded
   @return        Error code if failed
*/
atlk_rc_t
atlk_errno_errors_get(atlk_errno_handler_t * const errno_handler_ptr, uint32_t *num_errors_ptr, atlk_errno_t errors_array[]);


/**
   @brief     Create new error and insert it into the repository

   @param[in] errno_handler_ptr Pointer to the errno handler
   @param[in] error             Error type
   @param[in] submodule         Number of the submodule in which the error occured

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t 
atlk_errno_error_set(atlk_errno_handler_t * const errno_handler_ptr, const uint32_t error, const uint32_t submodule);

/**
   @brief      Get the current number of errors

   @param[in]  errno_handler_ptr   Pointer to the errno handler
   @param[out] curr_num_errors     Current number of errors

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t 
atlk_errno_num_errors_get(atlk_errno_handler_t * const errno_handler_ptr, uint32_t *curr_num_errors);


/**
   @brief     Clear all errors in the repository

   @param[in] errno_handler_ptr Pointer to the errno handler

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t
atlk_errno_clear(atlk_errno_handler_t * const errno_handler_ptr);


/**
   @brief     Free all memory and destroy the repository

   @param[in] errno_handler_ptr Pointer to the errno handler

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t
atlk_errno_destroy(atlk_errno_handler_t * const errno_handler_ptr);

#endif /* _ATLK_ERRNO_H */
