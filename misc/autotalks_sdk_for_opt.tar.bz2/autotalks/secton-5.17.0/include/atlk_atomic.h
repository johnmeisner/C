/* Copyright (C) 2012-2016 Autotalks Ltd. */
#ifndef _ATLK_ATOMIC_H
#define _ATLK_ATOMIC_H

#include <atlk/sdk.h>

#if defined __GNUC__ && !defined __arc__
#define ATLK_ATOMIC_USE_GCC_BUILTIN

#elif defined __THREADX__
#include <tx_api.h>
#define ATLK_ATOMIC_USE_THREADX_API

#else
#error "Neither GCC atomic builtins nor ThreadX API are available"
#endif

typedef struct {
  volatile int counter;
} atlk_atomic_t;

#define ATLK_ATOMIC_INIT(i) { (i) }

#define atlk_atomic_read(v) ((v)->counter)

#define atlk_atomic_set(v, i) (((v)->counter) = (i))

#endif /* _ATLK_ATOMIC_H */
