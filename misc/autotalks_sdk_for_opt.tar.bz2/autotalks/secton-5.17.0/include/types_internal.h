#ifndef _TYPES_INTERNAL_H
#define _TYPES_INTERNAL_H

#include <common/types.h>

/** 1/8 dBm to dBm conversion factor */
#define POWER_DBM8_PER_DBM 8

/* Factor to divide DSP RSSI in oreder to get the real DB value.
(DSP uses 0.5 DB steps for RSSI) */
#define DSP_RSSI_TO_REAL_DB_STEPS 2

/* Offset to decrease from DSP RSSI in order to get the real value.
(DSP adds offset to RSSI so it will fit in DSP RSSI uint8_t field) */
#define DSP_RSSI_TO_REAL_OFFSET_802_11 110
#define DSP_RSSI_TO_REAL_OFFSET_CV2X   128

#define DSP_DIVERSITY_RSSI_NA 0

power_dbm8_t
dsp_rssi_to_dbm8_convert(int16_t dsp_rssi, int16_t dsp_rssi_to_real_offset);

#endif /* _TYPES_INTERNAL_H */