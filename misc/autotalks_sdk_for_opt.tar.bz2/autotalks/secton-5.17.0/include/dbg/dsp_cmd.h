#ifndef _DSP_CMD_H_
#define _DSP_CMD_H_

#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <stdint.h>
#include <stddef.h>
#endif /* __KERNEL__ */

#include "dsp_common_defs.h"

#define DSP_CMD_REQUEST_DATA_SIZE 64U

/* Mail box messages bit specification. */
#define MBOX_D2H_TX_CHANNEL_0   0x001U
#define MBOX_D2H_TX_CHANNEL_1   0x002U
#define MBOX_D2H_RX_CHANNEL_0   0x004U
#define MBOX_D2H_RX_CHANNEL_1   0x008U
#define MBOX_D2H_CMD_DONE_0     0x010U
#define MBOX_D2H_CMD_DONE_1     0x020U
#define MBOX_D2H_ASSERT         0x040U

#define MBOX_D2H_COMP_CALIB_READY 0x080U

#define MBOX_D2H_BOOTED         0x100U
#define MBOX_D2H_RUNNING_0      0x200U
#define MBOX_D2H_RUNNING_1      0x400U
#define MBOX_D2H_CMD_REQ        0x800U

#define MBOX_D2H_PPS_LOCKED     0x1000U
#define MBOX_D2H_PPS_LOCK_LOST  0x2000U
#define MBOX_D2H_PPS_SYNCED     0x4000U

#define MBOX_D2H_TRIGGER_CATCHED 0x8000U

#define MBOX_H2D_TX_CHANNEL_0   0x0001U
#define MBOX_H2D_TX_CHANNEL_1   0x0002U
#define MBOX_H2D_CMD_REQ_0      0x0004U
#define MBOX_H2D_CMD_REQ_1      0x0008U

#define MBOX_H2D_CMD_DONE       0x4000U

#define MBOX_H2D_ATTACH_0       0x0100U
#define MBOX_H2D_ATTACH_1       0x0200U
#define MBOX_H2D_PPS_IND        0x1000U

enum dsp_cmd_if_status {
  DSP_CMD_IF_STATUS_IDLE            = 0U,
  DSP_CMD_IF_STATUS_REQUEST_PENDING = 1U,
  DSP_CMD_IF_STATUS_REQUEST_DONE    = 2U
};

enum dsp_cmd_status {
  DSP_CMD_STATUS_PENDING = 0U,
  DSP_CMD_STATUS_DONE    = 1U,
  DSP_CMD_STATUS_FAILED  = 2U
};

typedef struct dsp_cmd_request_generic {
  /* A generic Host to DSP command */
  uint8_t msg[DSP_CMD_REQUEST_DATA_SIZE];
} dsp_cmd_request_generic_t;

typedef struct dsp_cmd_request {
  uint32_t code; /* see enum h2d_cmd_code*/
  uint32_t status; /* see h2d_cmd_status */
  dsp_cmd_request_generic_t data;
} dsp_cmd_request_t;

typedef struct dsp_cmd_if {
  uint32_t          status; /* see h2d_cmd_if_status */
  dsp_cmd_request_t request;
} dsp_cmd_if_t;

#endif /* _DSP_CMD_H_ */
