#ifndef _RF_COOKIE_H
#define _RF_COOKIE_H

#include "rf_defs.h"
#include "dsp_external_tables.h"

#define COMPENSATOR_MSG_BUF_SIZE         64                          /* buf size in number of messages, must be power of 2  */
#define COMPENSATOR_CAL_TBL_SIZE_MAX     1024                        /* compensator calibration tbl size in bytes */

#define COMPENSATOR_DISABLED             0U
#define COMPENSATOR_ENABLED              1U
#define COMPENSATOR_INFO_DOWNLOAD        2U
#define COMPENSATOR_DOWNLOAD_FAIL        3U

/** Bit mask for valid flags (all must be powers of 2) */
#define COMPENSATOR_VALID_TSSI_DETECTOR  0x01U
#define COMPENSATOR_VALID_TEMPERATURE    0x02U
#define COMPENSATOR_VALID_EVENT_STATUS   0x04U
#define COMPENSATOR_VALID_KEEP_ALIVE     0x08U
#define COMPENSATOR_VALID_CABLE_LOSS     0x80U                       /* sticky bit from DSP, SW shall not clear it */

/** Compesator interface */
typedef struct compensator_api
{
  dsp_d2h dsp_uint8_t        state;                                  /* compensator current state: disabled, enabled, info_downloading */

  /*** COMPENSATOR INFO ***/
  dsp_d2h dsp_uint8_t        hw_ver;                                 /* 4 MSB of MAJOR / 4 LSB of MINOR version number of HW revision  */
  dsp_d2h dsp_uint8_t        sw_ver;                                 /* 4 MSB of MAJOR / 4 LSB of MINOR version number of SW revision  */
  dsp_d2h dsp_uint8_t        prot_ver;                               /* 4 MSB of MAJOR / 4 LSB of MINOR version number of UART protocol revision */

  /*** COMPENSATOR PARAMS ***/
  dsp_d2h dsp_uint8_t        tssi_detector;                          /* last tssi / detector value from the compensator */
  dsp_d2h dsp_int8_t         temperature;                            /* actual temperature of the compensator */
  dsp_d2h dsp_uint8_t        event_status;                           /* bit flags for various compensastor events indication */
  dsp_d2h dsp_uint8_t        valid_flags;                            /* DSP set bit as valid, SW clear after read. see COMPENSATOR_VALID_... flags for details */

  dsp_d2h dsp_uint8_t        cable_loss;                             /* dB8 of cable loss: DSP will not calculate if provided in RF config (cable_loss != 0) */

  /*** MONITORING / DEBUG ***/
  dsp_d2h dsp_uint32_t       msg_total_cnt;                          /* total number of messages received from the compensator */
  dsp_d2h dsp_uint32_t       msg_error_cnt;                          /* number of broken messages received from the compensator */
  dsp_d2h dsp_uint16_t       msg_buffer[ COMPENSATOR_MSG_BUF_SIZE ]; /* circular buffer with N last raw UART messages from the compensator */

  /*** RAW CALIBRATION DATA ***/
  dsp_d2h DSP_POINTER(void,  calib_raw_data_buff);                   /* pointer to raw calibration data. non zero if there is calibration data to parse */

  /*** PARSED CALIBRATION DATA ***/
  dsp_h2d dsp_uint8_t        calib_valid;                            /* SW set to 1 after successful parsing of compensator calibration data */
  dsp_h2d comp_cal_info_t    calibration;                            /* struct with parsed calibration data from the compensator */

} dsp_packed compensator_api_t;


/** RF shared memory control */
#pragma pack(push, 4)
typedef struct rf_cookie {
  /** Compensator status */
  dsp_d2h DSP_POINTER(compensator_api_t, compensator);

  /** Last sampled RF temperature */
  dsp_h2d dsp_int32_t        rf_temperature;

  /** RSSI temperature bias */
  dsp_h2d dsp_rssi_bias_t    rssi_tempr_bias;

  /**
      DSP marks a status as valid by setting the corresponding bit to 1,
      Host marks a field as invalid after read by setting the corresponding
      bit to 0. see RF_STATUS_VALID_*
  */
  dsp_d2h uint8_t            valid_flags;
} rf_cookie_t;
#pragma pack(pop)

#endif /* _RF_COOKIE_H */
