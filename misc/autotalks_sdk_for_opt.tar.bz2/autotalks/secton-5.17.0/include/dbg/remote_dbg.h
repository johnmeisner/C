/* Copyright (C) 2016 Autotalks Ltd. */
#ifndef _REMOTE_DBG_PROTOCOL_H
#define _REMOTE_DBG_PROTOCOL_H

#include <wlan/dsp_interface.h>

#include "remote_defs.h"
#include "remote_object.h"
#include "remote_counters.h"

#define RF_MEM_MAX_FRAGMENT_SIZE          128
#define MEM_MAX_READ_IN_DWORDS            350
#define REMOTE_DBG_BOOT_TIMER_MAX_PHASES  2
#define REMOTE_DBG_LOG_FILE_NAME_MAX_SIZE 60
#define REMOTE_DBG_BLOB_MAX_CHUNK_LENGTH  2048

typedef enum {
  REMOTE_DBG_REQUEST_TYPE_OBJECT_SET = 0,
  REMOTE_DBG_REQUEST_TYPE_OBJECT_GET,
  REMOTE_DBG_REQUEST_TYPE_MAX,
} remote_dbg_request_type_t;

typedef enum {
  REMOTE_DBG_OBJECT_TYPE_MEM_8 = REMOTE_DBG_REQUEST_TYPE_MAX,
  REMOTE_DBG_OBJECT_TYPE_MEM_16,
  REMOTE_DBG_OBJECT_TYPE_MEM_32,
  REMOTE_DBG_OBJECT_TYPE_MEM_32_DUMP,
  REMOTE_DBG_OBJECT_TYPE_DSP_MEM_32,
  REMOTE_DBG_OBJECT_TYPE_DSP_MEM_32_RANGE,
  REMOTE_DBG_OBJECT_TYPE_EPROM_32,
  REMOTE_DBG_OBJECT_TYPE_DDM_HB_CYCLE,
  REMOTE_DBG_OBJECT_TYPE_STATS,
  REMOTE_DBG_OBJECT_TYPE_WLAN_STATS_EXTENDED,
  REMOTE_DBG_OBJECT_TYPE_WLAN_RING_INFO,
  REMOTE_DBG_OBJECT_TYPE_DSP_COOKIE,
  REMOTE_DBG_OBJECT_TYPE_EPROM_MEM_APP_INFO,
  REMOTE_DBG_OBJECT_TYPE_PROFILER_STATISTICS,
  REMOTE_DBG_OBJECT_TYPE_BOOT_TIMER_MEASUREMENTS,
  REMOTE_DBG_OBJECT_TYPE_WLAN_CBR,
  REMOTE_DBG_OBJECT_TYPE_WLAN_FILTERS,
  REMOTE_DBG_OBJECT_TYPE_SOC_REG_32,
  REMOTE_DBG_OBJECT_TYPE_PLL4_FREQUENCY,
  REMOTE_DBG_OBJECT_TYPE_DSP_LOGGING_START,
  REMOTE_DBG_OBJECT_TYPE_DSP_LOGGING_STOP,
  REMOTE_DBG_OBJECT_TYPE_BLOB_DATA_GET,
  REMOTE_DBG_OBJECT_TYPE_BLOB_SIZE_GET,
  REMOTE_DBG_OBJECT_TYPE_TRACEX_RECORD_STATE_SET,
  REMOTE_DBG_OBJECT_TYPE_INTERNAL_L2_STATS_GET,
  REMOTE_DBG_OBJECT_TYPE_MAX,
} remote_dbg_object_type_t;

typedef enum {
  REMOTE_DBG_BLOB_UNIQUE_TYPE_TRACEX_BUFFER,
  REMOTE_DBG_BLOB_UNIQUE_TYPE_MAX,
} remote_dbg_blob_unique_type_t;

typedef enum {
  REMOTE_DBG_L2_INTERNAL_STAT_TYPE_SHMEME,
  REMOTE_DBG_L2_INTERNAL_STAT_TYPE_SPI,
  REMOTE_DBG_L2_INTERNAL_STAT_TYPE_NOT_SUPPORTED,
} remote_dbg_l2_internal_stat_type_t;

typedef remote_struct {
  uint8_t request_type;
  uint8_t padding[1];
  uint16_t object_type;
  /* @note: Object type must be last */
  remote_obj_header_t object;
} remote_dbg_object_req_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_object_req_t);

typedef remote_struct {
  uint8_t result;
  /** Padding to 4 byte alignment */
  uint8_t padding[3];
} remote_dbg_rsp_header_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_rsp_header_t);

typedef remote_struct {
  uint32_t address;
  uint8_t value;
  uint8_t padding[3];
} remote_dbg_mem_8_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_mem_8_t);

typedef remote_struct {
  uint32_t address;
  uint16_t value;
  uint8_t padding[2];
} remote_dbg_mem_16_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_mem_16_t);

typedef remote_struct {
  uint32_t address;
  uint32_t value;
} remote_dbg_mem_32_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_mem_32_t);

typedef remote_struct {
  uint32_t address;
  uint32_t size;
  uint32_t value[MEM_MAX_READ_IN_DWORDS];
} remote_dbg_mem_32_dump_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_mem_32_dump_t);

typedef remote_struct {
  uint32_t address;
  uint32_t bitmask;
  uint32_t value;
} remote_dbg_soc_reg_32_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_soc_reg_32_t);

typedef remote_struct {
  uint32_t device_id;
  uint32_t address;
  uint32_t value;
} remote_dbg_dsp_mem_32_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_dsp_mem_32_t);

typedef remote_struct {
  uint32_t device_id;
  uint32_t address;
  uint32_t size;
  uint8_t buffer[RF_MEM_MAX_FRAGMENT_SIZE];
} remote_dbg_dsp_mem_32_range_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_dsp_mem_32_range_t);

/* Remote DBG statistics */
typedef remote_struct {
  remote_atlk_flow_counters_t ll_driver_stat;
  remote_atlk_flow_counters_t rt_stat;
  remote_atlk_flow_counters_t rsvc_stat;
  remote_atlk_flow_counters_t v2x_stat;
  remote_atlk_flow_counters_t wdm_stat;
  remote_atlk_flow_counters_t ddm_stat;
  remote_atlk_flow_counters_t ecc_stat;
} remote_dbg_stat_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_stat_t);

typedef remote_struct {
  uint32_t last_rf_gain;
  uint32_t rx_queue_full_cnt;
  uint32_t htsig_error;
  uint32_t lsig_error;
  uint32_t vhtsiga_error;
  uint32_t vhtsigb_error;
  uint32_t packet_over_packet;
  uint32_t sifs_missed;
} remote_dbg_wlan_stats_extended_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_wlan_stats_extended_t);

/* Remote WLAN device ring info */
typedef remote_struct {
  /* dsp_ring_info_t is packed already */
  dsp_ring_info_t tx_rings[DSP_TX_RINGS_PER_IF];
  dsp_ring_info_t rx_ring;
} remote_dbg_wlan_device_ring_info_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_wlan_device_ring_info_t);

/* Remote DBG WLAN ring info */
typedef remote_struct {
   remote_dbg_wlan_device_ring_info_t device_info[ATLK_INTERFACES_MAX];
} remote_dbg_wlan_ring_info_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_wlan_ring_info_t);

/* Remote DBG WLAN atk42xx_dsp_control */
typedef remote_struct {
  /* dsp_control is packed already */
  dsp_cookie_t dsp_control;
} remote_dbg_wlan_dsp_cookie_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_wlan_dsp_cookie_t);

/* DBG channel busy ratio */
typedef remote_struct {
  uint32_t slots_busy;
  uint32_t slots_total;
  int32_t noise_floor;
} remote_dbg_wlan_cbr_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_wlan_cbr_t);

/* Remote DBG Profiler statistics */
typedef remote_struct {
  uint64_t idle_task_cycles_count;
  uint64_t total_cycles_from_last_read;
} remote_dbg_profiler_statistics_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_profiler_statistics_t);

/* Remote DBG Boot Timer phase */
typedef remote_struct {
  uint32_t start;
  uint32_t end;
} remote_dbg_boot_timer_phase_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_boot_timer_phase_t);

/* Remote DBG Boot Timer measurements */
typedef remote_struct {
  remote_dbg_boot_timer_phase_t phases[REMOTE_DBG_BOOT_TIMER_MAX_PHASES];
  uint32_t total_time_us;
  uint32_t phases_count;
} remote_dbg_boot_timer_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_boot_timer_t);

/* Remote DBG DSP logging parameter */
typedef remote_struct {
  uint8_t log_folder_name[REMOTE_DBG_LOG_FILE_NAME_MAX_SIZE];
  uint32_t trigger_type;
  uint32_t antenna_select;
  int32_t trigger_subframe;
} remote_dbg_dsp_logging_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_dsp_logging_t);

/* Remote DBG blob size get */
typedef remote_struct {
  uint32_t size;
} remote_dbg_blob_size_get_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_blob_size_get_t);

/* Remote DBG blob get */
typedef remote_struct {
  uint8_t     buffer[REMOTE_DBG_BLOB_MAX_CHUNK_LENGTH];
  uint32_t  returned_buffer_size;
} remote_dbg_blob_get_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_blob_get_t);

/* l2 shared memory internal statistics */
typedef remote_struct {
  uint32_t buffer_size;
  uint32_t enqueue_packets;
  uint32_t dequeue_packets;
  uint32_t enqueue_failed;
  uint32_t dequeue_failed;
  uint32_t highest_watermark_level;
  uint32_t current_watermark_level;
  uint32_t current_packets_in_queue;
  uint32_t highest_number_of_packets_in_queue;
  uint32_t max_dequeue_ts_diff_usec;
  uint32_t average_dequeue_ts_diff_usec;
} remote_dbg_l2_shmem_internal_stat_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_l2_shmem_internal_stat_t);

typedef struct {
  /** Total successfully sent bytes - sum of the messages bytes sent by the upper layer */
  uint32_t tx_bytes;
  /** Total successfully sent messages - sum of the messages sent by the upper layer */
  uint32_t tx_messages;
  /** Total successfully sent pages */
  uint32_t tx_pages;
  /** Total errors during sending */
  uint32_t tx_errors;
  /** Total errors due to no space in buffers */
  uint32_t tx_no_space_in_buffer_errors;
  /** Total successfully received bytes - sum of the messages bytes sent to the upper layer */
  uint32_t rx_bytes;
  /** Total successfully received messages - sum of the messages sent to the upper layer */
  uint32_t rx_messages;
  /** Total successfully received pages */
  uint32_t rx_pages;
  /** Total errors during reception (dropped pages + dropped messages) */
  uint32_t rx_errors;
  /** Total dropped pages (with content) due to errors */
  uint32_t rx_pages_dropped;
  /** Total Rx pages dropped due bad CRC */
  uint32_t rx_pages_bad_crc;
  /** Total Rx pages dropped due to overflow */
  uint32_t rx_pages_dropped_overflow;
  /** Total number of messages dropped */
  uint32_t rx_messages_dropped;
  /** Total number of messages dropped due to bad CRC */
  uint32_t rx_messages_bad_crc;
  /** Total number spi recovery */
  uint32_t spi_recovery_counter;
  /** SPI page size */
  uint32_t spi_page_size;
} remote_dbg_l2_spi_internal_stat_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_l2_spi_internal_stat_t);

/* l2 internal statistics */
typedef remote_struct {
  uint32_t l2_type;
  union {
    struct {
      uint16_t process_id[4];
      uint32_t process_shared_mem_address[4];
      remote_dbg_l2_shmem_internal_stat_t device_to_host[4];
      remote_dbg_l2_shmem_internal_stat_t host_to_device[4];
    } shmem;

    struct {
      remote_dbg_l2_spi_internal_stat_t stat;
    } spi;
  };
} remote_dbg_l2_internal_stat_get_t;

REMOTE_CHECK_DATA_SIZE(remote_dbg_l2_internal_stat_get_t);

#endif /* _REMOTE_DBG_PROTOCOL_H */
