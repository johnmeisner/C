#ifndef _DSP_EXTERNAL_TABLES_H_
#define _DSP_EXTERNAL_TABLES_H_
#include "dsp_common_defs.h"


#define TEMPR_DOMAIN_MAX 8
#define FREQ_DOMAIN_MAX 8
/*********************************************************************

       TSSI structure

 *********************************************************************/

#define TSSI_DET2DBM_TABLE_SIZE 8

#define TSSI_DET_TABLE_DEFAULT_INIT                                     \
  {                                                                     \
    8, 11, 22, 39, 65, 109, 173, 240                                    \
  }

#define TSSI_DBM_TABLE_DEFAULT_INIT                                     \
  {                                                                     \
    40, 63, 85, 109, 133, 159, 185, 210                                 \
  }

#define DSP_EXTERNAL_TABLES_DEFAULT_INIT                                \
  {                                                                     \
    .tssi_tempr_cnt = TSSI_DET2DBM_TABLE_SIZE,                          \
    .tssi_freq_cnt = 1,                                                 \
    .tssi_tempr = {0},                                                  \
    .tssi_freq = {0},                                                   \
    .tssi_det = {TSSI_DET_TABLE_DEFAULT_INIT},                          \
    .tssi_dBm = {TSSI_DBM_TABLE_DEFAULT_INIT},                          \
  }

#pragma pack(push, 1)
typedef struct dsp_cal_table {
  dsp_uint8_t tempr_cnt;
  dsp_uint8_t freq_cnt;
  dsp_tempr_t tempr[TEMPR_DOMAIN_MAX];
  dsp_freq_t  freq[FREQ_DOMAIN_MAX];
} dsp_packed dsp_cal_table_t;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct dsp_tssi_table {
  dsp_cal_table_t table_info;
  dsp_tssi_det_t  det[FREQ_DOMAIN_MAX][TEMPR_DOMAIN_MAX][TSSI_DET2DBM_TABLE_SIZE];
  dsp_tssi_dBm_t  dBm[FREQ_DOMAIN_MAX][TEMPR_DOMAIN_MAX][TSSI_DET2DBM_TABLE_SIZE];
} dsp_packed dsp_tssi_table_t;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct dsp_tssi_bias_table {
  dsp_cal_table_t    table_info;
  dsp_tssi_bias_t    bias[FREQ_DOMAIN_MAX][TEMPR_DOMAIN_MAX];
} dsp_packed dsp_tssi_bias_table_t;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct tssi_tables {
  dsp_tssi_table_t       tssi;
} dsp_packed tssi_tables_t;
#pragma pack(pop)


/*********************************************************************

       RSSI structure

 *********************************************************************/

#define RSSI_TABLE_SIZE 8

#define RSSI_TABLE_DEFAULT_INIT                                         \
  {                                                                     \
    0, 0, 0, 0, 0, 0, 0, 0                                              \
  }

#pragma pack(push, 1)
typedef struct dsp_rssi_offset_table {
  dsp_cal_table_t    table_info;
  dsp_rssi_offset_t  offset[FREQ_DOMAIN_MAX][TEMPR_DOMAIN_MAX][RSSI_TABLE_SIZE];
} dsp_packed dsp_rssi_offset_table_t;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct dsp_rssi_tempr_bias_table_t {
  dsp_cal_table_t    table_info;
  dsp_rssi_bias_t    bias[FREQ_DOMAIN_MAX][TEMPR_DOMAIN_MAX];
} dsp_packed dsp_rssi_tempr_bias_table_t;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct rssi_tables {
  dsp_rssi_offset_table_t     rssi_offset;
  dsp_rssi_tempr_bias_table_t bias;
} dsp_packed rssi_tables_t;
#pragma pack(pop)

/*********************************************************************

       OPEN_LOOP structure

 *********************************************************************/
#define OPEN_LOOP_TABLE_SIZE 4

#pragma pack(push, 1)
typedef struct open_loop_table {
  dsp_cal_table_t     table_info;
  dsp_open_loop_dbm_t dBm[/*FREQ_DOMAIN_MAX*/1][/*TEMPR_DOMAIN_MAX*/3][OPEN_LOOP_TABLE_SIZE];
} open_loop_table_t;
#pragma pack(pop)

/*********************************************************************

       COMPENSATOR calibration structure

 *********************************************************************/
 
#pragma pack(push, 1)
typedef struct txrx_gain_table {
  dsp_cal_table_t   table_info;
  dsp_comp_gain_t   rx_gain[FREQ_DOMAIN_MAX][TEMPR_DOMAIN_MAX];
  dsp_comp_gain_t   tx_gain[FREQ_DOMAIN_MAX][TEMPR_DOMAIN_MAX];
} dsp_packed txrx_gain_table_t;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct comp_cal_info
{
  txrx_gain_table_t txrx_gain;
  dsp_tssi_table_t  tssi;
} comp_cal_info_t;
#pragma pack(pop)

#endif /* _DSP_EXTERNAL_TABLES_H_ */
