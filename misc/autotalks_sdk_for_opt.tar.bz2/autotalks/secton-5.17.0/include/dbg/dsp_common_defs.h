#ifndef _DSP_COMMON_DEFS_H_
#define _DSP_COMMON_DEFS_H_
#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <stdint.h>
#include <stddef.h>
#endif /* __KERNEL__ */

/**
   WLAN HW bandwidth
 */
typedef enum {
  /** Initial state */
  WLAN_HW_BW_INIT = 0,
  /** 20MHz */
  WLAN_HW_BW_20MHZ = 1,

  /** 40MHz */
  WLAN_HW_BW_40MHZ = 2,

  /** 80MHz */
  WLAN_HW_BW_80MHZ = 4,

  /** 160MHz */
  WLAN_HW_BW_160MHZ = 8,

  /** 5MHz */
  WLAN_HW_BW_5MHZ = 5,

  /** 10MHz */
  WLAN_HW_BW_10MHZ = 6,

} wlan_hw_bw_t;

/** Helper macros */
#ifndef ATLK_DIV_ROUND_UP
#define ATLK_DIV_ROUND_UP(n, d) (((n) + (d) - 1) / (d))
#endif

#ifndef ROUND_UP
#define ROUND_UP(n, d) (ATLK_DIV_ROUND_UP((n), (d)) * (d))
#endif

#ifndef DSP_POINTER
#ifdef DSP_COOKIE_POINTER_TO_UINT32
#define DSP_POINTER(type, var) uint32_t var
#else
#define DSP_POINTER(type, var) type *var
#endif /* DSP_COOKIE_POINTER_TO_UINT32 */
#endif /* DSP_POINTER */

/** Specifier for Host read/write and DSP read-only fields */
#define dsp_h2d

/** Specifier for DSP read/write and Host read-only fields */
#define dsp_d2h

/** Number of Antenna ports  */
#define DSP_NUM_ANT_PORTS 2U

/** Structure packing specifier */
#if defined(_WIN32) || defined(_WIN64)
#define dsp_packed
#define dsp_align(_size_) __declspec(align(_size_))
#else
#define dsp_packed __attribute__ ((packed))
#define dsp_align(_size_) __attribute__ ((aligned(_size_)))
#endif

/** DSP ring descriptor identification magic */
#define DSP_RING_DESCRIPTOR_MAGIC 0xDE5CDE5CU

/** DSP is running (i.e. has booted OK and attached to host) */
/** DSP has booted OK */
#define DSP_STATUS_F_BOOTED             0x0020U
#define DSP_STATUS_F_RUNNING_IF0        0x0040U
#define DSP_STATUS_F_RUNNING_IF1        0x0080U
#define DSP_STATUS_F_PLL_LOCK_ERROR_CH1 0x0100U
#define DSP_STATUS_F_PLL_LOCK_ERROR_CH2 0x0200U
#define DSP_STATUS_F_RC_CAL_ERROR_CH1   0x0400U
#define DSP_STATUS_F_RC_CAL_ERROR_CH2   0x0800U
#define DSP_STATUS_F_PPS_LOCK           0x1000U
#define DSP_STATUS_F_PPS_SYNC           0x2000U

#define PHY_STATUS_F_DCOC_I_FAIL      0x010000U
#define PHY_STATUS_F_DCOC_Q_FAIL      0x020000U
#define PHY_STATUS_F_NO_RF_FAIL       0x040000U
#define PHY_STATUS_F_RF_PLL_UNLOCKED  0x080000U
#define PHY_STATUS_F_CAL_FAIL         0x100000U
#define PHY_STATUS_F_FW_FAIL          0x200000U
#define PHY_STATUS_F_RXIQ_FAIL        0x400000U

/** Put DSP in low power mode */
#define DSP_CONTROL_F_SLEEP_MODE 0x01U

/** Put DSP in RTL SIMULATION mode */
#define DSP_CONTROL_F_RTL_SIMULATION  0x10U

/** Enable Ranging */
#define DSP_CONTROL_F_RANGING         0x20U


/** Enable TP SW trigger on the following events */
#define DSP_DEBUG_F_SW_TRIG_CRC_ERROR   0x01U

#define DSP_DEBUG_F_SW_TRIG_LSIG_ERROR  0x02U

#define DSP_DEBUG_F_SW_TRIG_HTSIG_ERROR 0x04U

#define DSP_DEBUG_F_SW_TRIG_RX_START    0x08U

#define DSP_DEBUG_F_SW_TRIG_RX_END      0x10U

#define DSP_DEBUG_F_SW_TRIG_TX_START    0x20U

#define DSP_DEBUG_F_SW_TRIG_TX_END      0x40U

#define DSP_DEBUG_F_SW_TRIG_TX_ABORT    0x80U

#define DSP_DEBUG_F_SW_TRIG_PDET        0x100U

#define DSP_DEBUG_F_SW_TRIG_CRC_PASS    0x200U

#define DSP_DEBUG_F_SW_TRIG_CRCB_PASS   0x400U

#define DSP_DEBUG_F_SW_TRIG_ASSERT      0x800U

#define DSP_DEBUG_F_SW_RX_SYMBOL        0x1000U

#define DSP_DEBUG_F_SW_TX_SYMBOL        0x2000U

#define DSP_DEBUG_F_SW_RX_TD_TP         0x4000

#define DSP_DEBUG_F_SW_RX_MSE_TP        0x8000
/* DAC / ADC sample rate values */
#define LMAC_MIB_SAMPLE_RATE_40_MHZ   40U
#define LMAC_MIB_SAMPLE_RATE_80_MHZ   80U
#define LMAC_MIB_SAMPLE_RATE_160_MHZ  160U

#define DSP_COMPENSATOR_DATA_SIZE_MAX 8U

/**
   Start address alignment and size alignment for data elements for which
   we want to have optimal bus access performance.
*/
#define DSP_MEM_ALIGN 16U

typedef uint16_t dsp_freq_t;
typedef int8_t   dsp_tempr_t;
typedef uint8_t  dsp_tssi_det_t;
typedef uint8_t  dsp_tssi_dBm_t;
typedef int8_t   dsp_rssi_offset_t;
typedef int8_t   dsp_tssi_bias_t;
typedef int8_t   dsp_rssi_bias_t;
typedef uint8_t  dsp_comp_gain_t;
typedef int8_t   dsp_open_loop_dbm_t;

/** Following definitions apply only for Host/DSP shared memory, all defined
    as 32 bits due to lack of HW support in narrow transaction (CRII-537) */
typedef unsigned int  dsp_uint8_t;
typedef unsigned int  dsp_uint16_t;
typedef unsigned int  dsp_uint32_t;
typedef          int  dsp_int32_t;
typedef          int  dsp_int16_t;
typedef          int  dsp_int8_t;

/** Host configuration/status flags */

/** Host CPU type (see enum host_cpu_type) */
#define HOST_CONFIG_F_CPU   0x01U

/**
   Craton - A7
   Secton - A7 or M3
*/
typedef enum host_cpu_type {
  HOST_CPU_TYPE_ARM_A7 = 0,
  HOST_CPU_TYPE_ARM_M3 = 1
} host_cpu_type_t;

/** DSP ring information */
#pragma pack(push, 4)
typedef struct dsp_ring_info {
  /** Bus address of first ring descriptor */
  dsp_h2d dsp_uint32_t addr;

  /** Start index (DSP read/write, Host read-only) */
  dsp_d2h dsp_uint32_t start;

  /** End index (Host read/write, DSP read-only) */
  dsp_h2d dsp_uint32_t end;

  /** Size (i.e. total number of descriptors) */
  dsp_h2d dsp_uint32_t size;

} dsp_ring_info_t;
#pragma pack(pop)

/** DSP debug report */
#pragma pack(push, 4)
typedef struct dsp_debug_report {
  /** Module name in which assertion had failed  */
  uint8_t  function[32];

  /** Line number in which assertion had failed  */
  uint32_t line;

} dsp_debug_report_t;
#pragma pack(pop)

/** UART data for Generic Compensator to be sent during packet TX */
#pragma pack(push, 1)
typedef struct generic_compensator_data {
  uint8_t data[DSP_COMPENSATOR_DATA_SIZE_MAX];
  uint8_t len;
  uint8_t reserved;
} dsp_packed generic_compensator_data_t;
#pragma pack(pop)

#endif /* _DSP_COMMON_DEFS_H_ */
