#ifndef _WLAN_DSP_UTILS_H_
#define _WLAN_DSP_UTILS_H_

#ifdef __KERNEL__
#include <linux/types.h>
#include <linux/string.h>
#else
#include <stdio.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#endif /* __KERNEL__ */

#define DSP_BOARD_INFO_MAGIC 0x5D9A6B7C
#define DSP_CALIB_HEAD_MAGIC 0xDB270B3E

typedef unsigned int wlan_dsp_rc_t;

#define WLAN_DSP_RC(code) ((wlan_dsp_rc_t)(code))

#define WLAN_DSP_OK               WLAN_DSP_RC(0)
#define WLAN_DSP_E_OUT_OF_MEMORY  WLAN_DSP_RC(1)
#define WLAN_DSP_W_INV_RSSI       WLAN_DSP_RC(2)
#define WLAN_DSP_E_INVALID_FORMAT WLAN_DSP_RC(3)
#define WLAN_DSP_E_INVALID_ARG    WLAN_DSP_RC(4)

enum {
  PARTITION_COMMON,
  PARTITION_CHANNEL_0,
  PARTITION_CHANNEL_1,
  PARTITION_NUM
};

typedef struct  partition_info {
  uint16_t offset;
  uint16_t size;
} __attribute__((packed)) partition_info_t;

/**
   This function shall be called on DSP attach. It is responsible
   to translate the calibration raw data into DSP format.

   src_aux_mem  A pointer to a buffer that holds the calibration raw data.
   dst_aux_mem  A pointer to DSP auxilary memory.
   src_len      Raw data size in bytes
   dst_len      Auxilary memory size in bytes.

   Return       WLAN DSP return code.
*/
wlan_dsp_rc_t wlan_dsp_load_auxilary_mem(void *src_aux_mem, void *dst_aux_mem,
                                         size_t src_len,    size_t dst_max_len,
                                         int channel_id,    int diversity);

/**
   This function tells exact size in bytes of the calibration data.
   The exact size is required for proper CRC32 check and parsing afterwards
*/
size_t        wlan_dsp_get_calib_data_size(void *src_aux_mem);

/**
   This function is responsible for translation of the compensator
   raw calibration data into DSP format / comp_cal_info_t structure
*/
wlan_dsp_rc_t wlan_dsp_load_comp_calib_data(void *src_aux_mem, void *dst_aux_mem, size_t src_len);

/**
   This function shall be called only after dsp_cookie auxilary pointer is initialized
   (Only after wlan_dsp_load_auxilary_mem is called).

   aux_mem      A pointer to the DSP's auxilary memory.
   diversity    Diversity mode flag

   Return       True (1,2 or 3) if a compensator exist, otherwise False (0).
*/
int wlan_dsp_get_compensator_enable(void *aux_mem, int diversity);

/**
   This function shall be called only after dsp_cookie auxilary pointer is initialized
   (Only after wlan_dsp_load_auxilary_mem is called).

   aux_mem      A pointer to the DSP's auxilary memory.

   Return       Compensator type (see ::compensator_type_t).
*/
uint8_t wlan_dsp_get_compensator_type(void *aux_mem, int channel);

/**
   Reset DSP auxilary memory to default values.

   aux_mem      A pointer to DSP auxilary memory.
   diversity    diversity mode
*/
void wlan_dsp_aux_mem_reset_defaults(void *aux_mem, int diversity);

/**
   This function shall be called only after dsp_cookie auxilary pointer is initialized
   (Only after wlan_dsp_load_auxilary_mem is called).

   aux_mem      A pointer to the DSP's auxilary memory.

   Return       True (1) if RF chip type is PLUTON2, otherwise False (0).
*/
int wlan_dsp_is_pluton2(void *aux_mem);


#define WLAN_DSP_BUILD_FLAGS_C2S     (0x00000001U)
#define WLAN_DSP_BUILD_FLAGS_C2      (0x00000002U)
#define WLAN_DSP_BUILD_FLAGS_C1      (0x00000004U)
#define WLAN_DSP_BUILD_FLAGS_SPECMAN (0x00000008U)
#define WLAN_DSP_BUILD_FLAGS_C3      (0x00000010U)
#define WLAN_DSP_BUILD_FLAGS_CV2X    (0x00000020U)
#define WLAN_DSP_BUILD_FLAGS_DEBUG   (0x00000040U)

/**
   This function returns the size of the calibration info bianry format.

   header       A pointer to the start of the binary (16 Bytes are mandatory).

   Return       True (1) if the magic is correct, otherwise False (0).
                if succeeded, size will hold the result.
*/
wlan_dsp_rc_t
wlan_dsp_get_auxilary_mem_bin_size(void *header, size_t *size);

#define WLAN_DBG_STR_MAX_LEN 64U

typedef enum wlan_dsp_rel_stage {
  WLAN_DSP_REL_STAGE_ALPHA,
  WLAN_DSP_REL_STAGE_BETA,
  WLAN_DSP_REL_STAGE_RC
} wlan_dsp_rel_stage_t;

typedef struct wlan_dsp_version {
  int major;
  int minor;
  int rev;
  wlan_dsp_rel_stage_t rel_stage;
  int rel_num;
  char git_rev_id[8];
  uint32_t build_flags;
  char dbg_str[WLAN_DBG_STR_MAX_LEN];
} wlan_dsp_version_t;

wlan_dsp_rc_t
wlan_dsp_parse_version_str(char *dsp_version_str, wlan_dsp_version_t *version);

int
wlan_dsp_get_pps_source(void *aux_mem);

int
wlan_dsp_get_cca_gpio(void *aux_mem);

#endif /*_WLAN_DSP_UTILS_H_ */
