#ifndef _H2D_COMMON_CMD_H_
#define _H2D_COMMON_CMD_H_

#include "dsp_cmd.h"

enum h2d_cmd_code {
  H2D_CMD_OP_READ_REGISTER,          // 0
  H2D_CMD_OP_WRITE_REGISTER,         // 1
  H2D_CMD_OP_CHANNEL_FREQ_SET,       // 2
  H2D_CMD_OP_RUN_DCOC = 4,           // 4
  H2D_CMD_OP_RUN_TX_IQ_CAL,          // 5
  H2D_CMD_OP_RUN_RX_IQ_CAL,          // 6
  H2D_CMD_OP_RUN_FULL_CAL,           // 7
  H2D_CMD_OP_TEST_TONE,              // 8
  H2D_CMD_OP_RUN_RSSI_CAL,           // 9
  H2D_CMD_OP_TIMER,                  // 10
  H2D_CMD_OP_TSF_SET,                // 11
  H2D_CMD_OP_RUN_TX_GAINS_CAL = 14,  // 14
  H2D_CMD_OP_REQ_COMP_INFO = 21,     // 21
  H2D_CMD_OP_SET_RF_PATH_STATE,      // 22
  H2D_CMD_OP_GET_RF_CHIP_INFO,       // 23
  H2D_CMD_OP_CFG_GENERIC_COMP        // 24

};

enum h2d_regop_device_id {
  CMD_DEVICE_RF = 0U,
  CMD_DEVICE_WLAN = 1U,
  CMD_DEVICE_DSP_CPM = 2U
};

enum cmd_test_tone {
  CMD_TEST_TONE_CW_STOP = 0U,   // 0
  CMD_TEST_TONE_CW_START = 1U,  // 1
  CMD_TEST_OFDM_START = 2U,     // 2
  CMD_TEST_OFDM_STOP = 3U       // 3
};

enum cmd_dfs {
  CMD_DFS_RESET,                // 0
  CMD_DFS_IS_RADAR_DETECTED     // 1
};

typedef struct h2d_op_test_one {
  uint32_t enable; // 1 - start, 0 - stop
  uint32_t fft_indx;
  int32_t tx_power_dBm2;
  uint32_t ant_id;
} h2d_op_test_tone_t;

typedef struct h2d_op_channel_freq_set {
  uint32_t freq;
} h2d_op_channel_freq_set_t;

typedef struct h2d_op_register_access {
  uint32_t device_id; /* see enum h2d_regop_device_id */
  uint32_t address;
  uint32_t value;
} h2d_op_register_access_t;

typedef struct h2d_op_timer {
  uint32_t interval_usec; /* timer interval  */
} h2d_op_timer_t;

typedef struct h2d_op_rssi {
  int8_t rssi_lut[8]; /* see enum cmd_device_id */
} h2d_op_rssi_t;

#define RF_CHIP_INFO_SIZE_BYTES 16

typedef struct h2d_op_get_rf_info {
  uint8_t chip_info[RF_CHIP_INFO_SIZE_BYTES];
} h2d_op_get_rf_info_t;

#endif /* _H2D_COMMON_CMD_H_ */
