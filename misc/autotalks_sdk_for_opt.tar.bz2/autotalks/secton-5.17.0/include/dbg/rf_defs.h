/**
   Copyright (C) 2015 Autotalks Ltd.
*/

#ifndef _RF_DEFS_H
#define _RF_DEFS_H

#include "dsp_common_defs.h"

/**
   RF Chip type
 */
typedef enum {
  RF_CHIP_PLUTON_B0,
  RF_CHIP_RESERVED1,
  RF_CHIP_RESERVED2,
  RF_CHIP_PLUTON2,
  RF_CHIP_NONE
} rf_chip_t;

/**
   RF band
 */
typedef enum {
  RF_BAND_700MHZ,
  RF_BAND_2400MHZ,
  RF_BAND_5GHZ,
  RF_BAND_COUNT
} rf_band_t;

/**
   RF channel bandwidth
 */
typedef enum {
  /** 20MHz */
  RF_CHANNEL_BW_20MHZ = WLAN_HW_BW_20MHZ,

  /** 40MHz */
  RF_CHANNEL_BW_40MHZ = WLAN_HW_BW_40MHZ,

  /** 80MHz */
  RF_CHANNEL_BW_80MHZ = WLAN_HW_BW_80MHZ,

  /** 160MHz */
  RF_CHANNEL_BW_160MHZ = WLAN_HW_BW_160MHZ,

  /** 5MHz */
  RF_CHANNEL_BW_5MHZ = WLAN_HW_BW_5MHZ,

  /** 10MHz */
  RF_CHANNEL_BW_10MHZ = WLAN_HW_BW_10MHZ,

} rf_channel_bw_t;

#define RF_CHANNEL_BW_COUNT          (RF_CHANNEL_BW_160MHZ + 1)
#define RF_STATUS_VALID_TEMPERATURE  0x1U

#endif /* _RF_DEFS_H */
