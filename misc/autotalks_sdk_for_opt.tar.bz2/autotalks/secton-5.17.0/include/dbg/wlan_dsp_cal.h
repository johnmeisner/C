#ifndef _WLAN_DSP_CAL_H_
#define _WLAN_DSP_CAL_H_

#include "dsp_external_tables.h"

#define WLAN_DSP_TX_PA_GAIN_DEFAULT 28

#define GRFI_SIG_MAP_CNT_ 9

typedef enum board_type {
  BOARD_TYPE_EVK = 0U,
  BOARD_TYPE_MM,
  BOARD_TYPE_CIS2,
  BOARD_TYPE_JA,
  BOARD_TYPE_FCS,
  BOARD_TYPE_CIS,
  BOARD_TYPE_CNT
} board_type_t;

typedef enum fem_type {
  FEM_TYPE_NONE = 0U,
  FEM_TYPE_SKYA21043,
  FEM_TYPE_QPF1003Q,
  FEM_TYPE_QPF1004Q,
  FEM_TYPE_QPF1005Q,
  FEM_TYPE_CNT
} fem_type_t;

typedef enum switch_type {
  SWITCH_TYPE_NONE = 0U,
  SWITCH_TYPE_SKYA21070,
  SWITCH_TYPE_2XSKYA21070,
  SWITCH_TYPE_CNT
} switch_type_t;

typedef enum clock_source {
  CLOCK_SOURCE_DIGCLK = 0U,
  CLOCK_SOURCE_XON,
  CLOCK_SOURCE_CNT
} clock_source_t;

typedef enum rf_tempr_source {
  RF_TEMPR_SOURCE_SAR_ADC0 = 0U,
  RF_TEMPR_SOURCE_SAR_ADC1,
  RF_TEMPR_SOURCE_CNT
} rf_tempr_source_t;

typedef enum compensator_type {
  COMPENSATOR_NONE = 0U,
  COMPENSATOR_ATLK,
  COMPENSATOR_GENERIC,
  COMPENSATOR_CNT
} compensator_type_t;

#pragma pack(push, 1)
typedef struct dsp_cal {
  tssi_tables_t     tssi_tables;
  open_loop_table_t open_loop_table;
  uint8_t           reserved[20];
  rssi_tables_t     rssi_tables;
} dsp_packed dsp_cal_t;
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct dsp_board_info {
  uint32_t       board_type;
  uint32_t       rf_type;
  int32_t        tempr_slope;
  int16_t        tempr_offset;
  uint16_t       fem_type;
  uint16_t       switch_type;
  int16_t        tx_pa_gain;
  int16_t        external_rx_gain;
  uint16_t       reserved16;
  uint32_t       reserved32[3];
  dsp_cal_t      cal_info;
  uint8_t        compensator_enable;
  uint8_t        compensator_cable_loss;
  uint8_t        rf_channels_swap;
  uint8_t        rf_sig_map[GRFI_SIG_MAP_CNT_];
  uint8_t        rf_sig_map_2g4[GRFI_SIG_MAP_CNT_];
  uint8_t        dsp_version[3];
  uint8_t        pps_source;
  uint8_t        cca_gpio;
  uint8_t        clock_source;
  uint8_t        rf_tempr_source;
  uint8_t        reserved8[16];        //NOTE: the size of this struct must be multiple of 4 bytes
} dsp_packed dsp_board_info_t;
#pragma pack(pop)

/* STATIC_ASSERT for dsp_board_info_t size is multiple of 4 bytes */
enum { dsp_board_info_size_assert = 1 / ((sizeof(dsp_board_info_t) & 3) == 0) };

#endif /*_WLAN_DSP_CAL_H_*/
