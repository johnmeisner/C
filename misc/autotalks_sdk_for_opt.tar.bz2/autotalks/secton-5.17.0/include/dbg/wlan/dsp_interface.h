#ifndef _DSP_INTERFACE_H
#define _DSP_INTERFACE_H

#include "dsp_common_defs.h"
#include "dsp_defs.h"
#include "h2d_cmd.h"
#include "rf_defs.h"
#include "rf_cookie.h"

/**
   DSP Cookie address offset
*/
#define WLAN_DSP_COOKIE_OFFSET_CUT2 0x3F900U
#define WLAN_DSP_COOKIE_OFFSET_CUT3 0xCF900U

/**
   DSP Cache code address offset
*/
#define WLAN_DSP_CACHE_CODE_OFFSET_CUT2 (WLAN_DSP_COOKIE_OFFSET_CUT2 + \
                                         offsetof(dsp_cookie_t, magic))
#define WLAN_DSP_CACHE_CODE_OFFSET_CUT3 (WLAN_DSP_COOKIE_OFFSET_CUT3 + \
                                         offsetof(dsp_cookie_t, magic))

#pragma pack(push, 1)
/** Rate information */
typedef struct dsp_rate {
  /** Rate flags (see DSP_RATE_F_* definitions) */
  uint16_t flags;

  /** Rate format (see wifi_format_t) */
  uint8_t format;

  /** Modulation and Coding Scheme (MCS) index */
  uint8_t mcs;

  /** Number of tries in this rate before going to the next rate
   *  (0 for end of rate list) */
  uint8_t num_tries;

  /** Transmit bandwidth (see wifi_bw_t) */
  uint8_t bw;

  uint8_t __pad[2];

} dsp_packed dsp_rate_t;
#pragma pack(pop)

/** A-MPDU configuration */
#pragma pack(push, 1)
typedef struct dsp_ampdu_config {
  /** Number of null delimiters to append before this MPDU in the A-MPDU */
  uint32_t ampdu_ndelim;

  /** Total A-MPDU length in bytes: non-zero only for first MPDU of A-MPDU */
  uint32_t ampdu_length;

  /**
     More MPDUs for this AMPDU.
     Zero for last MPDU of A-MPDU, non-zero otherwise.
     This field together with ampdu_length signal if this MPDU is the first,
     middle or last MPDU of the A-MPDU.
  */
  uint8_t ampdu_more;

  /** Number of MPDUs in the A-MPDU */
  uint8_t n_mpdus;

  uint8_t __pad[2];
} dsp_packed dsp_ampdu_config_t;
#pragma pack(pop)

/** DSP transmission completion information */
#pragma pack(push, 1)
typedef struct dsp_tx_info {
  /** Value of TSF when packet was transmitted */
  uint32_t ts_tstamp;

  /**
     64-bit block ack bitmap (for A-MPDU transmit completion,
     only valid for first MPDU of A-MPDU).
  */
  uint32_t ba_bitmap[2];

  /** Transmission status flags (see DSP_TX_COMP_F_* definitions) */
  uint16_t ts_flags;

  /** Transmission status (see DSP_TX_COMP_STATUS_* definitions */
  uint16_t ts_status;

  /**
     Block ack start sequence (for A-MPDU transmit completion,
     only valid for first MPDU of A-MPDU).
  */
  uint16_t ba_start_seq_num;

  /**
     Final rate that was tried from ::dsp_ring_tx_descriptor_t::rates,
     value in [0, 1, ..., DSP_NUM_RATES-1].
  */
  uint8_t ts_rateindex;

  /** Ack Received Signal Strength Indication (RSSI) */
  int8_t ts_rssi;

  /** Short retry count (i.e. data frate retries) for final attempted rate */
  uint8_t ts_shortretry;

  /** Long retry count (i.e. RTS/CTS retries) for final attempted rate */
  uint8_t ts_longretry;

  union {
  /** ADC reported TSSI - mainly used for TSSI calibration */
  uint8_t tssi[2];

  // dpd real value
  uint16_t dpd_val;

  }tssi_dpd;

  /**
     A pointer to a memory buffer in which DSP can put ranging related
     info (e.g IQ samples) of the received response frame (ACK).
  */
  dsp_h2d uint32_t resp_ranging_info_ptr;

} dsp_packed dsp_tx_info_t;
#pragma pack(pop)

/* STATIC_ASSERT for generic_compensator_data_t size to do not overlap with dpd_val field in dsp_tx_info_t */
enum { generic_compensator_data_size_assert = 1 / (DSP_NUM_DEVS*sizeof(generic_compensator_data_t) <= offsetof(dsp_tx_info_t, tssi_dpd)) };

/** DSP ring transmit descriptor */
#pragma pack(push, 1)
typedef struct dsp_ring_tx_descriptor {
  /** Bus address of data buffer (must be aligned to DSP_MEM_ALIGN) */
  uint32_t buf_bus;

  union{
  /** Length in bytes */
  uint32_t len;

  uint16_t tssi16[2];
  }tssi_len;

  /** Transmission flags (see DSP_TX_F_* definitions) */
  uint32_t flags;

  /**
     Specifies the rates that are going to be tried for this transmission.

     @note This is intented for a future implementation of multi-rate retries,
     currently only the first rate of the series is tried.
  */
  dsp_rate_t rates[DSP_NUM_RATES];

  /** A-MPDU configuration (only valid if flags & DSP_TX_F_IS_AMPDU) */
  dsp_ampdu_config_t ampdu;

  union {
  /**
     UART data for Generic Compensator to be sent during packet TX.
     Provided by SW (per antenna if in diversity mode).
  */
  dsp_h2d generic_compensator_data_t comp_data[DSP_NUM_DEVS];

  /**
     TX completion information.
     Filled by LMAC after completion of the transmission.
  */
  dsp_d2h dsp_tx_info_t info;
  };

  /** TX power control information */
  int8_t txpower_ctrl[DSP_NUM_DEVS];

  /**
     Format (see wifi_format_t) to use for RTS/CTS if enabled in rate flags
     (see DSP_RATE_F_RTS_CTS/DSP_RATE_F_CTS_TO_SELF).
  */
  uint8_t rtscts_format;

  /**
     Modulation and Coding Scheme (MCS) to use for RTS/CTS if enabled in rate
     flags (see DSP_RATE_F_RTS_CTS/DSP_RATE_F_CTS_TO_SELF).
  */
  uint8_t rtscts_mcs;

} dsp_packed dsp_ring_tx_descriptor_t;
#pragma pack(pop)

/** DSP PHY receive information */
#pragma pack(push, 1)
typedef struct dsp_phy_rx_info {
  /** RF gain */
  uint8_t rf_gain;

  /** Receive Signal Strength Indication (RSSI) */
  uint8_t rssi;

  uint8_t __pad[2];

} dsp_packed dsp_phy_rx_info_t;
#pragma pack(pop)

/** DSP receive information */
#pragma pack(push, 1)
typedef struct dsp_rx_info {
  /** Length in bytes */
  uint32_t len;

  /** Receive flags (see DSP_RX_F_* definitions) */
  uint32_t flags;

  /** Receive status (see DSP_RX_STATUS_* definitions) */
  uint32_t status;

  /** Receive timestamp LSB (TSF) */
  uint32_t tstamp_lsb;

  /** EVM Linear */
  uint32_t evm_numerator;

  uint32_t evm_denominator;

  /** Receive rate information */
  dsp_rate_t rate;

  /** phy RX info per antena (in diversity mode both antenas are relevant) */
  dsp_phy_rx_info_t phy_info[DSP_NUM_DEVS];

  /**
     A pointer to a memory buffer in which DSP can put ranging related
     info, (e.g IQ samples).
  */
  dsp_h2d uint32_t ranging_info_ptr;

  /** Receive timestamp MSB (TSF) */
  uint32_t tstamp_msb;

  /** Doppler shift, S16Q16 format */
  int32_t doppler_shift;

} dsp_packed dsp_rx_info_t;
#pragma pack(pop)

/** DSP ring receive descriptor */
typedef struct dsp_ring_rx_descriptor {
  /** Host bus address for received data */
  uintptr_t buf_bus;

  /** Reception status information */
  dsp_rx_info_t info;

} dsp_packed dsp_ring_rx_descriptor_t;

/** DSP ring descriptor identification magic */
#define DSP_RING_DESCRIPTOR_MAGIC 0xDE5CDE5CU

/** DSP ring descriptor size (must be a multiple of DSP_MEM_ALIGN) */
#define DSP_RING_DESCRIPTOR_SIZE 96U

/**
   DSP ring descriptor.

   @note Start address and size must be aligned to DSP_MEM_ALIGN.
*/
#pragma pack(push, 1)
typedef struct dsp_ring_descriptor {
  /** Descriptor identification magic (see DSP_RING_DESCRIPTOR_MAGIC) */
  dsp_h2d uint32_t magic;

  /** Descriptor index */
  dsp_h2d uint32_t index;

  /** Transmit/Receive descriptor */
  union {
    /** Transmit descriptor */
    dsp_ring_tx_descriptor_t tx;

    /** Receive descriptor */
    dsp_ring_rx_descriptor_t rx;

    /**
       Padding bytes to ensure the descriptor size
       is DSP_RING_DESCRIPTOR_SIZE.
    */
    uint8_t __padding[DSP_RING_DESCRIPTOR_SIZE -
                      sizeof(uint32_t) /* magic */ -
                      sizeof(uint32_t) /* index */];
  } ds;

} dsp_packed dsp_ring_descriptor_t;
#pragma pack(pop)

/** EDCA Function configuration */
#pragma pack(push, 4)
typedef struct lmac_edcaf_config {
  /** Access category ID (see wifi_ac_t) */
  dsp_uint32_t ac;

  /** Arbitration interframe space number [0..255] */
  dsp_uint32_t aifsn;

  /** Minimum contention window [a value of the form 2^n-1 in the range 1..32767] */
  dsp_uint32_t cwmin;

  /** Maximum contention window [a value of the form 2^n-1 in the range 1..32767] */
  dsp_uint32_t cwmax;

  /** Maximum burst time (in units of 32usecs), 0 meaning disabled */
  dsp_uint32_t txop_limit;

} lmac_edcaf_config_t;
#pragma pack(pop)

/** DSP channel offset */
typedef enum dsp_channel_offset {
  /** 0MHz */
  DSP_CHANNEL_OFFSET_0     = 0,

  /** +10MHz */
  DSP_CHANNEL_OFFSET_20U   = 1,

  /** +30MHz */
  DSP_CHANNEL_OFFSET_20UU  = 2,

  /** -10MHz */
  DSP_CHANNEL_OFFSET_20L   = 3,

  /** -30MHz */
  DSP_CHANNEL_OFFSET_20LL  = 4,

  /** +20MHz */
  DSP_CHANNEL_OFFSET_40U   = 5,

  /** -20MHz */
  DSP_CHANNEL_OFFSET_40L   = 6

} dsp_channel_offset_t;

/** DSP (LMAC/PHY) Management Information Base (MIB) */
#pragma pack(push, 4)
typedef struct dsp_mib {
  /** PHY Mode (see wifi_phymode_t) */
  dsp_uint32_t phymode;

  /** Bandwidth Index (see wifi_bw_t) */
  dsp_uint32_t bw;

  /** EDCA configuration for Beacons and ACs */
  lmac_edcaf_config_t edca[DSP_TX_RINGS_PER_IF];

  /** Enables real CRC32 calculation */
  dsp_uint32_t crc_enable;

  /** aSIFSTime in micro-seconds */
  dsp_uint32_t sifs;

  /** PIFS time */
  dsp_uint32_t pifs;

  /** aSlotTime in micro-seconds */
  dsp_uint32_t slot_time;

  /** ACKTxTime (see IEEE Std. 802.11-2012 section 9.3.7) */
  dsp_uint32_t ack_tx_time;

  /** ACK timeout in micro-seconds */
  dsp_uint32_t ack_timeout;

  /** CTS timeout in micro-seconds */
  dsp_uint32_t cts_timeout;

  /** 48-bit MAC address */
  dsp_macaddr_t macaddr;

  /** 48-bit MAC address mask for RX control response frames */
  dsp_macaddr_t macaddr_mask;

  /** PHY Parameters */

  /** Normal (800ns) or Half (400ns) Guard Interval */
  dsp_uint8_t use_half_gi;

  /** Non zero for dynamic bw support */
  dsp_uint8_t use_dyn_bw;

  /** Num TX chains available */
  dsp_uint8_t n_tx;

  /** Num RX chains available */
  dsp_uint8_t n_rx;

  /** CBR threshold in "RSSI" like values : (dBm + 110)*2*/
  dsp_int8_t cbr_threshold;

  /**
     Cyclic Shift Delay (CSD) offset for 802.11p mode.
     For 802.11n/ac is defined by standard.
  */
  dsp_uint8_t csd_11p;

  /** Baseband DAC sample rate in Msps (MHz) */
  dsp_uint8_t sample_dac_mhz;

  /** Baseband ADC sample rate in Msps (MHz) */
  dsp_uint8_t sample_adc_mhz;

  /** Channel information */
  dsp_uint32_t channel_freq_mhz;   /* Channel center frequency in MHz */
  dsp_uint32_t pri20_indx;         /* See dsp_channel_offset_t
                                  pri20 index 0,20U,20UU,20L,20LL */

  dsp_int32_t tx_min_power_dBm8;

  dsp_int32_t tx_max_power_dBm8;

  /** RF type (see rf_chip_t) */
  dsp_uint8_t rf_type;

  /** RF Band (see rf_band_t) */
  dsp_uint8_t rf_band;

  /** GRFI memory */
  dsp_uint32_t grfi_memory;

} dsp_mib_t;
#pragma pack(pop)

/** LMAC counters  */
typedef struct dsp_lmac_counters {
  dsp_d2h dsp_uint32_t crc_error;

  dsp_d2h dsp_uint32_t sifs_missed;

  dsp_d2h dsp_uint32_t tx_total;

  dsp_d2h dsp_uint32_t tx_ampdu_total;

  dsp_d2h dsp_uint32_t rx_total;

} dsp_lmac_counters_t;

/**
   will be added to cookie on DSP 11.5.X
 */
typedef struct dsp_lmac_counters2 {
  dsp_d2h dsp_uint32_t success_rts;

  dsp_d2h dsp_uint32_t missed_ack;

  dsp_d2h dsp_uint32_t missed_cts;

  dsp_d2h dsp_uint32_t missed_back;

  dsp_d2h dsp_uint32_t resereved[4];

} dsp_lmac_counters2_t;

/**
 * DSP lmac statistics
 */
typedef struct dsp_lmac_total_counters {
  dsp_d2h dsp_uint32_t crc_error;

  dsp_d2h dsp_uint32_t rx_total;

  dsp_d2h dsp_uint32_t tx_total;

  dsp_d2h dsp_uint32_t tx_ampdu_total;

  dsp_d2h dsp_uint32_t missed_back;

  dsp_d2h dsp_uint32_t missed_ack;

  dsp_d2h dsp_uint32_t success_rts;

  dsp_d2h dsp_uint32_t missed_cts;

  dsp_d2h dsp_uint32_t missed_sifs;

} dsp_lmac_total_counters_t;

typedef struct dsp_lmac_mcs_counters {
  dsp_d2h dsp_uint32_t crc_error;

  dsp_d2h dsp_uint32_t rx_total;

} dsp_lmac_mcs_counters_t;

typedef struct dsp_lmac_statistics {
  dsp_lmac_total_counters_t counters;

  dsp_lmac_mcs_counters_t mcs_counters[LMAC_MCS_NUM];

} dsp_lmac_statistics_t;
/**
   DSP Counters
 */
typedef struct dsp_counters {
  dsp_d2h dsp_uint32_t pps;

  dsp_d2h dsp_uint32_t resereved[4];

} dsp_counters_t;


/** PHY counters  */
typedef struct dsp_phy_counters {
  dsp_d2h dsp_uint32_t lsig_error;

  dsp_d2h dsp_uint32_t htsig_error;

  dsp_d2h dsp_uint32_t vhtsiga_error;

  dsp_d2h dsp_uint32_t vhtsigb_error;

  dsp_d2h dsp_uint32_t packet_over_packet;

} dsp_phy_counters_t;

/** PHY flags */

/** DSP will operate in loopback mode in PHY level (i.e A frame transmitted
    through Channel #1 will be received on Channel #2 and vice versa) */
#define PHY_F_LOOPBACK_SELF           0x0001U
#define PHY_F_LOOPBACK_CROSS          0x0002U
#define PHY_F_DFE_ENABLE              0x0004U
#define PHY_F_EXTERNAL_ABORT_ENABLE   0x0008U
#define PHY_F_TSSI_LOOP_DIS           0x0010U
#define PHY_F_T109_RSU                0x0080U /** Put DSP in T109 mode (RSU) */
#define PHY_F_T109_OBU                0x0100U /** Put DSP in T109 mode (OBU) */
#define PHY_F_1609                    0x0200U /** Put DSP in T1609 mode */
#define PHY_F_DFS                     0x0400U

typedef struct phy_cookie {
  /** DSP flags (see PHY_F_* definitions) */
  dsp_h2d dsp_uint32_t phy_flags;

  /** PHY counters */
  dsp_d2h dsp_phy_counters_t counters;

  /** Control frames TX power in 0.5dBm */
  dsp_uint32_t control_tx_power_dBm5;

  /** CCA GPIO */
  uint8_t      cca_gpio;

  /** Reserved for future use */
  uint8_t      phy_reserved2[3];
  dsp_uint32_t phy_reserved1[12];

  /** General purpose (host) memory for DSP usage. the internal structure is
      defined in dsp_external_tables_t  */
  dsp_h2d dsp_uint32_t auxilary_memory;

  /** General purpose external memory size in bytes */
  dsp_h2d dsp_uint32_t auxilary_memory_size;

} phy_cookie_t;


/** LMAC shared memory descriptor */
#pragma pack(push, 4)
typedef struct lmac_cookie {
  /** True if UMAC is currently attached */
  dsp_h2d dsp_uint32_t umac_attached;

  /** TX rings */
  dsp_ring_info_t tx_rings[DSP_TX_RINGS_PER_IF];

  /** RX ring */
  dsp_ring_info_t rx_ring;

  /** MIB for this lmac instance */
  dsp_mib_t mib;

  /** LMAC counters  */
  dsp_lmac_counters_t counters;

} lmac_cookie_t;
#pragma pack(pop)


/** Shared memory identification magic */
#define DSP_COOKIE_MAGIC 0xC0051E01U

/** DSP flags */

/** DSP firmware can handle userio */
#define DSP_STATUS_HAS_USERIO  0x01U

/** DSP firmware is for Craton2 CUT2  */
#define DSP_STATUS_CUT2        0x02U

/** DSP firmware has PHY TX support */
#define DSP_STATUS_HAS_PHY_TX  0x04U

/** DSP firmware has PHY RX support */
#define DSP_STATUS_HAS_PHY_RX  0x08U

/** DSP firmware has LMAC support */
#define DSP_STATUS_HAS_LMAC    0x10U

/** Put DSP in low power mode */
#define DSP_CONTROL_F_SLEEP_MODE      0x01U

/** Put DSP in RTL SIMULATION mode */
#define DSP_CONTROL_F_RTL_SIMULATION  0x10U

/** Enable Ranging */
#define DSP_CONTROL_F_RANGING         0x20U

/** DSP recovery boot flag */
#define DSP_CONTROL_F_RECOVERY_BOOT   0x4000U

/** Enable TP SW trigger on the following events */
#define DSP_DEBUG_F_SW_TRIG_CRC_ERROR   0x01U

#define DSP_DEBUG_F_SW_TRIG_LSIG_ERROR  0x02U

#define DSP_DEBUG_F_SW_TRIG_HTSIG_ERROR 0x04U

#define DSP_DEBUG_F_SW_TRIG_RX_START    0x08U

#define DSP_DEBUG_F_SW_TRIG_RX_END      0x10U

#define DSP_DEBUG_F_SW_TRIG_TX_START    0x20U

#define DSP_DEBUG_F_SW_TRIG_TX_END      0x40U

#define DSP_DEBUG_F_SW_TRIG_TX_ABORT    0x80U

#define DSP_DEBUG_F_SW_TRIG_PDET        0x100U

#define DSP_DEBUG_F_SW_TRIG_CRC_PASS    0x200U

#define DSP_DEBUG_F_SW_TRIG_CRCB_PASS   0x400U

#define DSP_DEBUG_F_SW_TRIG_ASSERT      0x800U

#define DSP_DEBUG_F_SW_RX_SYMBOL        0x1000U

#define DSP_DEBUG_F_SW_TX_SYMBOL        0x2000U

/** Host configuration/status flags */

/** Deliver Control frames to UMAC */
#define LMAC_CONTROL_F_RX_PASS_CTRL        0x00000001U

/** Deliver Frames with bad CRC to UMAC */
#define LMAC_CONTROL_F_RX_PASS_CRC_FAILED  0x00000002U

/** Deliver unicast frames that are not addresses to me to UMAC */
#define LMAC_CONTROL_F_RX_PASS_NOT_FOR_ME  0x00000004U

/** Do not transmit control response frames (ACK/BACK/CTS) */
#define LMAC_CONTROL_F_PASSIVE             0x00000008U

/** Deliver PS-Pollc frames to UMAC */
#define LMAC_CONTROL_F_RX_PASS_PSPOLL      0x00000010U

typedef enum slot_index_1609_4 {
    SLOT_INDEX_0 = 0,
    SLOT_INDEX_1,
    SLOT_INDEX_NUM
} slot_index_1609_4_t;

#pragma pack(push, 4)
/** 1609.4 Switching capabilities MIB table */
typedef struct wlan_1609_4_MIB {
  uint32_t ts_duration[SLOT_INDEX_NUM];
  uint32_t sync_tolerance;
  uint32_t max_ch_switch_time;
} wlan_1609_4_MIB_t;

typedef struct wlan_1609_4_counters {
  dsp_d2h dsp_uint32_t tx_total[SLOT_INDEX_NUM];

  dsp_d2h dsp_uint32_t rx_total[SLOT_INDEX_NUM];

  dsp_d2h dsp_uint32_t crc_error[SLOT_INDEX_NUM];

  dsp_d2h dsp_uint32_t rx_aborted[SLOT_INDEX_NUM];
} wlan_1609_4_counters_t;

/** Host/DSP shared memory descriptor (resides in DSP TCM) */
typedef struct dsp_cookie {

  /** DSP version string */
  uint8_t dsp_version_str[64];

  /** LMAC control flags */
  dsp_uint32_t lmac_control_flags[DSP_NUM_DEVS];

  /** GPS PPS source, 0-7 GPIOs 0-7 or 8-9 ETH0/1 */
  uint8_t gps_pps_source;

  /** Reserved */
  uint8_t reserved_1[3];

  dsp_cmd_if_t d2h_cmd_if;

  wlan_1609_4_MIB_t wlan_1609_4_MIB[DSP_NUM_DEVS];

  DSP_POINTER(wlan_1609_4_counters_t, wlan_1609_4_counters[DSP_NUM_DEVS]);

  DSP_POINTER(dsp_lmac_statistics_t, lmac_statistics[DSP_NUM_DEVS]);

  uint32_t dsp_health_check_counter[DSP_NUM_DEVS];

  uint32_t cookie_id;

  uint32_t common_id;

  /** Reserved */
  dsp_uint32_t reserved[8];

  dsp_d2h dsp_uint32_t rx_buffers_size[DSP_NUM_DEVS];

  /** Shared memory identification magic (see DSP_COOKIE_MAGIC) */
  dsp_d2h dsp_uint32_t magic;

  /** DSP version - [7:0]   DSP SW Rev
                    [15:8]  DSP SW Minor
                    [23:16] DSP SW Major
                    [31:24] HW version
  */
  dsp_d2h dsp_uint32_t dsp_version;

  /** DSP status flags (see DSP_F_* definitions) */
  dsp_d2h dsp_uint32_t dsp_status_flags;

  /** DSP control flags (see DSP_CONTROL_F_* definitions) */
  dsp_h2d dsp_uint32_t dsp_control_flags;

  /** Host configuraion/status flags (see HOST_CONFIG_F_* definitions) */
  dsp_h2d dsp_uint32_t host_config_flags;

    /** DSP debug flags (see DSP_DEBUG_F_* definitions) */
  dsp_h2d dsp_uint32_t dsp_debug_flags[DSP_NUM_DEVS];

  /** LMAC shared memory */
  lmac_cookie_t lmac_cookie[DSP_NUM_DEVS];

  /** PHY shared memory */
  phy_cookie_t phy_cookie[DSP_NUM_DEVS];

  /** Host to DSP command interface */
  dsp_cmd_if_t h2d_cmd_if[DSP_NUM_DEVS];

  /** DSP debug report */
  dsp_debug_report_t debug_report;

  /** RF shared memory */
  rf_cookie_t rf_cookie[DSP_NUM_DEVS];

  /** DSP version control rev ID string */
  char dsp_rev_id[8];

  /**
     additional lmac counters - to be moved to lmac_cookie on DSP 11.5.X
   */
  dsp_lmac_counters2_t lmac_counters2[DSP_NUM_DEVS];

  /**
     DSP Counters.
   */
  dsp_counters_t dsp_counters;

}  dsp_cookie_t;
#pragma pack(pop)

#endif /* __DSP_INTERFACE_H */
