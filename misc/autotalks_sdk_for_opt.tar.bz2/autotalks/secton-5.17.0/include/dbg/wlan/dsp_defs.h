#ifndef _DSP_TYPES_H
#define _DSP_TYPES_H

#include <dsp_common_defs.h>

#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <stdint.h>
#include <stddef.h>
#endif /* __KERNEL__ */

/** Helper macros */
#ifndef ATLK_DIV_ROUND_UP
#define ATLK_DIV_ROUND_UP(n, d) (((n) + (d) - 1) / (d))
#endif

#ifndef ROUND_UP
#define ROUND_UP(n, d) (ATLK_DIV_ROUND_UP((n), (d)) * (d))
#endif

/** Number of LMAC instances */
#define DSP_NUM_DEVS 2U

/** Number of 1609.4 alternating channels */
#define DSP_ALTERNATING_CHANNELS_NUM 2U


/** Number of TX rings */
#define DSP_TX_RINGS_PER_CHANNEL WIFI_NUM_EDCAF

/** Total TX rings per interface */
#define DSP_TX_RINGS_PER_IF (DSP_ALTERNATING_CHANNELS_NUM * (uint8_t)DSP_TX_RINGS_PER_CHANNEL)
#define DSP_RX_RINGS_PER_IF 1U

/** LMAC Scoreboard table maximum size */
#define LMAC_SCOREBOARD_TABLE_MAX_SIZE 16U

/** MAC address size */
#define DSP_MAC_ADDR_SIZE 6U

/** Number of rates to be tried for multi-rate retry functionality */
#define DSP_NUM_RATES 4U

/**
    More MPDUs are expected as part of this A-MPDU.
    Relevant only if IS_AMPDU bit is set.
*/
#define DSP_RX_F_AMPDU_MORE   0x00000008U

/** This reception is part of A-MPDU */
#define DSP_RX_F_IS_AMPDU     0x00000010U

/** This reception is a control frame */
#define DSP_RX_F_IS_CTL       0x00000040U

/** This reception is in 1609.4 slot 1, otherwise slot 0 or not relevant */
#define DSP_RX_F_1609_SLOT_1  0x00000080U

/** Receive completion status */

/** Reception has a CRC error */
#define DSP_RX_STATUS_ERR_CRC 0x00000001U

/** DSP transmission control flags */

/** Frame will be transmitted with noack QoS policy */
#define DSP_TX_F_NOACK        0x00000001U

/** Frame has QoS header */
#define DSP_TX_F_ISQOS        0x00000002U

/** Frame is AMPDU aggregate */
#define DSP_TX_F_IS_AMPDU     0x00000010U

/** Frame is control frame */
#define DSP_TX_F_IS_CTL       0x00000040U

/** Do not generate IRQ for this frame's completion */
#define DSP_TX_F_NOIRQ        0x00000080U

/** Frame is the first 802.11 fragment */
#define DSP_TX_F_IS_FIRSTFRAG 0x00000100U

/** Frame is the last 802.11 fragment */
#define DSP_TX_F_IS_LASTFRAG  0x00000200U

/** DSP transmission completion flags */

/**
   Frame was acknowledged with block-ack (ba_bitmap, ba_start_seq_num are valid,
   see dsp_tx_info_t).
*/
#define DSP_TX_COMP_F_BLOCK_ACK 0x01U

/**
    Frame transmission aborted (e.g. due to 1609.4/other channel access
    limitations)
*/
#define DSP_TX_COMP_F_ABORTED   0x80U

/** DSP transmission completion status */

/** Retries exhausted for frame transmission */
#define DSP_TX_COMP_STATUS_ERR_XRETRY 0x01U


typedef unsigned char dsp_macaddr_t[ROUND_UP(DSP_MAC_ADDR_SIZE, 4U)];

/** Rate-related flags */

/** Send with RTS/CTS */
#define DSP_RATE_B_RTS_CTS     0U
#define DSP_RATE_F_RTS_CTS     (1U << DSP_RATE_B_RTS_CTS)

/** Send with CTS-to-self */
#define DSP_RATE_B_CTS_TO_SELF 1U
#define DSP_RATE_F_CTS_TO_SELF (1U << DSP_RATE_B_CTS_TO_SELF)

/** Use short guard interval (same as short preamble, mutually exclusive) */
#define DSP_RATE_B_SHORT_GI    2U
#define DSP_RATE_F_SHORT_GI    (1U << DSP_RATE_B_SHORT_GI)

/** Use short preamble (same as short guard interval, mutually exclusive) */
#define DSP_RATE_B_SHORT_PRE   3U
#define DSP_RATE_F_SHORT_PRE   (1U << DSP_RATE_B_SHORT_PRE)

/** Send with Space-Time Block Coding (STBC) */
#define DSP_RATE_B_STBC        4U
#define DSP_RATE_F_STBC        (1U << DSP_RATE_B_STBC)

/** Send with RTS/CTS */
#define DSP_RATE_B_RTS_DYNAMIC_BW  5U
#define DSP_RATE_F_RTS_DYNAMIC_BW  (1U << DSP_RATE_B_RTS_DYNAMIC_BW)

/**
   WIFI bandwidth
 */
typedef enum {
  /** Initial state */
  WIFI_BW_INIT = WLAN_HW_BW_INIT,
  /** 20MHz */
  WIFI_BW_20MHZ = WLAN_HW_BW_20MHZ,

  /** 40MHz */
  WIFI_BW_40MHZ = WLAN_HW_BW_40MHZ,

  /** 80MHz */
  WIFI_BW_80MHZ = WLAN_HW_BW_80MHZ,

  /** 160MHz */
  WIFI_BW_160MHZ = WLAN_HW_BW_160MHZ,

  /** 5MHz */
  WIFI_BW_5MHZ = WLAN_HW_BW_5MHZ,

  /** 10MHz */
  WIFI_BW_10MHZ = WLAN_HW_BW_10MHZ,

} wifi_bw_t;

/** WLAN PHY mode */
typedef enum wifi_phymode {
  /** 11b only */
  WIFI_PHYMODE_11B  = 0,

  /** 11b/g/n mixed (OFDM and DSSS/ERP present) */
  WIFI_PHYMODE_11BGN  = 1,

  /** Legacy only */
  WIFI_PHYMODE_11AG  = 2,

  /** 11a/g/n OFDM only */
  WIFI_PHYMODE_11AGN = 3,

  /** Up to 11ac (11a/g/n/ac) */
  WIFI_PHYMODE_11AC = 4,

  /** 11p only */
  WIFI_PHYMODE_11P  = 5

} wifi_phymode_t;

/** Packet format */
typedef enum wifi_format {
  /** Legacy 11b */
  WIFI_FORMAT_LEGACY_11B = 0,

  /** Legacy 11ag OFDM */
  WIFI_FORMAT_LEGACY_11AG,

  /** HT-MF */
  WIFI_FORMAT_HT,

  /** VHT */
  WIFI_FORMAT_VHT,

} wifi_format_t;

/**
   Access Category IDs.

   @note We consider the four ACs of the standard, plus one for beacons.
   @note The lower ID has the highest priority.
*/
typedef enum wifi_ac {
  /** Beacons */
  WIFI_AC_BEACON = 0U,

  /** Voice */
  WIFI_AC_VO,

  /** Video */
  WIFI_AC_VI,

  /** Best Effort */
  WIFI_AC_BE,

  /** Background */
  WIFI_AC_BK,

  /** Number of access categories (always last) */
  WIFI_NUM_EDCAF

} wifi_ac_t;

/** LMAC MIB definitions */

/** AIFS (Arbitrary Inter-frame Spacing) values enumeration */
typedef enum {
  LMAC_AIFS_1 = 1U,
  LMAC_AIFS_2 = 2U,
  LMAC_AIFS_3 = 3U,
  LMAC_AIFS_4 = 4U,
  LMAC_AIFS_5 = 5U,
  LMAC_AIFS_6 = 6U,
  LMAC_AIFS_7 = 7U,
  LMAC_AIFS_8 = 8U,
  LMAC_AIFS_9 = 9U,
} lmac_aifs_t;

/** Contention Window values enumeration */
typedef enum {
  LMAC_CW_1 = 1U,
  LMAC_CW_3 = 3U,
  LMAC_CW_7 = 7U,
  LMAC_CW_15 = 15U,
  LMAC_CW_31 = 31U,
  LMAC_CW_1023 = 1023U,
} lmac_cw_t;

typedef enum
{
  LMAC_MCS0 = 0,
  LMAC_MCS1,
  LMAC_MCS2,
  LMAC_MCS3,
  LMAC_MCS4,
  LMAC_MCS5,
  LMAC_MCS6,
  LMAC_MCS7,
  LMAC_MCS8,
  LMAC_MCS9,
  LMAC_MCS_NUM
} lmac_mcs_t;

/* LMAC MIB CRC enable / disable */
#define LMAC_MIB_CRC_DISABLE 0U
#define LMAC_MIB_CRC_ENABLE 1U


/* Defaults for DSP FW power-up */
#define LMAC_MIB_N_TX_CHAINS_DEFAULT 1U
#define LMAC_MIB_N_RX_CHAINS_DEFAULT 1U

/*
  DCC-CBR (Channel Busy Ratio) default
  CRII-1554: 0x32 translates to a threshold of -85dBm after converting
  RCPI to dBm.
*/
#define LMAC_CBR_THRESHOLD_DEFAULT 0x32U

/* Cyclic Shift Delay (CSD) offset for 802.11p mode */
#define LMAC_CSD_11P_DEFAULT       2

typedef enum switch_type_1609_4  {
  SWITCH_TYPE_ALTERNATE = 0,  // 0
  SWITCH_TYPE_ASYNC,          // 1
  SWITCH_TYPE_SYNC,           // 2
  SWITCH_TYPE_MAX_CNT         // 3
} switch_type_1609_4_t;

#endif /* _DSP_TYPES_H */
