#ifndef _DSP_RANGING_H_
#define _DSP_RANGING_H_
#include "dsp_defs.h"

#define RANGING_SAMPLES_BLOCKS_NUM 2
#define RANGING_SAMPLES_PER_BLOCK_NUM 64
#define RANGING_SAMPLES_SIZE (RANGING_SAMPLES_BLOCKS_NUM * \
                              RANGING_SAMPLES_PER_BLOCK_NUM *\
                              sizeof(uint32_t))

#define HCOEFS_SAMPLES_NUM  (RANGING_SAMPLES_BLOCKS_NUM * RANGING_SAMPLES_PER_BLOCK_NUM)

#define RANGING_FLAGS_PDET_BEFORE_AGC 0x00000001

typedef struct {
  /** RX timestamp in usecs */
  uint32_t rx_tstamp;
  /** RX timestamp offset in nsecs */
  uint32_t rx_tstamp_offset;
  /** ACK Transmit timestamp LSB (TSF) (Relevant only for RX side) */
  uint32_t ack_tstamp_lsb;
} ranging_timing_t;

typedef struct {
  /** Timing info */
  ranging_timing_t timing;
  /** S16Q16 format */
  int32_t  doppler_shift; 
  /** IQ samples */
  uint32_t Hcoefs[HCOEFS_SAMPLES_NUM];
  /** Flags */
  uint32_t flags;
  /** RF gain of the ACK frame (Relevant only for TX side) */
  uint8_t ack_rf_gain[DSP_NUM_DEVS];
  /** RSSI of the ACK frame (Relevant only for TX side) */
  uint8_t ack_rssi[DSP_NUM_DEVS];
  /** EVM of the ACK frame (Relevant only for TX side) */
  uint32_t ack_evm_num;
  uint32_t ack_evm_denom;
  /** AGC lock offset (TDE cycles units) from PDET */
  uint16_t agc_lock_offset;
  /** TSSI of ACK (Relevant only for RX side) */
  uint8_t  ack_tssi[DSP_NUM_DEVS];
  /** Reserved */
  uint8_t reserved[12];
} dsp_ranging_block_t;

#endif /* _DSP_RANGING_H_ */
