#ifndef _H2D_CMD_H_
#define _H2D_CMD_H_

#include "dsp_cmd.h"
#include "dsp_defs.h"
#include <h2d_cmd_common.h>

enum h2d_cmd_code_dsrc {
  /* Read results from h2d_op_cbr_ctl.slots_total and
     h2d_op_cbr_ctl.slots_busy */
  H2D_CMD_OP_CBR_READ = 3,            // 3
  H2D_CMD_OP_1609_4 = 12,             // 12
  H2D_CMD_OP_DETACH,                  // 13
  H2D_CMD_OP_SCOREBOARD_CONTROL = 15, // 15
  H2D_CMD_OP_MACADDR_SET,             // 16
  H2D_CMD_OP_DFS_COMMAND,             // 17
  H2D_CMD_DPD_ENABLE,                 // 18
  H2D_CMD_OP_SET_PPS_VALIDITY,        // 19
  H2D_CMD_OP_EDCA_UPDATE              // 20
};

enum cmd_1609_4 {
  CMD_1609_4_UPDATE_FREQ = 0U,        // 0
  CMD_1609_4_SWITCH_CHAN,             // 1
  CMD_1609_4_MAX                      // 3
};


typedef enum {
  H2D_SCOREBOARD_ACTION_CLEAR_ALL,
  H2D_SCOREBOARD_ACTION_ADD,
  H2D_SCOREBOARD_ACTION_DELETE
} h2d_scoreboard_action_t;

typedef struct h2d_op_scoreboard_control {
  uint8_t  action;  /* see h2d_scoreboard_action_t */
  /**
     if action is 'CLEAR_ALL', the scoreboard table
     will be completely deleted, In this case
     the following fields are not relevant

     In case of 'ADD' action, DSP will look for a corresponding
     scoreboard according to the specified macaddr and TID fields,
     If found it will update winstart and reset the bitmask.
     If not found, DSP will add a new scoardboard with the new macaddr/TID/winstart.
     If scoreboard table is full the 'status' field will be set to 1 (0 otherwise).

     In case of 'DELETE' action, DSP will delete the relevant scorebaord from
     table only if it is found. If not found, 'status' field will be set to 1 (0 otherwise).

     In all action types, 'table_occupancy' field will be updated.
  */

  uint8_t  macaddr[DSP_MAC_ADDR_SIZE];
  uint8_t  tid;
  uint16_t winstart;
  uint8_t  status;
  uint8_t  table_occupancy;
} h2d_op_scoreboard_control_t;

#define H2D_CMD_TSF_SEC_SECTON_VALID_VAL 0xDDFFC0DEU
#define H2D_CMD_TSF_SEC_CRATON2_VALID_VAL 0xEEFFC0DEU

typedef struct h2d_op_macaddr_set {
  uint8_t  macaddr[DSP_MAC_ADDR_SIZE];
  uint8_t  macaddr_mask[DSP_MAC_ADDR_SIZE];
} h2d_op_macaddr_set_t;

typedef struct h2d_op_1609_4 {
  uint32_t cmd_1609_4; /* according to enum cmd_1609_4 */
  uint8_t payload[DSP_CMD_REQUEST_DATA_SIZE - sizeof(uint32_t)]; // - sizeof(uint32_t) because of size of cmd_1609_4 field
} h2d_op_1609_4_t;

/* CMD_1609_4_UPDATE_FREQ */
typedef struct h2d_op_1609_4_update_freq {
  uint32_t freq;      /* new frequency */
  uint32_t slot;      /* slot index */
} h2d_op_1609_4_update_freq_t;

/* CMD_1609_4_CHANGE_MODE */
typedef struct h2d_op_1609_4_switch_chan {
  uint32_t switch_type;       /* channel switch type [switch_type_1609_4_t] */
  uint32_t slot;              /* slot */
} h2d_op_1609_4_switch_chan_t;

/* H2D_CMD_OP_SET_PPS_VALIDITY */
typedef struct h2d_op_set_pps_validity {
  uint32_t validity;              /* PPS validity flag */
} h2d_op_set_pps_validity_t;

typedef struct h2d_op_dfs {
  uint32_t cmd_dfs    ; /* according to enum cmd_dfs */
  uint32_t is_radar_detected; /* return value : 1 - radar detected, 0 - no radar detected */
} h2d_op_dfs_t;

typedef struct h2d_op_dpd {
  uint32_t dpd_enable;
} h2d_op_dpd_t;

typedef struct h2d_op_cbr_ctl {
  /* Total number of symbol time (8usecs) slots for
     current measure  */
  uint32_t slots_total[2];
  /* Number of symbol time (8usecs) busy slots for
     current measure  */
  uint32_t slots_busy[2];
  /* noise floor in the channel in dBm */
  int32_t noise_floor[2];
} h2d_op_cbr_ctl_t;

#define H2D_CMD_TSF_SEC_SECTON_VALID_VAL  0xDDFFC0DEU
#define H2D_CMD_TSF_SEC_CRATON2_VALID_VAL 0xEEFFC0DEU

typedef struct h2d_op_pps {
  uint32_t tsf_lsb; /* TSF value on PPS from TDE0 (LSB) */
  uint32_t tsf_msb; /* TSF value on PPS from TDE0 (MSB) */
  uint32_t tsf_lsb_sec; /* expected TSF value on PPS from GNSS (LSB) */
  uint32_t tsf_msb_sec; /* extected TSF value on PPS from GNSS (MSB) */
  uint32_t tsf_sec_mode;
} h2d_op_pps_t;

#endif /* _H2D_CMD_H_ */
