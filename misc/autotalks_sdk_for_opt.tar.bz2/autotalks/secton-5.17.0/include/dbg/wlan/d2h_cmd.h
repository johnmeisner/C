#ifndef _WLAN_D2H_CMD_H_
#define _WLAN_D2H_CMD_H_

#include "dsp_cmd.h"

enum d2h_cmd_code {
  D2H_CMD_OP_AFE_PLL_CONFIG_GET = 0U,     // 0
  D2H_CMD_OP_AFE_PLL_CONFIG_SET = 1U     // 1
};

typedef struct d2h_op_afe_pll_config {
  uint32_t ndiv;
  uint32_t fract;
  uint32_t odf;
} d2h_op_afe_pll_config_t;

#endif /* _WLAN_D2H_CMD_H_ */
