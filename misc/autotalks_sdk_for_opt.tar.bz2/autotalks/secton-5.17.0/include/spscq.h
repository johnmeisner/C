/* Copyright (C) 2021 Autotalks Ltd. */

#ifndef _SPSCQ_H
#define _SPSCQ_H

#include <atlk/sdk.h>

/**
   @file
   Single-Producer Single-Consumer Queue

   This queue assumes single producer and single consumer meaning it is not
   thread safe.
*/

/* Reserved bytes for SPSCQ handler */
#define SPSCQ_HANDLER_BYTES_SIZE 64

/* Use this to define SPSCQ buffer size including SPSCQ handler */
#define SPSCQ_BUFFER_SIZE_WORDS(SIZE) ATLK_DIV_ROUND_UP(((SIZE) + SPSCQ_HANDLER_BYTES_SIZE), sizeof(uint32_t))

/* Handler type for SPSCQ */
typedef uintptr_t spscq_handler_t;

/**
   Initialize SPSCQ.

   @param[in] spscq_handler_ptr SPSCQ handler pointer
   @param[in] spscq_buffer_ptr SPSCQ buffer pointer
   @param[in] spscq_buffer_size SPSCQ buffer size
   @param[in] element_size queue single element size

   @note Actual queue size would be number of elements - 1

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
spscq_init(spscq_handler_t *spscq_handler_ptr,
           void *spscq_buffer_ptr,
           size_t spscq_buffer_size,
           size_t element_size);

/**
   Get pointer to free element buffer in SPSCQ.

   @param[in]  spscq_handler SPSCQ handler
   @param[out] element_buffer_pptr SPSCQ free element buffer pointer
   @param[out] element_size_ptr element buffer size pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
spscq_enqueue_ptr_get(spscq_handler_t spscq_handler,
                      void **element_buffer_pptr,
                      size_t *element_size_ptr);

/**
   Enqueue element into SPSCQ.

   @param[in] spscq_handler SPSCQ handler
   @param[in] element_buffer_ptr SPSCQ element buffer pointer

   @note spscq_enqueue must be done from single context only

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
spscq_enqueue(spscq_handler_t spscq_handler,
              void *element_buffer_ptr);

/**
   Get pointer to queue head element buffer in SPSCQ.
   Will WAIT when SPSCQ is empty.

   @param[in]  spscq_handler SPSCQ handler
   @param[out] element_buffer_pptr SPSCQ head element buffer pointer
   @param[out] element_size_ptr element buffer size pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
spscq_dequeue_ptr_get(spscq_handler_t spscq_handler,
                      void **element_buffer_pptr,
                      size_t *element_size_ptr);

/**
   Dequeue element from SPSCQ.

   @param[in] spscq_handler SPSCQ handler

   @note spscq_dequeue must be done from single context only

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
spscq_dequeue(spscq_handler_t spscq_handler);

/**
   Deinitialize SPSCQ.

   @param[in] spscq_handler SPSCQ handler

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
spscq_deinit(spscq_handler_t spscq_handler);

#endif /* _SPSCQ_H */
