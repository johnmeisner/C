/** Copyright (C) 2021 Autotalks Ltd. */
#ifndef _CYCLIC_BUFFER_H
#define _CYCLIC_BUFFER_H

/*
   @file
   Header file of cyclic buffer implementation, duplicated in the Host and the Device
*/

#ifdef __cplusplus
extern "C" {
#endif

//#define CYCLIC_BUFFER_DEQUEUE_TIMESTAMP_DEBUG_EN

typedef enum {
  CYCLIC_BUFFER_ENQUEUE_NON_BLOCKING,
  CYCLIC_BUFFER_ENQUEUE_BLOCKING,
} cyclic_buffer_enqueue_type_t;

/* Hold pointer to memory allocated buffer */
typedef struct {
  /** Pointer to the base memory buffer */
  uint8_t *buffer_ptr;
} cyclic_buffer_base_address_t;

typedef struct {
  uint32_t enqueue_packets;
  uint32_t dequeue_packets;
  uint32_t enqueue_failed;
  uint32_t dequeue_failed;
  uint32_t highest_watermark_level;
  uint32_t current_watermark_level;
  uint32_t current_packets_in_queue;
  uint32_t highest_number_of_packets_in_queue;
#ifdef CYCLIC_BUFFER_DEQUEUE_TIMESTAMP_DEBUG_EN
  uint32_t max_dequeue_ts_diff_usec;
  uint64_t last_dequeue_ts_sec;
  uint32_t last_dequeue_ts_usec;
  uint64_t tatal_dequeue_ts_diff_usec;
  uint64_t dequeue_count;
#endif
} cyclic_buffer_statistics_t;

/**
   Dequeue payload from buffer
   @Note: dequeue function is not thread safe, but enqueue and dequeue can be called separately from different threads

   @param[in] buffer_base_ptr   Pointer to the cyclic buffer
   @param[in] payload_max_size  Max size of payload
   @param[out] payload_ptr      Pointer to where to copy the dequeued payload
   @param[out] payload_size_ptr Pointer to write the actual size of the dequeued payload

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
cyclic_buffer_dequeue(uint8_t *buffer_base_ptr, uint32_t payload_max_size, uint8_t *payload_ptr, uint32_t *payload_size_ptr);

/**
   Insert payload to buffer
   @Note: enqueue function is not thread safe, but enqueue and dequeue can be called separately from different threads

   @param[in] buffer_base_ptr         Pointer to the cyclic buffer
   @param[in] payload_ptr             Pointer to payload
   @param[in] payload_size            payload size
   @param[in] enqueue_type            Blocking or non blocking
   @param[in] blocking_interval_usec  Time to sleep in case of blocking send and queue is full

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
cyclic_buffer_enqueue(uint8_t *buffer_base_ptr,
                      uint8_t *payload_ptr,
                      uint32_t payload_size,
                      cyclic_buffer_enqueue_type_t enqueue_type,
                      uint32_t blocking_interval_usec);

/**
   Initialize the cyclic buffer header, header will be located at the beginning of the buffer.
   And will be used for controlling the enqueue and dequeue functions.
   buffer needs to be pre-allocated by the user

   @param[in] buffer_base_ptr  Pointer to the cyclic buffer
   @param[in] buffer_size      Buffer size

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
cyclic_buffer_init(uint8_t *buffer_base_ptr, uint32_t buffer_size);

/**
   De-init cyclic buffer
   The buffer memory will not be released in this function

   @param[in] buffer_base_ptr  Pointer to the cyclic buffer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
cyclic_buffer_deinit(uint8_t *buffer_base_ptr);

/**
   Get buffer statistics

   @param[in] buffer_base_ptr  Pointer to the cyclic buffer
   @param[out] statistics_ptr  Pointer to buffer statistics struct
   @param[out] buffer_size_ptr Pointer to buffer size value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
cyclic_buffer_statistics_get(uint8_t *buffer_base_ptr, cyclic_buffer_statistics_t *statistics_ptr, uint32_t *buffer_size_ptr);

/**
   Clear buffer statistics

   @param[in] buffer_base_ptr  Pointer to the cyclic buffer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
cyclic_buffer_statistics_clear(uint8_t *buffer_base_ptr);

#endif /* _CYCLIC_BUFFER_H */
