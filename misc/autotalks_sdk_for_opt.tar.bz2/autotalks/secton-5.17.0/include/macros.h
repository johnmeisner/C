#ifndef INCLUDE_MACROS_H_
#define INCLUDE_MACROS_H_

#include <stdio.h>
#include <trace.h>
#include <atlk_common_utils.h>

#ifndef BUG
  #define BUG()                                                                           \
  do {                                                                                    \
    atlk_backtrace_print();                                                               \
    TR_IMMEDIATE_ERROR("BUG: failure at %s:%d/%s()!", __FILE__, __LINE__, __FUNCTION__);  \
    atlk_exit(-1);                                                                        \
  } while (0)

  #define BUG_ON(condition)                                                               \
  do {                                                                                    \
    if (atlk_unlikely((condition)!=0)) {                                                  \
      BUG();                                                                              \
    }                                                                                     \
  } while(0)

  /**
   * Break the build if condition is true (no runtime or code size penalty)
   *
   * @attention This macro uses the ::condition argument both in expandable (as an assert
   *   condition) and non-expandable (as a part of assert message) forms.
   *   Despite MISRA2012-RULE-20_12-2 disallows such usage, in this macro it is an intended
   *   behavior.
   *   If the macro is used with #defines in ::condition, suppress MISRA2012-RULE-20_12-2
   *   at points of use of the macro.
   */
  #define BUILD_BUG_ON(condition)   _Static_assert(!(condition), "BUILD_BUG_ON: " #condition )

#endif /* BUG */

#ifndef ARRAY_SIZE
  #define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#endif

#define ROUND(a,b)    (((a) + (b) - 1) & ~((b) - 1))
#define DIV_ROUND(n,d)    (((n) + ((d)/2)) / (d))
#define DIV_ROUND_UP(n,d) (((n) + (d) - 1U) / (d))
#define roundup(x, y)   ((((x) + ((y) - 1)) / (y)) * (y))

#ifndef MIN
#define MIN(x,y) (((x) < (y)) ? (x) : (y))
#endif

#ifndef MAX
#define MAX(x,y) (((x) > (y)) ? (x) : (y))
#endif

#ifndef MIN
  #define MIN(x,y) (((x) < (y)) ? (x) : (y))
#endif

#ifndef MAX
  #define MAX(x,y) (((x) > (y)) ? (x) : (y))
#endif

#if !defined __cplusplus
  #undef min
  /* suppress ISO C prohibition of braced-groups within expression by putting
  __extension__ */
  #define min(x, y) __extension__({         \
          typeof(x) _min1 = (x);            \
          typeof(y) _min2 = (y);            \
          (void) (&_min1 == &_min2);        \
          _min1 < _min2 ? _min1 : _min2; })

  #undef max
  #define max(x, y) __extension__ ({        \
          typeof(x) _max1 = (x);            \
          typeof(y) _max2 = (y);            \
          (void) (&_max1 == &_max2);        \
          _max1 > _max2 ? _max1 : _max2; })
#endif /* !__cplusplus */

#define ALIGN(x,a)    __ALIGN_MASK((x),(typeof(x))(a)-1)
#define __ALIGN_MASK(x,mask)  (((x)+(mask))&~(mask))

/**
 Pre-defined macros for NULL pointer checking
 */
#define NULL_PARAM_CHECK1(X, RC) {            \
  if ((X) == NULL) {                          \
    (RC) = ATLK_E_INVALID_ARG;                \
  }                                           \
  else {                                      \
    (RC) = ATLK_OK;                           \
  }                                           \
}

/* parasoft suppress MISRA2012-RULE-20_7 */
#define NULL_PARAM_CHECK2(X, Y, RC) {         \
  NULL_PARAM_CHECK1(X, (RC));                 \
  if ((RC) == ATLK_OK) {                      \
    NULL_PARAM_CHECK1(Y, (RC));               \
  }                                           \
}

#define NULL_PARAM_CHECK3(X, Y, Z, RC) {      \
  NULL_PARAM_CHECK2(X, Y, (RC));              \
  if ((RC) == ATLK_OK) {                      \
    NULL_PARAM_CHECK1(Z, (RC));               \
  }                                           \
}

#define NULL_PARAM_CHECK4(X, Y, Z, A, RC) {   \
  NULL_PARAM_CHECK3(X, Y, Z, (RC));           \
  if ((RC) == ATLK_OK) {                      \
    NULL_PARAM_CHECK1(A, (RC));               \
  }                                           \
}

/**
 * container_of - cast a member of a structure out to the containing structure
 * @ptr:  the pointer to the member.
 * @type: the type of the container struct this is embedded in.
 * @member: the name of the member within the struct.
 *
 */
#define container_of(ptr, type, member) ({      \
  const typeof( ((type *)0)->member ) *__mptr = (ptr);  \
  (type *)( (char *)__mptr - offsetof(type,member) );})
/* parasoft unsuppress MISRA2012-RULE-20_7 */

#define BIT(N) (1ULL << (N))
#define BITMASK(N) ((1ULL << ((N))) - 1ULL)

#define BIT_32(N) ((uint32_t)(1UL << (N)))
/* Use 1ULL to enable shift by 32 bits and get 0xFFFFFFFF for a 32-bit mask right way */
#define BITMASK_32(N) ((uint32_t)((1ULL << (N)) - 1ULL))

#define ATLK_IS_ALIGNED(value, nbytes) (((value) & ((nbytes) - 1)) == 0)

#define FAILED(rc) atlk_unlikely((rc) < 0)

/* Is an integer value power of 2? (i.e. 2^n) */
#define is_power_of_2(x) ({ typeof(x) _x = (x); (_x & (_x - (typeof(x))1)) == (typeof(x))0; })

/* This function is meant to suppress MISRA warning 21_8,
   that forbids use of exit function */
atlk_inline void
atlk_exit(int status)
{
  exit(status);
}

#endif /* INCLUDE_MACROS_H_ */
