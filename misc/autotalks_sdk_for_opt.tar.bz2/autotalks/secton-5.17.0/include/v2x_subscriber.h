#ifndef _V2X_SUBSCRIBER_H
#define _V2X_SUBSCRIBER_H

#include <atlk/sdk.h>
#include <atlk/v2x.h>

#include <dsm_internal.h>

/** Max number of int32_t values per sample */
#ifndef V2X_SAMPLING_NUM_VALUES_PER_SAMPLE_MAX
#define V2X_SAMPLING_NUM_VALUES_PER_SAMPLE_MAX (768U / sizeof(uint32_t))
#endif // V2X_SAMPLING_NUM_VALUES_PER_SAMPLE_MAX

/** Maximum sample subscribers */
#define V2X_INDICATION_SUBSCRIBERS_MAX 32

/** Sample size in words of CBR indication */
#define V2X_CBR_SAMPLE_SIZE_IN_WORDS 4

typedef struct {
  int32_t int32_array[V2X_SAMPLING_NUM_VALUES_PER_SAMPLE_MAX];
} v2x_indication_value_t;

/* This struct size must be smaller than v2x_indication_value_t*/
typedef struct {
  /** Interface index */
  uint8_t if_index;

  /** flags */
  uint32_t flags; /* error */

  /** packet id */
  uint32_t packet_id;

  /** structure must be aligned to 32 bit */
  uint8_t padding[3];

} v2x_tx_indication_value_t;

/** V2X sample type */
typedef enum {
  /**
     CBR (channel busy ratio) sample.

     Samples should be received via ::v2x_indication_int32_receive. Sampled values are
     in the range of 0 to 100.
  */
  V2X_INDICATION_TYPE_CBR = 0U,

  /** Measurements sample, contains which type of meta-data has been sent in the last frame. */
  V2X_INDICATION_TYPE_MEASUREMENT,

  /** Indication about tx failure. */
  V2X_INDICATION_TYPE_TX,

  V2X_INDICATION_TYPE_MAX,

} v2x_indication_type_t;

/** V2X sample subscriber configuration */
typedef struct {
  /** Ingress/egress physical interface index */
  if_index_t if_index;

  /** Subscription sample type */
  v2x_indication_type_t type;
} v2x_sample_subscriber_config_t;

/** V2X sample subscriber configuration default initializer */
#define V2X_SAMPLE_SUBSCRIBER_CONFIG_INIT {     \
  .if_index = IF_INDEX_NA,                      \
  .type = V2X_INDICATION_TYPE_MAX,                  \
}

typedef atlk_rc_t (*v2x_indication_cb_t)(if_index_t if_index, v2x_indication_type_t type, uint32_t *values, uint32_t size);

/**
   Sets a call back function

   @note Sets a call back function to be called on sample reception, instead of having the data stored in the subscriber ref structure
         by default the call back is not set (i.e. NULL), and it needs to be set after calling v2x_subscriber_create.
         if no call back is set, data is copied to the subscriber ref structure until retrieved by calling v2x_subscriber_sample_int32_receive
         call back function gets as params the interface index, the sample type, an array of values and the number of values in the array
         call back function should return ASAP an atlk_rc_t.

   @param[in] subscriber_ptr V2X sample subscriber instance
   @param[in] cb_function_ptr call back function

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_subscriber_callback_set(v2x_sample_subscriber_t *subscriber_ptr, v2x_indication_cb_t cb_function_ptr);

/**
   Initialize V2X subscriber module

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
void
v2x_subscriber_init(void);

/**
   Deinitialize V2X subscriber module

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_subscriber_deinit(void);

/**
   Create V2X subscriber module

   @param[in]  service_ptr DDM service instance
   @param[out] subscriber_pptr V2X sample subscriber pointer
   @param[in]  config_ptr V2X sample subscriber configuration

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_subscriber_create(dsm_service_desc_t *service_ptr,
                      v2x_sample_subscriber_t **subscriber_pptr,
                      const v2x_sample_subscriber_config_t *config_ptr);

/**
   Receive V2X sample data

   @note In case of V2X_INDICATION_TYPE_CBR: one integer is returned. i.e. the CBR percent
         in case of V2X_INDICATION_TYPE_MEASUREMENT: up to V2X_SAMPLING_NUM_VALUES_PER_SAMPLE_MAX
                  (32) integers are filled in RAW format

   @param[in]  subscriber_ptr V2X sample subscriber instance
   @param[out] value_ptr V2X sample value
   @param[in]  wait_ptr Wait specification

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_subscriber_sample_int32_receive(v2x_sample_subscriber_t *subscriber_ptr,
                                    int32_t *value_ptr,
                                    const atlk_wait_t *wait_ptr);

/**
   Handles the sample received from lmac

   @note should only be called by the lmac.
         the number of integer values set in the value array is passed in sample_size

   @param[in]  subscriber_ptr V2X sample subscriber instance
   @param[in]  if_index  Interface index
   @param[in]  type V2X sample type
   @param[out] value_ptr V2X sample value
   @param[in]  indication_size_in_words V2X sample size in words

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_subscriber_indication_handle(dsm_service_desc_t *service_ptr,
                             uint8_t if_index,
                             v2x_indication_type_t type,
                             v2x_indication_value_t *value_ptr,
                             uint32_t indication_size_in_words);

/**
   Delete V2X subscriber module

   @param[in] subscriber_ptr V2X sample subscriber instance

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_subscriber_delete(v2x_sample_subscriber_t *subscriber_ptr);

#endif /* _V2X_SUBSCRIBER_H */
