#ifndef _CORE_OBJECT_INTERNAL_H
#define _CORE_OBJECT_INTERNAL_H

#include <atlk/object.h>
#include <atlk/sdk.h>

#include <remote_service/remote_object.h>
#include <dbg/remote_dbg.h>

atlk_rc_t atlk_must_check
object_remote_size_get(const atlk_object_t *object, size_t *size);

atlk_rc_t atlk_must_check
object_encode(const atlk_object_t *object,
              void *remote_obj_ptr,
              int encode_value);

atlk_rc_t atlk_must_check
object_decode(atlk_object_t *object, const void *remote_obj);

typedef struct {
  atlk_object_flags_t exptected_flags;
  int is_get_supported;
  int is_set_supported;
  remote_dbg_object_type_t remote_type;
} object_type_rule_t;

atlk_rc_t atlk_must_check
object_rule_type_get(uint16_t type,
                     object_type_rule_t **rule_pptr,
                     object_type_rule_t *rule_array,
                     size_t rule_array_size);

atlk_rc_t atlk_must_check
object_validate(object_type_rule_t *rule_ptr, int is_set, atlk_object_flags_t flags);

#endif /* _CORE_OBJECT_INTERNAL_H */
