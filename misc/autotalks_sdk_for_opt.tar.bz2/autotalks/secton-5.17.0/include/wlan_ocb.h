#ifndef _CORE_WLAN_OCB_H
#define _CORE_WLAN_OCB_H

#include <atlk/sdk.h>
#include <atlk/v2x_service.h>
#include <atlk/wdm_service.h>

#include <dsm_internal.h>
#include <atlk_packet.h>
#include <atlk_queue.h>
#include <atlk/object.h>

#define WLAN_OCB_PACKET_QUEUE_LEN 32U

typedef enum {
  SOCKET_STATE_UNUSED = 0,
  SOCKET_STATE_IN_USE,
  SOCKET_STATE_IN_DELETION
} socket_state_t;


typedef struct wlan_ocb_socket_s {
  /* Socket State */
  socket_state_t state;
  /* Interface index */
  if_index_t if_index;
  /* Protocol ID and frame type */
  v2x_protocol_t protocol;
  /* Pointer to the relevant service */
  dsm_service_desc_t *dsm_v2x_service;
  /* Pointer to RX packet queue buffer */
  uintptr_t rx_queue_buffer[WLAN_OCB_PACKET_QUEUE_LEN];
  /* Pointer to RX packet queue structure */
  queue_handler_t rx_queue;
  /* V2X socket statistics */
  v2x_socket_stats_t stats;
} wlan_ocb_socket_t;

/**
   Initialize WLAN OCB module

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
 */
atlk_rc_t atlk_must_check
wlan_ocb_module_init(void);

/**
   Deinitialize WLAN OCB module

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wlan_ocb_deinit(void);

atlk_rc_t atlk_must_check
wlan_ocb_socket_create(dsm_service_desc_t *dsm_v2x_service,
                       wlan_ocb_socket_t **wlan_ocb_socket_pptr,
                       const v2x_socket_config_t *config);

/**
   Delete V2X socket.

   @param[in] socket_ptr V2X socket pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wlan_ocb_socket_delete(wlan_ocb_socket_t *socket_ptr);

atlk_rc_t atlk_must_check
wlan_ocb_send(wlan_ocb_socket_t *wlan_ocb_socket_ptr,
              atlk_packet_t *v2x_packet_ptr,
              const v2x_send_params_t *params,
              const void *user_data_ptr,
              size_t user_data_size,
              void *user_data_response_ptr,
              size_t *user_data_response_size_ptr,
              const atlk_wait_t *wait_ptr);

atlk_rc_t atlk_must_check
wlan_ocb_receive(wlan_ocb_socket_t *socket_ptr,
                 void *data_ptr,
                 size_t *data_size_ptr,
                 v2x_receive_params_t *params_ptr,
                 void *user_data_ptr,
                 size_t user_data_size,
                 const atlk_wait_t *wait_ptr);

/**
   Get V2X socket statistics

   @param[in] socket_ptr V2X socket
   @param[out] stats_ptr Statistics pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wlan_ocb_socket_stats_get(wlan_ocb_socket_t *socket_ptr,
                          v2x_socket_stats_t *stats_ptr);

/**
   Set TX callback.

   TX callback is called for each MPDU transmitted.

   @remark Callbacks for different interfaces might be called simultaneously.
   Hence, callbacks should be designed to be reentrant.

   @remark When a callback is set to NULL, it clears previously set callback.

   @param[in] if_index WLAN MAC interface
   @param[in] tx_callback TX callback function

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wlan_ocb_tx_traffic_monitor_set(if_index_t if_index,
                                wdm_tx_traffic_monitor_t tx_callback);

/**
   Set RX callback.

   RX callback is called for each MPDU received (even when there are no open
   V2X sockets).

   @remark Callbacks for different interfaces might be called simultaneously.
   Hence, callbacks should be designed to be reentrant.

   @remark When a callback is set to NULL, it clears previously set callback.

   @param[in] if_index WLAN MAC interface
   @param[in] rx_callback RX callback function

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wlan_ocb_rx_traffic_monitor_set(if_index_t if_index,
                                wdm_rx_traffic_monitor_t rx_callback);

/**
   Get OCB pass through mode.

   @return OCB pass through mode
*/
int
wlan_ocb_pass_through_mode_get(void);

/**
   Set OCB pass through mode.

   @param[in] mode Mode to set
*/
void
wlan_ocb_pass_through_mode_set(int mode);

#endif /* _CORE_WLAN_OCB_H */
