#ifndef _CORE_LOG_CORE_INTERNAL_H
#define _CORE_LOG_CORE_INTERNAL_H

#include <inttypes.h>

#include <log_core.h>

#define LOG_CORE_INTERNAL_QUEUE_ELEMENTS   512U

typedef struct {
  uint8_t               is_initialized;
  log_level_t           log_level;
  pthread_mutex_t       mutex;
  log_reader_database_t *decoding_database_ptr;
} log_core_control_block_t;

#endif /* _CORE_LOG_CORE_INTERNAL_H */
