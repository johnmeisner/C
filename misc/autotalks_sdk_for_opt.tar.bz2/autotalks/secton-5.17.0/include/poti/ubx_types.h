/** Copyright (C) 2022 Autotalks Ltd. */
#ifndef _ATLK_UBX_TYPES_H
#define _ATLK_UBX_TYPES_H

#include <atlk/sdk.h>

/**
   @file
   UBX binary protocol, device structures and types declerations
*/

/** UBX protocol payload max length in bytes **/
#define MAX_PAYLOAD_LEN                           256U

/** differential corrections were applied flag value **/
#define UBX_NAV_PVT_FLAGS_VAL_DGPS                1U

/** Valid GPS FIX value **/
#define UBX_NAV_PVT_FLAGS_VAL_GPS_FIX_OK          1U

/** UTC Time is valid flag value **/
#define UBX_NAV_PVT_FLAGS_VAL_VALID_TIME          1U

/** UTC Date is valid flag value **/
#define UBX_NAV_PVT_FLAGS_VAL_VALID_DATE          1U

/** Flag value to indicate if UBX should be an output protocol on UART1 **/
#define UBX_CFG_UART1_OUT_PROT_KEY_ID_UBX         0x10740001U

/** Flag value to indicate if NMEA should be an output protocol on UART1 **/
#define UBX_CFG_UART1_OUT_PROT_KEY_ID_NMEA        0x10740002U

/** UBX protocol message classes and IDs **/
typedef enum {
  /** Navigation solution messages **/
  UBX_MSG_ID_NAV_DOP      = 0x0104U,
  UBX_MSG_ID_NAV_PVT      = 0x0107U,
  UBX_MSG_ID_NAV_EELL     = 0x013DU,

  /** Acknowledgement and negative acknowledgement messages **/
  UBX_MSG_ID_ACK_NAK      = 0x0500U,
  UBX_MSG_ID_ACK_ACK      = 0x0501U,

  /** Configuration and command messages **/
  UBX_MSG_ID_CFG_VALSET   = 0x068AU,
  UBX_MSG_ID_CFG_PRT      = 0x0600U,
  UBX_MSG_ID_CFG_MSG      = 0x0601U,
  UBX_MSG_ID_CFG_RATE     = 0x0608U
} ubx_msg_id_t;

/** UART port character length **/
typedef enum {
  UBX_PRT_CFG_CHAR_LENGTH_5_BIT = 0U,
  UBX_PRT_CFG_CHAR_LENGTH_6_BIT,
  UBX_PRT_CFG_CHAR_LENGTH_7_BIT,
  UBX_PRT_CFG_CHAR_LENGTH_8_BIT
} ubx_prt_cfg_char_length;

/** UART port parity type **/
typedef enum {
  UBX_PRT_CFG_PARITY_EVEN     = 0U,
  UBX_PRT_CFG_PARITY_ODD      = 1U,
  UBX_PRT_CFG_PARITY_DISABLE  = 4U
} ubx_prt_cfg_parity_type;

/** UART port amount of stop bits **/
typedef enum {
  UBX_PRT_CFG_STOP_BITS_1     = 0U,
  UBX_PRT_CFG_STOP_BITS_1_5,
  UBX_PRT_CFG_STOP_BITS_2,
  UBX_PRT_CFG_STOP_BITS_0_5
} ubx_prt_cfg_stop_bits;

/** GNSS fix types **/
typedef enum {
  /** No fix available **/
  UBX_FIX_TYPE_NO_FIX = 0U,

  /** Dead reckoning fix **/
  UBX_FIX_TYPE_DEAD_RECKONING,

  /** 2 dimensions fix **/
  UBX_FIX_TYPE_2D,

  /** 3 dimensions fix **/
  UBX_FIX_TYPE_3D,

  /** GPS and Dead Reckoning fix **/
  UBX_FIX_TYPE_GPS_DEAD_RECKONING,

  /** Time only fix **/
  UBX_FIX_TYPE_TIME_ONLY
} ubx_fix_type_t;

/** Layers where the UBX configuration should be applied in the device **/
typedef enum {
  /** Update configuration in the RAM layer (volatile) **/
  UBX_CFG_LAYER_RAM   = 1U << 0,

  /** Update configuration in the BBR (battery-backed RAM) layer (non-volatile) **/
  UBX_CFG_LAYER_BBR   = 1U << 1,

  /** Update configuration in the Flash layer (non-volatile) **/
  UBX_CFG_LAYER_FLASH = 1U << 2
} ubx_cfg_layer_t;

/** UBX protocol payload **/
typedef struct {
  /** UBX protocol message class & ID**/
  ubx_msg_id_t msg_id;

  /** Actual payload length in bytes **/
  uint16_t actual_length;

  /** The payload data **/
  uint8_t data[MAX_PAYLOAD_LEN];
} ubx_payload_t;

/** UTC date according to UBX protocol **/
typedef struct {
  /** Year, range 1999..2099 (UTC) **/
  uint16_t year;

  /** Month, range 1..12 (UTC) **/
  uint8_t month;

  /** Day of month, range 1..31 (UTC) **/
  uint8_t day;
} __attribute__((packed)) ubx_utc_date_t;

/** UTC time according to UBX protocol **/
typedef struct {
  /** Hour of day, range 0..23 (UTC) **/
  uint8_t hour;

  /** Minute of hour, range 0..59 (UTC) **/
  uint8_t min;

  /** Seconds of minute, range 0..60 (UTC) **/
  uint8_t sec;
} __attribute__((packed)) ubx_utc_time_t;

/** UBX protocol configuration key value pair data (1 bytes value) **/
typedef struct {
  /** Register key ID **/
  uint32_t key_id;

  /** Register value **/
  uint8_t value;
} __attribute__((packed)) ubx_cfg_key_id_value8_pair_t;

/** UBX protocol configuration key value pair data (2 bytes value) **/
typedef struct {
  /** Register key ID **/
  uint32_t key_id;

  /** Register value **/
  uint16_t value;
} __attribute__((packed)) ubx_cfg_key_id_value16_pair_t;

/** UBX protocol configuration key value pair data (4 bytes value) **/
typedef struct {
  /** Register key ID **/
  uint32_t key_id;

  /** Register value **/
  uint32_t value;
} __attribute__((packed)) ubx_cfg_key_id_value32_pair_t;

/** UBX protocol configuration key value pair data (8 bytes value) **/
typedef struct {
  /** Register key ID **/
  uint32_t key_id;

  /** Register value **/
  uint64_t value;
} __attribute__((packed)) ubx_cfg_key_id_value64_pair_t;

/** UBX protocol CFG-VALSET message header - Set configuration item values **/
typedef struct {
  /** Message version (0x00 for this version) **/
  uint8_t version;

  /** The layers where the configuration should be applied (RAM, BBR, Flash) **/
  uint8_t layers;

  /** Reserved data **/
  uint8_t reserved0[2];
} __attribute__((packed)) ubx_cfg_valset_header_t;

/** UBX protocol ACK-ACK / ACK-NAK message **/
typedef struct {
  /** Class ID of the ACK/NAK Message **/
  uint8_t cls_id;

  /** Message ID of the ACK/NAK Message **/
  uint8_t msg_id;
} __attribute__((packed)) ubx_msg_payload_ack_t;

/** UBX protocol CFG-OUTPROT message - Output protocol configuration of interface **/
typedef struct {
  /** CFG-VALSET message header **/
  ubx_cfg_valset_header_t valset_header;

  /** UBX protocol key value pair **/
  ubx_cfg_key_id_value8_pair_t ubx;

  /** NMEA protocol key value pair **/
  ubx_cfg_key_id_value8_pair_t nmea;
} __attribute__((packed)) ubx_msg_payload_cfg_valset_outprot_t;

/** UBX protocol NAV-DOP message - Dilution of precision navigation message **/
typedef struct {
  /** GPS time of week of the navigation epoch in milliseconds **/
  uint32_t itow;

  /** Geometric DOP scaled by 1e-2 **/
  uint16_t gdop;

  /** Position DOP scaled by 1e-2 **/
  uint16_t pdop;

  /** Time DOP scaled by 1e-2 **/
  uint16_t tdop;

  /** Vertical DOP scaled by 1e-2 **/
  uint16_t vdop;

  /** Horizontal DOP scaled by 1e-2 **/
  uint16_t hdop;

  /** Northing DOP scaled by 1e-2 **/
  uint16_t ndop;

  /** Easting DOP scaled by 1e-2 **/
  uint16_t edop;
} __attribute__((packed)) ubx_msg_payload_nav_dop_t;

/** UBX protocol NAV-EELL message - Position error ellipse parameters navigation message **/
typedef struct {
  /** GPS time of week of the navigation epoch in milliseconds **/
  uint32_t itow;

  /** Message version (0x00 for this version) **/
  uint8_t version;

  /** Reserved field **/
  uint8_t reserved0;

  /** Orientation of semi-major axis of error ellipse (degrees from true north) scaled by 1e-2**/
  uint16_t err_ellipse_orient;

  /** Semi-major axis of error ellipse in millimeters **/
  uint32_t err_ellipse_major;

  /** Semi-minor axis of error ellipse in millimeters **/
  uint32_t err_ellipse_minor;
} __attribute__((packed)) ubx_msg_payload_nav_eell_t;

/** UBX protocol NAV-PVT message - Navigation, position, velocity and time solution navigation message **/
typedef struct {
  /** GPS time of week of the navigation epoch in milliseconds **/
  uint32_t itow;

  /** UTC date **/
  ubx_utc_date_t utc_date;

  /** UTC time **/
  ubx_utc_time_t utc_time;

  /** Validity bit fields flags **/
  struct {
    /** 1 = Valid UTC date **/
    uint8_t valid_date          : 1;

    /** 1 = Valid UTC time of day **/
    uint8_t valid_time          : 1;

    /** 1 = UTC time of day has been fully resolved (noseconds uncertainty). Cannot be used to check if time is completely solved **/
    uint8_t fully_resolved      : 1;

    /** 1 = Valid magnetic declination **/
    uint8_t valid_mag           : 1;
  } valid;

  /** Time accuracy estimate (UTC) in nanoseconds**/
  uint32_t tacc;

  /** Fraction of second, range -1e9 .. 1e9 (UTC) **/
  int32_t nano;

  /** GNSS fix type - 0 = no fix, 1 = DR, 2 = 2D, 3 = 3D, 4 = GNSSDR, 5 = time only fix **/
  uint8_t fix_type;

  /** Fix status flags **/
  struct {
    /** 1 = Valid fix (i.e within DOP & accuracy masks) **/
    uint8_t gnss_fix_ok         : 1;

    /** 1 = Differential corrections were applied **/
    uint8_t diff_soln           : 1;

    /** Power save mode state (see Power management section in the integration manual for details) **/
    uint8_t psm_state           : 3;

    /** 1 = Heading of vehicle is valid, only set if the receiver is in sensor fusion mode **/
    uint8_t head_veh_valid      : 1;

    /** Carrier phase range solution status - 0 = no solution, 1 = solution with floating ambiguities, 2 = solution with fixed ambiguities **/
    uint8_t carrier_soln        : 2;
  } flags;

  /** Additional flags **/
  struct {
    /** Reserved **/
    uint8_t reserved            : 5;

    /** 1 = Information about UTC Date and TOD validity confirmation is available **/
    uint8_t confirmed_avai      : 1;

    /** 1 = UTC Date validity could be confirmed **/
    uint8_t confirmed_date      : 1;

    /** 1 = UTC Time of Day could be confirmed **/
    uint8_t confirmed_time      : 1;
  } flags2;

  /** Number of satellites used in Nav Solution **/
  uint8_t num_sv;

  /** Longitude in degrees scaled by 1e-7 **/
  int32_t lon;

  /** Latitude in degrees scaled by 1e-7 **/
  int32_t lat;

  /** Height above ellipsoid in millimeters **/
  int32_t height;

  /** Height above mean sea level in millimeters **/
  int32_t h_msl;

  /** Horizontal accuracy estimate in millimeters **/
  uint32_t h_acc;

  /** Vertical accuracy estimate in millimeters **/
  uint32_t v_acc;

  /** NED north velocity in millimeter per second **/
  int32_t vel_n;

  /** NED east velocity in millimeter per second **/
  int32_t vel_e;

  /** NED down velocity in millimeter per second **/
  int32_t vel_d;

  /** Ground speed (2D speed) millimeter per second **/
  int32_t g_speed;

  /** Heading of motion (2D) in degrees scaled by 1e-5 **/
  int32_t head_mot;

  /** Speed accuracy estimate in millimeter per second **/
  uint32_t s_acc;

  /** Heading accuracy estimate in degrees scaled by 1e-5 **/
  uint32_t head_acc;

  /** Position DOP scaled by 1e-2 **/
  uint16_t pdop;

  /** Additional flags **/
  struct {
    /** 1 = Invalid lon, lat, height and hMSL **/
    uint16_t invalid_llh          : 1;

    /** Age of the most recently received differential correction **/
    uint16_t last_correction_age  : 4;
  } flags3;

  /** Reserved **/
  uint8_t reserved0[4];

  /** Heading of vehicle (2D), this is only valid when "head_veh_valid" is set, otherwise the output is set to the heading of motion **/
  int32_t head_veh;

  /** Magnetic declination. Only supported in ADR 4.10 and later **/
  int16_t mag_dec;

  /** Magnetic declination accuracy. Only supported in ADR 4.10 and later **/
  uint16_t mag_acc;
} __attribute__((packed)) ubx_msg_payload_nav_pvt_t;

/** UBX protocol CFG-PRT message - Port configuration for UART ports **/
typedef struct {
  /** UART port identifier number **/
  uint8_t port_id;

  /** Reserved **/
  uint8_t reserved1;

  /** TX ready PIN configuration **/
  struct {
    /** Enable TX ready feature for this port **/
    uint16_t en     : 1;

    /** Polarity. 0 - High active, 1 - Low active **/
    uint16_t pol    : 1;

    /** PIO to be used **/
    uint16_t pin    : 5;

    /** TX ready threshold. active after >= thres*8 bytes are pending. 0x000 - no threshold, 0x001 8bytes, ... , 0x1FE 4080bytes, 0x1FF 4088bytes **/
    uint16_t thres  : 9;
  } tx_ready;

  /** A bit mask describing the UART mode **/
  struct {
    /** Reserved **/
    uint32_t reserved0  : 6;

    /** Character length **/
    uint32_t char_len   : 2;

    /** Reserved **/
    uint32_t reserved1  : 1;

    /** Parity **/
    uint32_t parity     : 3;

    /** Number of stop bits **/
    uint32_t stop_bits  : 2;

    /** Reserved **/
    uint32_t reserved2  : 18;
  } mode;

  /** Baud rate in bits / second **/
  uint32_t baudrate;

  /** A mask describing which input protocols are active **/
  struct {
    /** UBX protocol **/
    uint16_t ubx        : 1;

    /** NMEA protocol **/
    uint16_t nmea       : 1;

    /** RTCM protocol **/
    uint16_t rtcm       : 1;

    /** Reserved **/
    uint16_t reserved0  : 2;

    /** RTCM3 protocol **/
    uint16_t rtcm3      : 1;

    /** Reserved **/
    uint16_t reserved1  : 10;
  } in_proto_mask;

  /** A mask describing which out protocols are active **/
  struct {
    /** UBX protocol **/
    uint16_t ubx        : 1;

    /** NMEA protocol **/
    uint16_t nmea       : 1;

    /** Reserved **/
    uint16_t reserved0  : 3;

    /** RTCM3 protocol **/
    uint16_t rtcm3      : 1;

    /** Reserved **/
    uint16_t reserved1  : 10;
  } out_proto_mask;

  /** Flags bit mask **/
  struct {
    /** Reserved **/
    uint16_t reserved0    : 1;

    /** Extended TX timeout. the port will time out if allocated TX memory >= 4 kB and no activity for 1.5s**/
    uint16_t ext_tx_tout  : 1;

    /** Reserved **/
    uint16_t reserved1    : 14;
  } flags;

  /** Reserved **/
  uint8_t reserved2[2];
} __attribute__((packed)) ubx_msg_payload_cfg_prt_uart_t;

/** UBX protocol CFG-RATE message - Navigation / measurment rate settings **/
typedef struct {
  /** The elapsed time between GNSS measurements in milliseconds, which defines the rate, e.g. 100ms => 10Hz **/
  uint16_t meas_rate;

  /** The ratio between the number of measurements and the number of navigation solutions **/
  uint16_t nav_rate;

  /** The time system to which measurements are aligned **/
  uint16_t time_ref;
} __attribute__((packed)) ubx_msg_payload_cfg_rate_t;

/** UBX protocol CFG-MSG message - Enable / disable UBX message and set message rate **/
typedef struct {
  /** UBX message class ID **/
  uint8_t msg_class;

  /** UBX message ID **/
  uint8_t msg_id;

  /** Send rate on current active port **/
  uint8_t rate;
} __attribute__((packed)) ubx_msg_payload_cfg_msg_t;

#endif /* _ATLK_UBX_TYPES_H */