/* Copyright (C) 2015 Autotalks Ltd. */
#ifndef _ATLK_NAV_MIB_API_H
#define _ATLK_NAV_MIB_API_H

#include <atlk/mib_service.h>
#include <atlk/mibs/nav-mib.h>

struct mib_service;

void
nav_mib_set_fix_available(int val);

void
nav_mib_data_src_set(mib_navDataSource_t data_src);

void
nav_mib_set_systime_leap_seconds_since_2004(int32_t leap_seconds);

void
nav_mib_set_sys_time_status(mib_navSysTimeStatus_t time_stat);

void
nav_mib_set_sys_time_accuracy(mib_navSysTimeAccuracy_t accuracy);

int
get_nav_update_enabled(void);

void
set_nav_update_enabled(int value);

atlk_rc_t
nav_mib_config_save_status_set(mib_service_t *service,
                               mib_ConfigSaveStatus_t value);

#endif /* _ATLK_NAV_MIB_API_H */
