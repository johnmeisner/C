/* Copyright (C) 2015-2016 Autotalks Ltd. */
#ifndef _ATLK_NMEA_NAV_INTERNAL_H
#define _ATLK_NMEA_NAV_INTERNAL_H

#include <poti/nmea_nav.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   Convert NMEA timestamp to navigation timestamp.

   @param[out] time Navigation timestamp
   @param[in] timestamp NMEA timestamp

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_to_nav_fix_time(nav_time_t *time,
            const nmea_nav_timestamp_t *timestamp);

/**
   Convert RMC data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data RMC data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_rmc_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_rmc_t *data);

/**
   Convert GGA data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data GGA data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_gga_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_gga_t *data);

/**
   Convert GSA data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data GSA data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_gsa_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_gsa_t *data);

/**
   Convert GLL data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data GLL data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_gll_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_gll_t *data);

/**
   Convert GST data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data GST data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_gst_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_gst_t *data);

/**
   Convert GSV data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data GSV data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_gsv_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_gsv_t *data);

/**
   Convert VTG data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data VTG data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_vtg_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_vtg_t *data);

/**
   Convert GNS data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data GNS data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_gns_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_gns_t *data);

/**
   Convert STM UTC data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data STM UTC data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_stm_utc_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_stm_utc_t *data);

/**
   Convert STM TG data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data STM TG data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_stm_tg_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_stm_tg_t *data);

/**
   Convert STM KFCOV data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data STM KFCOV data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_stm_kfcov_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_stm_kfcov_t *data);

/**
   Convert STM DRCOV data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data STM DRCOV data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_stm_drcov_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_stm_drcov_t *data);

/**
   Convert UBX TIME data to navigation fix data frame.

   @param[in,out] nmea_nav NMEA navigation object
   @param[in] address Sentence address
   @param[in] data UBX TIME data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_data_ubx_time_to_nav_fix(nmea_nav_t *nmea_nav,
            const nmea_address_t *address,
            const nmea_data_ubx_time_t *data);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_NMEA_NAV_INTERNAL_H */
