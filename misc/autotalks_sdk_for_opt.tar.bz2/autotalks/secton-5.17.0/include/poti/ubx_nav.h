/** Copyright (C) 2022 Autotalks Ltd. */
#ifndef _ATLK_UBX_NAV_H
#define _ATLK_UBX_NAV_H

#include <atlk/sdk.h>
#include <poti/poti.h>
#include <poti/ubx_types.h>

/**
   @file
   UBX protocol navigation messages handler API decleration 
*/

/**
   Handles navigation payload with concrete handler to parse and extract relevant data

   @param[in] payload Incoming UBX protocol navigation payload
   @param[out] nav_data Navigation structure to fill data with from @p payload

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ubx_nav_handle(ubx_payload_t *payload,
               nav_data_t *nav_data);

#endif /* _ATLK_UBX_NAV_H */