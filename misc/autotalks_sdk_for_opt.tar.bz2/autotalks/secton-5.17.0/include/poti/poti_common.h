#ifndef _CORE_COMMON_H
#define _CORE_COMMON_H

#include <string.h>
#include <pthread.h>

#include <atlk/sdk.h>

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(x) ((int)(sizeof(x) / sizeof((x)[0])))
#endif

#define TR_DEBUG(...)

atlk_rc_t atlk_must_check
atlk_mutex_create(pthread_mutex_t *mutex_ptr);

atlk_rc_t atlk_must_check
atlk_cond_create(pthread_condattr_t *cond_attr_ptr, pthread_cond_t *cond_ptr);

atlk_rc_t atlk_must_check
atlk_cond_destroy(pthread_condattr_t *cond_attr_ptr, pthread_cond_t *cond_ptr);

void
hex_dump(uint8_t* data, size_t size, int ascii_only);

atlk_rc_t atlk_must_check
one_byte_checksum(const uint8_t *buf, size_t buf_size, uint8_t *checksum);

void *
atlk_malloc(size_t size);

void
atlk_free(void *ptr);

atlk_inline void
atlk_memcpy(void *dest, const void *src, size_t size)
{
  (void)memcpy(dest, src, size);
}

atlk_inline void
atlk_memset(void *dest, int c, size_t size)
{
  (void)memset(dest, c, size);
}

atlk_rc_t
atlk_usec_to_timespec(size_t usec,
                      struct timespec *ts_ptr);

/* This function is meant to suppress MISRA warning 21_8,
   that forbids use of exit functio */
atlk_inline void
atlk_exit(int status)
{
  exit(status);
}

/** Unit scale conversion factors */
#ifndef CENTI_PER_UNIT
#define CENTI_PER_UNIT  100U
#endif
#ifndef MILLI_PER_UNIT
#define MILLI_PER_UNIT  1000U
#endif
#ifndef MICRO_PER_MILLI
#define MICRO_PER_MILLI 1000U
#endif
#ifndef NANO_PER_MICRO
#define NANO_PER_MICRO  1000U
#endif
#ifndef MICRO_PER_UNIT
#define MICRO_PER_UNIT  1000000U
#endif
#ifndef NANO_PER_MILLI
#define NANO_PER_MILLI  1000000U
#endif
#ifndef NANO_PER_UNIT
#define NANO_PER_UNIT   1000000000U
#endif

#endif /* _CORE_COMMON_H */
