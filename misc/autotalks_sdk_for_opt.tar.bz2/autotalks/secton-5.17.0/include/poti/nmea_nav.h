/* Copyright (C) 2015-2016 Autotalks Ltd. */
#ifndef _ATLK_NMEA_NAV_H
#define _ATLK_NMEA_NAV_H

#include <atlk/sdk.h>
#include <poti/nav.h>
#include <poti/nmea.h>
#include <poti/coord.h>
#include <poti/gnss.h>

#ifdef __cplusplus
extern "C" {
#endif

/** UTC time (and date) status */
typedef enum {
  /** UTC time is not valid */
  NMEA_NAV_UTC_TIME_STATUS_NOT_VALID = 0,

  /** UTC time is valid */
  NMEA_NAV_UTC_TIME_STATUS_VALID,

  /** UTC time is not available */
  NMEA_NAV_UTC_TIME_STATUS_NA

} nmea_nav_utc_time_status_t;

/** UTC to GPS time offset status */
typedef enum {
  /** UTC offset is not valid */
  NMEA_NAV_UTC_OFFSET_STATUS_NOT_VALID = 0,

  /** UTC offset is the firmware default value */
  NMEA_NAV_UTC_OFFSET_STATUS_FIRMWARE_DEFAULT,

  /** UTC offset was read from NVM */
  NMEA_NAV_UTC_OFFSET_STATUS_READ_FROM_NVM,

  /** UTC offset was set by user */
  NMEA_NAV_UTC_OFFSET_STATUS_SET_BY_USER,

  /** UTC offset was downloaded from sky */
  NMEA_NAV_UTC_OFFSET_STATUS_VALID,

  /** UTC offset is not available */
  NMEA_NAV_UTC_OFFSET_STATUS_NA

} nmea_nav_utc_offset_status_t;

/** NMEA timestamp */
typedef struct {
  /** UTC time */
  nmea_time_t utc_time;

  /** UTC date */
  nmea_date_t utc_date;

  /** UTC time (and date) status */
  nmea_nav_utc_time_status_t utc_time_status;

  /** UTC to GPS time offset in seconds */
  nmea_int_t utc_offset_sec;

  /** UTC to GPS time offset status */
  nmea_nav_utc_offset_status_t utc_offset_status;

} nmea_nav_timestamp_t;

/** NMEA timestamp default initializer */
#define NMEA_NAV_TIMESTAMP_INIT {                       \
  .utc_time = NMEA_TIME_NA,                             \
  .utc_date = NMEA_DATE_NA,                             \
  .utc_time_status = NMEA_NAV_UTC_TIME_STATUS_NA,       \
  .utc_offset_sec = NMEA_INT_NA,                        \
  .utc_offset_status = NMEA_NAV_UTC_OFFSET_STATUS_NA    \
}

/** NMEA navigation object */
typedef struct {
  /**
    10 Hz Cycle ender address.

    @note When @p cycle_ender is of type ::NMEA_TYPE_PARAMETRIC and talker ID is
    set to ::NMEA_TALKER_ID_NA, talker ID is ignored (i.e. "don't care").
  */
  nmea_address_t cycle_ender_10hz;

  /** NMEA 1 Hz cycle ender */
  nmea_address_t cycle_ender_1hz;

  /** Navigation fix data frame */
  nav_fix_t fix;

  /** Navigation satellites info data frame */
  nav_satellite_report_t sat;

  /** Last known NMEA timestamp */
  nmea_nav_timestamp_t timestamp;

  /** GNSS antenna offset */
  coord_ego_t ant_offset;

  /** Last known "good" heading in degrees */
  double last_heading_deg;

  /** Last known "course" */
  nmea_float_t last_course;

  /** Minimum speed for which heading is considered as "good" */
  double min_speed_mps;

  /** Whether TG sentence is used */
  int stm_tg_used;

  /** GNSS model */
  gnss_model_t gnss_model;

  /** Navigation data frame_handler */
  nav_data_handler_t handler;

  /** Navigation service */
  nav_service_t *service;

  /** Read/Write lock protect */
  pthread_mutex_t rw_lock;

} nmea_nav_t;

/** NMEA navigation object default initializer */
#define NMEA_NAV_INIT {                     \
  .cycle_ender_10hz = NMEA_ADDRESS_INIT,    \
  .cycle_ender_1hz = NMEA_ADDRESS_INIT,     \
  .fix = NAV_FIX_INIT,                      \
  .sat = NAV_SATELLITE_REPORT_INIT,         \
  .timestamp = NMEA_NAV_TIMESTAMP_INIT,     \
  .ant_offset = COORD_EGO_ZERO_INIT,        \
  .last_heading_deg = NAN,                  \
  .last_course = {0},                       \
  .min_speed_mps = NAN,                     \
  .stm_tg_used = 0,                         \
  .gnss_model = GNSS_MODEL_NA,              \
  .handler = NULL,                          \
  .service = NULL,                          \
  .rw_lock = PTHREAD_MUTEX_INITIALIZER,     \
}

/** NMEA navigation object configuration parameters */
typedef struct {
  /** Pointer to NMEA object */
  nmea_t *nmea;

  /** UTC offset in seconds */
  nmea_int_t utc_offset_sec;

  /** GNSS antenna offset */
  coord_ego_t ant_offset;

  /** Minimum speed for which heading is considered as "good" */
  double min_speed_mps;

  /** GNSS model */
  gnss_model_t gnss_model;

  /** Navigation data frame handler */
  nav_data_handler_t handler;

  /** Navigation service */
  nav_service_t *service;

} nmea_nav_config_t;

/** NMEA navigation object configuration parameters default initializer */
#define NMEA_NAV_CONFIG_INIT {              \
  .nmea = NULL,                             \
  .utc_offset_sec = NMEA_INT_NA,            \
  .ant_offset = COORD_EGO_INIT,             \
  .min_speed_mps = NAN,                     \
  .gnss_model = GNSS_MODEL_NA,              \
  .handler = NULL,                          \
  .service = NULL                           \
}

/**
   Initilaize NMEA navigation object.

   @param[out] nmea_nav NMEA navigation object to init
   @param[in] config NMEA navigation object configuration parameters

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_nav_init(nmea_nav_t *nmea_nav,
            const nmea_nav_config_t *config);

/**
   Deinitilaize NMEA navigation object.

   @param[in] nmea_nav NMEA navigation object to init

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_nav_deinit(nmea_nav_t *nmea_nav);

/**
   Initilaize NMEA navigation cycle enders.

   @param[out] nmea_nav NMEA navigation object to init
   @param[in] cycle_ender_10hz String address of 10 Hz cycle ender
   @param[in] cycle_ender_1hz String address of 1 Hz cycle ender

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_nav_cycle_enders_init(nmea_nav_t *nmea_nav,
            const char *cycle_ender_10hz,
            const char *cycle_ender_1hz);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_NMEA_NAV_H */
