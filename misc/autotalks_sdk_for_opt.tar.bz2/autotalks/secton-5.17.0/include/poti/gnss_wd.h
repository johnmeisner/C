/* Copyright (C) 2016 Autotalks Ltd. */
#ifndef _GNSS_WD_H
#define _GNSS_WD_H

#include <atlk/sdk.h>
#include <extern/os.h>
#include <poti/gnss.h>

/** GNSS WD configuration parameters */
typedef struct {
  /** GNSS HW reset */
  gnss_hw_reset_t hw_reset;

  /** Maximum number of GNSS HW reset retries */
  uint32_t retries_max;

  /** How often to poll NMEA I/O counters in milliseconds */
  uint32_t poll_interval_ms;

  /** GNSS HW watchdog thread scheduling parameters */
  atlk_thread_sched_t sched_params;

} gnss_wd_config_t;

/** GNSS WD configuration parameters default initializer */
#define GNSS_WD_CONFIG_INIT {                   \
  .hw_reset = NULL,                             \
  .retries_max = 5,                             \
  .poll_interval_ms = 2000,                     \
  .sched_params = ATLK_THREAD_SCHED_INIT        \
}

/**
   Initialize GNSS WD.

   @param[in] config GNSS WD configuration parameters

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
gnss_wd_init(const gnss_wd_config_t *config);


/**
   Kick GNSS WD.

   This function forces GNSS WD to skip checking NMEA counters status
   for at least @interval_ms milliseconds. Required to overcome Teseo
   transient states (e.g. at system init and at end of FW update).

   @param[in] interval_ms Kick for this number of milliseconds

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
gnss_wd_kick(uint32_t interval_ms);

#endif /* _GNSS_WD_H */
