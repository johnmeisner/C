/* Copyright (C) 2015-2016 Autotalks Ltd. */
#ifndef _ATLK_NMEA_INTERNAL_H
#define _ATLK_NMEA_INTERNAL_H

#include "nmea.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
   Parse string value.

   Value is set to NA when field is NULL.

   @param[in] field Field to parse (optional)
   @param[out] value String value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_str_parse(const char *field,
            nmea_str_t *value);

/**
   Parse character value.

   Value is set to NA when field is NULL.

   @param[in] field Field to parse (optional)
   @param[out] value Character value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_char_parse(const char *field,
            nmea_char_t *value);

/**
   Parse integer value.

   Value is set to NA when field is NULL.

   @param[in] field Field to parse (optional)
   @param[out] value Integer value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_int_parse(const char *field,
            nmea_int_t *value);

/**
   Parse hexadecimal value.

   Value is set to NA when field is NULL.

   @param[in] field Field to parse (optional)
   @param[out] value Hexadecimal value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_hex_parse(const char *field,
            nmea_hex_t *value);

/**
   Parse date value.

   Value is set to NA when field is NULL.

   @param[in] field Field to parse (optional)
   @param[out] value Date value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_date_parse(const char *field,
            nmea_date_t *value);

/**
   Parse time value.

   Value is set to NA when field is NULL.

   @param[in] field Field to parse (optional)
   @param[out] value TIme value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_time_parse(const char *field,
            nmea_time_t *value);

/**
   Parse float value.

   Value is set to NA when field is NULL.

   @param[in] field Field to parse (optional)
   @param[out] value Float value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_float_parse(const char *field,
            nmea_float_t *value);

/**
   Parametric NMEA sentence address parse.

   @param[out] address Parsed address
   @param[in] sentence Sentence to parse

   @retval ::ATLK_OK if succeeded
   @return ::ATLK_E_UNSUPPORTED if @p sentence is not supported
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_parse_address(nmea_address_t *address,
            const char *sentence);

/**
   STM sentence address parse.

   @param[out] address Parsed address
   @param[in] sentence Sentence to parse

   @retval ::ATLK_OK if succeeded
   @return ::ATLK_E_UNSUPPORTED if @p sentence is not supported
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_parse_address_stm(nmea_address_t *address,
            const char *sentence);

/**
   UBX sentence address parse.

   @param[out] address Parsed address
   @param[in] sentence Sentence to parse

   @retval ::ATLK_OK if succeeded
   @return ::ATLK_E_UNSUPPORTED if @p sentence is not supported
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_parse_address_ubx(nmea_address_t *address,
            const char *sentence);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_NMEA_INTERNAL_H */
