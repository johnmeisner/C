/** Copyright (C) 2022 Autotalks Ltd. */
#ifndef _ATLK_SERIAL_DRIVER_H
#define _ATLK_SERIAL_DRIVER_H

#include <atlk/sdk.h>

/**
   @file
   Serial device driver API decleration
*/

/** Device file name max length in file system **/
#define SERIAL_DRIVER_DEV_NAME_LEN    32

/** Serial driver RX buffer length in bytes **/
#define SERIAL_DRIVER_RX_BUFFER_LEN   1024

/** Serial driver context **/
typedef struct {
  /** Device file descriptor **/
  int fd;

  /** Baud rate speed**/
  uint32_t baudrate;

  /** Device file name in file system **/
  char dev_name[SERIAL_DRIVER_DEV_NAME_LEN];

  /** Amount of bytes that received from the serial **/
  size_t rcvd_data;

  /** Pointer to the head of the RX buffer **/
  uint8_t *rx_head_buffer_ptr;

  /** RX buffer **/
  uint8_t rx_buffer[SERIAL_DRIVER_RX_BUFFER_LEN];
} serial_driver_context_t;

/**
   Initialize a serial driver context

   @param[out] context Serial driver context
   @param[in] dev_name Serial device file name in file system
   @param[in] baudrate Baud rate speed

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
serial_driver_init(serial_driver_context_t *context,
                   char *dev_name,
                   uint32_t baudrate);

/**
   Open the serial driver context for read and write of data

   @param[out] context Serial driver context

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
serial_driver_open(serial_driver_context_t *context);

/**
   Close the serial driver context and release resources

   @param[out] context Serial driver context

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
serial_driver_close(serial_driver_context_t *context);

/**
   Read data from serial

   @remark Read exactly @p data_length bytes from serial

   @param[out] context Serial driver context
   @param[out] data Pointer to buffer which the driver fill with received data
   @param[in] data_length Buffer's length and amount of bytes to read
   @param[in] wait Blocking with timeout or blocking indefinitely 

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
serial_driver_read(serial_driver_context_t *context,
                   uint8_t *data,
                   size_t data_length,
                   atlk_wait_t *wait);

/**
   Write data to serial

   @param[out] context Serial driver context
   @param[out] data Pointer to data buffer
   @param[in] data_length Buffer's length and amount of bytes to write

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
serial_driver_write(serial_driver_context_t *context,
                    uint8_t *data,
                    size_t data_length);

#endif /* _ATLK_UBX_PROTOCOL_H */
