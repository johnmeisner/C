/* Copyright (C) 2015-2016 Autotalks Ltd. */
#ifndef _ATLK_NMEA_DEBUG_H
#define _ATLK_NMEA_DEBUG_H

#include <atlk/sdk.h>
#include <extern/os.h>

#include <atlk/nmea.h>
#include <atlk/nmea_io.h>

#ifdef __cplusplus
extern "C" {
#endif

/** NMEA UDP forward configuration parameters */
typedef struct {
  /** Capture thread scheduling parameters */
  atlk_thread_sched_t sched_params;

  /** Server IPv4 address */
  uint32_t ipv4_address;

  /** UDP port on which input data is sent */
  uint16_t input_udp_port;
  
  /** UDP port on which output data is sent */
  uint16_t output_udp_port;

} nmea_udp_forward_config_t;

/** NMEA UDP forward configuration parameters configuration parameters */
#define NMEA_UDP_FORWARD_CONFIG_INIT {      \
  .sched_params = ATLK_THREAD_SCHED_INIT,   \
  .ipv4_address = UINT32_MAX,               \
  .input_udp_port = 0,                      \
  .output_udp_port = 0                      \
}

/**
   Initilaize UDP forwarding of raw NMEA I/O data.

   @note If @p config is NULL, parameters are retrieved from boot
   variable 'nmea_over_udp'.

   @param[in,out] nmea_io NMEA I/O object
   @param[in] config NMEA UDP forward configuration parameters (optional)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
nmea_udp_forward_init(nmea_io_t *nmea_io,
            const nmea_udp_forward_config_t *config);

/**
   Enable/disable timestamping NMEA I/O data.

   @param[in] enabled Whether to timestamp NMEA I/O data
*/
void
nmea_udp_forward_ts_set(int enabled);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_NMEA_DEBUG_H */
