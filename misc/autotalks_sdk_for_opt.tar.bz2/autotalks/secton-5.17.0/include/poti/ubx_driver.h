/** Copyright (C) 2022 Autotalks Ltd. */
#ifndef _ATLK_UBX_DRIVER_H
#define _ATLK_UBX_DRIVER_H

#include <poti/poti.h>
#include <poti/poti_api.h>
#include <poti/serial_driver.h>

/**
   @file
   UBX protocol and device driver API decleration
*/

/** UBX driver context **/
typedef struct {
  /** Flag to indicate if context is initialized **/
  bool is_init;

  /** Serial driver context **/
  serial_driver_context_t serial_ctx;

  /** POTI navigation data buffer **/
  nav_data_t nav_data;

  /** POTI service **/
  nav_service_t *nav_service;

  /** Hook to publish filled navigation data buffer **/
  nav_data_handler_t publisher;

  /** Navigation messages receiver task **/
  pthread_t rx_nav_task;
} ubx_driver_context_t;

/**
   Initialize a UBX driver

   @param[out] context UBX driver context
   @param[in] dev_name Serial device file name in file system
   @param[in] baudrate Baud rate speed
   @param[in] nav_service Pointer to POTI service
   @param[in] publisher Hook to publish filled navigation data buffer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ubx_driver_init(ubx_driver_context_t *context,
                char* serial_dev_name,
                uint32_t baudrate,
                nav_service_t *nav_service,
                nav_data_handler_t publisher);

/**
   Destory UBX driver context and release resources

   @param[in] context UBX driver context

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ubx_driver_destroy(ubx_driver_context_t *context);

/**
   Set run-time configuration for u-blox module

   @note In case of NEO-M8Q module this method must be call before init.
   NEO-M8Q in contrast to ZED-F9R is GNSS module w/o internal flash which means we have to configure it in run time. see (SDK-3632).
   It means that we have to try to configure this module for baud rate 9600(the default for NEO-M8Q module after reset) and
   for the desired one according to "sw_config" file, ZED-F9R module, poti reset or changing configuration after NEO-M8Q first init.

   @param[in] serial_dev_name Serial device file name in file system
   @param[in] baudrate Baud rate speed
   @param[in] protocol Navigation messages protocol type (NMEA string / UBX binary)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ubx_driver_configuration_set(char* serial_dev_name,
                             uint32_t baudrate,
                             poti_nav_message_format_t protocol);

#endif /* _ATLK_UBX_DRIVER_H */
