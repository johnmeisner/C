/* Copyright (C) 2015-2016 Autotalks Ltd. */
#ifndef _GNSS_TESEO_SOU_H
#define _GNSS_TESEO_SOU_H

#include <atlk/sdk.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   Start Teseo SOU.

   @note Function does nothing (returns ::ATLK_OK) if Teseo SOU has not
   been initialized.

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
teseo_sou_start(void);

/**
   Stop Teseo SOU.

   @note Function does nothing if Teseo SOU has not been initialized.
*/
void
teseo_sou_stop(void);

/** Teseo SOU status */
typedef struct {
  /** Count of N/A gyro 1-axis data during SOU feeder alarm */
  uint32_t gyro_1axis_data_na_cnt;

  /** Count of N/A wheels speed data during SOU feeder alarm */
  uint32_t wheels_speed_data_na_cnt;

  /** Count of underflows during gyro 1-axis scaling */
  uint32_t gyro_1axis_scaling_underflow_cnt;

  /** Count of overflows during gyro 1-axis scaling */
  uint32_t gyro_1axis_scaling_overflow_cnt;

} teseo_sou_stats_t;

/**
   Get Teseo SOU status.

   @param[out] value Teseo SOU status value

   @retval ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
teseo_sou_stats_get(teseo_sou_stats_t *value);

/**
   Reset Teseo SOU status.

   @retval ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
teseo_sou_stats_reset(void);

#ifdef __cplusplus
}
#endif

#endif /* _GNSS_TESEO_SOU_H */

