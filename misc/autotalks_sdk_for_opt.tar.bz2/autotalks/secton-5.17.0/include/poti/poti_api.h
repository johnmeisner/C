/* Copyright (C) 2019 Autotalks Ltd. */
#ifndef POTI_API_H
#define POTI_API_H

#include <atlk/sdk.h>
#include <poti.h>
#include <poti/nmea_io.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DEVICE_NAME(device, port) device "" port
#define DEFAULT_EXTERNAL_USB_GNSS_DEVICE_NAME_PREFIX "/dev/ttyUSB"
#define DEFAULT_EXTERNAL_USN_GNSS_DEVICE_NAME_PREFIX "/dev/ttyACM" //USB1 over USN hub
#define DEFAULT_EXTERNAL_UART_GNSS_DEVICE_NAME_PREFIX "/dev/ttyAMA"

/* A diagnostic POTI device, that is not connected to a real device, but can be fed with NMEA sentences using poti_sim_file_sentence_set interface.
   In order to read latest parsed fix sentence use poti_fix_get interface */
#define DEFAULT_SIM_FILE_GNSS_DEVICE_NAME_PREFIX "/tmp/poti_sim_file_"

#if defined __QNXNTO__
  #define DEFAULT_INTERNAL_GNSS_DEVICE_NAME "/dev/ser1"
#else /* __QNXNTO__ */
  #define DEFAULT_INTERNAL_GNSS_DEVICE_NAME DEVICE_NAME(DEFAULT_EXTERNAL_UART_GNSS_DEVICE_NAME_PREFIX, "1")
#endif /* __QNXNTO__ */

#define DEFAULT_INTERNAL_GNSS_DEVICE_BAUD UART_SPEED_230400_BPS
#define DEFAULT_INTERNAL_GNSS_DEVICE_1HZ_CYCLE_ENDER  "$PSTMCPU"
#define DEFAULT_INTERNAL_GNSS_DEVICE_10HZ_CYCLE_ENDER "$XXGLL"

#define DEFAULT_EXTERNAL_GNSS_DEVICE_BAUD UART_SPEED_115200_BPS
#define DEFAULT_EXTERNAL_GNSS_DEVICE_1HZ_CYCLE_ENDER  "$XXGGA" // or "$XXRMC"
#define DEFAULT_EXTERNAL_GNSS_DEVICE_10HZ_CYCLE_ENDER "$XXGLL"

typedef enum {
  POTI_CYCLE_END_NA       = 0,
  POTI_CYCLE_END_PSTMCPU  = 1,
  POTI_CYCLE_END_XXGGA    = 2,
  POTI_CYCLE_END_XXRMC    = 3,
} poti_cycle_ender_t;

/**
typedef enum {
  POTI_CYCLE_END_NA       = 0,
  POTI_CYCLE_END_PSTMCPU  = 1,
  POTI_CYCLE_END_XXGGA    = 2,
  POTI_CYCLE_END_XXRMC    = 3,
} poti_cycle_ender_t;


   @file poti_api.h
   @brief POTI API
*/

typedef enum {
   POTI_NAV_MESSAGE_FORMAT_BINARY      = 0,
   POTI_NAV_MESSAGE_FORMAT_NMEA_STRING = 1,
   POTI_NAV_MESSAGE_FORMAT_NUM,
} poti_nav_message_format_t;

typedef enum {
   POTI_GNSS_MODULE_UBLOX = 0,
   POTI_GNSS_MODULE_TESEO = 1,
   POTI_GNSS_MODULE_NUM
} poti_gnss_module_t;

/**
   @brief      POTI API initializer

   @param[out] poti_context_pptr    A pointer to a pointer to a POTI API instance. Filled with a pointer to allocated memory of an API context
   @param[in]  gnss_device_name     GNSS device name, if NULL uses default device name, i.e. "/dev  tyAMA1"
                                    other possible value is "/dev  tyACM0" for USB devices. if not NULL, only calls poti_internal_init
   @param[in]  baud                 Baud rate
   @param[in]  cycle_ender_1Hz      Sequence ID of 1Hz cycle end. if NULL ==> "$PSTMCPU" (TESEO),
                                    for other GNSS Device use "$XXGGA" or "$XXRMC"
   @param[in]  cycle_ender_10Hz     Sequence ID of 10Hz cycle end. if NULL ==> "$XXGLL"
   @param[in]  gnss                 GNSS module type. By this enumeration the library knows which GNSS driver to initialize.
   @param[in]  format               Navigation messages format from GNSS. NMEA (string) or UBX (binary) messages. UBX supported by ublox GNSS modules only.

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
poti_init(poti_context_t **poti_context_pptr,
          char *gnss_device_name,
          int32_t baud,
          char *cycle_ender_1Hz,
          char *cycle_ender_10Hz,
          poti_gnss_module_t gnss,
          poti_nav_message_format_t format);

/**
   @brief      POTI context getter

   @param[in]  gnss_device_name  GNSS device name, if NULL use as default the first POTI device
   @param[in]  gnss_device_name  GNSS device name
   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
poti_context_get(char *gnss_device_name,
                 poti_context_t **poti_context_pptr);

/**
   @brief     Delete navigation API

   @param[in] poti_context_ptr POTI API instance

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t atlk_must_check
poti_delete(poti_context_t *poti_context_ptr);

/**
   @brief     Navigation Fix handler. Callback is called each time a new navigation fix is available.

   @param[in] poti_context_ptr Navigation API instance
   @param[in] nav_fix_ptr      Navigation fix to handle
   @param[in] context_ptr      Call back passed to poti_callback_set

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
typedef atlk_rc_t atlk_must_check
(*nav_fix_handler_t)(poti_context_t *poti_context_ptr, nav_fix_t *nav_fix_ptr, void *context_ptr);

/**
   @brief      Returns the current GNSS position (extracted from the last GNSS data received of nav_fix type)

   @param[in]  poti_context_ptr Navigation API
   @param[out] nav_fix_ptr      NAV fix pointer

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
poti_fix_get(poti_context_t *poti_context_ptr,
             nav_fix_t *nav_fix_ptr);

/**
  @fn poti_sim_file_sentence_set
  @brief returns a fix for a given sentence (for test only)

  @param[in] sentence_ptr Sentence_ptr

  @retval ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t poti_sim_file_sentence_set(char *sentence_ptr);

/**
   @brief      Returns the current GNSS time (extracted from last GNSS data received)

   @param[in]  poti_context_ptr Navigation API,
   @param[out] nav_time_ptr     Time pointer

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
poti_time_get(poti_context_t *poti_context_ptr,
              nav_time_t *nav_time_ptr);

/**
   @brief      Returns the current GNSS time in uint64_t (extracted from last GNSS data received)

   @param[in]  poti_context_ptr Navigation API
   @param[out] time64_ptr       Time pointer

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
poti_time64_get(poti_context_t *poti_context_ptr,
                uint64_t *time64_ptr);

#ifndef MICRO_PER_UNIT
#define MICRO_PER_UNIT 1000000
#endif

#ifndef MICRO_PER_UNIT_UNSIGNED
#define MICRO_PER_UNIT_UNSIGNED 1000000U
#endif

/**
   @brief     Retrieves UTC time (in micros) since 2004

   @param[in] nav_time_ptr Navigation API

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_inline uint64_t
poti_time64_calculate(nav_time_t *nav_time_ptr)
{
  if (nav_time_ptr != NULL) {
    double dsec = 0;

    /* Extract signed integral and fractional values */
    double time_usec = modf(nav_time_ptr->tai_seconds_since_2004 - nav_time_ptr->leap_seconds_since_2004 , &dsec);

    return ((uint64_t)dsec) * MICRO_PER_UNIT + (uint64_t)(time_usec * MICRO_PER_UNIT);
  }
  else {
    return 0;
  }
}

/**
   @brief      Returns the current satellite report (extracted from the last GNSS data received of satellite type)

   @param[in]  poti_context_ptr         Navigation API
   @param[out] nav_satellite_report_ptr Satellite report ptr

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
poti_satellite_report_get(poti_context_t *poti_context_ptr,
                          nav_satellite_report_t *nav_satellite_report_ptr);

/**
   @brief         Get GNSS firmware version

   @param[in]     poti_context_ptr Navigation API
   @param[out]    version_ptr      Firmware version pointer
   @param[in,out] version_size     Maximum size (in) and actual (out) in chars

   @retval        ATLK_OK if succeeded
   @return        Error code if failed
*/
atlk_rc_t atlk_must_check
poti_firmware_version_get(poti_context_t *poti_context_ptr,
                          char *version_ptr,
                          uint32_t version_size);

/**
   @brief      Get GNSS statistics

   @param[in]  poti_context_ptr Navigation API
   @param[out] ststs_ptr        Pointer to NMEA I/O statistics

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
poti_stats_get(poti_context_t *poti_context_ptr,
               nmea_io_stats_t *ststs_ptr);

/**
   @brief     Reset GNSS statistics

   @param[in] poti_context_ptr Navigation API

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t atlk_must_check
poti_stats_reset(poti_context_t *poti_context_ptr);

/**
   @brief         Write NMEA sentence

   @param[in,out] poti_context_ptr Navigation API
   @param[in]     sentence_ptr     Pointer to sentence to be written
   @param[in]     sentence_size    Sentence size in bytes, including null-termination

   @retval        ATLK_OK if succeeded
   @return        ATLK_E_IO_ERROR on partial write
   @return        Error code if failed
*/
atlk_rc_t atlk_must_check
poti_write_sentence(poti_context_t *poti_context_ptr,
                    const char *sentence_ptr,
                    size_t sentence_size);

/**
   @brief     Set I/O device speed

   @param[in] poti_context_ptr Navigation API
   @param[in] speed_bps        Speed in bits/s

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t atlk_must_check
poti_speed_set(poti_context_t *poti_context_ptr,
               uart_speed_bps_t speed_bps);

/**
   Get cycle ender string from config.

   @param[in] poti_context_ptr Navigation api

   @retval ::char *
   @return Cycle ender
*/
atlk_inline char *
poti_cycle_ender_get(poti_cycle_ender_t cycle_ender)
{
  switch (cycle_ender) {
    case POTI_CYCLE_END_XXGGA:
      return "$XXGGA";

    case POTI_CYCLE_END_XXRMC:
      return "$XXRMC";

    case POTI_CYCLE_END_PSTMCPU:
      return "$PSTMCPU";

    default:
      break;
  }
  return NULL;
}

#ifdef __cplusplus
}
#endif

#endif /* POTI_API_H */
