/* Copyright (C) 2019 Autotalks Ltd. */

#ifndef _LL_SPI_COMMON_H
#define _LL_SPI_COMMON_H

/** Page header size */
#define PAGE_HEADER_SIZE 16

/** SPI link layer parameters */
/**
  @attention Page and transfer size must be aligned with RX path parameters of the host
  and device: SPI Rx FIFO trigger level and the DMA burst size calcaulted in bytes.
  Device SPI trigger level / DMA burst is 16 FIFIO elements that can be up to 4-byte width.
  So, it is recommended to use 64-byte alignment.
*/
#define LL_SPI_PAGE_SIZE_ALIGNMENT             64U
#define LL_SPI_PAGE_SIZE_MAX                   1920U
#define LL_SPI_PAGE_SIZE_MIN                   512U
#define LL_SPI_PAGE_SIZE_DEFAULT               640U
#define LL_SPI_TRANSFER_SIZE_MIN               512U
#define LL_SPI_TRANSFER_SIZE_DEFAULT           LL_SPI_PAGE_SIZE_MAX
/* SPI delay between two transactions [us] */
#define LL_SPI_TRANSACTION_DELAY_DEFAULT_USEC  50U
#define LL_SPI_TRANSACTION_DELAY_MAX           2000U
/* SPI recovery delay between two transactions [us] */
#define LL_SPI_RECOVERY_DELAY_DEFAULT_USEC     0U
#define LL_SPI_RECOVERY_DELAY_MAX              100000U

/**
 *  Size of static page buffers used for transmission
 *
 * Make buffer enough for three pages of maximum size.
 */
#define TX_PAGES_BUF_SIZE (3 * LL_SPI_PAGE_SIZE_MAX)
/** Size of static buffer for pages used for reception */
#define RX_PAGES_BUF_SIZE (3 * LL_SPI_PAGE_SIZE_MAX)

/** Maximum number of pages used for transmission */
#define NB_TX_MAX_PAGES (TX_PAGES_BUF_SIZE / LL_SPI_PAGE_SIZE_MIN)
/** Maxumim number of pages used for reception */
#define NB_RX_MAX_PAGES (RX_PAGES_BUF_SIZE / LL_SPI_PAGE_SIZE_MIN)

/** Default number of pages used for transmission */
#define NB_TX_DEFAULT_PAGES (TX_PAGES_BUF_SIZE / LL_SPI_PAGE_SIZE_DEFAULT)
/** Default number of pages used for reception */
#define NB_RX_DEFAULT_PAGES (RX_PAGES_BUF_SIZE / LL_SPI_PAGE_SIZE_DEFAULT)

/** Maximum number of transfers per page */
#define NB_TRANSFERS_MAX DIV_ROUND_UP(LL_SPI_PAGE_SIZE_MAX, LL_SPI_TRANSFER_SIZE_MIN)

/** Marker set at the end of the page */
#define POSTAMBLE 0x11223344

/** SPI default frequency  */
#define SPI_DEFAULT_FREQ_HZ 8666666

/** Structure describing the header of the page sent over SPI */
typedef struct {
  /** Version */
  uint8_t version;
  /** Page index */
  uint8_t index;
  /** Number of messages present in the page */
  uint8_t nb_msgs;
  struct {
    /** Verbose mode */
    uint8_t verbose : 1;
    /** Extract the device statistics */
    uint8_t stats_display : 1;
    /** Set the device loop mode */
    uint8_t loop : 1;
    /** Request the device to print debug information */
    uint8_t print_debug : 1;
    /** Flag used to request to the device to empty its Tx pages */
    uint8_t empty_tx : 1;
    /** Time lock status */
    uint8_t time_lock_status : 2;
    /** Flag indicating whether the device SPI is in master mode */
    uint8_t is_device_spi_master : 1;
  };
  /* Timestamp */
  uint64_t timestamp;
} __attribute__((packed)) remote_page_header_t;

/**
 * Structure describing the page sent over SPI
 *
 * Total size including header depend on spi_page_size hw configuration.
 * Postamble is a marker used to detect sync loss and placed at the end of page.
 *
 */
typedef struct {
  union {
    /** Header limited to PAGE_HEADER_SIZE */
    union {
      /** CRC + header */
      struct {
        /** CRC of the header */
        uint32_t crc;
        /** Header */
        remote_page_header_t hdr;
      };
      /** Used to fix the page header size */
      uint8_t buf[PAGE_HEADER_SIZE];
    };
    /** Data */
    uint8_t data[0];
  };
} remote_page_t;

/* Block used to store Tx page control information */
typedef struct
{
  /* Mutex to lock the page when modified or sent */
  pthread_mutex_t lock;
  /* Offset to the next free byte in the page */
  uint16_t offset;
} tx_page_control_block_t;

/** Structure describing the header of a message */
typedef struct {
  /** Length of the payload */
  uint16_t length;
  /** CRC of the payload */
#ifdef CRC_ENABLED
  uint32_t crc;
#endif /* CRC_ENABLED */
} remote_page_message_header_t;

/**
 * Calculate the CRC of the given page header
 *
 * @param[in] page The page
 *
 * @return the page header CRC
 */
uint32_t
ll_spi_calc_hdr_crc(remote_page_t *page_ptr);

/**
 * Return size of SPI page
 *
 * @return SPI page size
 */
uint32_t
ll_spi_page_size(void);

/**
 *  Init postamble in the given page
 *
 *  @param[in] page_ptr Pointer to page
 */
static inline void
page_postamble_set(remote_page_t *page_ptr, uint32_t value)
{
  uint32_t *postamble_ptr = (uint32_t*)(page_ptr->data + ll_spi_page_size() - sizeof(uint32_t));

  *postamble_ptr = value;
}

#endif /* _LL_SPI_COMMON_H */
