/* Copyright (C) 2020 Autotalks Ltd. */
#ifndef INCLUDE_TRACE_H_
#define INCLUDE_TRACE_H_

#include <log_core.h>

/**
   @file
   Trace macros
*/

#define TR_ENQUEUE(_level, _file, _line, _message, ...)                                                                             \
  do {                                                                                                                              \
    atlk_rc_t _rc;                                                                                                                  \
    uint8_t _is_log_level_valid;                                                                                                    \
                                                                                                                                    \
    _rc = log_core_level_is_valid((_level), &_is_log_level_valid);                                                                  \
    if ( (atlk_likely(_rc == ATLK_OK) != 0) && (atlk_likely(_is_log_level_valid != 0U) != 0) ) {                                    \
      log_core_log_enqueue("Host", LOG_CORE_LOG_TYPE_REGULAR, (_level), (_file), (_line), (_message), ##__VA_ARGS__);               \
    }                                                                                                                               \
} while (0);

#ifndef __MIZRA_PARASOFT_CPPTEST_SUPPRESS

#define TR_IMMEDIATE_ERROR(message, ...)  log_core_log_immediate(LOG_LEVEL_ERROR, __FILE__, __LINE__, (message), ##__VA_ARGS__);
#define TR_IMMEDIATE_INFO(message, ...)   log_core_log_immediate(LOG_LEVEL_INFO, __FILE__, __LINE__, (message), ##__VA_ARGS__);

#define TR_ERROR(message, ...)            TR_ENQUEUE(LOG_LEVEL_ERROR, __FILE__, __LINE__, (message), ##__VA_ARGS__)
#define TR_WARNING(message, ...)          TR_ENQUEUE(LOG_LEVEL_WARNING, __FILE__, __LINE__, (message), ##__VA_ARGS__)
#define TR_INFO(message, ...)             TR_ENQUEUE(LOG_LEVEL_INFO, __FILE__, __LINE__, (message), ##__VA_ARGS__)

#if defined(TR_DEBUG_ON)
  #define TR_DEBUG(message, ...)          TR_ENQUEUE(LOG_LEVEL_DEBUG, __FILE__, __LINE__, (message), ##__VA_ARGS__)
#else
  #define TR_DEBUG(message, ...)
#endif

#else /* __MIZRA_PARASOFT_CPPTEST_SUPPRESS */
#define TR_IMMEDIATE_ERROR(message, ...)
#define TR_IMMEDIATE_INFO(message, ...)
#define TR_ERROR(message, ...)
#define TR_WARNING(message, ...)
#define TR_INFO(message, ...)
#define TR_DEBUG(message, ...)

#endif /* __MIZRA_PARASOFT_CPPTEST_SUPPRESS */

#endif /* INCLUDE_TRACE_H_ */
