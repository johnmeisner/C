#ifndef _DBG_H
#define _DBG_H

#include <atlk/sdk.h>
#include <atlk/object.h>
#include <atlk/wdm.h>

#include <dbg/remote_dbg.h>
#include <counters.h>

#define RF_MEM_MAX_FRAGMENT_SIZE    128
#define MEM_MAX_READ_IN_DWORDS      350
#define LOG_FILE_NAME_PATH_MAX_SIZE 60

/**
   @file
   Debug declarations
*/

/** DBG service instance */
typedef atlk_handle_t dbg_service_t;

typedef enum {
  /**
     Access device memory space (32bit)
     Methods: Get, Set
     Type:    Opaque (dbg_mem_32_t)
  */
  DBG_MEM_32 = 0,

  /**
     Access device memory space (16bit)
     Methods: Get, Set
     Type:    Opaque (dbg_mem_16_t)
  */
  DBG_MEM_16,

  /**
     Access device memory space (8bit)
     Methods: Get, Set
     Type:    Opaque (dbg_mem_8_t)
  */
  DBG_MEM_8,

 /**
     Access device SoC registers (32bit) through M3 core
     Methods: Get, Set
     Type:    Opaque (dbg_soc_reg_32_t)
  */
  DBG_SOC_REG_32,

  /**
     Access device memory space and read dump memory
     Methods: Get, Set
     Type:    Opaque (dbg_mem_32_dump_t)
  */
  DBG_MEM_32_DUMP,

  /**
     Access DSP (Wlan/RF) memory space (32bit)
     Methods: Get, Set
     Type:    Opaque (dbg_dsp_mem_32_t)
  */
  DBG_DSP_MEM_32,

  /**
     Access DSP (Wlan/RF) memory space (32bit)
     Methods: Get, Set
     Type:    Opaque (dbg_dsp_mem_8_range_t)
  */
  DBG_DSP_MEM_32_RANGE,

  /**
     Access EPROM memory space (32bit)
     Methods: Get, Set
     Type:    Opaque (dbg_mem_32_t)
  */
  DBG_EPROM_MEM_32,

  /**
     Methods: Get, Set
     Type:    uint32
  */
  DBG_DSP_STATE,

  /**
     Methods: Get, Set
     Type:    uint32
  */
  DBG_DDM_HB_CYCLE,

  /**
     Get device debug statistics
     Methods: Get
     Type:    Opaque (dbg_stat_t)
   */
  DBG_STATS,

  /**
     Get WLAN extended statistics
     Methods: Get
     Type:    Opaque (dbg_wlan_extended_stat_t)
   */
  DBG_WLAN_STATS_EXTENDED,

  /**
     Get wlan ring info
     Methods: Get
     Type:    Opaque (dbg_wlan_ring_info_t)
   */
  DBG_WLAN_RING_INFO,

  /**
     Get DSP cookie
     Methods: Get
     Type:    Opaque (dbg_wlan_cookie_t / dsp_cv2x_cookie_t)
   */
  DBG_DSP_COOKIE,

  /**
     Access EPROM memory space (16 bytes)
     Methods: Get, Set
     Type:    Opaque (dbg_mem_32_t)
  */
  DBG_EPROM_MEM_APP_INFO,

  /**
     Profiler statistics get
     Methods: Get
     Type:    Opaque (dbg_profiler_t)
  */
  DBG_PROFILER_STATISTICS,

  /**
     Get wlan channel busy ratio
     Methods: Get
     Type:    Opaque (dbg_wlan_cbr_t)
   */
  DBG_WLAN_CBR,

  /**
     Methods: Get, Set
     Type:    uint32
  */
  DBG_WLAN_FILTERS,

  /**
     Boot timer measurements get
     Methods: Get
     Type:    Opaque (dbg_boot_timer_t)
   */
  DBG_BOOT_TIMER_MEASUREMENTS,

  /**
     PLL4 frequency
     Methods: Get, Set
     Type:    uint32
  */
  DBG_PLL4_FREQUENCY_MHZ,

  /**
     Start DSP logging
     Methods: Set
     Type:    Opaque (dbg_dsp_logging_parameter_t)
  */
  DBG_DSP_LOGGING_START,

  /**
     Stop DSP logging
     Methods: Set
     Type:    uint32
  */
  DBG_DSP_LOGGING_STOP,

  /**
     Blob get
     Methods: Get
     Type:    uint32
  */
  DBG_BLOB_DATA_GET,

  /**
     Blob size get
     Methods: Get
     Type:    Opaque (dbg_blob_get_t)
  */
  DBG_BLOB_SIZE_GET,

  /**
     ThreadX TraceX record state set
     Methods: Set
     Type:    uint32
  */
  DBG_TRACEX_RECORD_STATE_SET,

  /**
     L2 internal statistics get
     Methods: Get, Set
     Type:    Opaque
  */
  DBG_INTERNAL_L2_STATS_GET,

  DBG_OBJECT_TYPE_MAX,
} dbg_object_type_t;

typedef enum {
  DBG_BLOB_UNIQUE_TYPE_TRACEX_BUFFER = 0,
  DBG_BLOB_UNIQUE_TYPE_MAX,
} dbg_blob_unique_type_t;

typedef enum {
  DBG_L2_INTERNAL_STAT_TYPE_SHMEME,
  DBG_L2_INTERNAL_STAT_TYPE_SPI,
  DBG_L2_INTERNAL_STAT_TYPE_NOT_SUPPORTED,
} dbg_l2_internal_stat_type_t;

#define DBG_OBJECT_TYPE_NA (-1)
#define DBG_OBJECT_TYPE_COUNT (DBG_OBJECT_TYPE_MAX)

typedef struct {
  uint32_t address;
  uint8_t value;
} dbg_mem_8_t;

typedef struct {
  uint32_t address;
  uint16_t value;
} dbg_mem_16_t;

typedef struct {
  uint32_t address;
  uint32_t value;
} dbg_mem_32_t;

typedef struct {
  uint32_t address;
  uint32_t size;
  uint32_t buffer[MEM_MAX_READ_IN_DWORDS];
} dbg_mem_32_dump_t;

typedef struct {
  uint32_t address;
  uint32_t bitmask;
  uint32_t value;
} dbg_soc_reg_32_t;

typedef struct {
  uint32_t device_id;
  uint32_t address;
  uint32_t value;
} dbg_dsp_mem_32_t;

typedef struct {
  uint32_t device_id;
  uint32_t address;
  uint32_t size;
  uint8_t buffer[RF_MEM_MAX_FRAGMENT_SIZE];
} dbg_dsp_mem_32_range_t;

/* DBG statistics */
typedef struct {
  atlk_flow_counters_t ll_driver_stat;
  atlk_flow_counters_t rt_stat;
  atlk_flow_counters_t rsvc_stat;
  atlk_flow_counters_t v2x_stat;
  atlk_flow_counters_t wdm_stat;
  atlk_flow_counters_t ddm_stat;
  atlk_flow_counters_t ecc_stat;
} dbg_stat_t;

/* l2 shared memory internal statistics */
typedef struct {
  uint32_t buffer_size;
  uint32_t enqueue_packets;
  uint32_t dequeue_packets;
  uint32_t enqueue_failed;
  uint32_t dequeue_failed;
  uint32_t highest_watermark_level;
  uint32_t current_watermark_level;
  uint32_t current_packets_in_queue;
  uint32_t highest_number_of_packets_in_queue;
  uint32_t max_dequeue_ts_diff_usec;
  uint32_t average_dequeue_ts_diff_usec;
} dbg_l2_shmem_internal_stat_t;

typedef struct {
  /** Total successfully sent bytes - sum of the messages bytes sent by the upper layer */
  uint32_t tx_bytes;
  /** Total successfully sent messages - sum of the messages sent by the upper layer */
  uint32_t tx_messages;
  /** Total successfully sent pages */
  uint32_t tx_pages;
  /** Total errors during sending */
  uint32_t tx_errors;
  /** Total errors due to no space in buffers */
  uint32_t tx_no_space_in_buffer_errors;
  /** Total successfully received bytes - sum of the messages bytes sent to the upper layer */
  uint32_t rx_bytes;
  /** Total successfully received messages - sum of the messages sent to the upper layer */
  uint32_t rx_messages;
  /** Total successfully received pages */
  uint32_t rx_pages;
  /** Total errors during reception (dropped pages + dropped messages) */
  uint32_t rx_errors;
  /** Total dropped pages (with content) due to errors */
  uint32_t rx_pages_dropped;
  /** Total Rx pages dropped due bad CRC */
  uint32_t rx_pages_bad_crc;
  /** Total Rx pages dropped due to overflow */
  uint32_t rx_pages_dropped_overflow;
  /** Total number of messages dropped */
  uint32_t rx_messages_dropped;
  /** Total number of messages dropped due to bad CRC */
  uint32_t rx_messages_bad_crc;
  /** Total number spi recovery */
  uint32_t spi_recovery_counter;
  /** SPI page size */
  uint32_t spi_page_size;
} dbg_l2_spi_internal_stat_t;


/* l2 internal statistics */
typedef struct {
  uint32_t l2_type;
  union {
    struct {
      uint16_t process_id[4];
      uint32_t process_shared_mem_address[4];
      dbg_l2_shmem_internal_stat_t device_to_host[4];
      dbg_l2_shmem_internal_stat_t host_to_device[4];
    } shmem;

    struct {
      dbg_l2_spi_internal_stat_t stat;
    } spi;
  };
} dbg_l2_internal_stat_get_t;

/* DBG WLAN device ring info */
typedef struct {
  dsp_ring_info_t tx_rings[DSP_TX_RINGS_PER_IF];
  dsp_ring_info_t rx_ring;
} dbg_wlan_device_ring_info_t;

/** DBG WLAN ring info */
typedef struct {
  dbg_wlan_device_ring_info_t device_info[IF_INDEX_MAX];
} dbg_wlan_ring_info_t;

/* DBG WLAN cookie */
typedef struct {
  dsp_cookie_t dsp_cookie_obj;
} dbg_wlan_cookie_t;

/* DBG WLAN extended statistics */
typedef struct {
  uint32_t last_rf_gain;
  uint32_t rx_queue_full_cnt;
  uint32_t htsig_error;
  uint32_t lsig_error;
  uint32_t vhtsiga_error;
  uint32_t vhtsigb_error;
  uint32_t packet_over_packet;
  uint32_t sifs_missed;
} dbg_wlan_extended_stat_t;

/* DBG channel busy ratio */
typedef struct {
  uint32_t slots_busy;
  uint32_t slots_total;
  int32_t noise_floor;
} dbg_wlan_cbr_t;

/* DBG Profiler statistics */
typedef struct {
  uint64_t idle_task_cpu_cycles;
  uint64_t total_cycles_from_last_read;
} dbg_profiler_statistics_t;

typedef struct {
  uint32_t start;
  uint32_t end;
} dbg_boot_timer_phase_t;

typedef struct {
  uint32_t total_time_us;
  uint32_t phases_count;
  dbg_boot_timer_phase_t phases[REMOTE_DBG_BOOT_TIMER_MAX_PHASES];
} dbg_boot_timer_t;

/* DBG logging parameter */
typedef struct {
  uint32_t trigger_type;
  uint32_t antenna_select;
  int32_t  trigger_subframe;
  uint8_t  log_folder_name[LOG_FILE_NAME_PATH_MAX_SIZE];
} dbg_dsp_logging_parameter_t;

/* DBG blob get */
typedef struct {
  uint32_t size;
  uint8_t  buffer[REMOTE_DBG_BLOB_MAX_CHUNK_LENGTH];
} dbg_blob_get_t;

/* DBG blob handle */
typedef struct {
  uint32_t offset : 24 ;
  uint32_t unique_type : 8;
} dbg_blob_extended_data_t;

#endif /* _DBG_H */
