#ifndef _CRYPTO_LAYER_INTERFACE_H
#define _CRYPTO_LAYER_INTERFACE_H

#include <atlk/sdk.h>

typedef enum {
  KEY_INDEX_NEW_KEY,
  KEY_INDEX_OLD_KEY,
  KEY_INDEX_MAX,
} session_key_index_t;

typedef enum {
  MUTEX_ENCRYPT_INDEX,
  MUTEX_DECRYPT_INDEX,
  MUTEX_MAX_INDEX,
} session_key_mutex_handle_index_t;

typedef struct crypto_interface_connection crypto_interface_connection_t;

/**
   Encrypt data using master key

   @note        The AES symmetric encryption is done in place and the message is modified.

   @param[out]  crypto_interface_handle_ptr Pointer to crypto layer interface handle
   @param[in]   data_ptr                    Input data to be encrypted will be used for output as well
   @param[in]   data_size                   The size of the data to be encrypted (must be aligned to 16 byte)
   @param[in]   iv_ptr                      Pointer to initialization vector

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
crypto_layer_interface_cbc_encrypt_with_master_key(const crypto_interface_connection_t *crypto_interface_handle_ptr,
                                                   uint8_t *data,
                                                   uint32_t data_size,
                                                   uint8_t *iv_ptr);

/**
   Decrypt data using master key

   @note        The AES symmetric decryption is done in place and the message is modified.

   @param[out]  crypto_interface_handle_ptr Pointer to crypto layer interface handle
   @param[in]   data_ptr                    Input data to be decrypted will be used for output as well
   @param[in]   data_size                   The size of the data to be decrypted (must be aligned to 16 byte)
   @param[in]   iv_ptr                      Pointer to initialization vector

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
crypto_layer_interface_cbc_decrypt_with_master_key(const crypto_interface_connection_t *crypto_interface_handle_ptr,
                                                   uint8_t *data,
                                                   uint32_t data_size,
                                                   uint8_t *iv_ptr);

/**
   Calculate CMAC tag on data using master key

   @param[out]  crypto_interface_handle_ptr Pointer to crypto layer interface handle
   @param[in]   data_ptr                    Input data to calculate tag
   @param[in]   data_size                   The size of the data (must be aligned to 16 byte)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
crypto_layer_interface_authenticate_with_master_key(const crypto_interface_connection_t *crypto_interface_handle_ptr,
                                                    uint8_t *data_ptr,
                                                    uint32_t data_size,
                                                    uint8_t *tag_ptr);

/**
   Encrypt data using session key

   @note        The AES symmetric encryption is done in place and the message is modified.

   @param[out]  crypto_interface_handle_ptr Pointer to crypto layer interface handle
   @param[in]   data_ptr                    Input data to be encrypted will be used for output as well
   @param[in]   data_size                   The size of the data to be encrypted (must be aligned to 16 byte)
   @param[in]   iv_ptr                      Pointer to initialization vector

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
crypto_layer_interface_cbc_encrypt_with_session_key(const crypto_interface_connection_t *crypto_interface_handle_ptr,
                                                    uint8_t *data_ptr,
                                                    uint32_t data_size,
                                                    uint8_t *iv_ptr);

/**
   Decrypt data using session key

   @note        The AES symmetric decryption is done in place and the message is modified.

   @param[out] crypto_interface_handle_ptr Pointer to crypto layer interface handle
   @param[in]  data_ptr                    Input data to be decrypted will be used for output as well
   @param[in]  data_size                   The size of the data to be decrypted (must be aligned to 16 byte)
   @param[in]  session_key_index           The session key index - only while switching session key we support 2 session keys
   @param[in]   iv_ptr                     Pointer to initialization vector

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
crypto_layer_interface_cbc_decrypt_with_session_key(const crypto_interface_connection_t *crypto_interface_handle_ptr,
                                                    uint8_t *data_ptr,
                                                    uint32_t data_size,
                                                    session_key_index_t session_key_index,
                                                    uint8_t *iv_ptr);

/**
   Calculate CMAC tag on data using session key

   @param[out]  crypto_interface_handle_ptr Pointer to crypto layer interface handle
   @param[in]   data_ptr                    Input data to calculate tag
   @param[in]   data_size                   The size of the data (must be aligned to 16 byte)
   @param[in]   session_key_index           The session key index - only while switching session key we support 2 session keys

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
crypto_layer_interface_tag_compute_with_session_key(const crypto_interface_connection_t *crypto_interface_handle_ptr,
                                                    uint8_t *data_ptr,
                                                    uint32_t data_size,
                                                    uint8_t *tag_ptr,
                                                    session_key_index_t session_key_index);

/**
   compare tags

   @param[in] source_tag_ptr    Pointer received tag
   @param[in] computed_tag_ptr  Pointer computed tag
   @param[in] size              The size of the data (must be aligned to 16 byte)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
crypto_layer_interface_compare_tags(uint8_t *source_tag_ptr, uint8_t *computed_tag, uint8_t size);

/**
   Set master keys in local memory

   @note In real case this function should not be called the keys need to be stored on a secure storage
         Calling this function will save the keys locally

   @param[in] encr_key_ptr  Pointer encryption key buffer
   @param[in] auth_key_ptr  Pointer authentication key buffer
   @param[in] blob_ptr      Pointer blob
   @param[in] key_size      Key size

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
crypto_layer_interface_master_keys_local_set(uint8_t *encr_key_ptr,
                                             uint8_t *auth_key_ptr,
                                             uint8_t *blob_ptr,
                                             uint32_t key_size);

/**
   De-initialize crypto layer interface

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
crypto_layer_interface_deinitialize(void);

/**
   Save session keys locally

   @param[in] session_encr_plain_text_key_ptr  Pointer encryption key buffer
   @param[in] session_auth_plain_text_key_ptr  Pointer authentication key buffer
   @param[in] iv_plain_text_key_ptr            Pointer to initialization vector
   @param[in] key_size                         Key size

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
crypto_layer_interface_session_keys_local_set(uint8_t *session_encr_plain_text_key_ptr,
                                              uint8_t *session_auth_plain_text_key_ptr,
                                              uint8_t *iv_plain_text_key_ptr,
                                              uint32_t key_size);

/**
   Return the crypto layer interface connection handle

   @param[in] crypto_interface_pptr  Pointer to pointer to crypto interface connection_t

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
crypto_layer_interface_handle_get(crypto_interface_connection_t **handle_pptr);

/**
   Lock the use of session key
   @param[in] index The mutex index to use

   @return
  */
void
crypto_layer_interface_session_key_lock(session_key_mutex_handle_index_t index);

/**
   Release session key lock
   @param[in] index The mutex index to use

   @return
  */
void
crypto_layer_interface_session_key_unlock(session_key_mutex_handle_index_t index);

/**
   Return an initialization vector

   @param[out] iv_ptr Pointer to initialization vector

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
   */
atlk_rc_t
crypto_layer_interface_iv_get(const crypto_interface_connection_t *handle_ptr,
                              uint8_t *iv_ptr);

#ifdef __cplusplus
}
#endif

#endif /* _CRYPTO_LAYER_INTERFACE_H */
