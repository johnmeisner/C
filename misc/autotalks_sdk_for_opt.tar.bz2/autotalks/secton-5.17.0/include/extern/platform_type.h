#ifndef _EXTERN_PLATFORM_TYPE_H
#define _EXTERN_PLATFORM_TYPE_H

typedef enum {
  PLATFORM_TYPE_LINUX,
  PLATFORM_TYPE_QNX,
  PLATFORM_TYPE_NA,
} platform_type_t;

platform_type_t
platform_type_get(void);

#endif /* _EXTERN_PLATFORM_TYPE_H */
