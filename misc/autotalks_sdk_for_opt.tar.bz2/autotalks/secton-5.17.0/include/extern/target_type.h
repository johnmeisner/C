#ifndef _EXTERN_TARGET_TYPE_H
#define _EXTERN_TARGET_TYPE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
  TARGET_TYPE_CRATON2,
  TARGET_TYPE_SECTON,
} target_type_t;

typedef enum {
  DEVICE_TYPE_ON_A7,
  DEVICE_TYPE_ON_M3,
} device_type_t;

target_type_t
target_type_get(void);

device_type_t
device_type_get(void);

void
device_type_set(device_type_t type);

#ifdef __cplusplus
}
#endif

#endif /* _EXTERN_TARGET_TYPE_H */
