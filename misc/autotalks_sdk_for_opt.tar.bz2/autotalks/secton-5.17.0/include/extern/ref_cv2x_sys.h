#ifndef _EXTERN_REF_CV2X_SYS_H
#define _EXTERN_REF_CV2X_SYS_H

#include <atlk/sdk.h>
#include <atlk/cv2x.h>
#include <atlk/cv2x_rrc_pre_config.h>

/**
   @file  ref_cv2x_sys.h
   @brief This is a reference CV2X system initialization.
*/

/**
   @brief      A reference code for initializing a CV2X system

   @param[in]  interface_name          Interface names
   @param[in]  application_role_str    An application role string
   @param[out] config_ptr              A pointer to a config struct to fill
   @param[out] rrc_config_ptr          A pointer to an RRC config struct to fill

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t
ref_cv2x_sys_init(CV2X_IN const char *interface_name,
                  CV2X_IN char *application_role_str,
                  CV2X_OUT cv2x_configuration_t *config_ptr,
                  CV2X_OUT cv2x_rrc_pre_config_t *rrc_config_ptr);

/**
   @brief  A reference code for deinitializing a CV2X system

   @retval ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
ref_cv2x_sys_deinit(void);

/**
   @brief     A reference code for generating src_l2id from MAC address.

   @note      Ethernet MAC address is used to generate a unique src_l2id

   @retval    Integer value derived from MAC address
   @return    -1 if failed
*/
int
ref_cv2x_ue_id_get(void);


/**
   @brief      Set syslog destination UID

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
ref_cv2x_sys_logger_destination_register(void);

#endif /* _EXTERN_REF_CV2X_SYS_H */
