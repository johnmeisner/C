/** Copyright (C) 2012-2020 Autotalks Ltd. */
#ifndef _HDIF_SECURE_STORAGE_H_
#define _HDIF_SECURE_STORAGE_H_

#include <secure_hdif.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
  uint32_t key_size;
  uint8_t  encr_key[SECURE_HDIF_MAX_KEY_SIZE];
  uint8_t  auth_key[SECURE_HDIF_MAX_KEY_SIZE];
} secure_storage_master_keys_t;

typedef struct {
  /** Holds master keys blob that need to be sent to the device */
  uint8_t buffer[SECURE_HDIF_MASTER_KEYS_BLOB_SIZE];
} secure_storage_master_keys_blob_t;

/** File Format of the secure storage **/
typedef struct {
  uint32_t                          magic_number;
  uint32_t                          version;
  uint32_t                          master_keys_size;
  uint32_t                          master_blob_size;
  secure_storage_master_keys_t      master_keys;
  secure_storage_master_keys_blob_t master_blob;
} secure_storage_file_format_t;

atlk_rc_t hdif_secure_storage_master_keys_load(const char *storage_path, secure_storage_master_keys_t *master_keys_ptr);

atlk_rc_t hdif_secure_storage_master_keys_save(const char *storage_path, secure_storage_master_keys_t *master_keys_ptr);

atlk_rc_t hdif_secure_storage_master_keys_blob_load(const char *storage_path, secure_storage_master_keys_blob_t *master_keys_blob_ptr);

atlk_rc_t hdif_secure_storage_master_keys_blob_save(const char *storage_path, secure_storage_master_keys_blob_t *master_keys_blob_ptr);

atlk_rc_t hdif_secure_storage_create_empty(const char *storage_path);

atlk_rc_t hdif_secure_storage_exists(const char *storage_path);

#ifdef __cplusplus
}
#endif

#endif /* _HDIF_SECURE_STORAGE_H_ */
