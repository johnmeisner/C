/* Copyright (C) 2019 Autotalks Ltd. */

#ifndef _EXTERN_TIME_SYNC_POTI_H
#define _EXTERN_TIME_SYNC_POTI_H

/* Copyright (C) 2019 Autotalks Ltd. */

#include <atlk/sdk.h>
#include <stdbool.h>

/**
   @brief Get the current PPS lock signal status.

   @return UTC time availablilty (true/false)
*/
bool
time_sync_poti_is_ready(void);

/**
   @brief      Get current UTC time in microseconds since 2004 2004-01-01T00:00:00Z

   @param[out] utc_us_ptr A pointer to the UTC time in microseconds since 2004-01-01T00:00:00Z

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t
time_sync_poti_utc_us_since_2004_get(uint64_t *utc_us_ptr);



#endif /* _EXTERN_TIME_SYNC_POTI_H */
