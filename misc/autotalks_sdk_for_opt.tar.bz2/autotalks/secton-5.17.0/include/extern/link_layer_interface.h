#ifndef LINK_LAYER_INTERFACE_H
#define LINK_LAYER_INTERFACE_H

#include <eui48_utils.h>
#include <atlk/sdk.h>
#include <atlk_packet.h>
#include <atlk/rdev.h>
#include <link_layer/ll_spi_common.h>

#define LL_SOCK_FD_NAME_PREFIX  "ll_sock"
#define LL_SOCK_FD_NAME_DEFAULT LL_SOCK_FD_NAME_PREFIX"0"

#ifdef __cplusplus
extern "C" {
#endif

/** Interface enum */
typedef enum {
  LL_INTERFACE_PRIMARY,
  LL_INTERFACE_SECONDARY,
  LL_INTERFACE_TEE,
  LL_INTERFACE_MAX
} ll_interface_enum_t;

/** Interface connection to link layer options enum */
typedef enum {
  LL_INTERFACE_LINK_LAYER_TYPE_UDP_SOCKET,
  LL_INTERFACE_LINK_LAYER_TYPE_SPI,
  LL_INTERFACE_LINK_LAYER_TYPE_USB,
  LL_INTERFACE_LINK_LAYER_TYPE_LOCAL,
  LL_INTERFACE_LINK_LAYER_TYPE_LOCAL_SHARED_MEMORY,
  LL_INTERFACE_LINK_LAYER_TYPE_MESSAGE_QUEUE,
  LL_INTERFACE_LINK_LAYER_TYPE_SOCKET,
  LL_INTERFACE_LINK_LAYER_TYPE_TEE,
  LL_INTERFACE_LINK_LAYER_TYPE_TEST,
  LL_INTERFACE_LINK_LAYER_TYPE_MAX,
} ll_interface_link_layer_type_enum_t;


typedef struct ll_interface_connection ll_interface_connection_t;

/** SPI link layer config structure */
typedef struct {
  /** SPI clock */
  uint32_t clock_hz;

  /** SPI bits per element 8, 16 or 32 */
  uint8_t element_data_bits;

  /** SPI (0, 1, 2, 3) -> CPOL/CPHA bits (0/0, 0/1, 1/0, 1/1) */
  uint8_t mode;

  /** SPI delay between two transactions [us] */
  uint32_t transaction_delay;

  /** SPI recovery delay between two transactions [us] */
  uint32_t recovery_delay;

  /** SPI page size */
  uint32_t page_size;

  /** SPI transfer size */
  uint32_t slave_transfer_size;
} ll_interface_init_spi_config_t;

/** Link Layer config structure */
typedef struct {
  ll_interface_init_spi_config_t spi;
} ll_interface_init_config_t;

/** Link Layer config structure default initializer */
#define LL_CONFIGURE_INIT                                       \
{                                                               \
  .spi = {                                                      \
    .clock_hz = 0,                                              \
    .element_data_bits = 0,                                     \
    .mode = 0xff,                                               \
    .transaction_delay = LL_SPI_TRANSACTION_DELAY_DEFAULT_USEC, \
    .recovery_delay = LL_SPI_RECOVERY_DELAY_DEFAULT_USEC,       \
    .page_size = LL_SPI_PAGE_SIZE_DEFAULT,                      \
    .slave_transfer_size = LL_SPI_TRANSFER_SIZE_DEFAULT,        \
  },                                                            \
}

/** Unique parameters structure */
typedef struct {
  ll_interface_link_layer_type_enum_t type;
  uint8_t                             header_size;

  union {
    struct {
      uint16_t server_port_number;
      uint16_t broadcast_port_number;
      char     *source_address_ptr;
      char     *source_broadcast_address_ptr;
    } udp_socket;

    struct {
      /* Empty for now*/
    } spi;

    struct {
    /* Empty for now*/
    } usb;

    struct {
      /* Empty for now*/
    } local;

    struct {
      /* Empty for now*/
    } message_queue;

    struct {
      /* Empty for now*/
    } socket;
  };
} ll_interface_link_layer_type_params_t;

/** Unique send parameters structure */
typedef struct {
  union {
    struct {
      uint16_t destination_port_number;
      char     *destination_ip_ptr;
      uint8_t  is_broadcast;
      uint32_t sender_uid;
    } udp_socket;

    struct {
      /* Empty for now*/
    } usb;

    struct {
      /* Empty for now*/
    } spi;

    struct {
      /* Empty for now*/
    } local;

    struct {
      /* Empty for now*/
    } message_queue;

    struct {
      /* Empty for now*/
    } socket;

    struct {
      int tee_wait_time;
    } tee;
  };
} ll_interface_send_params_t;

/** Unique receive parameters structure */
typedef struct {
  union {
    struct {
    uint16_t source_port_number;
    char     *source_ip_ptr;
    } udp_socket;

    struct {
      /* Empty for now*/
    } usb;

    struct {
      /* Empty for now*/
    } spi;

    struct {
      /* Empty for now*/
    } local;

    struct {
      /* Empty for now*/
    } message_queue;

    struct {
      /* Empty for now*/
    } socket;

    struct {
      /* Empty for now*/
    } tee;
  };
} ll_interface_receive_params_t;

/**
   Connection type get, in server mode this function can return the
   secondary or primary ll_interface_connection

   @param[in]  ll_interface holds the connection type index
   @param[out] interface_connection_ptr pointer to the relevant connection type according to the interface

   @return ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
ll_interface_get(ll_interface_enum_t interface, ll_interface_connection_t **ll_interface_handle_pptr);

/**
   Interface de-init, this function de-init all connected Link layers according to the application role

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
ll_interface_deinit(void);

/**
   Interface init, this function init all connected Link layers according to the application role input paramter
   @param[in] interface_name_ptr pointer to device name
   @param[in] config_ptr pointer to link layer configuration staruct
   @param[in] app_role application role enum

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
ll_interface_init(const char *interface_name_ptr, ll_interface_init_config_t *config_ptr);

/**
   Sends the PDU with optional extra parameters using specific link layer send function,
   @param[in] ll_handle_ptr pointer to selected link layer interface handle
   @param[in] send_params_ptr pointer to all link layer specific send parameters (optional)
   @param[in] packet_ptr pointer to packet

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
ll_interface_send(const ll_interface_connection_t *ll_interface_handle_ptr, ll_interface_send_params_t *send_params_ptr, atlk_packet_t *packet_ptr);

/**
   Receive PDU using a selected link layer specific receive function,
   @param[in] ll_handle_ptr pointer to selected link layer interface handle
   @param[in] receive_params_ptr pointer to all link layer specific receive parameters
   @param[in] packet_ptr pointer to packet

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
ll_interface_receive(ll_interface_connection_t *ll_interface_handle_ptr, ll_interface_receive_params_t *receive_params_ptr, atlk_packet_t *packet_ptr);

/**
   Return link layer specific parameters
   @param[in]  handle_ptr pointer to selected link layer functions set
   @param[out] connection_type_params_ptr pointer to connection type params struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
ll_interface_link_layer_type_params_get(const ll_interface_connection_t *ll_interface_handle_ptr, ll_interface_link_layer_type_params_t *connection_type_params_ptr);

/**
   Return the current available space in the link layer

   @return the available space
*/
uint32_t
ll_interface_current_available_space_get(const ll_interface_connection_t *ll_interface_handle_ptr);

/**
   @brief     Register TSF update callback

   @param[in] callback      Callback function to register
   @param[in] update_source Update source to register

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t
ll_interface_tsf_time_callback_register(const ll_interface_connection_t *ll_interface_handle_ptr, tsf_update_cb_t callback, uint8_t update_source);

/**
   @brief     Get TSF WLAN reg map address

   @param[in]  ll_interface_handle_ptr  ll_interface_primary_handle_ptr Pointer to LL specific handles
   @param[out] tsf_base_pptr            Pointer to Pointer that Holds the TSF WLAN map base address

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t
ll_interface_tsf_reg_address_get(const ll_interface_connection_t *ll_interface_handle_ptr, uint32_t **tsf_base_pptr);

#ifdef __cplusplus
}
#endif

#endif /* LINK_LAYER_INTERFACE_H */
