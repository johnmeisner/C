#ifndef _EXTERN_REF_SYS_H
#define _EXTERN_REF_SYS_H

#include <atlk/sdk.h>
#include <atlk/dsm.h>
#include <common/types.h>

#define POTI_OFFSET_PATCH

#define TTY_DEVICE_NAME_MAX_SIZE 32 //NMEA_IO_DEV_NAME_SIZE
#define TTY_DEVICE_PORT_MIN      0
#define TTY_DEVICE_PORT_MAX      9

/** POTI serial device type **/
typedef enum {
  REF_SYS_POTI_TTY_NONE       = 0,
  REF_SYS_POTI_TTY_AMA        = 1,
  REF_SYS_POTI_TTY_ACM        = 2,
  REF_SYS_POTI_TTY_USB        = 3,
  REF_SYS_POTI_TTY_SIM_FILE   = 4,
  REF_SYS_POTI_TTY_MAX        = 5,
} ref_sys_poti_tty_t;

/** POTI GNSS module type **/
typedef enum {
  REF_SYS_POTI_TYPE_UBLOX,
  REF_SYS_POTI_TYPE_TESEO,
  REF_SYS_POTI_TYPE_END
} ref_sys_poti_type_t;

/** POTI messages format type **/
typedef enum {
  REF_SYS_POTI_MESSAGES_FORMAT_BINARY,
  REF_SYS_POTI_MESSAGES_FORMAT_NMEA_STRING,
  REF_SYS_POTI_MESSAGES_FORMAT_END
} ref_sys_poti_messages_format_t;

/**
   @file
   This is a reference system initialization.
*/

typedef atlk_rc_t (*ref_sys_callback_t)(intptr_t param_ptr);

/**
   Retrieve first and last operating interfaces indexes.

   @note It is allowed to retrieve only one of these parameters, and send a NULL pointer for the unneeded one.

   @param[out] first_if_index_ptr Pointer to index of the first operating interface
   @param[out] last_if_index_ptr Pointer to index of the last operating interface

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ref_sys_if_indexes_get(if_index_t *first_if_index_ptr, if_index_t *last_if_index_ptr);

/**
   Retrieve first and last operating RF (antenna) indexes.

   Takes into account SOC type, diversity mode and first/last interface indexes.

   @note It is allowed to retrieve only one of these parameters, and send a NULL pointer for the unneeded one.

   @param[out] first_rf_index_ptr Pointer to index of the first operating RF antena
   @param[out] last_rf_index_ptr Pointer to index of the last operating RF antena

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ref_sys_rf_indexes_get(rf_index_t *first_rf_index_ptr, rf_index_t *last_rf_index_ptr);

/**
   Get IF index from RF index

   @param[in] rf_index       RF antena index
   @param[out] if_index_ptr  Pointer to if index

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ref_sys_antenna_if_index_get(rf_index_t rf_index, if_index_t *if_index_ptr);

/**
   Initialize reference system using command line arguments

   @note This function calls ref_sys_init with NULL for the callback_func parameter

   @note If argv[1] exist it must be the remote interface name

   @param[in] argc Arguments count of application
   @param[in] argc Arguments variables of application
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ref_sys_init_ex(int argc, char *argv[]);

/**
   @brief      Initialize reference system

   @param[in]  callback_func         Callback function
   @param[in]  remote_interface_name Remote interface name (can be NULL)
   @param[in]  application_role_ptr  Application role pointer

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
ref_sys_init(ref_sys_callback_t callback_func,
             char *remote_interface_name,
             char *application_role_ptr,
             char *security_role_ptr);

/**
   @brief     Deinitialize reference system

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ref_sys_deinit(void);

/**
   @brief      Deinitialize reference system

   @param[in]  tty_type         TTY prefix name
   @param[in]  tty_port         TTY port
   @param[out] device_name_ptr  TTY device name. A pre allocated string with size of TTY_DEVICE_NAME_MAX_SIZE.

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ref_sys_poti_device_name_get(ref_sys_poti_tty_t tty_type, int32_t tty_port, char *device_name_ptr);

/**
   @brief      Initialize logger reference system

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
ref_sys_logger_init(void);

/**
   @brief      Deinitialize logger reference system

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
ref_sys_logger_deinit(void);

/**
   @brief      Get host SDK version

   @param[out] sdk_version_major_ptr Major number of SDK version
   @param[out] sdk_version_minor_ptr Minor number of SDK version
   @param[out] sdk_version_patch_ptr Patch number of SDK version

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
ref_sys_sdk_version_get(uint32_t *sdk_version_major_ptr, uint32_t *sdk_version_minor_ptr, uint32_t *sdk_version_patch_ptr);

/**
   @brief      Set syslog destination

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
ref_sys_logger_destination_register(void);

#endif /* _EXTERN_REF_SYS_H */
