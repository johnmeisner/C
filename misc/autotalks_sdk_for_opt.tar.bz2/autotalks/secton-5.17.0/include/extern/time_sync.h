/* Copyright (C) 2019 Autotalks Ltd. */

#ifndef _EXTERN_TIME_SYNC_H
#define _EXTERN_TIME_SYNC_H

/* Copyright (C) 2019 Autotalks Ltd. */

#include <atlk/sdk.h>
#include <atlk/ddm.h>
#include <stdbool.h>

typedef enum {
   TIME_SYNC_READY,
   TIME_SYNC_NOT_READY
} time_sync_status_t;

/**
   @brief This is a reference system initialization for time sync.

   @param[in] service_ptr DDM service instance

   @retval    ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
time_sync_init(ddm_service_t* ddm_service_ptr);

/**
   @fn time_sync_state_get
   Check if system time is synchronized.
   @param[out] a pointer to the status

*/
atlk_rc_t
time_sync_status_get(time_sync_status_t* status_ptr);

/**
   @fn time_sync_state_get
   @brief returns the current time sync state

*/
atlk_rc_t
time_sync_state_str_get(char* state_str, uint32_t str_buffer_size);

/**
   @brief         Non drifting sleep

   @param[in,out] ref_monotonic_time_ptr Pointer to monotonic time reference, from which to start sleeping. Updated after sleep.
   @param[in]     sleep_nsec             Time to sleep in nsec

   @retval        ATLK_OK if succeeded
   @return        Error code if failed
*/
atlk_rc_t
time_sync_non_drifting_sleep(struct timespec *const ref_monotonic_time_ptr, const int64_t sleep_nsec);

/**
   @fn time_sync_deinit
   Deinitialize reference system for time sync

   @return Error code if failed
*/
atlk_rc_t atlk_must_check
time_sync_deinit(void);


#endif /* _EXTERN_TIME_SYNC_H */
