/* Copyright (C) 2020 Autotalks Ltd. */
#ifndef _EXTERN_LOG_READER_H
#define _EXTERN_LOG_READER_H

#include <atlk/sdk.h>
#include <atlk/log.h>

/**
   @file
   Log reader header file
*/

/**
   @brief Initialize and populate log reader database

   @param[out] database_pptr  Pointer to pointer to log reader database

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_reader_database_init(log_reader_database_t **database_pptr);

/**
   @brief Deinitialize log reader database

   @return None
*/
void
log_reader_database_deinit(void);

#endif /* _EXTERN_LOG_READER_H */
