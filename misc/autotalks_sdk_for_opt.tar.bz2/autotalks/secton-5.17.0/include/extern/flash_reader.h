#ifndef _EXTERN_FLASH_LIB_H
#define _EXTERN_FLASH_LIB_H

#include <atlk/sdk.h>

/**
   Read calibration file from flash

   @param[out] buffer_pptr buffer for calibration file
   @param[out] size_ptr size of calibration file

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
flash_reader_partition_get(char **buffer_pptr, size_t *size_ptr);

#endif /* _EXTERN_FLASH_LIB_H */
