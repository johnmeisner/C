/** Copyright (C) 2012-2020 Autotalks Ltd. */
#ifndef _CRYPTO_LAYER_REF_SYS_H_
#define _CRYPTO_LAYER_REF_SYS_H_

/**
   @file
   Autotalks HOST-Device Secure Interface Reference - declarations and macros
*/

#include <atlk/ddm_secure_hdif.h>
#include "target_type.h"
#include <extern/crypto_layer_interface.h>

#ifdef __cplusplus
extern "C" {
#endif
/**
  Crypto layer init

  @param[in]  ddm_service_t pointer to ddm_service_t
  @param[in]  storage_path_str pointer to storage_path_str

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
crypto_layer_ref_sys_init(ddm_service_t *ddm_service_ptr, const char *storage_path_str);

/**
  Get crypto interface handle

  @param[in]  crypto_interface_connection_t pointer to crypto interface handle

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
crypto_layer_ref_sys_interface_handle_get(crypto_interface_connection_t **handle_pptr);

#ifdef __cplusplus
}
#endif

#endif /* _CRYPTO_LAYER_REF_SYS_H_ */
