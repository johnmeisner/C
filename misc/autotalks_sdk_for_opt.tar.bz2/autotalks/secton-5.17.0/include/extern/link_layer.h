#ifndef _EXTERN_LINK_LAYER_H
#define _EXTERN_LINK_LAYER_H

#include <atlk/rdev.h>

/* Get Link Layer device */
rdev_desc_t *
ll_get(const char *dev_name, uint8_t is_called_during_init);

rdev_desc_t *
ll_ipc_get(const char *dev_name, uint8_t is_called_during_init);

rdev_desc_t *
ll_tee_get(const char *dev_name, uint8_t is_called_during_init);

#endif /* _EXTERN_LINK_LAYER_H */
