#ifndef _ECC_INTERNAL_H
#define _ECC_INTERNAL_H

#include <atlk/sdk.h>
#include <atlk/ecc_service.h>

#include <dsm_internal.h>
#include <atlk_queue.h>

#define ECC_CORE_SOCKET_PACKET_QUEUE_LEN 32

typedef uint32_t ecc_core_socket_id_t;

/* ECC core request */
typedef struct {
  /* Generic request */
  ecc_request_t generic;

  /* Additional parameters for specific requests */

  /* ECDSA signing ephemeral private key */
  ecc_scalar_t random;

} ecc_core_request_t;

/* ECC core response */
typedef struct {
  /* Generic response */
  ecc_response_t generic;

} ecc_core_response_t;

typedef struct {
  /* Socket ID */
  ecc_core_socket_id_t socket_id;
  /* Is used socket */
  int is_used;
  /* Pointer to the relevant service */
  dsm_service_desc_t *service;
  /* Pointer to RX packet queue buffer */
  uintptr_t rx_queue_buffer[ECC_CORE_SOCKET_PACKET_QUEUE_LEN];
  /* Pointer to RX packet queue structure */
  queue_handler_t rx_queue;
} ecc_core_socket_t;

/**
   Init ECC core.

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ecc_core_init(void);

/**
   Deinit ECC core.

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ecc_core_deinit(void);

/**
   Create ECC socket.

   @param[in] service_ptr ECC service
   @param[out] socket_pptr ECC socket

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ecc_core_socket_create(dsm_service_desc_t *service_ptr,
                       ecc_core_socket_t **socket_pptr);

/**
   Delete ECC socket.

   @param[in] socket_ptr ECC socket to delete

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ecc_core_socket_delete(ecc_core_socket_t *socket_ptr);

/**
   Handle ECC response

   @param[in] rsp_ptr ECC response to handle
   @param[in] socket_id ECC socket ID of the response

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ecc_core_response_handle(const ecc_core_response_t *rsp_ptr,
                         ecc_core_socket_id_t socket_id);

/**
   Receive ECC response.

   @see @ref wait_usage.

   @param[in] socket_ptr ECC socket
   @param[out] response_ptr ECC response
   @param[in] wait_ptr Wait specification (optional)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ecc_core_response_receive(ecc_core_socket_t *socket_ptr,
                          ecc_core_response_t *response_ptr,
                          const atlk_wait_t *wait_ptr);

#endif /* _ECC_INTERNAL_H */
