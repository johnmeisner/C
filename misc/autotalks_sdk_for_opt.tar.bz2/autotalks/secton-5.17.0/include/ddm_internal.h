#ifndef _CORE_DDM_INTERNAL_H
#define _CORE_DDM_INTERNAL_H

#include <atlk/ddm.h>
#include <atlk/sdk.h>
#include <atlk/ddm_service.h>
#include <common/counters.h>
#include <dsm_internal.h>
#include <atlk/ddm_secure_hdif.h>

#define DDM_CALIB_FILE_MAIN_LOCATION_MASK      0x03U
#define DDM_CALIB_FILE_EXTENDED_EXIST_MASK     0x04U
#define DDM_RF_CONFIG_FILE_MAIN_LOCATION_MASK  0x01U

typedef struct {
  /** code buffer */
  char *code_buffer_ptr;
  /** code size */
  size_t code_size;
  /** data buffer */
  char *data_buffer_ptr;
  /** data size */
  size_t data_size;
  /** cache buffer */
  char *cache_buffer_ptr;
  /** cache size */
  size_t cache_size;
  /** calibration buffer */
  char *calib_buffer_ptr;
  /** calibration size */
  size_t calib_size;
  /** M0 code buffer */
  char *m0_buffer_ptr;
  /** M0 cache size */
  size_t m0_buffer_size;
  /** calibration extended buffer */
  char *calib_buffer_extended_ptr;
  /** calibration extended size */
  size_t calib_extended_size;
  /** calibration buffer */
  char *rf_config_buffer_ptr;
  /** calibration size */
  size_t rf_config_size;
  /** ddm module parms */
  ddm_sw_config_t sw_config;
  /** ddm module internal configuration parameters */
  ddm_sw_config_internal_t sw_config_internal;
} ddm_common_configuration_t;

/** DDM common configuration default initializer */
#define DDM_COMMON_CONF_INIT {        \
  .code_buffer_ptr = 0,               \
  .code_size = 0,                     \
  .data_buffer_ptr = 0,               \
  .data_size = 0,                     \
  .cache_buffer_ptr = 0,              \
  .cache_size = 0,                    \
  .calib_buffer_ptr = 0,              \
  .calib_size = 0,                    \
  .m0_buffer_ptr = 0,                 \
  .m0_buffer_size = 0,                \
  .calib_buffer_extended_ptr = 0,     \
  .calib_extended_size = 0,           \
  .rf_config_buffer_ptr = 0,          \
  .rf_config_size = 0,                \
  .sw_config = {0},                   \
  .sw_config_internal = {0},          \
}

typedef void (*ddm_config_change_notify)(ddm_service_t *service_ptr,
                                         const ddm_configure_t *config_ptr,
                                         void *context_ptr);

/**
   Set device configuration notification call back

   @param[in] service_ptr DDM service instance
   @param[in] handler Pointer to DDM configuration call back function

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
ddm_config_notify_register(ddm_service_t *service_ptr,
                           ddm_config_change_notify handler,
                           void *context_ptr);


atlk_rc_t atlk_must_check
ddm_common_state_get(dsm_service_desc_t *service_ptr,
                     ddm_state_t *state_ptr);

atlk_rc_t atlk_must_check
ddm_common_state_set(dsm_service_desc_t *service_ptr,
                      ddm_state_t state,
                      uint32_t timeout_ms);

atlk_rc_t
ddm_common_secure_hdif_session_key_expire(dsm_service_desc_t *service_ptr,
                                          uint32_t session_key_counter,
                                          uint32_t session_key_counter_max);

atlk_rc_t atlk_must_check
ddm_time_sync_status_set(dsm_service_desc_t *service_ptr,
                      ddm_tsf_lock_status_t time_sync_status);

atlk_rc_t atlk_must_check
ddm_module_init(void);

atlk_rc_t atlk_must_check
ddm_service_register(dsm_service_desc_t *service_ptr);

atlk_rc_t
ddm_common_notify_register(dsm_service_desc_t *service_ptr,
                           ddm_state_change_notify handler,
                           void *context_ptr);

atlk_rc_t
ddm_common_secure_hdif_session_keys_expire_notify_register(dsm_service_desc_t *service_ptr,
                                                           ddm_secure_hdif_session_keys_expire_notify handler);

atlk_rc_t atlk_must_check
ddm_common_time_sync_status_change_notify_register(dsm_service_desc_t *service_ptr,
                                                   ddm_time_sync_status_change_notify handler);

/**
   @brief     Unregister time sync status change callback from callback array

   @param[in] service_ptr Service for which to delete callback
   @param[in] handler     Callback to unregister

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t
ddm_common_time_sync_status_change_notify_unregister(dsm_service_desc_t *service_ptr,
                                                     ddm_time_sync_status_change_notify handler);

/**
   Deinitialize DDM module

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
ddm_deinit(void);

/**
   Returning application's own statistics without device stats.

   @param[in]  type_bitmap Bitmap of services to request, consisting of
                           several bitmaps, each corresponding to a service
   @param[out] buffer      Buffer for statistics
   @param[in]  buffer_size Buffer size

   @retval None
*/
void
ddm_statistic_session_get(uint8_t type_bitmap[DDM_STATISTICS_BITMAP_TYPE_SIZE],
                          uint8_t buffer_ptr[],
                          size_t  buffer_size);

/**
   Application's own statistics without device stats.

   @param[in]  type_bitmap                   Bitmap of services to request, consisting of
                                             Several bitmaps, each corresponding to a service
   @param[out] buffer_ptr                    Buffer for statistics
   @param[in]  buffer_size                   Buffer size
   @param[in]  need_device_stats             Specify getter behavior, see #ddm_stats_get_option_t
   @param[in]  accumulate_from_all_processes If set statistic from all process will be accumulated to this process"
   @param[in]  clear_stats                   Clear statistics"

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_statistic_total_get(uint8_t                type_bitmap[DDM_STATISTICS_BITMAP_TYPE_SIZE],
                        ddm_stats_t            buffer[],
                        size_t                 buffer_size,
                        ddm_stats_get_option_t need_device_stats,
                        uint8_t                accumulate_from_all_processes,
                        uint8_t                clear_stats);

/**
   Returns the minimal buffer size to hold statistics.

   @param[in] need_device_stats Specify getter behavior, see #ddm_stats_get_option_t
   @param[in] type_bitmap       Bitmap of services to request, consisting of
                                several bitmaps, each corresponding to a service

   @return Size of statistics in bytes, 0 on error
*/
size_t
ddm_statistic_min_size_get(ddm_stats_get_option_t need_dev_stats,
                           uint8_t type_bitmap[DDM_STATISTICS_BITMAP_TYPE_SIZE]);

/**
   Indicates that DDM stats TLV received.

   @param[in] data_ptr  Pointer to received data
   @param[in] data_size Size of received data


   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_stats_indication(stats_tlv_t *data_ptr, size_t data_size);

#endif /* _CORE_DDM_INTERNAL_H */
