/* Copyright (C) 2012-2019 Autotalks Ltd. */
#ifndef _ATLK_EUI24_H
#define _ATLK_EUI24_H

#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   24-bit Extended Unique Identifier declarations for L2ID
*/

/** Length of EUI-24 in octets */
#define EUI24_LEN 3

/** 24-bit Extended Unique Identifier */
typedef struct {
  uint8_t octets[EUI24_LEN];
} eui24_t;

/** Initializer that represents an invalid L2ID address */
#define EUI24_ZERO_INIT { .octets = { 0 } }

/** Initializer that represents a broadcast L2ID address */
#define EUI24_BCAST_INIT { \
  .octets = { 0xff, 0xff, 0xff } \
  }

/** Initializer that takes the EUI-24 octets as arguments */
#define EUI24_INIT(_0, _1, _2) { \
  .octets = { (_0), (_1), (_2) } \
  }

/** Format string for EUI-24 */
#define EUI24_FMT "%02x:%02x:%02x"

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_EUI24_H */
