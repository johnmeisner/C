#ifndef _COMMON_TYPES_H
#define _COMMON_TYPES_H

#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   Data rates

   MCS indices are referring to Table 21-30 in IEEE Std 802.11-2016.
*/
typedef enum {
  /** Data rate is N/A */
  DATARATE_NA = 0,

  /** 3 Mbit/s */
  DATARATE_3MBPS,

  /** 4.5 Mbit/s */
  DATARATE_4_5MBPS,

  /** 6 Mbit/s */
  DATARATE_6MBPS,

  /** 9 Mbit/s */
  DATARATE_9MBPS,

  /** 12 Mbit/s */
  DATARATE_12MBPS,

  /** 18 Mbit/s */
  DATARATE_18MBPS,

  /** 24 Mbit/s */
  DATARATE_24MBPS,

  /** 27 Mbit/s */
  DATARATE_27MBPS,

  /** 36 Mbit/s */
  DATARATE_36MBPS,

  /** 48 Mbit/s */
  DATARATE_48MBPS,

  /** 54 Mbit/s */
  DATARATE_54MBPS,

  /** Use MCS 0 regardless of bandwidth */
  DATARATE_MCS_0,

  /** Use MCS 1 regardless of bandwidth */
  DATARATE_MCS_1,

  /** Use MCS 2 regardless of bandwidth */
  DATARATE_MCS_2,

  /** Use MCS 3 regardless of bandwidth */
  DATARATE_MCS_3,

  /** Use MCS 4 regardless of bandwidth */
  DATARATE_MCS_4,

  /** Use MCS 5 regardless of bandwidth */
  DATARATE_MCS_5,

  /** Use MCS 6 regardless of bandwidth */
  DATARATE_MCS_6,

  /** Use MCS 7 regardless of bandwidth */
  DATARATE_MCS_7,

} datarate_t;

/** Default data rate */
#define DATARATE_DEFAULT_VALUE DATARATE_6MBPS

/** MAC User Priority */
typedef int8_t user_priority_t;

/** MAC User Priority minimum value */
#define USER_PRIORITY_MIN 0

/** MAC User Priority maximum value */
#define USER_PRIORITY_MAX 7

/** Value indicating that MAC User Priority is N/A */
#define USER_PRIORITY_NA INT8_MIN

/** Power in units of dBm */
typedef int8_t power_dbm_t;

/** Value indicating that power in units of dBm is N/A */
#define POWER_DBM_NA INT8_MIN

/** Power in units of 1/8 dBm */
typedef int16_t power_dbm8_t;

/** Value indicating that power in units of 1/8 dBm is N/A */
#define POWER_DBM8_NA INT16_MIN

/** 1/8 dBm to dBm conversion factor */
#define POWER_DBM8_PER_DBM 8

/**
   @file
   Autotalks common types
*/

/** MAC interface index */
typedef uint8_t if_index_t;

/** RF antenna index */
typedef uint8_t rf_index_t;

/** Value indicating that MAC interface index is N/A */
#define IF_INDEX_NA UINT8_MAX

/** MAC interface max number */
#define IF_INDEX_MAX 2U

/** RF antenna max number */
#define RF_INDEX_MAX 2U

/** Value indicating that CBR is N/A */
#define CBR_NA INT32_MIN

#ifdef __cplusplus
}
#endif

#endif /* _COMMON_TYPES_H */
