/** Copyright (C) 2019 Autotalks Ltd. */
#ifndef _ATLK_COUNTERS_H
#define _ATLK_COUNTERS_H

#include <remote_service/remote_counters.h>
#include <inttypes.h>

typedef remote_atlk_counters_t atlk_counters_t;

#define ATLK_COUNTERS_INIT REMOTE_COUNTERS_INIT

#define STATS_USE_SHARED_MEMORY 1

/** Statistics counters type, for updation via internal function */
typedef enum {
  /** Receive packet */
  RX_PACKET,

  /** Send packet */
  TX_PACKET,

  /** Receive byte */
  RX_BYTE,

  /** Send byte */
  TX_BYTE,

  /** Receive error */
  RX_ERROR,

  /** Send error */
  TX_ERROR,

  /** Receive dropped */
  RX_DROP,

  /** Send dropped */
  TX_DROP,
} atlk_counters_type_t;

/** Statistics services */
/** @note: This ENUM should be Host-Device identical */
typedef enum {
  STATS_SERVICE_TYPE_ITER_FIRST = 0U,
  STATS_SERVICE_TYPE_COMMON = 0U,
  STATS_SERVICE_TYPE_V2X,
  STATS_SERVICE_TYPE_CBR,
  STATS_SERVICE_TYPE_SYMMETRIC_CRYPTO,
  STATS_SERVICE_TYPE_HASH,
  STATS_SERVICE_TYPE_ECC,
  STATS_SERVICE_TYPE_EHSM,
  /* Per interface IVN statistics */
  STATS_SERVICE_TYPE_IVN_0,
  STATS_SERVICE_TYPE_IVN_1,
  STATS_SERVICE_TYPE_DDM,
  STATS_SERVICE_TYPE_WDM,
  STATS_SERVICE_TYPE_DSM,

  STATS_SERVICE_TYPE_MAX
} stats_service_type_t;

/** Statistics layers per service */
typedef enum {
  STATS_LAYER_TYPE_ITER_FIRST = 0U,

  /* Common or corresponding layers */
  STATS_LAYER_TYPE_LL = 0U,
  STATS_LAYER_TYPE_SECONDARY_LL,
  STATS_LAYER_TYPE_TEE_LL,
  STATS_LAYER_TYPE_RT,
  STATS_LAYER_TYPE_RSVC,
  STATS_LAYER_TYPE_SERVICE,

  /* Host-specific layers*/
  STATS_LAYER_TYPE_HOST_SERVICE,
  STATS_LAYER_TYPE_HOST_API,

  /* Device-specific layers*/
#define STATS_LAYER_TYPE_DEVICE_DRIVER STATS_LAYER_TYPE_HOST_SERVICE
#define STATS_LAYER_TYPE_DEVICE_HW     STATS_LAYER_TYPE_HOST_API

  STATS_LAYER_TYPE_MAX,
} stats_layer_type_t;

/** Meta-statistics, stats on stats */
#define STATS_SERVICE_TYPE_META STATS_SERVICE_TYPE_MAX

/* Meta stats and common structures for platform/sdk */
typedef struct {
  /* Registration-related metacounters */
  uint8_t  registered_blocks;
  uint8_t  direct_flow_counters_number;
  uint8_t  indirect_flow_counters_number;
  uint8_t  ext_counters_number;
  uint32_t ext_counters_total_size;

  /* Efficiency metacounters */
  uint8_t  overregistrations;
  uint32_t memory_overhead;
} __attribute__((packed)) stats_meta_stats_t;

typedef struct {
  uint8_t  service;
  uint8_t  layer;
  uint8_t  is_host_layer;
  uint16_t length;
  uint16_t pid;

  /* parasoft-begin-suppress MISRA2012-RULE-18_7-2 "We need a flexible array to implement various record formats" */
  uint8_t data[];
  /* parasoft-end-suppress MISRA2012-RULE-18_7-2 */
} stats_tlv_t;

typedef uint32_t atlk_counter_t;

/** DDM statistics */
typedef struct {
  /** Ingress from lower layer */
  atlk_counter_t il_success;
  atlk_counter_t il_fail;
  atlk_counter_t il_bytes;

  /** Ingress from upper layer */
  atlk_counter_t iu_success;
  atlk_counter_t iu_fail;
  atlk_counter_t iu_bytes;

  /** Egress counters */
  atlk_counter_t el_success;
  atlk_counter_t el_bytes;
  atlk_counter_t eu_success;
  atlk_counter_t eu_bytes;

  /** Operation errors */
  atlk_counter_t op_up_error;
  atlk_counter_t op_down_error;

  /**
     Data area for custom statistics.
     Must be last.
  */
  uint32_t custom_counters[0];
} atlk_flow_counters_t;

/**
   Convert atlk_flow_counters_t to atlk_counters_t.

   This is a backward compatibility interface for smooth transition from atlk_counters_t
   to atlk_flow_counters_t using and providing by layers. It's particularly useful until all
   of the layers start using atlk_flow_counters_t.

   @param[in]  src_ptr Pointer to source stats
   @param[out] dst_ptr Pointer to destination stats

   @return None
*/
static inline void
ddm_stats_convert_to_counters(atlk_flow_counters_t *src_ptr, atlk_counters_t *dst_ptr)
{
  dst_ptr->rx_packets = src_ptr->eu_success;
  dst_ptr->tx_packets = src_ptr->el_success;
  dst_ptr->rx_bytes   = src_ptr->eu_bytes;
  dst_ptr->tx_bytes   = src_ptr->el_bytes;
  dst_ptr->rx_errors  = src_ptr->op_up_error;
  dst_ptr->tx_errors  = src_ptr->op_down_error;
  /* Flow counters op_up_error and op_down_errors represent all receive and send failures */
  dst_ptr->rx_dropped = 0;
  dst_ptr->tx_dropped = 0;
}

/** DDM statistics types */
typedef struct {
  stats_service_type_t service;
  stats_layer_type_t   layer;
} ddm_statistic_type_t;

/**
   Callback provided by the statistics producing block, which invert dependency
   for statistics gathering layer: producing block declares a callback for
   aggregating custom statistics of different applications.
*/
typedef void (*consolidate_stats_t)(const atlk_flow_counters_t *stats_ptr,
                                    atlk_flow_counters_t *result_ptr);

/**
   Initialize statistic object for requested service.

   @param[in] type_ptr             Predefined enum unique id of a statistics producing block.
   @param[in] data_size            Necessary size for statistics.
   @param[in] consolidate_stats_cb Callback to aggregate statistic

   @note Minimum data_size should correspond to flow counters,
         while max is unlimited for the purpose of custom counters adding.

   @return Pointer to allocated statistic object, NULL in error
*/
atlk_flow_counters_t* atlk_must_check
ddm_stats_init(const ddm_statistic_type_t *type_ptr,
               const size_t               data_size,
               consolidate_stats_t        gather_cb);

/**
   Free allocated resources for statistics layer.

   @param[in] type_ptr Predefined enum unique id of a statistics producing block.
   @param[in] unlink   Boolean requesting statistics layer to clean up shared memory
                       (normally, statistics is kept in a storage until next device restart).
                       It might be especially effective for SECTON operating on x86 host.

  @return None
*/
void
ddm_stats_free(const ddm_statistic_type_t *type_ptr, unsigned int unlink);

/**
   Callback to consolidate flow counters.

   @param[in]  stats_ptr  Statistics to aggregation
   @param[out] result_ptr Memory for the result of aggregation

   @retval None
   @return None
*/
void
ddm_stats_flow_counters_consolidate_cb(const atlk_flow_counters_t *stats_ptr,
                                       atlk_flow_counters_t *result_ptr);

#endif /* _ATLK_COUNTERS_H */
