/* Copyright (C) 2014-2016 Autotalks Ltd. */
#ifndef _ATLK_COMPILER_H
#define _ATLK_COMPILER_H

/**
   @file
   Compiler specific attributes, declarations and macros
*/

/** Attribute to mark functions whose return code must be checked */
/* parasoft off (suppress MISRA2012-RULE-20_9_a) */
#if !defined __CC_ARM && \
  ((__GNUC__ >= 4) || ((__GNUC__ == 3) && (__GNUC_MINOR__ >= 4)))
#define atlk_must_check __attribute__((warn_unused_result))
#else
#define atlk_must_check
#endif
/* parasoft on */

/** Compiler branch hint support */
#if defined __MIZRA_PARASOFT_CPPTEST_SUPPRESS
#define atlk_likely(x) (x)
#define atlk_unlikely(x) (x)
#elif defined __CC_ARM || defined __GNUC__
#define atlk_likely(x) __builtin_expect(!!(x), 1)
#define atlk_unlikely(x) __builtin_expect(!!(x), 0)
#elif defined __MET__
#define atlk_likely(x) _Usually(x)
#define atlk_unlikely(x) _Rarely(x)
#else
#define atlk_likely(x) (x)
#define atlk_unlikely(x) (x)
#endif /* __MIZRA_PARASOFT_CPPTEST_SUPPRESS */

/** Explicit function inlining support */
#if defined __CC_ARM || defined __GNUC__
#define atlk_inline static __inline
#elif defined __MET__
#define atlk_inline static _Inline
#else
#define atlk_inline static
#endif

/** Format string checking support */
#if defined __CC_ARM || defined __GNUC__
#define atlk_format_printf(format_index, value_index) \
  __attribute__ ((format (printf, (format_index), (value_index)) ))
#else
#define atlk_format_printf(format_index, value_index)
#endif

/** No-return function attribute */
#if defined __CC_ARM || defined __GNUC__
#define atlk_no_return __attribute__ ((noreturn))
#else
#define atlk_no_return
#endif

/** Packed attribute */
#if defined (__CC_ARM) || defined (__GNUC__)
#define atlk_packed __attribute__ ((packed))
#else
#define #error "Cannot build, no atlk_packed definition"
#endif

/** Compiler memory access optimization barrier */
#if defined (__CC_ARM) || defined (__GNUC__)
#define optimization_barrier() __asm__ __volatile__ ( "" : : : "memory" )
#else
#define #error "Cannot build, no optimization_barrier definition"
#endif

#endif /* _ATLK_COMPILER_H */
