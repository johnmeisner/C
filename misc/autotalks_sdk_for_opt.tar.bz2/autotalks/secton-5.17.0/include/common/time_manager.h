/* Copyright (C) 2021 Autotalks Ltd. */
#ifndef _TIME_MANAGER_H
#define _TIME_MANAGER_H

#include <atlk/ddm.h>
#include <time_manager_internal.h>

/**
   @file
   Time manager
*/

/**
   @brief     Initialize time manager

   @param[in] update_source Update source, to signal if updating TSF will be done via heartbeat or LL
   @param[in] ll_interface_primary_handle_ptr Pointer to LL specific handles

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t
time_manager_init(uint8_t update_source, void *ll_interface_primary_handle_ptr);

/**
   @brief      Get TSF value

   @note       Used internally by the log_driver module and LL SPI, contains no trace prints

   @param[out] time_usec_ptr           TSF value
   @param[out] accuracy_usec_ptr       Accuracy in usec
   @param[out] ddm_tsf_lock_status_ptr TSF lock status

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t
time_manager_tsf_get(uint64_t *time_usec_ptr, uint64_t *accuracy_usec_ptr, ddm_tsf_lock_status_t *ddm_tsf_lock_status_ptr);

/**
   @brief  Deinitilize time manager

   @return None
*/
void
time_manager_deinit(void);

#endif /* _TIME_MANAGER_H */
