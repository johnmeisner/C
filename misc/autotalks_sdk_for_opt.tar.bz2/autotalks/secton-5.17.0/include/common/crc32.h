/* Copyright (C) 2019 Autotalks Ltd. */
#ifndef _CRC32_H_
#define _CRC32_H_

/**
  @file
  CRC32 calculation method
*/

/**
  Calculate CRC32 for a given buffer

  @param[in] crc32val previous CRC value
  @param[in] buffer_ptr buffer to calculate the CRC on
  @param[in] length buffer length

  @return the CRC value
*/
uint32_t
crc32_calculate(uint32_t crc32val, const uint8_t *buffer_ptr, uint32_t length);

#endif /* _CRC32_H_ */ 
