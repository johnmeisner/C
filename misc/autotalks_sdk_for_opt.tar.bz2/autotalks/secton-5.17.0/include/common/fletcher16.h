#ifndef _FLETCHER16_H
#define _FLETCHER16_H

/* Copyright (C) 2021 Autotalks Ltd. */

/**
  @file
  Fletcher16 checksum calculation method
*/

/**
  Update Fletcher16 csum with a given buffer data

  @param[in] buffer_ptr buffer to calculate the csum on
  @param[in] length buffer length

  @return the csum value
*/
uint16_t fletcher16_calculate(const uint8_t *buffer_ptr, size_t length);

#endif /* _FLETCHER16_H */

