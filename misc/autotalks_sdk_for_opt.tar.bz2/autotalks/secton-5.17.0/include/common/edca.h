#ifndef _COMMON_EDCA_H
#define _COMMON_EDCA_H

#ifdef __cplusplus
extern "C" {
#endif


/** EDCA Access Categories */
typedef enum {
  /** Background access category */
  EDCA_AC_BK = 0,

  /** Best effort access category */
  EDCA_AC_BE,

  /** Video access category */
  EDCA_AC_VI,

  /** Voice access category */
  EDCA_AC_VO,

  /** Access category count */
  EDCA_AC_COUNT,

} edca_ac_t;


/** EDCA configuration */
typedef struct {
  /** Arbitration interframe space number in the range 1..15 */
  uint32_t aifsn;

  /**
     Minimum contention window
     A value of the form 2^n-1 in the range 0..255
  */
  uint32_t cwmin;

  /**
     Maximum contention window
     A value of the form 2^n-1 in the range 0..65535
  */
  uint32_t cwmax;

  /**
     Maximum burst time (in units of 32usecs) in the range 0..65535
     0 means disabled
  */
  uint32_t txop_limit;

  /**
     Maximum duration (in time units) an MSDU would be retained
     before it is discarded. Value in the range 0..500

     @todo Currently @msdu_lifetime is not supported.
  */
  uint32_t msdu_lifetime;
} edca_config_t;

/** EDCA configuration static initializer */
#define WDM_EDCA_CONFIG_INIT { \
  .aifsn = 1, \
  .cwmin = 0, \
  .cwmax = 0, \
  .txop_limit = 0, \
  .msdu_lifetime = 0, \
}

#ifdef __cplusplus
}
#endif

#endif /* _COMMON_EDCA_H */
