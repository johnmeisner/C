#ifndef _POTI_PROXY_H_
#define _POTI_PROXY_H_

#include <poti/poti.h>

#endif /* _POTI_PROXY_H_ */
