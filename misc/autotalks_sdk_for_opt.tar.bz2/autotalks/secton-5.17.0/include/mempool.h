#ifndef MEMPOOL_H_
#define MEMPOOL_H_

#include <osal.h>

/** Memory pool descriptor. */
typedef void* mempool_desc_t;

/**
 * initialize the memory pool
 * @param[in] pool_ptr pointer to a buffer to use as pool
 * @param[in] pool_size buffer size
 *
 * @return memory pool descriptor
 */
mempool_desc_t
mempool_init(void *pool_ptr,
             unsigned int pool_size);

/**
 * initialize the memory pool with extra settings
 * @param[in] pool_ptr pointer to a buffer to use as pool
 * @param[in] pool_size buffer size
 * @param[in] min_block_size min size of an allocated block (in bytes)
 * @param[in] alignment_size alignment size (in bits)
 * @param[in] check_mode buffer size
 * @param[in] clear_mode buffer size
 * @param[in] min_size_mode buffer size
 *
 * @return memory pool descriptor
 */
mempool_desc_t
mempool_init_ex(void *pool_ptr,
                unsigned int pool_size,
                unsigned int min_block_size,
                unsigned int alignment_size,
                int check_mode, /* check pool after every action */
                int clear_mode, /* clear allocated buffers */
                int min_size_mode); /* return best block or first one */

/*
 * release the initialized memory pool
 *
 * @param[in] mpool memory pool descriptor
 *
 * return 0 on ok -1 on failure
 */
int
mempool_release(mempool_desc_t mpool);

/*
 * release the initialized memory pool
 *
 * @param[in] mpool memory pool descriptor
 * @param[in] nbytes size to allocate
 *
 * return pointer to buffer, NULL on failure
 */
void *
mempool_malloc(mempool_desc_t mpool, unsigned int nbytes);

/*
 * release an allocated memory buffer
 *
 * @param[in] mpool memory pool descriptor
 * @param[in] ap buffer pointer to free
 *
 * return 0 on ok -1 on failure
 */
int
mempool_free(mempool_desc_t mpool, void *ap);


#endif
