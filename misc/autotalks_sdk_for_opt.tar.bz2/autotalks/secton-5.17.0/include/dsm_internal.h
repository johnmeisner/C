#ifndef _CORE_DSM_INTERNAL_H
#define _CORE_DSM_INTERNAL_H

#include <atlk/dsm.h>
#include <osal.h>

#define DSM_DEVICE_MAX_COUNT 4U

/** Device descriptor */
typedef struct {
  /** Device name */
  char device_name[DSM_NAME_MAX_LEN];
  /** Device type */
  dsm_device_type_t device_type;
  /** Pointer to primary Link Layer interface */
  ll_interface_connection_t *ll_interface_primary_handle_ptr;
  /** Pointer to secondary Link Layer interface */
  ll_interface_connection_t *ll_interface_secondary_handle_ptr;
  /** Pointer to Trusted Execution Environment Link Layer interface */
  ll_interface_connection_t *ll_interface_tee_handle_ptr;
  /** RX thread */
  pthread_t rx_primary_thread;
  /** RX thread */
  pthread_t rx_secondary_thread;
  /** TEE RX thread */
  pthread_t rx_tee_thread;
  /**
     Device wait option for blocking functions
     which do not have wait option in API
  */
  atlk_wait_t wait_option;

  uint16_t service_broadcast_disable_bitfield;

  /** Pointer to secure hdif descriptor */
  crypto_interface_connection_t *crypto_interface_handle_ptr;
} dsm_device_desc_t;

int
dsm_service_type_valid(dsm_service_type_t type);

typedef struct {
  /* Time to wait between request and response when using OPTEE  in msec */
  int     tee_wait_time;
  sem_t   tee_sem;
} dsm_tee_context_t;

typedef struct dsm_service_desc {
  char service_name[DSM_NAME_MAX_LEN];
  dsm_service_type_t service_type;
  dsm_device_desc_t *device_ptr;
  int32_t log_level;
  dsm_tee_context_t tee_context;
  int service_use_tee;
} dsm_service_desc_t;

atlk_rc_t atlk_must_check
dsm_service_get(const char *service_name,
                dsm_service_desc_t **service_ptr,
                dsm_service_type_t service_type);

atlk_rc_t atlk_must_check
dsm_service_locate(dsm_device_desc_t *device_ptr,
                   dsm_service_type_t service_type,
                   dsm_service_desc_t **service_pptr);

#endif /* _CORE_DSM_INTERNAL_H */
