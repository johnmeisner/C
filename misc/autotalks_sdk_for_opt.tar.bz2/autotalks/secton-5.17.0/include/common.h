#ifndef _CORE_COMMON_H
#define _CORE_COMMON_H

#include <atlk/sdk.h>
#include <mempool.h>
#include <osal.h>
#include <macros.h>

#ifdef __cplusplus
extern "C" {
#endif

#define ATLK_MEMCPY_32_ALIGNMENT_SIZE_BYTE  32U

#if defined (__arm__)
/**
   Fast memory copying by using 'load and store multiple registers' assembly commands

   @note Source and destination must be 32 bit aligned
   @note Number of bytes to copy must be a multiple of 32 bytes
   @note Function is implemented in assembly code at  arm_memcpy_32.S

   @param[in] dest_ptr Destination pointer
   @param[in] src_ptr Source pointer
   @param[in] nbytes Number of bytes to copy

   @return 0 if succeeded, -1 if failed

*/
int arm_memcpy_32(void *dest_ptr, const void *src_ptr, size_t nbytes);

/**
   Optimized memory copying by using 'load and store multiple registers' assembly commands

   Deals with the special small sizes, then races to reach 32b alignment of the destination.
   Test for misalignment with the source. If the (source - dest alignment) & 3 != 0 then use the misaligned path.
   For the aligned path, iterate through the data, 32 bytes at a time. Then handle a word at a time, then a byte.
   For the misaligned path, Consider misaligned - 1, 2, or 3 bytes, and handle each with the appropriate shifts needed.

   @note Function is implemented in assembly code at arm_memcpy.S

   @param[in] dest_ptr Destination pointer
   @param[in] src_ptr Source pointer
   @param[in] nbytes Number of bytes to copy

   @return void
*/
void arm_memcpy(void *dest_ptr, const void *src_ptr, size_t nbytes);
#endif //  (__arm__)

/** Multi process application role options enum */
typedef enum {
  ATLK_APPLICATION_ROLE_CLIENT,
  ATLK_APPLICATION_ROLE_SERVER,
  ATLK_APPLICATION_ROLE_STAND_ALONE,
} atlk_application_role_enum_t;

/** Security role of application */
typedef enum {
  ATLK_SECURITY_NON_TRUSTED,
  ATLK_SECURITY_TRUSTED,
} atlk_security_role_t;

typedef enum {
  ATLK_AFFINITY_MODE_DISABLE,
  ATLK_AFFINITY_MODE_SPECIFIC_THREADS_ONLY,
  ATLK_AFFINITY_MODE_ENTIRE_PROCESS,
  ATLK_AFFINITY_MODE_INVALID,
} atlk_affinity_mode_t;

/* Need to be the same as in the device */
typedef enum {
  CRATON_DEV_IOC_READ_PROCESS_SHARED_MEMORY_SIZE_OPCODE = 0,
  CRATON_DEV_IOC_IS_DEVICE_ON_M3_OPCODE,
  CRATON_DEV_IOC_DO_NOT_USE,
  CRATON_DEV_IOC_SOC_VERSION_GET_OPCODE,
} craton_dev_ioc_t;

atlk_rc_t atlk_must_check
atlk_mutex_create(pthread_mutex_t *mutex_ptr);

atlk_rc_t atlk_must_check
atlk_cond_create(pthread_condattr_t *cond_attr_ptr, pthread_cond_t *cond_ptr);

atlk_rc_t atlk_must_check
atlk_cond_destroy(pthread_condattr_t *cond_attr_ptr, pthread_cond_t *cond_ptr);

void
hex_dump(uint8_t* data, size_t size, int ascii_only);

atlk_rc_t atlk_must_check
one_byte_checksum(const uint8_t *buf, size_t buf_size, uint8_t *checksum);

extern mempool_desc_t atlk_mempool_desc;

void *
atlk_malloc(size_t size);

void
atlk_free(void *ptr);

atlk_inline void
atlk_memcpy(void *dest, const void *src, size_t size)
{
  (void)memcpy(dest, src, size);
}

atlk_inline atlk_rc_t
atlk_memcpy_32(void *dest, const void *src, size_t size)
{
#if defined (__arm__)
  if (arm_memcpy_32(dest, src, size) != 0) {
    return ATLK_E_UNSPECIFIED;
  }
#else
  (void)dest;
  (void)src;
  (void)size;

  return ATLK_E_UNSUPPORTED;
#endif //  (__arm__)

  return ATLK_OK;
}

atlk_inline void
atlk_memset(void *dest, int c, size_t size)
{
  unsigned int filler = (unsigned int)c & 0xFFU;

  (void)memset(dest, (int)filler, size);
}

atlk_rc_t
atlk_usec_to_timespec(size_t usec,
                      struct timespec *ts_ptr);

/**
   Deinitialize common module

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
common_deinit(void);

/**
  Return the application role
  @return application role
*/

atlk_application_role_enum_t
atlk_application_role_get(void);

/**
  Set the application role
  @param[in] role app role

  @return void
*/
void
atlk_application_role_set(atlk_application_role_enum_t role);

/**
 * @brief Get security role of application
 *
 * @param void
 *
 * @return atlk_security_role_t ATLK_SECURITY_NON_TRUSTED or
 *         ATLK_SECURITY_TRUSTED
 */
atlk_security_role_t
atlk_security_role_get(void);

/**
 * @brief Set security role of application
 *
 * @param sec_role ATLK_SECURITY_NON_TRUSTED or
 *                 ATLK_SECURITY_TRUSTED
 */
void
atlk_security_role_set(atlk_security_role_t sec_role);

/**
 * @brief affinity mode set,
 * this function can fix a entire process or flag to certain threads to work with certain CPU/CPUs
 *
 * @param affinity_mode    holds the affinity mode
 *
 * @retval ::ATLK_OK if succeeded
 * @return Error code if failed
 */
atlk_rc_t
atlk_affinity_mode_set(atlk_affinity_mode_t affinity_mode);

/**
 * @brief affinity mode get
 *
 * @param affinity_mode_ptr    Pointer to affinity mode
 *
 * @retval ::ATLK_OK if succeeded
 * @return Error code if failed
 */
atlk_rc_t
atlk_affinity_mode_get(atlk_affinity_mode_t *affinity_mode_ptr);

/**
 * @brief affinity cpu mask set,
 * Set CPU mask: 8 bit are supported '1' represent working CPU, call this function before atlk_affinity_mode_set
 *
 * @param affinity_mode    holds the affinity mode
 *
 * @retval ::ATLK_OK if succeeded
 * @return Error code if failed
 */
atlk_rc_t
atlk_affinity_cpu_mask_set(uint8_t cpu_mask);

/**
 * @brief affinity cpu mask get,
 *
 * @param cpu_mask_ptr    Pointer to affinity cpu mask
 *
 * @retval ::ATLK_OK if succeeded
 * @return Error code if failed
 */
atlk_rc_t
atlk_affinity_cpu_mask_get(uint8_t *cpu_mask_ptr);

/**
 * @brief set a specific thread according to affinity mode
 * will do something only in case atlk_affinity_mode_set was called with ATLK_AFFINITY_MODE_SPECIFIC_THREADS_ONLY
 *
 *  @param pthread_t    holds the pointer to the thread struct control block
 *
 * @retval ::ATLK_OK if succeeded
 * @return Error code if failed
 */
atlk_rc_t
atlk_affinity_thread_set(pthread_t *thread_ptr);

/** Signed unit scale conversion factors */
#define CENTI_PER_UNIT  100
#define MILLI_PER_UNIT  1000
#define MICRO_PER_MILLI 1000
#define NANO_PER_MICRO  1000
#define MICRO_PER_UNIT  1000000
#define NANO_PER_MILLI  1000000
#define NANO_PER_UNIT   1000000000

/** Unsigned unit scale conversion factors */
#define CENTI_PER_UNIT_UNSIGNED  100U
#define MILLI_PER_UNIT_UNSIGNED  1000U
#define MICRO_PER_MILLI_UNSIGNED 1000U
#define NANO_PER_MICRO_UNSIGNED  1000U
#define MICRO_PER_UNIT_UNSIGNED  1000000U
#define NANO_PER_MILLI_UNSIGNED  1000000U
#define NANO_PER_UNIT_UNSIGNED   1000000000U

#ifdef __cplusplus
}
#endif

#endif /* _CORE_COMMON_H */
