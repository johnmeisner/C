#ifndef _ATLK_PACKET_H
#define _ATLK_PACKET_H

#include <string.h>

#include <atlk/sdk.h>
#include <common.h>

typedef struct atlk_packet {
  /** Packet data start pointer. Marks physical boundary of the packet start */
  uint8_t *packet_data_start;

  /** Packet data end pointer. Marks physical boundary of the packet end */
  uint8_t *packet_data_end;

  /** Pointer to the first byte written closest to packet data start */
  uint8_t *packet_prepend_ptr;

  /** Pointer to the byte after the last byte written in the buffer.  */
  uint8_t *packet_append_ptr;
} atlk_packet_t;

atlk_inline void
atlk_packet_check(const atlk_packet_t *packet)
{
  BUG_ON(packet == NULL);
  BUG_ON(packet->packet_prepend_ptr == NULL);
  BUG_ON(packet->packet_append_ptr == NULL);
  BUG_ON(packet->packet_append_ptr < packet->packet_prepend_ptr);
}

atlk_inline atlk_rc_t
atlk_packet_init(atlk_packet_t *packet, uint8_t *buffer, size_t size,
                 size_t head_size, size_t tail_size)
{
  atlk_rc_t rc;

  NULL_PARAM_CHECK2(packet, buffer, rc);
  if (atlk_error(rc)) {
    return rc;
  }

  packet->packet_data_start = buffer;
  packet->packet_data_end = buffer + size;
  packet->packet_prepend_ptr = buffer + head_size;
  packet->packet_append_ptr = buffer + size - tail_size;

  atlk_packet_check(packet);

  return ATLK_OK;
}

atlk_inline atlk_rc_t
atlk_packet_data_put(atlk_packet_t *packet, const uint8_t *data, size_t size,
                     size_t offset)
{
  atlk_packet_check(packet);
  if (packet->packet_prepend_ptr + size + offset > packet->packet_append_ptr) {
    return ATLK_E_OUT_OF_BOUNDS;
  }

  atlk_memcpy(packet->packet_prepend_ptr + offset, data, size);

  return ATLK_OK;
}

#if 0 // Obsolete
atlk_inline atlk_rc_t
atlk_packet_prepend(atlk_packet_t *packet,
                    const void *data,
                    size_t size)
{
  if (packet->packet_prepend_ptr - size < packet->packet_data_start) {
    return ATLK_E_OUT_OF_BOUNDS;
  }

  packet->packet_prepend_ptr -= size;

  atlk_memcpy(packet->packet_prepend_ptr, data, size);

  return ATLK_OK;
}
#endif

atlk_inline atlk_rc_t
atlk_packet_reserve_head(atlk_packet_t *packet,
                         size_t size,
                         uint8_t **reserved_space)
{
  if (reserved_space == NULL) {
    return ATLK_E_INVALID_ARG;
  }

  if (packet->packet_prepend_ptr - size < packet->packet_data_start) {
    return ATLK_E_OUT_OF_BOUNDS;
  }

  packet->packet_prepend_ptr -= size;
  *reserved_space = packet->packet_prepend_ptr;

  return ATLK_OK;
}


atlk_inline atlk_rc_t
atlk_packet_append(atlk_packet_t *packet,
                   const void *data,
                   size_t size)
{
  if (packet->packet_append_ptr + size > packet->packet_data_end) {
    return ATLK_E_OUT_OF_BOUNDS;
  }

  atlk_memcpy(packet->packet_append_ptr, data, size);

  packet->packet_append_ptr += size;

  return ATLK_OK;
}

#if 0 // Obsolete
atlk_inline atlk_rc_t
atlk_packet_reserve_tail(atlk_packet_t *packet,
                         size_t size,
                         uint8_t **reserved_space)
{
  if (reserved_space == NULL) {
    return ATLK_E_INVALID_ARG;
  }

  if (packet->packet_append_ptr + size >= packet->packet_data_end) {
    return ATLK_E_OUT_OF_BOUNDS;
  }

  *reserved_space = packet->packet_append_ptr;

  packet->packet_append_ptr += size;

  return ATLK_OK;
}
#endif

atlk_inline size_t
atlk_packet_size_get(const atlk_packet_t *packet)
{
  ptrdiff_t delta = packet->packet_append_ptr - packet->packet_prepend_ptr;

  atlk_packet_check(packet);

  return (size_t)delta;
}

atlk_inline size_t
atlk_packet_free_space_get(const atlk_packet_t *packet)
{
  ptrdiff_t delta = packet->packet_data_end - packet->packet_append_ptr;

  atlk_packet_check(packet);

  return (size_t)delta;
}

atlk_inline void *
atlk_packet_start_ptr(const atlk_packet_t *packet,
                      size_t *size)
{
  atlk_packet_check(packet);

  if (size) {
    *size = atlk_packet_size_get(packet);
  }

  return packet->packet_prepend_ptr;
}

/* parasoft-begin-suppress BD-PB-UCMETH-4 "This function is only used in ref_src/ code that is excluded from MISRA build" */
atlk_inline void *
atlk_packet_end_ptr(const atlk_packet_t *packet,
                    size_t *free_space_ptr)
{
  atlk_packet_check(packet);

  if (free_space_ptr) {
    *free_space_ptr = atlk_packet_free_space_get(packet);
  }

  return packet->packet_append_ptr;
}
/* parasoft-end-suppress BD-PB-UCMETH-4 "This function is only used in ref_src/ code that is excluded from MISRA build" */

atlk_inline void
atlk_packet_free(atlk_packet_t *packet)
{
  atlk_packet_check(packet);

  atlk_free(packet->packet_data_start);

  packet->packet_data_start = NULL;
}

atlk_inline atlk_rc_t
atlk_packet_header_strip(atlk_packet_t *packet, size_t size)
{
  atlk_packet_check(packet);

  if (packet->packet_prepend_ptr + size  > packet->packet_append_ptr) {
    return ATLK_E_OUT_OF_BOUNDS;
  }

  packet->packet_prepend_ptr += size;

  return ATLK_OK;
}

#endif /* _ATLK_PACKET_H */
