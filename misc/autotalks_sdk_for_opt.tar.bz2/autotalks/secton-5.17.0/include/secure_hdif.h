/** Copyright (C) 2016 Autotalks Ltd. */
#ifndef _ATLK_SECURE_HDIF_H_
#define _ATLK_SECURE_HDIF_H_

#include <atlk/dsm.h>
#include <atlk/ddm_service.h>
#include <atlk/ddm_secure_hdif.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
  If this flag is set, only the required space for the packet security operation will be reserved on the packet.
  And the actual security operation (encryption/decryption/authentication) will not be execute.
  It is needed for client server topology. As the client dosn't enforce the security level on the packet,
  but it needs to save the extra space on the packet. Later to be used by the server,
  in order to perform the secure HDIF operation on packet.
 */
#define SECURE_HDIF_SKIP_SECURITY_OPERATION_MASK    (1U << 7)

/* 16 byte alignment is required as this is the smallest block that the crypto engine can work on */
#define SECURE_HDIF_16_BYTE_ALIGNMENT     0x10U
#define SECURE_HDIF_HEADER_SIZE           (SECURE_HDIF_MAC_TAG_SIZE + SECURE_HDIF_IV_SIZE)

/** Secure HDIF security levels */
typedef enum {
  SECURE_HDIF_SECURITY_LEVEL_NONE = 0U,
  SECURE_HDIF_SECURITY_LEVEL_AUTHENTICATE,
  SECURE_HDIF_SECURITY_LEVEL_ENCRYPT,
  SECURE_HDIF_SECURITY_LEVEL_SKIP_SECURITY_OPERATION_MASK = SECURE_HDIF_SKIP_SECURITY_OPERATION_MASK,
} secure_hdif_security_levels_t;

/**
   Store locally the security levels table

   @param[in] service_type        the service id
   @param[in] security_levels_ptr pointer to security level struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
secure_hdif_local_security_levels_set(dsm_service_type_t service_type, ddm_secure_hdif_service_security_levels_t *security_levels_ptr);

/**
  * @brief
  * @param       service_type  Service type to query
  * @param       message_id   Message id to query
  * @param       level_ptr    [out] The level id for the service_type:message id
  * @return      ATLK_OK On success
  */
/**
   Get the locally stored security level for the message id

   @param[in] service_type the service id
   @param[in] message_id   the service opcode
   @param[out] security_level_ptr   the message id security level

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
secure_hdif_local_security_level_get(dsm_service_type_t service_type, uint8_t message_id, secure_hdif_security_levels_t  *security_level_ptr);
#ifdef __cplusplus
}
#endif

#endif /* _ATLK_SECURE_HDIF_H_ */
