#ifndef _CORE_LOG_CORE_H
#define _CORE_LOG_CORE_H

#include <atlk/sdk.h>
#include <atlk/log.h>

typedef enum {
  LOG_CORE_LOG_TYPE_ENCODED = 0,
  LOG_CORE_LOG_TYPE_REGULAR,
  LOG_CORE_LOG_TYPE_MAX,
} log_core_log_type_t;

/**
   Initialize logger core

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_core_init(void);

/**
   De-initialize logger core

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_core_deinit(void);

/**
   Enqueue log message

   @param[in] component_name  Component name (Optional)
   @param[in] log_type        Log type
   @param[in] level           Log level
   @param[in] file_name       File name (Optional)
   @param[in] line_number     Line number
   @param[in] log_message     Message to be logged

   @return None
*/
void
log_core_log_enqueue(const char *component_name,
                     log_core_log_type_t log_type,
                     log_level_t level,
                     char *file_name,
                     uint32_t line_number,
                     void *log_message,
                     ...);

/**
   Dequeue log message

   @param[in] wait_ptr      Wait specification (optional)
   @param[out] message_ptr  Pointer to formatted log message

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_core_log_dequeue(const atlk_wait_t *wait_ptr, log_formatted_message_t *message_ptr);

/**
   Log message to console

   @param[in] level           Log level
   @param[in] full_file_name  Full file name with path
   @param[in] line_number     Line number
   @param[in] log_message     Message to be logged

   @return None
*/
void
log_core_log_immediate(log_level_t level,
                       char *full_file_name,
                       uint32_t line_number,
                       char *log_message,
                       ...);

/**
   Set log decoding database

   @param[in] database_ptr  Pointer to log database struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_core_log_database_set(log_reader_database_t *database_ptr);

/**
   Set log level

   @param[in] log_level   Log level

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_core_level_set(log_level_t log_level);

/**
   Returns if log level is valid

   @param[in] log_level               Log level
   @param[out] is_log_level_valid_ptr Pointer to log level validity

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_core_level_is_valid(log_level_t log_level, uint8_t *is_log_level_valid_ptr);

#endif /* _CORE_LOG_CORE_H */
