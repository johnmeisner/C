#ifndef _ATLK_80211_H_
#define _ATLK_80211_H_


/**
   80211 headers definitions.
*/
#define ATLK80211_FCTL_VERS                  0x0003U
#define ATLK80211_FCTL_FTYPE                 0x000cU
#define ATLK80211_FCTL_STYPE                 0x00f0U
#define ATLK80211_FCTL_TODS                  0x0100U
#define ATLK80211_FCTL_FROMDS                0x0200U
#define ATLK80211_FCTL_PROTECTED             0x4000U
#define ATLK80211_FTYPE_MGMT                 0x0000U
#define ATLK80211_FTYPE_CTL                  0x0004U
#define ATLK80211_FTYPE_DATA                 0x0008U
#define ATLK80211_STYPE_ACTION               0x00D0U
#define ATLK80211_STYPE_QOS_DATA             0x0080U
#define ATLK80211_QOS_CTL_TID_MASK           0x000fU
#define ATLK80211_QOS_CTL_EOSP               0x0010U
#define ATLK80211_QOS_CTL_ACK_POLICY_NORMAL  0x0000U
#define ATLK80211_QOS_CTL_ACK_POLICY_NOACK   0x0020U
#define ATLK80211_QOS_CTL_LEN                2U

#define ATLK80211_HDR_FRAME_CTRL(X) ((X)->frame_control)
#define ATLK80211_HDR_DURATION_ID(X) ((X)->duration_id)
#define ATLK80211_HDR_ADDR1(X) ((X)->addr1)
#define ATLK80211_HDR_ADDR2(X) ((X)->addr2)
#define ATLK80211_HDR_ADDR3(X) ((X)->addr3)
#define ATLK80211_HDR_SEQ_CTRL(X) ((X)->seq_ctrl)

#define ATLK80211_QOS_HDR_FRAME_CTRL(X) ((X)->frame_control)
#define ATLK80211_QOS_HDR_DURATION_ID(X) ((X)->duration_id)
#define ATLK80211_QOS_HDR_ADDR1(X) ((X)->addr1)
#define ATLK80211_QOS_HDR_ADDR2(X) ((X)->addr2)
#define ATLK80211_QOS_HDR_ADDR3(X) ((X)->addr3)
#define ATLK80211_QOS_HDR_SEQ_CTRL(X) ((X)->seq_ctrl)
#define ATLK80211_QOS_HDR_QOS_CTRL(X) ((X)->qos_ctrl)

#define VSA_CATEGORY_FIELD_LEN               1U

/* IEEE802.11 QOS Header (26 Byte) */
typedef struct atlk_ieee80211_qos_hdr {
  uint16_t frame_control;
  uint16_t duration_id;
  uint8_t addr1[EUI48_LEN];
  uint8_t addr2[EUI48_LEN];
  uint8_t addr3[EUI48_LEN];
  uint16_t seq_ctrl;
  uint16_t qos_ctrl;
} __attribute__((packed)) atlk_ieee80211_qos_hdr_t;

typedef struct atlk_ieee80211_hdr_3addr {
  uint16_t frame_control;
  uint16_t duration_id;
  uint8_t addr1[EUI48_LEN];
  uint8_t addr2[EUI48_LEN];
  uint8_t addr3[EUI48_LEN];
  uint16_t seq_ctrl;
} __attribute__((packed)) atlk_ieee80211_hdr_3addr_t;

static inline int atlk_80211_is_data_present(uint16_t fc)
{
  return ((fc & (ATLK80211_FCTL_FTYPE | 0x40U)) ==
    ATLK80211_FTYPE_DATA) ? 1 : 0;
}

static inline int atlk_80211_is_data_qos(uint16_t fc)
{
  /*
   * mask with QOS_DATA rather than ATLK80211_FCTL_STYPE as we just
   * need to check the one bit
   */
  return ((fc & (ATLK80211_FCTL_FTYPE |
    ATLK80211_STYPE_QOS_DATA)) ==
   (ATLK80211_FTYPE_DATA | ATLK80211_STYPE_QOS_DATA)) ? 1 : 0;
}

#endif /* _ATLK_80211_H_ */
