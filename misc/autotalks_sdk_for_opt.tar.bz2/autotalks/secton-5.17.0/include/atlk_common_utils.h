#ifndef _ATLK_COMMON_UTILS_H
#define _ATLK_COMMON_UTILS_H

/**
   Print call stcuk - relevant only for Linux
   @note Host need to be compiled with symbols (--gdb)
*/
void atlk_backtrace_print(void);

#endif /* _ATLK_COMMON_UTILS_H */
