/** Copyright (C) 2017 Autotalks Ltd. */
#ifndef _ATLK_EHSM_H
#define _ATLK_EHSM_H

#include <atlk/sdk.h>
#include <atlk/ecc.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Lifecycle bit masks defines */
#define EHSM_LIFECYCLE_CSK_PROGRAMMED_BIT_MASK                          (1 << 0)
#define EHSM_LIFECYCLE_CSK_DELETED_BIT_MASK                             (1 << 1)
#define EHSM_LIFECYCLE_TAMPER_STANDBY_ENABLE_BIT_MASK                   (1 << 2)
#define EHSM_LIFECYCLE_TAMPER_NORMAL_ENABLE_BIT_MASK                    (1 << 3)
#define EHSM_LIFECYCLE_MASTER_PAIRING_KEY_CREATION_DISABLED_BIT_MASK    (1 << 4)
#define EHSM_LIFECYCLE_IMPORT_KEY_CREATION_DISABLED_BIT_MASK            (1 << 5)
#define EHSM_LIFECYCLE_IMPORT_PLAINTEXT_ECC_KEY_DISABLED_BIT_MASK       (1 << 6)
#define EHSM_LIFECYCLE_IMPORT_PLAINTEXT_SYMMETRIC_KEY_DISABLED_BIT_MASK (1 << 7)
#define EHSM_LIFECYCLE_TRNG_RANDOM_DATA_GENERATION_DISABLED_BIT_MASK    (1 << 8)
#define EHSM_LIFECYCLE_IMPORT_PLAINTEXT_HMAC_KEY_DISABLED_BIT_MASK      (1 << 9)

/** Embedded HSM service instance */
typedef atlk_handle_t ehsm_service_t;

typedef enum {
  /* Key isn't programmed and CSK value is zero */
  EHSM_CSK_STATUS_EMPTY = 0x0,

  /* Key isn't programmed and CSK value isn't zero */
  EHSM_CSK_STATUS_PARTIAL,

  /* Key programmed and CSK isn't deleted */
  EHSM_CSK_STATUS_PROGRAMMED,

  /* Key programmed and CSK is deleted */
  EHSM_CSK_STATUS_DELETED,

  /* Error reading the CSK, CSK checksum or lifecycle word from OTP */
  EHSM_CSK_STATUS_OTP_FAILURE,

  /* CSK checksum mismatch */
  EHSM_CSK_STATUS_CHECKSUM_FAILURE,
} ehsm_csk_status_t;

typedef enum {
  /** Embedded HSM is not initialized */
  EHSM_SYSTEM_STATUS_UNINITIALIZED = 0x0,

  /** Embedded HSM is initialized in M3 access mode */
  EHSM_SYSTEM_STATUS_INITIALIZED_M3_ACCESS,

  /** Embedded HSM is initialized in A7 access mode */
  EHSM_SYSTEM_STATUS_INITIALIZED_A7_ACCESS,
} ehsm_system_status_t;

typedef enum {
  /** SHE is not initialized */
  EHSM_SHE_STATUS_UNINITIALIZED = 0x0,

  /** SHE is initialized */
  EHSM_SHE_STATUS_INITIALIZED,

  /** SHE initialization failed */
  EHSM_SHE_STATUS_FAILURE,
} ehsm_she_status_t;

typedef enum {
  /** OTP is not initialized */
  EHSM_OTP_STATUS_UNINITIALIZED = 0x0,

  /** OTP is initialized */
  EHSM_OTP_STATUS_INITIALIZED,

  /** OTP disturbance was indicated during initialization */
  EHSM_OTP_STATUS_INIT_DISTURBED,
} ehsm_otp_status_t;

typedef enum {
  /** OTP is not initialized */
  EHSM_CRYPTOGRAPHIC_KEY_MANAGEMENT_STATUS_DISABLED = 0x0,

  /** OTP is initialized */
  EHSM_CRYPTOGRAPHIC_KEY_MANAGEMENT_STATUS_ENABLED,
} ehsm_cryptographic_key_management_status_t;

typedef enum {
  /** ROM integrity test*/
  EHSM_SELF_TEST_ROM_TEST,

  /** Symmetric test */
  EHSM_SELF_TEST_SYMMETRIC_TEST,

  /** SHA test */
  EHSM_SELF_TEST_SHA_TEST,

  /** HMAC test */
  EHSM_SELF_TEST_HMAC_TEST,

  /** ECDSA test */
  EHSM_SELF_TEST_ECDSA_TEST,

  /** DRBG test */
  EHSM_SELF_TEST_DRBG_TEST,

} ehsm_self_test_t;

#define EHSM_SELF_TEST_LAST_TEST EHSM_SELF_TEST_DRBG_TEST

typedef struct {
  uint8_t chip;
  uint8_t firmware_major;
  uint8_t firmware_minor;
} ehsm_version_t;

/** Embedded HSM information */
typedef struct {
  /** Embedded HSM version */
  ehsm_version_t version;

  /** ROM integrity test counter */
  uint32_t rom_integrity_test_counter;

  /** Tamper status */
  uint32_t tamper_counter;

  /** Lifecycle status, see 'Lifecycle bit masks defines' */
  uint32_t lifecycle_status;

  /** Cryptographic key management status, see ehsm_cryptographic_key_management_status_t */
  uint32_t cryptographic_key_management_status;

  /** CSK status, see ehsm_csk_status_t */
  uint8_t csk_status;

  /** System status, see ehsm_system_status_t */
  uint8_t system_status;

  /** SHE status, see ehsm_she_status_t */
  uint8_t she_status;

  /** OTP status, see ehsm_otp_status_t */
  uint8_t otp_status;

  /** FIPS mode */
  uint8_t fips_mode;
} ehsm_info_t;

/** Embedded HSM ECC blob size in bytes */
#define EHSM_ECC_BLOB_SIZE             116

/** eHSM Symmetric key parameter maximum size in bytes */
#define EHSM_SYMMETRIC_KEY_SIZE        32U

/** Embedded HSM Symmetric blob size in bytes */
#define EHSM_SYMMETRIC_BLOB_SIZE       84U

/** Embedded HSM Symmetric tag size in bytes */
#define EHSM_SYMMETRIC_TAG_SIZE        16U

/** Embedded HSM tag size in bytes*/
#define EHSM_TAG_SIZE                  52U

/** Embedded HSM KDF parameter maximum size in bytes */
#define EHSM_KDF_PARAM_MAX_SIZE        128U

/** Embedded HSM ECIES key maximum size in bytes */
#define EHSM_ECIES_KEY_MAX_SIZE        128U

/** Embedded HSM ECIES shared key maximum size in bytes */
#define EHSM_ECIES_SHARED_KEY_MAX_SIZE 256U

/** Embedded HSM ECIES data maximum size in bytes */
#define EHSM_ECIES_DATA_MAX_SIZE       64U

/** Embedded HSM random data maximum size in bytes */
#define EHSM_RANDOM_DATA_MAX_SIZE      512U

/** Embedded HSM associated data (AAD) maximum size in bytes */
#define EHSM_ASSOCIATED_DATA_MAX_SIZE  256U

/** Embedded HSM plaintext / data maximum size in bytes */
#define EHSM_DATA_MAX_SIZE             1024U

/** Embedded HSM hashed MAC blob size in bytes including blob type*/
#define EHSM_MAC_BLOB_SIZE             180U

/** Embedded HSM hashed MAC key maximum size in bytes */
#define EHSM_MAC_KEY_MAX_SIZE          128U

/** SHA-256 digest size in octets */
#define EHSM_SHA_256_DIGEST_SIZE       32U

/** SHA-384 digest size in octets */
#define EHSM_SHA_384_DIGEST_SIZE       48U

/** SHA-512 digest size in octets */
#define EHSM_SHA_512_DIGEST_SIZE       64U

/** Embedded HSM hashed MAC key maximum size in bytes */
#define EHSM_MAC_TAG_MAX_SIZE          64U

/** Private key type */
typedef enum {
  /** Private key that cannot interact with other private keys */
  EHSM_PRIVATE_KEY_TYPE_ISOLATED = 0,

  /** Private key whose public key counterpart can be a member of a CSR */
  EHSM_PRIVATE_KEY_TYPE_CSR_MEMBER = 1,

  /** Private key that can be used to sign a CSR */
  EHSM_PRIVATE_KEY_TYPE_CSR_SIGNER = 2,

  /** Private key that can be input to ::ehsm_ecc_private_key_multiply_add */
  EHSM_PRIVATE_KEY_TYPE_MA_INPUT = 3,

  /** Private key that is the output of ::ehsm_ecc_private_key_multiply_add */
  EHSM_PRIVATE_KEY_TYPE_MA_OUTPUT = 4,

  /** Private key that can interact with CA (certification authority) */
  EHSM_PRIVATE_KEY_TYPE_CA = 5,

} ehsm_private_key_type_t;

/** Public key algorithm */
typedef enum {
  /** Public key for ECDSA */
  EHSM_PUBLIC_KEY_ALGORITHM_ECDSA = 0,

  /** Key derivation for ECIES */
  EHSM_PUBLIC_KEY_ALGORITHM_PARTIAL_ECIES = 1,

  /** Public key for ECIES */
  EHSM_PUBLIC_KEY_ALGORITHM_ECIES = 2

} ehsm_public_key_algorithm_t;

/** Private key information */
typedef struct {
  /** Elliptic curve used with this key */
  ecc_curve_t key_curve;

  /** Type of key */
  ehsm_private_key_type_t key_type;

  /** Intended algorithm for key */
  ehsm_public_key_algorithm_t key_algorithm;

} ehsm_ecc_private_key_info_t;

/** Embedded HSM OTP word error correction type */
typedef enum {
  /** OTP word type redundancy */
  EHSM_OTP_WORD_TYPE_REDUNDANCY = 0,

  /** OTP word type ECC */
  EHSM_OTP_WORD_TYPE_ECC = 1

} ehsm_otp_word_type_t;

/** Boot security level */
typedef enum {
  /** Non secure boot */
  EHSM_BOOT_NON_SECURE_BOOT = 0,

  /** Secure boot */
  EHSM_BOOT_SECURE_BOOT
} ehsm_secure_boot_security_level_t;

typedef enum {
  /** Disable FIPS Mode */
  EHSM_BOOT_FIPS_MODE_DISABLED = 0,

  /** Enable FIPS Mode */
  EHSM_BOOT_FIPS_MODE_ENABLED
} ehsm_secure_boot_fips_mode_t;

/** Security version level */
typedef uint32_t ehsm_secure_boot_security_version_level_t;

/** Maximum security level */
#define EHSM_BOOT_SECURITY_VERSION_LEVEL_MAX 32U

/** Certificate minimal version */
typedef uint32_t ehsm_secure_boot_certificate_revision_level_t;

/** Minimum certificate revision level */
#define EHSM_BOOT_CERT_REVISION_LEVEL_MIN 0U

/** Maximum certificate revision level */
#define EHSM_BOOT_CERT_REVISION_LEVEL_MAX 16U

/** Maximum size in bytes of the alternate HASH */
#define EHSM_BOOT_DIGEST_MAX_HASH_BYTE_SIZE 64U

/** Alternate HASH algorithm */
typedef enum {
  /** Alternative HASH digest is of type SHA 224 (28 bytes) */
  EHSM_BOOT_ALT_HASH_ALGO_SHA_224 = 0,

  /** Alternative HASH digest is of type SHA 256 (32 bytes) */
  EHSM_BOOT_ALT_HASH_ALGO_SHA_256 = 1,

  /** Alternative HASH digest is of type SHA 384 (48 bytes) */
  EHSM_BOOT_ALT_HASH_ALGO_SHA_384 = 2,

  /** Alternative HASH digest is of type SHA 512 (64 bytes) */
  EHSM_BOOT_ALT_HASH_ALGO_SHA_512 = 3,

  /** Algorithm is of type NIST-P256 (64 bytes) */
  EHSM_BOOT_ALT_ALGO_NIST_256 = 4,

  /** Algorithm is of type NIST-P384 (96 bytes) */
  EHSM_BOOT_ALT_ALGO_NIST_384 = 5
} ehsm_secure_boot_alt_hash_algo_t;

/** eHSM Exchange rules */
typedef enum {
  EHSM_EXCHANGE_ROLE_RECEIVER = 0,
  EHSM_EXCHANGE_ROLE_SENDER
} ehsm_exchange_role_t;

/** Symmetric key type */
typedef enum {
  /** AES 128 */
  EHSM_SYMMETRIC_KEY_TYPE_AES_128 = 0,

  /** AES 256 */
  EHSM_SYMMETRIC_KEY_TYPE_AES_256 = 1,

  /** AES 192 */
  EHSM_SYMMETRIC_KEY_TYPE_AES_192 = 2,

  /** SM4 128 */
  EHSM_SYMMETRIC_KEY_TYPE_SM4_128 = 3,
} ehsm_symmetric_key_type_t;

/** Symmetric key mode */
typedef enum {
  /** ECB */
  EHSM_SYMMETRIC_KEY_MODE_ECB = 0,

  /** CBC */
  EHSM_SYMMETRIC_KEY_MODE_CBC = 1,

  /** CCM */
  EHSM_SYMMETRIC_KEY_MODE_CCM = 2,

  /** CMAC */
  EHSM_SYMMETRIC_KEY_MODE_CMAC = 3,
} ehsm_symmetric_key_mode_t;

/** Symmetric key restriction */
typedef enum {
  /** Symmetric key that can be used without restrictions */
  EHSM_SYMMETRIC_KEY_RESTRICTION_NONE = 0,

  /** Symmetric key that can be used only for encrypt/generate */
  EHSM_SYMMETRIC_KEY_RESTRICTION_ENCRYPT_GENERATE = 1,

  /** Symmetric key that can be used only for decrypt/verify */
  EHSM_SYMMETRIC_KEY_RESTRICTION_DECRYPT_VERIFY = 2,
} ehsm_symmetric_key_restriction_t;

/** Symmetric key information */
typedef struct {
  /** Type of key */
  ehsm_symmetric_key_type_t key_type;

  /** Intended mode for key */
  ehsm_symmetric_key_mode_t key_mode;

  /** Restriction used with this key */
  ehsm_symmetric_key_restriction_t key_restriction;
} ehsm_symmetric_key_info_t;

/** SM4 block size in octets */
#define EHSM_SYMMETRIC_SM4_BLOCK_SIZE 16u

/** SM4 nonce minimum size in octets */
#define EHSM_SYMMETRIC_SM4_NONCE_MIN_SIZE 7u

/** SM4 nonce maximum size in octets */
#define EHSM_SYMMETRIC_SM4_NONCE_MAX_SIZE 13u

/** SM4 associated data maximum sizes in octets */
#define EHSM_SYMMETRIC_SM4_ADATA_MAX_SIZE 0xFF00u

/** SM4 MAC Authentication tag minimum size in octets */
#define EHSM_SYMMETRIC_SM4_MAC_TAG_MIN_SIZE 4u

/** SM4 MAC Authentication tag maximum size in octets */
#define EHSM_SYMMETRIC_SM4_MAC_TAG_MAX_SIZE 16u

typedef enum {
  /** Hashed MAC key type begin enum iterator, must be first */
  EHSM_MAC_KEY_TYPE_BEGIN = 0,

  /** Hashed MAC key that can be used only for SHA-256 */
  EHSM_MAC_KEY_TYPE_SHA256 = EHSM_MAC_KEY_TYPE_BEGIN,

  /** Hashed MAC key that can be used only for SHA-384 */
  EHSM_MAC_KEY_TYPE_SHA384 = 1,

  /** Hashed MAC key that can be used only for SHA-512 */
  EHSM_MAC_KEY_TYPE_SHA512 = 2,

  /** Hashed MAC key type end enum iterator, must be last */
  EHSM_MAC_KEY_TYPE_END,
} ehsm_mac_key_type_t;

typedef enum {
  /** Hashed MAC key restriction begin enum iterator, must be first */
  EHSM_MAC_KEY_RESTRICTION_BEGIN = 0,

  /** Hashed MAC key that can be used without restrictions */
  EHSM_MAC_KEY_RESTRICTION_NONE = EHSM_MAC_KEY_RESTRICTION_BEGIN,

  /** Hashed MAC key that can be used only for MAC generation / signing */
  EHSM_MAC_KEY_RESTRICTION_GENERATE_ONLY = 1,

  /** Hashed MAC key that can be used only for MAC verification */
  EHSM_MAC_KEY_RESTRICTION_VERIFY_ONLY = 2,

  /** Hashed MAC key restriction end enum iterator, must be last */
  EHSM_MAC_KEY_RESTRICTION_END,
} ehsm_mac_key_restriction_t;

typedef struct {
  /** Type of key */
  ehsm_mac_key_type_t type;

  /** Size of key */
  uint8_t size;

  /** Restriction used with this key */
  ehsm_mac_key_restriction_t restriction;
} ehsm_mac_key_info_t;

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_EHSM_H */
