/** Copyright (C) 2020 Autotalks Ltd. */
#ifndef _ATLK_LOG_SERVICE_H
#define _ATLK_LOG_SERVICE_H

#include <atlk/sdk.h>
#include <atlk/log.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
  @file
  System log API
*/

/* Log trace macros */
#define LOG_SERVICE_TRACE_ERROR(_component_name, _message_format, ...) LOG_SERVICE_TRACE((_component_name),   \
                                                                                         LOG_LEVEL_ERROR,     \
                                                                                         __LINE__,            \
                                                                                         __FILE__,            \
                                                                                         (_message_format), ##__VA_ARGS__)

#define LOG_SERVICE_TRACE_WARNING(_component_name, _message_format, ...) LOG_SERVICE_TRACE((_component_name), \
                                                                                           LOG_LEVEL_WARNING, \
                                                                                           __LINE__,          \
                                                                                           __FILE__,          \
                                                                                           (_message_format), ##__VA_ARGS__)

#define LOG_SERVICE_TRACE_INFO(_component_name, _message_format, ...) LOG_SERVICE_TRACE((_component_name),    \
                                                                                         LOG_LEVEL_INFO,      \
                                                                                         __LINE__,            \
                                                                                         __FILE__,            \
                                                                                         (_message_format), ##__VA_ARGS__)

#define LOG_SERVICE_TRACE(_component_name, _level, _line, _file, _message_format, ...)                        \
  do {                                                                                                        \
      atlk_rc_t rc;                                                                                           \
      log_message_t log_message;                                                                              \
      uint8_t is_log_level_valid;                                                                             \
                                                                                                              \
      rc = log_level_is_valid(NULL, (_level), &is_log_level_valid);                                           \
      if ( (atlk_likely(rc == ATLK_OK)) && (atlk_likely(is_log_level_valid != 0)) ) {                         \
       (void)snprintf(log_message.message, LOG_MESSAGE_MAX_SIZE, (_message_format), ##__VA_ARGS__);           \
        log_message.file_name      = (_file);                                                                 \
        log_message.component_name = (_component_name);                                                       \
        log_message.line_number    = (_line);                                                                 \
        log_message.level          = (_level);                                                                \
                                                                                                              \
        log_message_add(NULL, &log_message);                                                                  \
      }                                                                                                       \
  } while (0);

/**
  Get LOG service instance

  @param[in] service_name   Name of service (NULL for default)
  @param[out] service_pptr  Pointer to pointer to LOG service instance

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_service_get(const char *service_name, log_service_t **service_pptr);

/**
   Get Device log version

   @param[in] service_ptr   LOG service instance
   @param[out] version_ptr  Pointer to log version struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_device_version_get(log_service_t *service_ptr, log_version_t *version_ptr);

/**
   Verify validity of message log level

   @note Compares against Host log level

   @param[in] service_ptr             LOG service instance
   @param[in] log_level               Log level
   @param[out] is_log_level_valid_ptr Pointer to log level validity

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_level_is_valid(log_service_t *service_ptr, log_level_t log_level, uint8_t *is_log_level_valid_ptr);

/**
   Add log message to log queue

   @param[in] service_ptr   LOG service instance
   @param[in] message_ptr   Pointer to log message struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
log_message_add(log_service_t *service_ptr, log_message_t *message_ptr);


/**
 * The below APIs are used as part of the logger infrastructure, implemented in ref_sys_logger module
 */

/**
   Get log message.

   @param[in] service_ptr   LOG service instance
   @param[in] wait_ptr      Wait specification (optional)
   @param[out] message_ptr  Pointer to formatted log message struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_message_get(log_service_t *service_ptr,
                const atlk_wait_t *wait_ptr,
                log_formatted_message_t *message_ptr);

/**
   Set log decoding database

   @param[in] service_ptr   LOG service instance
   @param[in] database_ptr  Pointer to log database struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_decoding_database_set(log_service_t *service_ptr, log_reader_database_t *database_ptr);

/**
   Set Device syslog destination uid

   @param[in] service_ptr   LOG service instance

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
log_device_destination_set(log_service_t *service_ptr);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_LOG_SERVICE_H */
