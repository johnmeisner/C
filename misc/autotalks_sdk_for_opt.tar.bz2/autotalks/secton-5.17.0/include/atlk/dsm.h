/** Copyright (C) 2012-2016 Autotalks Ltd. */
#ifndef _ATLK_DSM_H
#define _ATLK_DSM_H

/**
   @file
   Device and Service Management API
 */

#include <common/eui48.h>

#include <atlk/sdk.h>
#include <atlk/rdev.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Maximum device, service or layer name length cannot exceed 32 characters (33 with NULL terminator) */
#define DSM_NAME_MAX_LEN 33U

/** Minimum device, service or layer name length cannot be less then 1 character */
#define DSM_NAME_MIN_LEN 1U

#define DSM_DEVICE_TYPE_NONE  ((dsm_device_type_t)(-1))
#define DSM_DEVICE_TYPE_COUNT ((uint32_t)(DSM_DEVICE_TYPE_MAX))

#define DSM_SERVICE_TYPE_NONE  ((dsm_service_type_t)(-1))
#define DSM_SERVICE_TYPE_COUNT ((uint32_t)(DSM_SERVICE_TYPE_MAX))

#define DSM_SERVICE_BROADCAST_DISABLE 1

/** Device type */
typedef enum {
  DSM_DEVICE_TYPE_CRATON2 = 0U,
  DSM_DEVICE_TYPE_SECTON,
  DSM_DEVICE_TYPE_MAX
} dsm_device_type_t;

/** Service type indexes */
typedef enum {
  /** V2X service type */
  DSM_SERVICE_TYPE_V2X = 0U,

  /** ECC service type */
  DSM_SERVICE_TYPE_ECC,

  /** HSM service type */
  DSM_SERVICE_TYPE_HSM,

  /** Wireless Diagnostics & Management service type */
  DSM_SERVICE_TYPE_WDM,

  /** Device Diagnostics & Management service type */
  DSM_SERVICE_TYPE_DDM,

  /** In-Vehicle Network service type */
  DSM_SERVICE_TYPE_IVN,

  /** Debug service type */
  DSM_SERVICE_TYPE_DBG,

  /** HASH service type */
  DSM_SERVICE_TYPE_HASH,

  /** Symmetric crypto service type */
  DSM_SERVICE_TYPE_SYMMETRIC_CRYPTO,

  /** LOG service type */
  DSM_SERVICE_TYPE_LOG,

  /** MAX service type. Must be always last */
  DSM_SERVICE_TYPE_MAX
} dsm_service_type_t;

typedef struct ll_interface_connection ll_interface_connection_t;
typedef struct crypto_interface_connection crypto_interface_connection_t;

/** Device configuration struct */
typedef struct {
  /** Device name */
  const char *device_name;

  /** Device type */
  dsm_device_type_t device_type;

  /** Pointer to remote device descriptor */
  ll_interface_connection_t *ll_interface_primary_handle_ptr;

  /** Pointer to secondary device descriptor or NULL */
  ll_interface_connection_t *ll_interface_secondary_handle_ptr;

  /** Pointer to tee interface or NULL  */
  ll_interface_connection_t *ll_interface_tee_handle_ptr;

  uint16_t service_broadcast_disable_bitfield;

  /** Pointer to secure HDIF descriptor */
  crypto_interface_connection_t *crypto_interface_handle_ptr;
} dsm_device_config_t;

/** Device information */
typedef struct {
  /** Device name */
  const char *device_name;

  /** Device type */
  dsm_device_type_t device_type;

  /** Remote device address */
  eui48_t rdev_address;

  /** Remote device interface name */
  char *rdev_interface_name;

} dsm_device_info_t;

/** Service configuration structure */
typedef struct {
  const char *service_name;
  dsm_service_type_t service_type;
  const char *device_name;
  int32_t log_level;
  int config_use_tee;
} dsm_service_config_t;

/**
   Register new devices

   @param[in] desc_array_ptr Array of device descriptors
   @param[in] desc_array_size Size of the array

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
 */
atlk_rc_t atlk_must_check
dsm_device_register(const dsm_device_config_t *desc_array_ptr,
                    size_t desc_array_size);

/**
   Initialize a registered device

   @param[in] device_name Name of the device

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
 */
atlk_rc_t atlk_must_check
dsm_device_init(const char *device_name);

/**
   Un-initialize a registered device,
   this will Not clear the device entry from the table,
   device will need to be reinitialized after that

   @param[in] device_name Name of device to be deleted

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
 */
atlk_rc_t
dsm_device_delete(const char *device_name);

/**
   Get device wait option

   @param[in] device_name Name of the device
   @param[out] wait_option_ptr Wait option pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
 */
atlk_rc_t
dsm_device_wait_option_get(const char *device_name, atlk_wait_t *wait_option_ptr);

/**
   Set device wait option

   @param[in] device_name Name of the device
   @param[in] wait_option Wait option

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
 */
atlk_rc_t atlk_must_check
dsm_device_wait_option_set(const char *device_name, atlk_wait_t wait_option);

/**
   Get device information

   @param[out] info_array_ptr Array of device info to be filled
   @param[in,out] info_array_size_ptr Size of the array

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
 */
atlk_rc_t atlk_must_check
dsm_device_info_get(dsm_device_info_t *info_array_ptr,
                    size_t *info_array_size_ptr);

/**
   Register new services

   @param[in] desc_array_ptr Array of service descriptors
   @param[in] desc_array_size Size of the array

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
 */
atlk_rc_t atlk_must_check
dsm_service_register(const dsm_service_config_t *desc_array_ptr,
                     size_t desc_array_size);

/**
   Initialize a registered service

   @param[in] service_name Name of the service

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
 */
atlk_rc_t atlk_must_check
dsm_service_init(const char *service_name);

/**
   Deinitialize devices and services.

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
dsm_deinit(void);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_DSM_H */
