/* Copyright (C) 2017 Autotalks Ltd. */
#ifndef _ATLK_DDM_SERVICE_INTERNAL_H
#define _ATLK_DDM_SERVICE_INTERNAL_H

#include <atlk/sdk.h>
#include <atlk/object.h>
#include <atlk/ddm.h>

/**
   Set DDM objects

   @param[in] service_ptr DDM service instance
   @param[in] object_array_ptr DDM objects array
   @param[in] object_array_count Number of element is DDM objects array

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_object_set(ddm_service_t *service_ptr,
               atlk_object_t *object_array_ptr,
               size_t object_array_count);

/**
   Get DDM objects

   @param[in] service_ptr DDM service instance
   @param[out] object_array_ptr DDM objects array
   @param[in] object_array_count Number of element is DDM objects array

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_object_get(ddm_service_t *service_ptr,
               atlk_object_t *object_array_ptr,
               size_t object_array_count);

#endif /* _ATLK_DDM_SERVICE_INTERNAL_H */
