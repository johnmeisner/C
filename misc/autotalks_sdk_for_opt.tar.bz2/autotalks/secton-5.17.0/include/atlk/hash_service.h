/** Copyright (C) 2018 Autotalks Ltd. */
#ifndef _ATLK_HASH_SERVICE_H
#define _ATLK_HASH_SERVICE_H

#include <atlk/sdk.h>
#include <atlk/hash.h>
#include <atlk/ecc.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   Autotalks HASH Service API
*/

/**
   Get HASH service instance.

   @param[in] service_name_ptr Name of service (NULL for default)
   @param[out] service_pptr HASH service instance

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_service_get(const char *service_name_ptr,
                 hash_service_t **service_pptr);

/**
   Compute HASH by algorithm.

   @note The calculated hash value consists only of the first octets in hash_digest_t::value.
         The number of octets is indicated by hash_digest_t::value_size.

   @note When HW acceleration is enabled, only SHA_256 and SHA_384 are supported. When it is
         disabled (SW computation), all the algorithms can be used.
         HW acceleration must be disabled when working with SECTON.

   @param[in] service_ptr HASH service instance
   @param[in] data_ptr Data over which the hash will be computed
   @param[in] data_size Data length in octets. Maximum length is 2048 octets
   @param[in] algorithm HASH algorithm: SHA_256, SHA_384 and SM3 only
   @param[in] hw_acceleration HW acceleration
   @param[out] digest_ptr Calculated HASH digest

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_compute(hash_service_t *service_ptr,
             const void *data_ptr,
             size_t data_size,
             hash_algorithm_t algorithm,
             hash_hw_acceleration_t hw_acceleration,
             hash_digest_t *digest_ptr);

/**
   Compute SHA-SM3 Z digest

   @remark support SM2-2010 keys only

   @param[in]  service_ptr HASH service instance
   @param[in]  id_ptr ID data
   @param[in]  id_size ID data length in octets, Maximum length is 8191 octets
   @param[in]  public_key_ptr SM2-2010 public key
   @param[out] z_digest_ptr Calculated SHA-SM3 Z digest

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_sm3_compute_z(hash_service_t *service_ptr,
                   const void *id_ptr,
                   size_t id_size,
                   const ecc_point_t *public_key_ptr,
                   hash_digest_t *z_digest_ptr);

/**
   Compute SHA-SM3 E digest

   @param[in]  service_ptr HASH service instance
   @param[in]  data_ptr Data over which the hash will be computed
   @param[in]  data_size Data length in octets
   @param[in]  z_digest_ptr SHA-SM3 Z digest
   @param[out] e_digest_ptr Calculated SHA-SM3 E digest

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_sm3_compute_e(hash_service_t *service_ptr,
                   const void *data_ptr,
                   size_t data_size,
                   const hash_digest_t *z_digest_ptr,
                   hash_digest_t *e_digest_ptr);

/**
   Initialize HASH by algorithm.

   @note This function is supported only in CRATON for SHA_256 and SHA_384 algorithm

   @param[in] service_ptr HASH service instance
   @param[in] total_length Total length of expected data to be digested
   @param[in] algorithm HASH algorithm: SHA_256, SHA_384 and SHA_SM3 only
   @param[out] hash_context_ptr HASH context

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_init(hash_service_t *service_ptr,
          size_t total_length,
          hash_algorithm_t algorithm,
          hash_context_t *hash_context_ptr);

/**
   Update HASH-XXX context.

   @note @p chunk_length has to be ::HASH_UPDATE_LENGTH_ALIGNMENT bytes aligned,
                         except last chunk

   @note This function is supported only in CRATON for SHA_256 and SHA_384 algorithm

   @param[in] service_ptr HASH service instance
   @param[in] hash_context_ptr HASH context
   @param[in] chunk_ptr Chunk of data to be processed
   @param[in] chunk_length Length of data chunk in octets, Maximum 2048 octets

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_update(hash_service_t *service_ptr,
            const hash_context_t *hash_context_ptr,
            const void *chunk_ptr,
            size_t chunk_length);

/**
   Finalize HASH-XXX context.

   @note This function is supported only in CRATON for SHA_256 and SHA_384 algorithm

   @param[in] service_ptr HASH service instance
   @param[in] hash_context_ptr HASH context
   @param[out] digest_ptr Calculated HASH-XXX digest

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_final(hash_service_t *service_ptr,
           const hash_context_t *hash_context_ptr,
           hash_digest_t *digest_ptr);

/**
   Reset HASH mechanism.

   @note This function is supported only in CRATON for SHA_256 and SHA_384 algorithm

   @param[in] service_ptr HASH service instance

   @note This API can optionally be called when a previous HASH operation hasn't
         finished. For instance, hash_init and hash_update were called but
         no call to hash_final was made.

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_reset(hash_service_t *service_ptr);

/**
   Create HASH socket.

   @note This function is supported only in CRATON for SHA_256 and SHA_384 algorithm

   @param[in] service_ptr HASH service instance
   @param[out] socket_pptr Created HASH socket pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_socket_create(hash_service_t *service_ptr, hash_socket_t **socket_pptr);

/**
   Send HASH request.

   @note This function is supported only in CRATON for SHA_256 and SHA_384 algorithm

   @note HASH server requests queue depth is 16. When the queue is full, HASH
         requests will be dropped gracefully (server-side), but this function
         will still return ::ATLK_OK. User implementation should take this
         limitation into account.

   @param[in] socket_ptr HASH socket
   @param[in] request_ptr HASH request
   @param[in] wait_ptr Wait specification (optional)

   @note Only supported wait option is NULL which is non blocking mode
   @note Only supported request sub type is HASH_REQUEST_SUB_TYPE_COMPUTE

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_request_send(hash_socket_t *socket_ptr,
                  const hash_async_request_t *request_ptr,
                  const atlk_wait_t *wait_ptr);

/**
   Receive HASH response.

   @note This function is supported only in CRATON for SHA_256 and SHA_384 algorithm

   @param[in] socket_ptr HASH socket
   @param[out] response_ptr HASH response
   @param[in] wait_ptr Wait specification (optional)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_response_receive(hash_socket_t *socket_ptr,
                      hash_async_response_t *response_ptr,
                      const atlk_wait_t *wait_ptr);

/**
   Delete HASH socket.

   @note This function is supported only in CRATON for SHA_256 and SHA_384 algorithm

   @param[in] socket_ptr HASH socket to delete

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_socket_delete(hash_socket_t *socket_ptr);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_HASH_SERVICE_H */
