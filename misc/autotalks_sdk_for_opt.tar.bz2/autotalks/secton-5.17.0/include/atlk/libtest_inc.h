/* Copyright (C) 2018-2022 Autotalks Ltd. */

#ifndef LIB_TEST_INC_H_
#define LIB_TEST_INC_H_

#include <stdio.h>

#include "atlk/cv2x.h"
#include "atlk/sdk.h"
#include "atlk/wdm.h"
#include "atlk/ddm.h"
#include "atlk/hash_service.h"
#include "atlk/ehsm_service.h"
#include "atlk/ecc_service.h"
#include "atlk/ecc.h"


/* ----------------------------- Enumerations ------------------------------ */


typedef enum {
  LIBTEST_TX_PARAM_HARQ_OFF               = 0,
  LIBTEST_TX_PARAM_HARQ_ON                = 1,
  LIBTEST_TX_PARAM_HARQ_ON_SPECIFIC_DELTA = 2,
  LIBTEST_TX_PARAM_HARQ_BY_RRC            = 3,

  LIBTEST_TX_PARAM_HARQ_MAX = LIBTEST_TX_PARAM_HARQ_BY_RRC

} libtest_harq_mode;

typedef enum {
  LIBTEST_TX_PARAM_DIV_MODE_ANT0 = 0,
  LIBTEST_TX_PARAM_DIV_MODE_ANT1 = 1,
  LIBTEST_TX_PARAM_DIV_MODE_BOTH = 2,

  LIBTEST_TX_PARAM_DIV_MODE_MAX = LIBTEST_TX_PARAM_DIV_MODE_BOTH

} libtest_diversity_mode;

typedef enum {
  LIBTEST_TX_SECURITY_MODE_DISABLED  = 0,
  LIBTEST_TX_SECURITY_MODE_SIGN      = 1,
  LIBTEST_TX_SECURITY_MODE_FAST_SIGN = 2, // Fast sign mode is the ability to send the same signed message without signing each one

  LIBTEST_TX_SECURITY_MODE_MAX = LIBTEST_TX_SECURITY_MODE_FAST_SIGN

} libtest_tx_security_mode;

typedef enum {
  LIBTEST_RX_SECURITY_MODE_DISABLED = 0,
  LIBTEST_RX_SECURITY_MODE_VERIFY   = 1,

  LIBTEST_RX_SECURITY_MODE_MAX = LIBTEST_RX_SECURITY_MODE_VERIFY

} libtest_rx_security_mode;

typedef enum {
  // Note: First enumerator MUST equal 0, and each enumerator should be an increment by one of its preceding one.
  //       We rely on this in statistics loops and in maintaining the public_keys & blobs arrays.

  LIBTEST_ECC_ALGORITHM_NIST_256         = 0,
  LIBTEST_ECC_ALGORITHM_NIST_384         = 1,
  LIBTEST_ECC_ALGORITHM_BRAINPOOL_256_T1 = 2,
  LIBTEST_ECC_ALGORITHM_BRAINPOOL_384_T1 = 3,
  LIBTEST_ECC_ALGORITHM_BRAINPOOL_256_R1 = 4,
  LIBTEST_ECC_ALGORITHM_BRAINPOOL_384_R1 = 5,
  LIBTEST_ECC_ALGORITHM_SM2_2010         = 6,
  LIBTEST_ECC_ALGORITHM_SM2_2012         = 7,

  LIBTEST_ECC_ALGORITHM_MAX = LIBTEST_ECC_ALGORITHM_SM2_2012

} libtest_ecc_algorithm;


/* ------------------------------ Definitions ------------------------------ */


#define LIBTEST_CBR_CLEAR                             UINT8_MAX
#define LIBTEST_UTC_STR_IN_PAYLOAD_LEN                24    // Length of UTC time string written into message payload (including NULL terminator)
#define LIBTEST_TXN_MAX                               5     // Maximum number of transmitter threads supported by libtest

#define LIBTEST_TX_PARAM_TXN_INVALID                  0
#define LIBTEST_TX_PARAM_NUM_INVALID                  UINT32_MAX
#define LIBTEST_TX_PARAM_PGI_INVALID                  0
#define LIBTEST_TX_PARAM_SPEED_INVALID                UINT32_MAX
#define LIBTEST_TX_PARAM_PDB_INVALID                  0
#define LIBTEST_TX_PARAM_POWER_INVALID                INT16_MAX
#define LIBTEST_TX_PARAM_SIZE_INVALID                 0
#define LIBTEST_TX_PARAM_RSVP_INVALID                 UINT32_MAX
#define LIBTEST_TX_PARAM_PRIORITY_INVALID             0
#define LIBTEST_TX_PARAM_HARQ_INVALID                 UINT32_MAX
#define LIBTEST_TX_PARAM_HARQ_GAP_INVALID             UINT32_MAX
#define LIBTEST_TX_PARAM_SRC_L2ID_INVALID             UINT32_MAX
#define LIBTEST_TX_PARAM_DST_L2ID_INVALID             UINT32_MAX
#define LIBTEST_TX_PARAM_FAMILY_ID_INVALID            UINT32_MAX
#define LIBTEST_TX_PARAM_DIVERSITY_INVALID            UINT32_MAX
#define LIBTEST_TX_PARAM_BANDWIDTH_INVALID            0
#define LIBTEST_TX_PARAM_MCS_INVALID                  UINT32_MAX
#define LIBTEST_TX_PARAM_DFN_INVALID                  UINT32_MAX
#define LIBTEST_TX_PARAM_SFN_INVALID                  UINT32_MAX
#define LIBTEST_TX_PARAM_FREQ_INVALID                 UINT32_MAX
#define LIBTEST_TX_PARAM_SCH_SIZE_INVALID             0
#define LIBTEST_TX_PARAM_NUM_OF_SCHS_INVALID          0
#define LIBTEST_TX_PARAM_START_SCH_INVALID            UINT32_MAX

#define LIBTEST_RX_PARAM_BANDWIDTH_INVALID            0
#define LIBTEST_RX_PARAM_SCH_SIZE_INVALID             0
#define LIBTEST_RX_PARAM_FREQ_INVALID                 UINT32_MAX
#define LIBTEST_RX_PARAM_SRC_L2ID_INVALID             UINT32_MAX
#define LIBTEST_RX_PARAM_NON_IP_HEADER_EN_INVALID     UINT32_MAX

#define LIBTEST_RX_PARAM_NON_IP_HEADER_OFF            0
#define LIBTEST_RX_PARAM_NON_IP_HEADER_ON             1

#define LIBTEST_PARAM_FREQ_MHZ_MIN                    5770
#define LIBTEST_PARAM_FREQ_MHZ_MAX                    6000
#define LIBTEST_PARAM_L2ID_MAX                        0xFFFFFF  // Used for both SRC (Tx & Rx) & DST L2ID

#define LIBTEST_ECC_ALGORITHM_DEFAULT                 LIBTEST_ECC_ALGORITHM_NIST_256

#define LIBTEST_TX_PARAMS_INIT {                        \
  .txn          = LIBTEST_TX_PARAM_TXN_INVALID,         \
  .num          = LIBTEST_TX_PARAM_NUM_INVALID,         \
  .pgi          = LIBTEST_TX_PARAM_PGI_INVALID,         \
  .speed_kph    = LIBTEST_TX_PARAM_SPEED_INVALID,       \
  .pdb_ms       = LIBTEST_TX_PARAM_PDB_INVALID,         \
  .power_dbm8   = LIBTEST_TX_PARAM_POWER_INVALID,       \
  .payload_size = LIBTEST_TX_PARAM_SIZE_INVALID,        \
  .rsvp         = LIBTEST_TX_PARAM_RSVP_INVALID,        \
  .priority     = LIBTEST_TX_PARAM_PRIORITY_INVALID,    \
  .harq         = LIBTEST_TX_PARAM_HARQ_INVALID,        \
  .harq_gap     = LIBTEST_TX_PARAM_HARQ_GAP_INVALID,    \
  .src_l2id     = LIBTEST_TX_PARAM_SRC_L2ID_INVALID,    \
  .dst_l2id     = LIBTEST_TX_PARAM_DST_L2ID_INVALID,    \
  .family_id    = LIBTEST_TX_PARAM_FAMILY_ID_INVALID,   \
  .diversity    = LIBTEST_TX_PARAM_DIVERSITY_INVALID,   \
  .bandwidth    = LIBTEST_TX_PARAM_BANDWIDTH_INVALID,   \
  .mcs          = LIBTEST_TX_PARAM_MCS_INVALID,         \
  .dfn          = LIBTEST_TX_PARAM_DFN_INVALID,         \
  .sfn          = LIBTEST_TX_PARAM_SFN_INVALID,         \
  .freq_mhz     = LIBTEST_TX_PARAM_FREQ_INVALID,        \
  .sch_size     = LIBTEST_TX_PARAM_SCH_SIZE_INVALID,    \
  .num_of_schs  = LIBTEST_TX_PARAM_NUM_OF_SCHS_INVALID, \
  .start_sch    = LIBTEST_TX_PARAM_START_SCH_INVALID,   \
}

#define LIBTEST_RX_PARAMS_INIT {                                  \
  .bandwidth        = LIBTEST_RX_PARAM_BANDWIDTH_INVALID,         \
  .sch_size         = LIBTEST_RX_PARAM_SCH_SIZE_INVALID,          \
  .freq_mhz         = LIBTEST_RX_PARAM_FREQ_INVALID,              \
  .src_l2id         = LIBTEST_RX_PARAM_SRC_L2ID_INVALID,          \
  .non_ip_header_en = LIBTEST_RX_PARAM_NON_IP_HEADER_EN_INVALID,  \
}

#define LIBTEST_SOCKET_POLICY_DIRECT_MODE_PARAMS_INIT {                                 \
  .pool_id                                 = CV2X_DEFAULT_POOL_ID,                      \
  .subframe_number                         = CV2X_RR_POLICY_SUB_FRAME_NO_DEFAULT,       \
  .direct_frame_number                     = CV2X_RR_POLICY_DIRECT_FRAME_NO_DEFAULT,    \
  .mcs                                     = CV2X_RR_POLICY_MCS_DEFAULT,                \
  .harq_control_interval_logical_subframes = HARQ_MODE_OFF,                             \
  .starting_subchannel                     = CV2X_RR_POLICY_START_SUBCHANNEL_DEFAULT,   \
  .harq_starting_subchannel                = CV2X_RR_POLICY_START_SUBCHANNEL_DEFAULT,   \
  .number_of_subchannels                   = CV2X_RR_POLICY_NUM_OF_SUBCHANNELS_DEFAULT, \
}


/* ------------------------------ Structures ------------------------------- */


// Parameters for send command
typedef struct libtest_tx_params_st {
  uint32_t     txn;                 // Number of transmitters
  uint32_t     num;                 // Number of messages to transmit
  uint32_t     pgi;                 // Interval in milliseconds between messages transmission by the application
  uint32_t     speed_kph;           // Vehicle speed in KPH
  uint32_t     pdb_ms;              // Packet Delay Budget in milliseconds
  power_dbm8_t power_dbm8;          // Power in units of 1/8 dBm
  uint32_t     harq;                // HARQ mode: 0 - Off. 1 - On. 2 - On with configured gap. Other values - Determined by RRC
  uint32_t     harq_gap;            // HARQ gap in milliseconds. Effective only in case HARQ mode is 2 (on with configured gap)
  uint32_t     src_l2id;            // Source L2 ID used for Tx
  uint32_t     dst_l2id;            // Destination L2 ID
  uint32_t     family_id;           // Family ID (IEEE / ISO / ETSI-ITS) to be set inside Non-IP header
  uint32_t     diversity;           // Tx diversity mode: 0 - Only antenna 0 is on. 1 - Only antenna 1 is on. Other values - Both antennas are on
  uint32_t     bandwidth;           // Bandwidth in MHz
  uint32_t     mcs;                 // MCS (Modulation and Coding Scheme)
  uint32_t     dfn;                 // Data Frame Number (0 - 1023)
  uint32_t     sfn;                 // System Frame Number (0 - 9)
  uint32_t     freq_mhz;            // Frequency in MHz
  uint32_t     sch_size;            // Size of sub-channel in RBs
  uint32_t     num_of_schs;         // Number of sub-channels to use for transmission
  uint32_t     start_sch;           // Start sub-channel (first SCH index is 0)

  // Policy information
  uint32_t     payload_size;        // Messages' payload size in bytes
  uint32_t     rsvp;                // Interval between messages (in logical sub-frames)
  uint32_t     priority;            // Messages' priority (1 - 8)

} libtest_tx_params_t;

// Parameters for receive command
typedef struct libtest_rx_params_st {
  uint32_t bandwidth;               // Bandwidth in MHz
  uint32_t sch_size;                // Size of sub-channel in RBs
  uint32_t freq_mhz;                // Frequency in MHz
  uint32_t src_l2id;                // Source L2 ID used for Rx
  uint32_t non_ip_header_en;        // Determines how to process Non-IP-Header existence indication in PDCP header
                                    // (0 - Ignore indication. 1 - Process according to PDCP header)

} libtest_rx_params_t;

typedef struct libtest_security_header_st {
  ecc_point_type_t public_key_point_type;
  uint32_t         public_key_x_coordinate[ECC_SCALAR_NUM_OF_UINT32];
  uint32_t         signature_r_scalar[ECC_SCALAR_NUM_OF_UINT32];
  uint32_t         signature_s_scalar[ECC_SCALAR_NUM_OF_UINT32];

} libtest_security_header_t;


// Parameters for direct mode socket policy setting
typedef struct libtest_socket_policy_direct_mode_params_st {
  int8_t     pool_id;                                 // Pool ID - CV2X_DEFAULT_POOL_ID (-1) will cause cv2xlib to choose default pool
  uint8_t    subframe_number;                         // Subframe number (logical) - Range: 0 - 9
                                                      // Upon a valid subframe number, cv2xlib allocation will be done on this subframe number
  uint16_t   direct_frame_number;                     // Direct frame number (logical) - Range: 0 - 1023.
                                                      // Upon a valid Direct frame number, cv2xlib allocation will be done on this direct subframe number
  cv2x_mcs_t mcs;                                     // MCS modulation - Range: CV2X_INVALID_MCS, 0 - 31. CV2X_INVALID_MCS (-1) will mark to ignore this value
  uint32_t   harq_control_interval_logical_subframes; // HARQ control interval in logical subframes for policy (from rv0). 0 will denote no HARQ
  int        starting_subchannel;                     // Starting sub-channel (0 based) - (-1) will sign a dynamic allocation
  int        harq_starting_subchannel;                // Starting sub-channel (0 based) for HARQ - (-1) will sign a dynamic allocation
  uint8_t    number_of_subchannels;                   // Number of sub-channels. 0 will mark to ignore this value

} libtest_socket_policy_direct_mode_params_t;


/* ------------------------------- Typedefs -------------------------------- */


// Type definition for libtest callback print function
typedef int (*libtest_print_cb_t)(const char *format, ...);


/* ----------------------------- libtest APIs ------------------------------ */

/**
  @brief     Initializes CV2X test library

  @param[in] print_cb_ptr A pointer to a callback print function to be used by the test library.
                          If NULL is given, the test library will not output printouts.

  @retval    ATLK_OK if succeeded
  @return    Error code if failed
*/
atlk_rc_t libtest_init(libtest_print_cb_t print_cb_ptr);

/**
  @brief  De-initializes CV2X test library

  @return void
*/
void libtest_deinit(void);

/**
  @brief     Prints version numbers of SDK / DSP / BSP / HW

  @param[in] wdm_service_ptr A pointer to an initialized DDM service
  @param[in] ddm_service_ptr A pointer to an initialized WDM service

  @retval    ATLK_OK if succeeded
  @return    Error code if failed
*/
atlk_rc_t libtest_version_print(wdm_service_t *wdm_service_ptr, ddm_service_t *ddm_service_ptr);

/**
  @brief     Sets a constant CBR (CBR simulation mode)

  @param[in] cv2x_service_ptr A pointer to an initialized CV2X service
  @param[in] cbr              The CBR value to set (in percents units).
                              Setting value of LIBTEST_CBR_CLEAR stops the CBR simulation mode.

  @retval    ATLK_OK if succeeded
  @return    Error code if failed
*/
atlk_rc_t libtest_cbr_simulate(cv2x_service_t *cv2x_service_ptr, uint8_t cbr);

/**
  @brief     Requests the test library to transmit CV2X messages according to input arguments

  @param[in] cv2x_service_ptr A pointer to an initialized CV2X service
  @param[in] wdm_service_ptr  A pointer to an initialized WDM service
  @param[in] hash_service_ptr A pointer to an initialized HASH service
  @param[in] ehsm_service_ptr A pointer to an initialized EHSM service
  @param[in] tx_params_arr    An array containing transmission parameters; entry per transmitter; maximum LIBTEST_TXN_MAX transmitters.
                              Mandatory fields to be filled in for a transmission request:
                              txn, num, rsvp, pgi, priority, power_dbm8, harq, payload_size,
                              speed_kph, src_l2id, dst_l2id, diversity, harq, harq_gap
                              Minimum / Maximum values for parameters can be found in this file under "Definitions".

  @retval    ATLK_OK if succeeded
  @return    Error code if failed
*/
atlk_rc_t libtest_tx_api_func(cv2x_service_t      *cv2x_service_ptr,
                              wdm_service_t       *wdm_service_ptr,
                              hash_service_t      *hash_service_ptr,
                              ehsm_service_t      *ehsm_service_ptr,
                              libtest_tx_params_t  tx_params_arr[]);

/**
  @brief     Requests the test library to run an application level receiver thread

  @param[in] cv2x_service_ptr A pointer to an initialized CV2X service
  @param[in] wdm_service_ptr  A pointer to an initialized WDM service
  @param[in] hash_service_ptr A pointer to an initialized HASH service
  @param[in] ecc_socket_ptr   A pointer to an initialized ECC socket
  @param[in] rx_params_ptr    A pointer to receive parameters structure.
                              Mandatory fields to be filled are src_l2id & non_ip_header_en.
                              Minimum / Maximum values for parameters can be found in this file under "Definitions".

  @retval    ATLK_OK if succeeded
  @return    Error code if failed
*/
atlk_rc_t libtest_rx_api_func(cv2x_service_t      *cv2x_service_ptr,
                              wdm_service_t       *wdm_service_ptr,
                              hash_service_t      *hash_service_ptr,
                              ecc_socket_t        *ecc_socket_ptr,
                              libtest_rx_params_t *rx_params_ptr);

/**
  @brief  Stops all running transmitters

  @return void
*/
void libtest_tx_stop_all(void);

/**
  @brief     Stops a transmitter by index list

  @param[in] should_stop_arr An array filled in with boolean values marking whether a transmitter should be stopped.
                             Each array entry represents a transmitter: Entry 0 for transmitter 1, Entry 1 for transmitter 2, and so on.
  @param[in] stop_arr_size   Number of entries in <should_stop_arr>

  @retval    ATLK_OK if succeeded
  @return    Error code if failed
*/
void libtest_tx_stop_by_index(bool should_stop_arr[], uint8_t stop_arr_size);

/**
  @brief  Stops the application receiver thread (if running)

  @return void
*/
void libtest_rx_stop(void);

/**
  @brief  Displays Tx statistics

  @return void
*/
void libtest_tx_stats(void);

/**
  @brief  Displays Rx statistics

  @return void
*/
void libtest_rx_stats(void);

/**
  @brief  Resets Tx & Rx statistics

  @return void
*/
void libtest_stats_reset(void);

/**
  @brief     Checks if there is a running Rx thread

  @retval    True if there is a running Rx thread. False otherwise.
*/
bool libtest_rx_is_thread_running(void);

/**
  @brief     Sets Tx message signing mode and ECC algorithm

  @param[in] security_mode The signing mode to set (DISABLED, SIGN, FAST_SIGN)
  @param[in] ecc_algo      The ECC algorithm to set (NIST_256, NIST_384, BP_256_T1, BP_384_T1, BP_256_R1, BP_384_R1, SM2_2010, SM2_2012).
                           Has no effect when <security_mode> is set to DISABLED.

  @retval    ATLK_OK if succeeded
  @return    Error code if failed
*/
atlk_rc_t libtest_tx_set_security_info(uint32_t security_mode, uint32_t ecc_algo);

/**
  @brief     Sets Rx message signature verification mode and ECC algorithm

  @param[in] security_mode The signature verification mode to set (DISABLED, VERIFY)
  @param[in] ecc_algo      The ECC algorithm to set (NIST_256, NIST_384, BP_256_T1, BP_384_T1, BP_256_R1, BP_384_R1, SM2_2010, SM2_2012).
                           Has no effect when <security_mode> is set to DISABLED.

  @retval    ATLK_OK if succeeded
  @return    Error code if failed
*/
atlk_rc_t libtest_rx_set_security_info(uint32_t security_mode, uint32_t ecc_algo);

/**
  @brief  Displays Tx message signing statistics

  @return void
*/
void libtest_sign_stats_show(void);

/**
  @brief  Resets Tx message signing statistics

  @return void
*/
void libtest_sign_stats_reset(void);

/**
  @brief  Displays Rx message signature verification statistics

  @return void
*/
void libtest_verify_stats_show(void);

/**
  @brief  Resets Rx message signature verification statistics

  @return void
*/
void libtest_verify_stats_reset(void);

/**
  @brief      Computes HASH according to input arguments

  @param[in]  hash_service_ptr A pointer to an initialized HASH service
  @param[in]  public_key_ptr   A pointer to a public key
  @param[in]  data_ptr         A pointer to the data on which the hash shall be applies
  @param[in]  data_size        Size in bytes of the data
  @param[in]  ecc_algo         The ECC algorithm to use for hash (according to libtest_ecc_algorithm enumeration)
  @param[out] digest_ptr       An address to be filled in with the hash digest (the hash result)

  @retval     ATLK_OK if succeeded
  @return     Error code if failed
*/
atlk_rc_t libtest_hash_compute(hash_service_t *hash_service_ptr,
                               ecc_point_t    *public_key_ptr,
                               const void     *data_ptr,
                               size_t          data_size,
                               uint32_t        ecc_algo,
                               hash_digest_t  *digest_ptr);

/**
  @brief      Performs signing of a hash digest according to input arguments

  @param[in]  ehsm_service_ptr A pointer to an initialized EHSM service
  @param[in]  blob_ptr         A pointer to a private key blob
  @param[in]  digest_ptr       A pointer to the hash digest to be signed
  @param[out] signature_ptr    An address to be filled in with the signature

  @retval     ATLK_OK if succeeded
  @return     Error code if failed
*/
atlk_rc_t libtest_ecdsa_sign(ehsm_service_t                    *ehsm_service_ptr,
                             void                              *blob_ptr,
                             const hash_digest_t               *digest_ptr,
                             ecc_fast_verification_signature_t *signature_ptr);

/**
   @brief     Sets (updates) socket RR policy with direct mode parameters

   @param[in] socket_ptr           CV2X socket pointer
   @param[in] policy_dm_params_ptr CV2X socket policy direct mode configuration

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t atlk_must_check
libtest_socket_policy_direct_mode_set(CV2X_INOUT       cv2x_socket_t                              *const socket_ptr,
                                      CV2X_IN    const libtest_socket_policy_direct_mode_params_t *const policy_dm_params_ptr);

#endif /* LIB_TEST_INC_H_ */
