/** Copyright (C) 2018 Autotalks Ltd. */
#ifndef _ATLK_ADMIN_H
#define _ATLK_ADMIN_H

#include <atlk/sdk.h>
#include <atlk/ddm.h>
#include <atlk/wdm.h>
#include <atlk/ehsm.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   Aministration API
*/

/** Size of Application information */
#define DDM_APP_INFO_SIZE_BYTES 16U

#define NOR_FLASH_TRANSACTION_MAX_SIZE      256U
#define NOR_FLASH_USER_DATA_PARTITION_SIZE  0x20000U

/**
   Get compensator raw calibration data

   @param[in]  service_ptr   WDM service instance
   @param[in]  rf_index      RF index
   @param[out] stats_ptr     Pointer to compensator raw calibration data struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_compensator_raw_calibration_data_get(wdm_service_t *service_ptr,
                                         rf_index_t rf_index,
                                         wdm_compensator_raw_calibration_data_t *raw_calibration_data_ptr);

/**
   Set RF temperature offset in Celsius.

   @note Currently it is used to store temperature delta between real
         temperature and read temperature from ADC, in Celsius:
         offset = read temperature - real temperature.

   @param[in] service_ptr        WDM service instance
   @param[in] temperature_offset RF temperature calibration data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_rf_temperature_offset_set(wdm_service_t *service_ptr, int32_t temperature_offset);

/**
   Get RF temperature offset in Celsius.

   @note Currently it is used to store temperature delta between real
         temperature and read temperature from ADC, in Celsius:
         offset = read temperature - real temperature.

   @param[in] service_ptr            WDM service instance
   @param[in] temperature_offset_ptr RF temperature calibration data

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_rf_temperature_offset_get(wdm_service_t *service_ptr, int32_t *temperature_offset_ptr);

/**
   Set EEPROM user-defined application information.

   @note EEPROM has DDM_APP_INFO_SIZE_BYTES bytes which are reserved for user defined application
         information storage.
         A value of all zeros erases EEPROM application information.
         Board must be reset for the set to take affect.

   @note This function sets the application information field in EEPROM only, unit hw-config is not affected

   @param[in] service_ptr DDM service instance
   @param[in] offset      Offset within the user defined region
   @param[in] buffer_ptr  buffer of data to be written to EEPROM
   @param[in] size        Size of input buffer in bytes

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_eeprom_app_info_set(ddm_service_t *service_ptr,
                        uint32_t offset,
                        uint8_t *buffer_ptr,
                        size_t size);

/**
   Get user-defined application information.

   @note buffer_ptr argument must point to a buffer of at least DDM_APP_INFO_SIZE_BYTES bytes

   @param[in]  service_ptr DDM service instance
   @param[out] buffer_ptr  Pointer to buffer to hold application information

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_app_info_get(ddm_service_t *service_ptr,
                 uint8_t *buffer_ptr);

/**
   Generate Chip Specific Key (CSK).

   @note This function should be called once in a chip lifecycle.

   @param[in] service_ptr Embedded HSM service instance

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
 */
atlk_rc_t atlk_must_check
ehsm_csk_generate(ehsm_service_t *service_ptr);


/**
   Write to EEPROM.

   @param[in] service_ptr DDM service instance
   @param[in] buffer_ptr  Buffer of data to be written to EEPROM
   @param[in] size        Buffer size in bytes
   @param[in] offset      EEPROM address offset to start writing to in bytes

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_eeprom_write(ddm_service_t *service_ptr,
                 uint8_t *buffer_ptr,
                 uint16_t size,
                 uint16_t offset);

/**
   Read from EEPROM.

   @param[in] service_ptr DDM service instance
   @param[in] buffer_ptr  Buffer of data to be read from EEPROM
   @param[in] size        Buffer size in bytes
   @param[in] offset      EEPROM address offset to start reading from in bytes

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_eeprom_read(ddm_service_t *service_ptr,
                uint8_t *buffer_ptr,
                uint16_t size,
                uint16_t offset);


/**
   Generate a master key and return it in plain text as well as in blob format.

   @note    A master key is required to be used between Host and Secton Device
            Once all master keys are generated, the HOST should lock the possibility of generating more
            master keys.
            Both blob and key should be stored on the host securely.
            On start up the blob is to be provided to Secton Device and the key is used by the Host.

   @param[in] ddm_service_ptr       pointer to ddm service
   @param[in] key_size_to_generate  the key size to be generated 16 or 32 byte
   @param[out] encr_key_ptr         Buffer to store the generated key used for encryption
   @param[out] auth_key_ptr         Buffer to store the generated key used for authentication
   @param[out] keys_blob_ptr        Pointer Master keys blob

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
ddm_secure_hdif_master_keys_generate(ddm_service_t *ddm_service_ptr,
                                     uint32_t      key_size_to_generate,
                                     uint8_t       *encr_key_ptr,
                                     uint8_t       *auth_key_ptr,
                                     uint8_t       *keys_blob_ptr);

/**
   Sets lifecycle status for the given fields

   OTP bits can only be set, so there is no need to specify a value to set
   Current values can be obtained via API ehsm_info_get

   @param[in] service_ptr Embedded HSM service instance
   @param[in] lifecycle_bitmask The bitmask value of the fields to set in the eHSM OTP lifecycle status fields

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_lifecycle_set(ehsm_service_t *ehsm_service_ptr, uint32_t lifecycle_bitmask);

/**
   Read customer partition from NOR flash - SECTON only.

   @param[in] service_ptr DDM service instance
   @param[in] buffer_ptr  Pointer to data buffer to be read from flash
   @param[in] size        Buffer size in bytes - max size is 1024 byte
   @param[in] offset      Address offset in customer partition to start reading from (in bytes)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_nor_flash_customer_partition_read(ddm_service_t *service_ptr,
                                      uint8_t *buffer_ptr,
                                      uint32_t size,
                                      uint32_t offset);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_ADMIN_H */
