/**
   @file      cv2x_rrc_pre_config.h
   @brief     CV2X Radio Resource Control Pre-Configuration definitions and types
   @note      RRC parameters meaning are according to the Radio Resource Control Protocol specification:
              https://www.etsi.org/deliver/etsi_ts/136300_136399/136331/14.14.00_60/ts_136331v141400p.pdf
   @copyright Copyright (C) 2018-2020 Autotalks Ltd.
*/

#ifndef CV2X_RRC_PRE_CONFIG_H
#define CV2X_RRC_PRE_CONFIG_H


#include <stdint.h>
#include <stdbool.h>
#include "atlk/sdk.h"


#ifdef __cplusplus
extern "C" {
#endif


/* ------------------------ Definitions -------------------------- */


/* Lists' minimum & maximum length */

#define CV2X_RRC_MIN_FREQ_V2X_R14                         1U
#define CV2X_RRC_MAX_FREQ_V2X_R14                         8U

#define CV2X_RRC_MIN_SL_V2X_TX_CONFIG2_R14                1U
#define CV2X_RRC_MAX_SL_V2X_TX_CONFIG2_R14                128U

#define CV2X_RRC_MIN_SL_V2X_CBR_CONFIG2_R14               1U
#define CV2X_RRC_MAX_SL_V2X_CBR_CONFIG2_R14               8U

#define CV2X_RRC_MIN_SL_V2X_RX_POOL_PRECONF_R14           1U
#define CV2X_RRC_MAX_SL_V2X_RX_POOL_PRECONF_R14           16U

#define CV2X_RRC_MIN_SL_V2X_TX_POOL_PRECONF_R14           1U
#define CV2X_RRC_MAX_SL_V2X_TX_POOL_PRECONF_R14           8U

#define CV2X_RRC_MIN_RESERVATION_PERIOD_R14               1U
#define CV2X_RRC_MAX_RESERVATION_PERIOD_R14               16U

#define CV2X_RRC_MIN_PSSCH_TX_CONFIG_R14                  1U
#define CV2X_RRC_MAX_PSSCH_TX_CONFIG_R14                  16U

#define CV2X_RRC_MIN_CBR_PSSCH_TX_CONFIG                  1U
#define CV2X_RRC_MAX_CBR_PSSCH_TX_CONFIG                  8U

#define CV2X_RRC_MIN_CBR_LEVEL_R14                        1U
#define CV2X_RRC_MAX_CBR_LEVEL_R14                        16U

#define CV2X_RRC_THRES_PSSCH_RSRP_LIST_LEN                64U

#define CV2X_RRC_POOL_BMP_LEN                             13U

/* Variables' minimum & maximum values */
#define CV2X_RRC_MAX_EARFCN2                              262143U
#define CV2X_RRC_MAX_MCS_PSSCH_R14                        31U
#define CV2X_RRC_MAX_SUB_CHANNEL_NUMBER_PSSCH_R14         20U
#define CV2X_RRC_MAX_CR_LIMIT_R14                         10000U
#define CV2X_RRC_MIN_TX_POWER_R14                         (-41)
#define CV2X_RRC_MAX_TX_POWER_R14                         31
#define CV2X_RRC_TX_POWER_R14_MINUSINFINITY               0
#define CV2X_RRC_MAX_CBR_LEVEL_VALUE_R14                  100U
#define CV2X_RRC_MIN_PRIORITY_R13                         1U
#define CV2X_RRC_MAX_PRIORITY_R13                         8U
#define CV2X_RRC_MAX_OFFSET_DFN                           1000U
#define CV2X_RRC_MIN_P_MAX                                (-30)
#define CV2X_RRC_MAX_P_MAX                                33
#define CV2X_RRC_MIN_ADDITIONAL_SPECTRUM_EMISSION_R12     1U
#define CV2X_RRC_MAX_ADDITIONAL_SPECTRUM_EMISSION_R12     32U
#define CV2X_RRC_MIN_ADDITIONAL_SPECTRUM_EMISSION_V10L0   33U
#define CV2X_RRC_MAX_ADDITIONAL_SPECTRUM_EMISSION_V10L0   288U
#define CV2X_RRC_MIN_ZONE_ID_LONGI_MOD_R14                1U
#define CV2X_RRC_MAX_ZONE_ID_LONGI_MOD_R14                4U
#define CV2X_RRC_MIN_ZONE_ID_LATI_MOD_R14                 1U
#define CV2X_RRC_MAX_ZONE_ID_LATI_MOD_R14                 4U
#define CV2X_RRC_MAX_SYNC_OFFSET_INDICATOR_R14            159U
#define CV2X_RRC_MIN_TX_PARAMETERS_R14                    (-126)
#define CV2X_RRC_MAX_TX_PARAMETERS_R14                    31
#define CV2X_RRC_MAX_SYNC_TX_THRESH_OOC_R14               11U
#define CV2X_RRC_MIN_MIN_NUM_CANDIDATE_SF_R14             1U
#define CV2X_RRC_MAX_MIN_NUM_CANDIDATE_SF_R14             13U
#define CV2X_RRC_MAX_THRES_PSSCH_RSRP                     66U
#define CV2X_RRC_MAX_OFFSET_INDICATOR_SMALL_R12           319U
#define CV2X_RRC_MAX_OFFSET_INDICATOR_LARGE_R12           10239U
#define CV2X_RRC_MAX_START_RB_SUBCHANNEL_R14              99U
#define CV2X_RRC_MAX_START_RB_PSCCH_POOL_R14              99U
#define CV2X_RRC_MAX_ZONE_ID_R14                          7U
#define CV2X_RRC_MAX_THRESH_S_RSSI_CBR_R14                45U
#define CV2X_RRC_MAX_CBR_LEVEL_1_R14                      15U
#define CV2X_RRC_MAX_SL_V2X_CBRCONFIG2_1_R14              7U
#define CV2X_RRC_MIN_PRIORITY_THRESHOLD_R14               1U
#define CV2X_RRC_MAX_PRIORITY_THRESHOLD_R14               8U
#define CV2X_RRC_MAX_SL_V2X_TXCONFIG2_1_R14               127U

/* List index by frequency */
#define CV2X_RRC_V2X_DEFAULT_FREQ_LIST_INDEX              0

/* Values needed for converting frequency */
#define CV2X_RRC_FREQ_LOWEST_BAND46                       5150
#define CV2X_RRC_EARFCN_CALC_OFFSET_BAND46                46790

#define CV2X_RRC_FREQ_LOWEST_BAND47                       5855
#define CV2X_RRC_EARFCN_CALC_OFFSET_BAND47                54540

#define CV2X_RRC_FREQ_LOWEST                              CV2X_RRC_FREQ_LOWEST_BAND46

/* Currently we support two consecutive bands*/
/* 46790 - 54539 ==> Band 46, 54540 - 55239 ==> Band 47 */
#define CV2X_RRC_EARFCN_IS_BAND_46(rrc_freq)              ((rrc_freq) < CV2X_RRC_EARFCN_CALC_OFFSET_BAND47)
#define CV2X_RRC_FREQ_IS_BAND_46(cv2x_freq)               ((cv2x_freq) < CV2X_RRC_FREQ_LOWEST_BAND47)

/* Converting RRC frequency value to MHz units (and vice versa) is done according to TS136.101@5.7.3.*/
/* May be used after validating values. */
#define RRC_FREQ_TO_CV2X_FREQ(rrc_freq)                  (CV2X_RRC_EARFCN_IS_BAND_46(rrc_freq) ? \
  	                                                     (CV2X_RRC_FREQ_LOWEST_BAND46 + (((rrc_freq) - CV2X_RRC_EARFCN_CALC_OFFSET_BAND46) / 10)) : \
  	                                                     (CV2X_RRC_FREQ_LOWEST_BAND47 + (((rrc_freq) - CV2X_RRC_EARFCN_CALC_OFFSET_BAND47) / 10)) )

#define CV2X_FREQ_TO_RRC_FREQ(cv2x_freq)                 (CV2X_RRC_FREQ_IS_BAND_46(cv2x_freq) ? \
                                                         ((10 * ((cv2x_freq) - CV2X_RRC_FREQ_LOWEST_BAND46)) + CV2X_RRC_EARFCN_CALC_OFFSET_BAND46) : \
                                                         ((10 * ((cv2x_freq) - CV2X_RRC_FREQ_LOWEST_BAND47)) + CV2X_RRC_EARFCN_CALC_OFFSET_BAND47) )

/* Converting RRC threshold for RSSI CBR to DBM units is done according to TS 36.214 [48]. */
/* Value 0 corresponds to -112 dBm, value 1 to -110 dBm, value n to (-112 + n*2) dBm, and so on. */
#define RRC_RSSI_THRESHOLD_TO_DBM(rrc_rssi_threshold)    (-112 + ((rrc_rssi_threshold) * 2))


/* ------------------------ Enumerations ------------------------- */


/** Bandwidth in number of Resource Blocks */
typedef enum {
  CV2X_RRC_BANDWIDTH_N6 = 0,
  CV2X_RRC_BANDWIDTH_N15,
  CV2X_RRC_BANDWIDTH_N25,
  CV2X_RRC_BANDWIDTH_N50,
  CV2X_RRC_BANDWIDTH_N75,
  CV2X_RRC_BANDWIDTH_N100,

  CV2X_RRC_BANDWIDTH_MAX = CV2X_RRC_BANDWIDTH_N100

} cv2x_rrc_sl_bandwidth_t;


/** Sub-channel size in number of Resource Blocks */
typedef enum {
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N4 = 0,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N5,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N6,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N8,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N9,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N10,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N12,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N15,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N16,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N18,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N20,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N25,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N30,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N48,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N50,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N72,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N75,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N96,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_N100,

  CV2X_RRC_SUBCHANNEL_SIZE_R14_MAX = CV2X_RRC_SUBCHANNEL_SIZE_R14_N100,

  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE13,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE12,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE11,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE10,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE9,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE8,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE7,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE6,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE5,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE4,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE3,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE2,
  CV2X_RRC_SUBCHANNEL_SIZE_R14_SPARE1,

} cv2x_rrc_subchannel_size_r14_t;


/** Number of sub-channels */
typedef enum {
  CV2X_RRC_SUBCHANNEL_NUM_R14_N1 = 0,
  CV2X_RRC_SUBCHANNEL_NUM_R14_N3,
  CV2X_RRC_SUBCHANNEL_NUM_R14_N5,
  CV2X_RRC_SUBCHANNEL_NUM_R14_N8,
  CV2X_RRC_SUBCHANNEL_NUM_R14_N10,
  CV2X_RRC_SUBCHANNEL_NUM_R14_N15,
  CV2X_RRC_SUBCHANNEL_NUM_R14_N20,

  CV2X_RRC_SUBCHANNEL_NUM_R14_MAX = CV2X_RRC_SUBCHANNEL_NUM_R14_N20,

  CV2X_RRC_SUBCHANNEL_NUM_R14_SPARE1

} cv2x_rrc_subchannel_num_r14_t;


/** TDD ( Time-Division Duplex) physical channel configuration */
typedef enum {
  CV2X_RRC_SFRAME_ASSIGNMENT_NONE = 0,
  CV2X_RRC_SFRAME_ASSIGNMENT_0,
  CV2X_RRC_SFRAME_ASSIGNMENT_1,
  CV2X_RRC_SFRAME_ASSIGNMENT_2,
  CV2X_RRC_SFRAME_ASSIGNMENT_3,
  CV2X_RRC_SFRAME_ASSIGNMENT_4,
  CV2X_RRC_SFRAME_ASSIGNMENT_5,
  CV2X_RRC_SFRAME_ASSIGNMENT_6,

  CV2X_RRC_SFRAME_ASSIGNMENT_MAX = CV2X_RRC_SFRAME_ASSIGNMENT_6

} cv2x_rrc_tdd_config_sl_r12_t;


/** Measurement filtering coefficient */
typedef enum {
  CV2X_RRC_FILTER_COEFF_0 = 0,
  CV2X_RRC_FILTER_COEFF_1,
  CV2X_RRC_FILTER_COEFF_2,
  CV2X_RRC_FILTER_COEFF_3,
  CV2X_RRC_FILTER_COEFF_4,
  CV2X_RRC_FILTER_COEFF_5,
  CV2X_RRC_FILTER_COEFF_6,
  CV2X_RRC_FILTER_COEFF_7,
  CV2X_RRC_FILTER_COEFF_8,
  CV2X_RRC_FILTER_COEFF_9,
  CV2X_RRC_FILTER_COEFF_11,
  CV2X_RRC_FILTER_COEFF_13,
  CV2X_RRC_FILTER_COEFF_15,
  CV2X_RRC_FILTER_COEFF_17,
  CV2X_RRC_FILTER_COEFF_19,

  CV2X_RRC_FILTER_COEFF_MAX = CV2X_RRC_FILTER_COEFF_19,

  CV2X_RRC_FILTER_COEFF_SPARE1

} cv2x_rrc_filter_coefficient_t;


/** Hysteresis when evaluating a sync reference UE using absolute comparison */
typedef enum {
  CV2X_RRC_SYNC_REF_MIN_HYST_R14_dB0 = 0,
  CV2X_RRC_SYNC_REF_MIN_HYST_R14_dB3,
  CV2X_RRC_SYNC_REF_MIN_HYST_R14_dB6,
  CV2X_RRC_SYNC_REF_MIN_HYST_R14_dB9,
  CV2X_RRC_SYNC_REF_MIN_HYST_R14_dB12,

  CV2X_RRC_SYNC_REF_MIN_HYST_R14_MAX = CV2X_RRC_SYNC_REF_MIN_HYST_R14_dB12

} cv2x_rrc_sync_ref_min_hyst_r14_t;


/** Hysteresis when evaluating a sync reference UE using relative comparison */
typedef enum {
  CV2X_RRC_SYNC_REF_DIFF_HYST_R14_dB0 = 0,
  CV2X_RRC_SYNC_REF_DIFF_HYST_R14_dB3,
  CV2X_RRC_SYNC_REF_DIFF_HYST_R14_dB6,
  CV2X_RRC_SYNC_REF_DIFF_HYST_R14_dB9,
  CV2X_RRC_SYNC_REF_DIFF_HYST_R14_dB12,
  CV2X_RRC_SYNC_REF_DIFF_HYST_R14_dBinf,

  CV2X_RRC_SYNC_REF_DIFF_HYST_R14_MAX = CV2X_RRC_SYNC_REF_DIFF_HYST_R14_dBinf

} cv2x_rrc_sync_ref_diff_hyst_r14_t;


/** RSVP value */
typedef enum {
  /** 20 ms */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V0DOT2 = 0,

  /** 50 ms */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V0DOT5,

  /** 100 ms */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V1,

  /** 200 ms */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V2,

  /** 300 ms */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V3,

  /** 400 ms */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V4,

  /** 500 ms */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V5,

  /** 600 ms */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V6,

  /** 700 ms */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V7,

  /** 800 ms */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V8,

  /** 900 ms */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V9,

  /** 1 second */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_V10,

  /** Maximum enumeration value */
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_MAX = CV2X_RRC_RESTRICT_RR_PERIOD_R14_V10,

  CV2X_RRC_RESTRICT_RR_PERIOD_R14_SPARE4,
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_SPARE3,
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_SPARE2,
  CV2X_RRC_RESTRICT_RR_PERIOD_R14_SPARE1,

} cv2x_rrc_sl_restrict_rr_period_r14_t;


/** Synchronization reference type */
typedef enum {
  CV2X_RRC_TYPE_TX_SYNC_R14_GNSS = 0,
  CV2X_RRC_TYPE_TX_SYNC_R14_ENB,
  CV2X_RRC_TYPE_TX_SYNC_R14_UE,

  CV2X_RRC_TYPE_TX_SYNC_R14_MAX = CV2X_RRC_TYPE_TX_SYNC_R14_UE

} cv2x_rrc_type_tx_sync_r14_t;


/** Speed threshold */
typedef enum {
  CV2X_RRC_THRESH_UE_SPEED_R14_KMPH60 = 0,
  CV2X_RRC_THRESH_UE_SPEED_R14_KMPH80,
  CV2X_RRC_THRESH_UE_SPEED_R14_KMPH100,
  CV2X_RRC_THRESH_UE_SPEED_R14_KMPH120,
  CV2X_RRC_THRESH_UE_SPEED_R14_KMPH140,
  CV2X_RRC_THRESH_UE_SPEED_R14_KMPH160,
  CV2X_RRC_THRESH_UE_SPEED_R14_KMPH180,
  CV2X_RRC_THRESH_UE_SPEED_R14_KMPH200,

  CV2X_RRC_THRESH_UE_SPEED_R14_MAX = CV2X_RRC_THRESH_UE_SPEED_R14_KMPH200

} cv2x_rrc_thres_ue_speed_r14_t;


/** Re-transmissions mode */
typedef enum {
  /** No re-transmission */
  CV2X_RRC_ALLOWED_RETX_NUMBER_PSSCH_R14_N0 = 0,

  /** One re-transmission */
  CV2X_RRC_ALLOWED_RETX_NUMBER_PSSCH_R14_N1,

  /** UE may autonomously select no re-transmission or one re-transmission */
  CV2X_RRC_ALLOWED_RETX_NUMBER_PSSCH_R14_BOTH,

  /** Maximum enumeration value */
  CV2X_RRC_ALLOWED_RETX_NUMBER_PSSCH_R14_MAX = CV2X_RRC_ALLOWED_RETX_NUMBER_PSSCH_R14_BOTH,

  CV2X_RRC_ALLOWED_RETX_NUMBER_PSSCH_R14_SPARE1,

} cv2x_rrc_allowed_retx_number_pssch_r14_t;


/** Probability for keeping selected resources */
typedef enum {
  /** 0%: No reservation keep */
  CV2X_RRC_PROB_RESOURCE_KEEP_R14_V0 = 0,

  /** 20% */
  CV2X_RRC_PROB_RESOURCE_KEEP_R14_V0DOT2,

  /** 40% */
  CV2X_RRC_PROB_RESOURCE_KEEP_R14_V0DOT4,

  /** 60% */
  CV2X_RRC_PROB_RESOURCE_KEEP_R14_V0DOT6,

  /** 80% */
  CV2X_RRC_PROB_RESOURCE_KEEP_R14_V0DOT8,

  /** Maximum enumeration value */
  CV2X_RRC_PROB_RESOURCE_KEEP_R14_MAX = CV2X_RRC_PROB_RESOURCE_KEEP_R14_V0DOT8,

  CV2X_RRC_PROB_RESOURCE_KEEP_R14_SPARE3,
  CV2X_RRC_PROB_RESOURCE_KEEP_R14_SPARE2,
  CV2X_RRC_PROB_RESOURCE_KEEP_R14_SPARE1,

} cv2x_rrc_prob_resource_keep_r14_t;


/** Number of skipped transmissions that will trigger resource re-selection */
typedef enum {
  CV2X_RRC_RESELECT_AFTER_R14_N1 = 0,
  CV2X_RRC_RESELECT_AFTER_R14_N2,
  CV2X_RRC_RESELECT_AFTER_R14_N3,
  CV2X_RRC_RESELECT_AFTER_R14_N4,
  CV2X_RRC_RESELECT_AFTER_R14_N5,
  CV2X_RRC_RESELECT_AFTER_R14_N6,
  CV2X_RRC_RESELECT_AFTER_R14_N7,
  CV2X_RRC_RESELECT_AFTER_R14_N8,
  CV2X_RRC_RESELECT_AFTER_R14_N9,

  CV2X_RRC_RESELECT_AFTER_R14_MAX = CV2X_RRC_RESELECT_AFTER_R14_N9,

  CV2X_RRC_RESELECT_AFTER_R14_SPARE7,
  CV2X_RRC_RESELECT_AFTER_R14_SPARE6,
  CV2X_RRC_RESELECT_AFTER_R14_SPARE5,
  CV2X_RRC_RESELECT_AFTER_R14_SPARE4,
  CV2X_RRC_RESELECT_AFTER_R14_SPARE3,
  CV2X_RRC_RESELECT_AFTER_R14_SPARE2,
  CV2X_RRC_RESELECT_AFTER_R14_SPARE1,

} cv2x_rrc_sl_reselect_after_r14_t;


/** Synchronization source (used for sync source priority) */
typedef enum {
  CV2X_RRC_SYNC_PRIORITY_R14_GNSS = 0,
  CV2X_RRC_SYNC_PRIORITY_R14_ENB,

  CV2X_RRC_SYNC_PRIORITY_R14_MAX = CV2X_RRC_SYNC_PRIORITY_R14_ENB

} cv2x_rrc_sync_priority_r14_t;


/** Geographic zone length / width in meters */
typedef enum {
  CV2X_RRC_ZONE_LEN_WID_M5 = 0,
  CV2X_RRC_ZONE_LEN_WID_M10,
  CV2X_RRC_ZONE_LEN_WID_M20,
  CV2X_RRC_ZONE_LEN_WID_M50,
  CV2X_RRC_ZONE_LEN_WID_M100,
  CV2X_RRC_ZONE_LEN_WID_M200,
  CV2X_RRC_ZONE_LEN_WID_M500,

  CV2X_RRC_ZONE_LEN_WID_MAX = CV2X_RRC_ZONE_LEN_WID_M500,

  CV2X_RRC_ZONE_LEN_WID_SPARE1,

} cv2x_rrc_zone_len_wid_t;


/** Length of resource pool bitmap in number of bits */
typedef enum {
  CV2X_RRC_BIT_STRING_BITS_10 = 0,
  CV2X_RRC_BIT_STRING_BITS_16,
  CV2X_RRC_BIT_STRING_BITS_20,
  CV2X_RRC_BIT_STRING_BITS_30,
  CV2X_RRC_BIT_STRING_BITS_40,
  CV2X_RRC_BIT_STRING_BITS_50,
  CV2X_RRC_BIT_STRING_BITS_60,
  CV2X_RRC_BIT_STRING_BITS_100,

  CV2X_RRC_BIT_STRING_BITS_MAX = CV2X_RRC_BIT_STRING_BITS_100

} cv2x_rrc_subframe_bitmap_sl_t;


/** Used as a flag to mark max_tx_power_r14 value interpretation */
typedef enum {
  /** Ignore max_tx_power_r14 value as it is not available in RRC Pre-Configuration */
  CV2X_RRC_MAX_TX_POWER_STATUS_ABSENT = 0,

  /** Value of -Infinity */
  CV2X_RRC_MAX_TX_POWER_STATUS_MINUS_INFINITY,

  /** Valid power value in dBm */
  CV2X_RRC_MAX_TX_POWER_STATUS_VALUE,

  /** Maximum enumeration value */
  CV2X_RRC_MAX_TX_POWER_STATUS_MAX = CV2X_RRC_MAX_TX_POWER_STATUS_VALUE

} cv2x_rrc_max_tx_power_status_t;


/** Used as a flag to mark sl_offset_indicator_r14 value interpretation */
typedef enum {
  /** Ignore sl_offset_indicator_r14 value as it is not available in RRC Pre-Configuration */
  CV2X_SL_OFFSET_INDICATOR_STATUS_ABSENT = 0,

  /** sl_offset_indicator_r14 value is in range of 0 - 319 */
  CV2X_SL_OFFSET_INDICATOR_STATUS_SMALL,

  /** sl_offset_indicator_r14 value is in range of 0 - 10239 */
  CV2X_SL_OFFSET_INDICATOR_STATUS_LARGE,

  /** Maximum enumeration value */
  CV2X_SL_OFFSET_INDICATOR_STATUS_MAX = CV2X_SL_OFFSET_INDICATOR_STATUS_LARGE

} cv2x_sl_offset_indicator_status_t;


/* -------------------------- Structures ------------------------- */


/* Level-4 IE structures */
/* --------------------- */

/** Tx parameters */
typedef struct cv2x_rrc_sl_pssch_tx_parameters_r14 {
  uint8_t                                  min_mcs_pssch_r14;                // Mandatory | Range: 0 - 31
  uint8_t                                  max_mcs_pssch_r14;                // Mandatory | Range: 0 - 31
  uint8_t                                  min_sub_channel_number_pssch_r14; // Mandatory | Range: 0 - 20
  uint8_t                                  max_sub_channel_number_pssch_r14; // Mandatory | Range: 0 - 20
  cv2x_rrc_allowed_retx_number_pssch_r14_t allowed_retx_number_pssch_r14;    // Mandatory
  cv2x_rrc_max_tx_power_status_t           max_tx_power_status;              // Flag to mark the next field interpretation
  int8_t                                   max_tx_power_r14;                 // Optional  | Range: -41 - 31

} cv2x_rrc_sl_pssch_tx_parameters_r14_t;


/* Level-3 IE structures */
/* --------------------- */

/** PDCP ROHC (Robust Header Compression) Profiles-r12 */
typedef struct cv2x_rrc_rohc_profiles_r12 {
  bool profile0x0001_r12; // Mandatory
  bool profile0x0002_r12; // Mandatory
  bool profile0x0004_r12; // Mandatory
  bool profile0x0006_r12; // Mandatory
  bool profile0x0101_r12; // Mandatory
  bool profile0x0102_r12; // Mandatory
  bool profile0x0104_r12; // Mandatory

} cv2x_rrc_rohc_profiles_r12_t;


/** Sync offset indicators */
typedef struct cv2x_rrc_sync_offset_indicators_r14 {
  uint8_t sync_offset_indicator1_r14;           // Mandatory | Range: 0 - 159
  uint8_t sync_offset_indicator2_r14;           // Mandatory | Range: 0 - 159
  bool    is_sync_offset_indicator3_available;  // Flag to mark whether next field is available
  uint8_t sync_offset_indicator3_r14;           // Optional  | Range: 0 - 159

} cv2x_rrc_sync_offset_indicators_r14_t;


/** P2X related resource selection mechanism */
typedef struct cv2x_rrc_sl_p2x_resource_selection_config_r14 {
  bool is_partial_sensing_available;  // Flag to mark whether next field is available
  bool partial_sensing_r14;           // Optional
  bool is_random_selection_available; // Flag to mark whether next field is available
  bool random_selection_r14;          // Optional

} cv2x_rrc_sl_p2x_resource_selection_config_r14_t;


/** Sync references allowed to use the associated pool */
typedef struct cv2x_rrc_sl_sync_allowed_r14 {
  bool is_gnss_sync_available;  // Flag to mark whether next field is available
  bool gnss_sync_r14;           // Optional
  bool is_enb_sync_available;   // Flag to mark whether next field is available
  bool enb_sync_r14;            // Optional
  bool is_ue_sync_available;    // Flag to mark whether next field is available
  bool ue_sync_r14;             // Optional

} cv2x_rrc_sl_sync_allowed_r14_t;


/** CBR-to-PPPP mappings */
typedef struct cv2x_rrc_sl_cbr_pppp_tx_pre_config_list_r14 {
  uint8_t   priority_threshold_r14;        // Mandatory | Range: 1 - 8
  uint32_t  default_tx_config_index_r14;   // Mandatory | Range: 0 - 15
  uint32_t  cbr_config_index_r14;          // Mandatory | Range: 0 - 7

  uint8_t   *tx_config_index_list_r14_ptr; // Mandatory
  uint32_t  tx_config_index_list_r14_len;  // Length: 1 - 16 [CBR_LEVEL_R14]

} cv2x_rrc_sl_cbr_pppp_tx_pre_config_list_r14_t;


/** Tx configuration per Tx sync source */
typedef struct sl_pssch_tx_config_list_r14_t
{
  bool                                  is_type_tx_sync_available;  // Flag to mark whether next field is available
  cv2x_rrc_type_tx_sync_r14_t           type_tx_sync_r14;           // Optional
  cv2x_rrc_thres_ue_speed_r14_t         thres_ue_speed_r14;         // Mandatory
  cv2x_rrc_sl_pssch_tx_parameters_r14_t parameters_above_thres_r14; // Mandatory
  cv2x_rrc_sl_pssch_tx_parameters_r14_t parameters_below_thres_r14; // Mandatory

} cv2x_rrc_sl_pssch_tx_config_list_r14_t;


/** P2X sensing configuration */
typedef struct cv2x_rrc_p2x_sensing_config_r14 {
  uint8_t  min_num_candidate_sf_r14;   // Mandatory | Range: 1 - 13
  uint16_t gap_candidate_sensing_r14;  // Mandatory | Valid bits: 0 - 9

} cv2x_rrc_p2x_sensing_config_r14_t;


/* Level-2 IE structures */
/* --------------------- */

/** General configuration */
typedef struct cv2x_rrc_sl_pre_config_general_r12 {

  /* PDCP ROHC profiles configuration */
  cv2x_rrc_rohc_profiles_r12_t rohc_profiles_r12;                   // Mandatory

  /* Physical configuration */
  uint32_t                     carrier_freq_r12;                    // Mandatory | Range: 0 - 262143
  int8_t                       max_tx_power_r12;                    // Mandatory | Range: -30 - 33
  uint8_t                      additional_spectrum_emission_r12;    // Mandatory | Range: 1 - 32
  cv2x_rrc_sl_bandwidth_t      sl_bandwidth_r12;                    // Mandatory
  cv2x_rrc_tdd_config_sl_r12_t tdd_config_sl_r12;                   // Mandatory
  uint32_t                     reserved_r12;                        // Mandatory | Valid bits: 0 - 18
  bool                         is_add_spec_emiss_v10l0_available;   // Flag to mark whether next field is available
  uint16_t                     additional_spectrum_emission_v10l0;  // Optional  | Range: 33 - 288

} cv2x_rrc_sl_pre_config_general_r12_t;


/** Sync configuration */
typedef struct cv2x_rrc_sl_pre_config_v2x_sync_r14 {
  cv2x_rrc_sync_offset_indicators_r14_t sl_v2x_sync_offset_indicators_r14;  // Mandatory
  int32_t                               sync_tx_parameters_r14;             // Mandatory | Range: -126 - 31
  uint8_t                               sync_tx_thresh_ooc_r14;             // Mandatory | Range: 0 - 11
  cv2x_rrc_filter_coefficient_t         filter_coefficient_r14;             // Mandatory
  cv2x_rrc_sync_ref_min_hyst_r14_t      sync_ref_min_hyst_r14;              // Mandatory
  cv2x_rrc_sync_ref_diff_hyst_r14_t     sync_ref_diff_hyst_r14;             // Mandatory

} cv2x_rrc_sl_pre_config_v2x_sync_r14_t;


/** Pool configuration (common for V2X-Tx / V2X-Rx / P2X-Tx pools) */
typedef struct cv2x_rrc_sl_pre_config_common_pool_r14 {
  cv2x_sl_offset_indicator_status_t               sl_offset_indicator_status;             // Flag to mark the next field interpretation
  uint16_t                                        sl_offset_indicator_r14;                // Optional | Range: 0 - 319 for small; 0 - 10239 for large
  cv2x_rrc_subframe_bitmap_sl_t                   sl_subframe_size;                       // Flag to mark the next field interpretation
  uint8_t                                         sl_subframe_r14[CV2X_RRC_POOL_BMP_LEN]; // Mandatory
  bool                                            adjacency_pscch_pscch_r14;              // Mandatory
  cv2x_rrc_subchannel_size_r14_t                  size_subchannel_r14;                    // Mandatory
  cv2x_rrc_subchannel_num_r14_t                   num_subchannel_r14;                     // Mandatory
  uint8_t                                         start_rb_subchannel_r14;                // Mandatory | Range: 0 - 99
  bool                                            is_start_rb_pscch_pool_available;       // Flag to mark whether next field is available
  uint8_t                                         start_rb_pscch_pool_r14;                // Optional  | Range: 0 - 99
  int8_t                                          data_tx_params_r14;                     // Mandatory | Range: -126 - 31
  bool                                            is_zone_id_available;                   // Flag to mark whether next field is available
  uint8_t                                         zone_id_r14;                            // Optional  | Range: 0 - 7
  bool                                            is_thresh_s_rssi_cbr_available;         // Flag to mark whether next field is available
  uint8_t                                         thresh_s_rssi_cbr_r14;                  // Optional  | Range: 0 - 45

  cv2x_rrc_sl_cbr_pppp_tx_pre_config_list_r14_t   *cbr_pssch_tx_config_list_r14_ptr;      // Optional
  uint32_t                                        cbr_pssch_tx_config_list_r14_len;       // Length: 1 - 8 [CBR_PSSCH_TX_CONFIG]

  bool                                            is_p2x_rsrc_select_cfg_available;       // Flag to mark whether next field is available
  cv2x_rrc_sl_p2x_resource_selection_config_r14_t sl_p2x_resource_selection_config_r14;   // Optional
  bool                                            is_sync_allowed_available;              // Flag to mark whether next field is available
  cv2x_rrc_sl_sync_allowed_r14_t                  sl_sync_allowed_r14;                    // Optional

  cv2x_rrc_sl_restrict_rr_period_r14_t            *sl_restrict_rr_period_list_r14_ptr;    // Optional
  uint32_t                                        sl_restrict_rr_period_list_r14_len;     // Length: 1 - 16 [RESERVATION_PERIOD_R14]

} cv2x_rrc_sl_pre_config_common_pool_r14_t;


/** Pool sensing configuration used for resource selection */
typedef struct cv2x_rrc_sl_comm_tx_pool_sensing_config_r14 {

  cv2x_rrc_sl_pssch_tx_config_list_r14_t *pssch_tx_config_list_r14_ptr;     // Mandatory
  uint32_t                               pssch_tx_config_list_r14_len;      // Length: 1 - 16 [PSSCH_TX_CONFIG_R14]

  uint8_t                                thres_pssch_rsrp_list_r14_arr[CV2X_RRC_THRES_PSSCH_RSRP_LIST_LEN]; // Mandatory

  cv2x_rrc_sl_restrict_rr_period_r14_t   *restrict_rr_period_list_r14_ptr;  // Optional
  uint32_t                               restrict_rr_period_list_r14_len;   // Length: 1 - 16 [RESERVATION_PERIOD_R14]

  cv2x_rrc_prob_resource_keep_r14_t      prob_resource_keep_r14;            // Mandatory
  bool                                   is_p2x_sensing_config_available;   // Flag to mark whether next field is available
  cv2x_rrc_p2x_sensing_config_r14_t      p2x_sensing_config_r14;            // Optional
  bool                                   is_reselect_after_available;       // Flag to mark whether next field is available
  cv2x_rrc_sl_reselect_after_r14_t       reselect_after_r14;                // Optional

} cv2x_rrc_sl_comm_tx_pool_sensing_config_r14_t;


/** Zone configuration used for resource selection */
typedef struct cv2x_rrc_sl_zone_config_r14 {

  cv2x_rrc_zone_len_wid_t zone_length_r14;        // Mandatory
  cv2x_rrc_zone_len_wid_t zone_width_r14;         // Mandatory
  uint8_t                 zone_id_longi_mod_r14;  // Mandatory | Range: 1 - 4
  uint8_t                 zone_id_lati_mod_r14;   // Mandatory | Range: 1 - 4

} cv2x_rrc_sl_zone_config_r14_t;


/** CBR ranges */
typedef struct cv2x_rrc_sl_cbr_levels_config_list_r14 {
  uint8_t  *cbr_level_list_r14_ptr; // Mandatory
  uint32_t cbr_level_list_r14_len;  // Length: 1 - 16 [CBR_LEVEL_R14]

} cv2x_rrc_sl_cbr_levels_config_list_r14_t;


/** Tx parameters per CBR range */
typedef struct cv2x_rrc_sl_cbr_pssch_tx_config_r14 {
  uint16_t                              cr_limit_r14;             // Mandatory | Range: 0 - 10000
  cv2x_rrc_sl_pssch_tx_parameters_r14_t pssch_tx_parameters_r14;  // Mandatory

} cv2x_rrc_sl_cbr_pssch_tx_config_r14_t;


/* Level-1 IE structures */
/* --------------------- */

/** RRC Pre-Configuration per frequency */
typedef struct cv2x_rrc_sl_v2x_pre_config_freq_list_r14 {
  cv2x_rrc_sl_pre_config_general_r12_t          v2x_comm_pre_config_general_r14;   // Mandatory
  bool                                          is_v2x_pcfg_v2x_sync_available;    // Flag to mark whether next field is available
  cv2x_rrc_sl_pre_config_v2x_sync_r14_t         v2x_comm_pre_config_v2x_sync_r14;  // Optional

  cv2x_rrc_sl_pre_config_common_pool_r14_t      *v2x_common_rx_pool_list_r14_ptr;  // Mandatory
  uint32_t                                      v2x_common_rx_pool_list_r14_len;   // Length: 1 - 16 [SL_V2X_RX_POOL_PRECONF_R14]

  cv2x_rrc_sl_pre_config_common_pool_r14_t      *v2x_common_tx_pool_list_r14_ptr;  // Mandatory
  uint32_t                                      v2x_common_tx_pool_list_r14_len;   // Length: 1 - 8 [SL_V2X_TX_POOL_PRECONF_R14]

  cv2x_rrc_sl_pre_config_common_pool_r14_t      *p2x_common_tx_pool_list_r14_ptr;  // Mandatory
  uint32_t                                      p2x_common_tx_pool_list_r14_len;   // Length: 1 - 8 [SL_V2X_TX_POOL_PRECONF_R14]

  bool                                          is_v2x_rsrc_select_cfg_available;  // Flag to mark whether next field is available
  cv2x_rrc_sl_comm_tx_pool_sensing_config_r14_t v2x_resource_selection_config_r14; // Optional [by standard]
                                                                                   // Forcing its presence in our solution [Autonomous Resource Selection (Mode4)].

  bool                                          is_zone_config_available;          // Flag to mark whether next field is available
  cv2x_rrc_sl_zone_config_r14_t                 zone_config_r14;                   // Optional
  cv2x_rrc_sync_priority_r14_t                  sync_priority_r14;                 // Mandatory
  bool                                          is_thres_sl_tx_prio_available;     // Flag to mark whether next field is available
  uint8_t                                       thres_sl_tx_prioritization_r14;    // Optional | Range: 1 - 8
  bool                                          is_offset_dfn_available;           // Flag to mark whether next field is available
  uint16_t                                      offset_dfn_r14;                    // Optional | Range: 0 - 1000

} cv2x_rrc_sl_v2x_pre_config_freq_list_r14_t;


/** CBR ranges and Tx configuration */
typedef struct cv2x_rrc_sl_cbr_pre_config_tx_config_list_r14 {
  cv2x_rrc_sl_cbr_levels_config_list_r14_t *cbr_range_common_config_list_r14_ptr; // Mandatory
  uint32_t                                 cbr_range_common_config_list_r14_len;  // Length: 1 - 8 [SL_V2X_CBR_CONFIG2_R14]

  cv2x_rrc_sl_cbr_pssch_tx_config_r14_t    *sl_cbr_pssch_tx_config_list_r14_ptr;  // Mandatory
  uint32_t                                 sl_cbr_pssch_tx_config_list_r14_len;   // Length: 1 - 128 [SL_V2X_TX_CONFIG2_R14]

} cv2x_rrc_sl_cbr_pre_config_tx_config_list_r14_t;


/* Level-0 IE structures */
/* --------------------- */

/** RRC Pre-Configuration root structure */
typedef struct cv2x_rrc_pre_config {
  cv2x_rrc_sl_v2x_pre_config_freq_list_r14_t      *v2x_pre_config_freq_list_r14_ptr;  // Mandatory
  uint32_t                                        v2x_pre_config_freq_list_r14_len;   // Length: 1 - 8 [FREQ_V2X_R14]

  uint32_t                                        *anchor_carrier_freq_list_r14_ptr;  // Optional
  uint32_t                                        anchor_carrier_freq_list_r14_len;   // Length: 1 - 8 [FREQ_V2X_R14]

  bool                                            is_cbr_pre_config_available;        // Flag to mark whether next field is available
  cv2x_rrc_sl_cbr_pre_config_tx_config_list_r14_t cbr_pre_config_list_r14;            // Optional
                                                                                      // (This is not a list. The "list" in the
                                                                                      // type / name is taken from the standard)

} cv2x_rrc_pre_config_t;


#ifdef __cplusplus
}
#endif


#endif  // CV2X_RRC_PRE_CONFIG_H
