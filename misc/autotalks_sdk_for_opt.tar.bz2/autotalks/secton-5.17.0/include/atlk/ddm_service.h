/** Copyright (C) 2016 Autotalks Ltd. */
#ifndef _ATLK_DDM_SERVICE_H
#define _ATLK_DDM_SERVICE_H

#include <common/eui48.h>

#include <atlk/sdk.h>
#include <atlk/ddm.h>
#include <common/counters.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
  @file
  Device Diagnostics and Management Service API
*/

/** Function prototype for status notify callback */
typedef void (*ddm_state_change_notify)(ddm_service_t *service_ptr,
                                        ddm_state_t state,
                                        void *context_ptr);


/** Function prototype for TSF status notify callback */
typedef void (*ddm_time_sync_status_change_notify)(ddm_service_t *service_ptr,
                                                   ddm_tsf_lock_status_t status);

/**
  Get DDM service instance.

  @param[in] service_name Name of service (NULL for default)
  @param[out] service_pptr DDM service instance

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_service_get(const char *service_name,
                ddm_service_t **service_pptr);

/**
  Get device state

  @param[in] service_ptr DDM service instance
  @param[out] state_ptr Device state

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_state_get(ddm_service_t *service_ptr,
              ddm_state_t *ddm_state_ptr);


/**
  Set device configuration

  @param[in] service_ptr DDM service instance
  @param[in] ddm_configuration_ptr Pointer to DDM configuration structure

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_configuration_set(ddm_service_t *service_ptr,
                      const ddm_configure_t *ddm_configuration_ptr);

/**
  Write device calibration values to device NVM

  @note Applicable for SECTON only

  @param[in] service_ptr DDM service instance
  @param[in] ddm_calibration_ptr Pointer to device calibration structure

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_calibration_write(ddm_service_t *service_ptr,
                      const ddm_calibration_t *ddm_calibration_ptr);

/**
  Write device RF CONFIG values to device NVM

  @note Applicable for SECTON only

  @param[in] service_ptr    DDM service instance
  @param[in] rf_config_ptr  Pointer to device RF CONFIG structure

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_rf_config_write(ddm_service_t *service_ptr,
                    const ddm_rf_config_t *rf_config_ptr);

/**
  Get device calibration values

  @param[in] service_ptr DDM service instance
  @param[in] ddm_calibration_ptr Pointer to device calibration structure

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_calibration_get(ddm_service_t *service_ptr,
                    ddm_calibration_t *ddm_calibration_ptr);

/**
  Get device RF CONFIG values

  @param[in]  service_ptr    DDM service instance
  @param[out] rf_config_ptr  Pointer to device calibration structure

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_rf_config_get(ddm_service_t *service_ptr, ddm_rf_config_t *rf_config_ptr);

/**
  Apply calibration files to device

  @param[in] service_ptr DDM service instance
  @param[in] ddm_main_calib_ptr Pointer to main calibration structure
  @param[in] ddm_ext_calib_ptr Pointer to extended calibration structure
  @param[in] load_default_calib_ext If set to 1 and ddm_ext_calib_ptr is NULL,
                                    load extended calibration according to
                                    sw_config structure

  @remark: If ddm_main_calib_ptr is NULL, main calibration file is not
          downloaded. Instead, device loads it from DDR/NVM according to
          sw_config.lmac_calib_file_location

  @remark: If ddm_ext_calib_ptr is NULL, extended calibration file is not
          downloaded. Instead load_default_calib_ext is checked:
          - If set, device loads it from DDR according to sw_config.lmac_calib_file_location
          - Otherwise, device does not load extended calibration

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_calibration_set(ddm_service_t *service_ptr,
                    ddm_calibration_t *ddm_main_calib_ptr,
                    ddm_calibration_t *ddm_ext_calib_ptr,
                    uint32_t load_default_calib_ext);

/**
  Get SoC unique ID

  @param[in] service_ptr DDM service instance
  @param[in] unique_id_ptr Unique ID pointer

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_unique_id_get(ddm_service_t *service_ptr,
                  ddm_unique_id_t *unique_id_ptr);

/**
  Reset device

  @param[in] service_ptr DDM service instance

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_reset(ddm_service_t *service_ptr);

/**
  Register to DDM state change notifier

  @param[in] service_ptr DDM service instance
  @param[in] handler Change notify handler
  @param[in] context_ptr Context to be passed to the handler
*/
atlk_rc_t atlk_must_check
ddm_state_change_notify_register(ddm_service_t *service_ptr,
                                ddm_state_change_notify handler,
                                void *context_ptr);

/**
  Register to DDM Time sync status change notifier

  @param[in] service_ptr DDM service instance
  @param[in] handler     Change notify handler to register

  @retval    ATLK_OK if succeeded
  @return    Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_time_sync_status_change_notify_register(ddm_service_t *service_ptr,
                                            ddm_time_sync_status_change_notify handler);

/**
  Unregister DDM Time sync status change notifier

  @param[in] service_ptr DDM service instance
  @param[in] handler     Change notify handler to unregister

  @retval    ATLK_OK if succeeded
  @return    Error code if failed
*/
atlk_rc_t
ddm_time_sync_status_change_notify_unregister(ddm_service_t *service_ptr,
                                              ddm_time_sync_status_change_notify handler);

/**
  Get device version.

  @param[in] service_ptr DDM service instance
  @param[out] ddm_version Device version string
  @param[in] version_size_ptr Device version string length

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_version_get(ddm_service_t *service_ptr,
                char *version,
                size_t *version_size_ptr);

/**
  Get device system versions.

  @param[in] service_ptr DDM service instance
  @param[out] system_versions Device system versions

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_system_versions_get(ddm_service_t *service_ptr,
                        ddm_system_versions_t *system_versions);

/**
  Set TSF value

  @param[in] service_ptr DDM service instance
  @param[in] time_usec Time in microseconds

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_tsf_set(ddm_service_t *service_ptr,
            uint64_t time_usec);

/**
  Get TSF value

  @note Uses local performance & accuracy optimization (if using Secton SPI).
        If invoked again in less than 10 msec, might retrieve a timestamp smaller
        than timestamp received in previous invocation (relevant only for Secton SPI).

  @param[in] service_ptr DDM service instance
  @param[out] time_usec_ptr Time in microseconds
  @param[out] accuracy_usec_ptr Accuracy in microseconds
  @param[out] ddm_tsf_lock_status_ptr DDM TSF lock status pointer

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_tsf_get(ddm_service_t *service_ptr,
            uint64_t *time_usec_ptr,
            uint64_t *accuracy_usec_ptr,
            ddm_tsf_lock_status_t *ddm_tsf_lock_status_ptr);

/**
  Get TSF value from hardware

  @param[in]  service_ptr             DDM service instance
  @param[out] time_usec_ptr           Time in microseconds
  @param[out] accuracy_usec_ptr       Accuracy in microseconds
  @param[out] ddm_tsf_lock_status_ptr DDM TSF lock status pointer

  @retval     ATLK_OK if succeeded
  @return     Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_hw_tsf_get(ddm_service_t *service_ptr,
                uint64_t *time_usec_ptr,
                uint64_t *accuracy_usec_ptr,
                ddm_tsf_lock_status_t *ddm_tsf_lock_status_ptr);

/**
  Set PPS signal lock validity indication

  @param[in] service_ptr DDM service instance
  @param[in] is_valid validity indication (true/false)

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_pps_validity_set(ddm_service_t *service_ptr,
                    uint32_t is_valid);

/**
  Indicate that PPS is not synchronized

  @param[in] service_ptr DDM service instance

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_pps_force_unsync(ddm_service_t *service_ptr);

/**
  Get PPS counter

  @param[in] service_ptr DDM service instance
  @param[out] pps_counter_ptr PPS counter

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_pps_counter_get(ddm_service_t *service_ptr,
                    uint32_t *pps_counter_ptr);

/**
  Set Hold-Over parameter for Rx

  @param[in] service_ptr DDM service instance
  @param[in] us Time in microseconds

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t
ddm_rx_hold_over_set(ddm_service_t *service_ptr, uint32_t us);

/**
  Set Hold-Over parameter for tx

  @param[in] service_ptr DDM service instance
  @param[in] us Time in microseconds

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/atlk_rc_t
ddm_tx_hold_over_set(ddm_service_t *service_ptr, uint32_t us);

/**
  Get Hold-Over parameter for Rx

  @param[in] service_ptr DDM service instance
  @param[out] us_ptr Micro seconds pointer

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t
ddm_rx_hold_over_get(ddm_service_t *service_ptr, uint32_t* us_ptr);

/**
  Get Hold-Over parameter for tx

  @param[in] service_ptr DDM service instance
  @param[out] us_ptr Micro seconds pointer

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t
ddm_tx_hold_over_get(ddm_service_t *service_ptr, uint32_t* us_ptr);

/**
  Get DDM last PPS timing offset

  @param[in] service_ptr DDM service instance
  @param[out] us_ptr Micro seconds pointer

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t
ddm_pps_last_timing_offset_get(ddm_service_t *service_ptr, int32_t *us_ptr);

/**
  Get DDM status

  @param[in]  service_ptr DDM service instance
  @param[out] status_ptr  Pointer to device status struct

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_status_get(ddm_service_t *service_ptr,
               ddm_status_t *status_ptr);

/**
  Set GPIO mode

  @param[in] service_ptr DDM service instance
  @param[in] bank GPIO bank
  @param[in] pin_offset GPIO pin offset in bank
  @param[in] mode GPIO mode

  @retval ::ATLK_OK if succeeded
  @return Error code if failed

  @note In case mode = DDM_GPIO_SW, direction will be automatically set to
        DDM_GPIO_DIR_OUT, and value to DDM_GPIO_VAL_0

  @note This function is available for SECTON device only
*/
atlk_rc_t atlk_must_check
ddm_gpio_mode_set(ddm_service_t *service_ptr,
                  ddm_gpio_bank_t bank,
                  ddm_gpio_pin_offset_t pin_offset,
                  ddm_gpio_mode_t mode);
/**
  Get GPIO mode

  @param[in] service_ptr DDM service instance
  @param[in] bank GPIO bank
  @param[in] pin_offset GPIO pin offset in bank
  @param[out] mode_ptr GPIO mode

  @retval ::ATLK_OK if succeeded
  @return Error code if failed

  @note This function is available for SECTON device only
*/
atlk_rc_t atlk_must_check
ddm_gpio_mode_get(ddm_service_t *service_ptr,
                  ddm_gpio_bank_t bank,
                  ddm_gpio_pin_offset_t pin_offset,
                  ddm_gpio_mode_t *mode_ptr);

/**
  Set GPIO direction

  @param[in] service_ptr DDM service instance
  @param[in] bank GPIO bank
  @param[in] pin_offset GPIO pin offset in bank
  @param[in] direction GPIO direction

  @retval ::ATLK_OK if succeeded
  @return Error code if failed

  @note Setting GPIO direction is applicable only if mode = DDM_GPIO_SW.
  @note In case direction = DDM_GPIO_DIR_OUT, the value will be automatically
        set to DDM_GPIO_VAL_0.

  @note This function is available for SECTON device only
*/
atlk_rc_t atlk_must_check
ddm_gpio_direction_set(ddm_service_t *service_ptr,
                      ddm_gpio_bank_t bank,
                      ddm_gpio_pin_offset_t pin_offset,
                      ddm_gpio_direction_t direction);

/**
  Get GPIO direction

  @param[in] service_ptr DDM service instance
  @param[in] bank GPIO bank
  @param[in] pin_offset GPIO pin offset in bank
  @param[out] direction_ptr GPIO direction

  @retval ::ATLK_OK if succeeded
  @return Error code if failed

  @note Getting GPIO direction is applicable only if mode = DDM_GPIO_SW.

  @note This function is available for SECTON device only
*/
atlk_rc_t atlk_must_check
ddm_gpio_direction_get(ddm_service_t *service_ptr,
                      ddm_gpio_bank_t bank,
                      ddm_gpio_pin_offset_t pin_offset,
                      ddm_gpio_direction_t *direction_ptr);

/**
  Set GPIO value

  @param[in] service_ptr DDM service instance
  @param[in] bank GPIO bank
  @param[in] pin_offset GPIO pin offset in bank
  @param[in] value GPIO logical value

  @retval ::ATLK_OK if succeeded
  @return Error code if failed

  @note Setting GPIO value is applicable only if mode = DDM_GPIO_SW and
        direction = DDM_GPIO_DIR_OUT.

  @note This function is available for SECTON device only
*/
atlk_rc_t atlk_must_check
ddm_gpio_value_set(ddm_service_t *service_ptr,
                  ddm_gpio_bank_t bank,
                  ddm_gpio_pin_offset_t pin_offset,
                  ddm_gpio_value_t value);

/**
  Get GPIO value

  @param[in] service_ptr DDM service instance
  @param[in] bank GPIO bank
  @param[in] pin_offset GPIO pin offset in bank
  @param[out] value_ptr GPIO logical value

  @retval ::ATLK_OK if succeeded
  @return Error code if failed

  @note Getting GPIO value is applicable only if mode = DDM_GPIO_SW.

  @note This function is available for SECTON device only
*/
atlk_rc_t atlk_must_check
ddm_gpio_value_get(ddm_service_t *service_ptr,
                  ddm_gpio_bank_t bank,
                  ddm_gpio_pin_offset_t pin_offset,
                  ddm_gpio_value_t *value_ptr);

/**
  Get baseband V2X hardware revision

  @param[in] service_ptr DDM service instance
  @param[out] revision_ptr Baseband V2X hardware revision

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_baseband_v2x_hw_revision_get(ddm_service_t *service_ptr,
                                ddm_baseband_v2x_hw_revision_t *revision_ptr);

/**
  Get DDM BSP version.

  @param[in] service_ptr DDM service instance
  @param[out] bsp_version_ptr BSP version

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_bsp_version_get(ddm_service_t *service_ptr,
                    ddm_bsp_version_t *bsp_version_ptr);

/** DDM statistics type bitmap size */
#define DDM_STATISTICS_BITMAP_TYPE_SIZE 16

/**
   Get DDM Device stats.

   @param[in] service_ptr  DDM service instance
   @param[in] stats_bitmap Bitmap of services to request, consisting of
                           several bitmaps, each corresponding to a service

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_device_stats_get(ddm_service_t *service_ptr,
                     uint8_t stats_bitmap[DDM_STATISTICS_BITMAP_TYPE_SIZE]);

/** DDM device statistics getter types */
typedef enum ddm_stats_get_option {
  /** Skip device statistics */
  DDM_STATS_GET_OPTION_SKIP_DEVICE_STATS = 0U,

  /** Get device statistics from cache */
  DDM_STATS_GET_OPTION_CACHED_DEVICE_STATS,

  /** Fetch device statistics from device */
  DDM_STATS_GET_OPTION_FETCH_DEVICE_STATS,
} ddm_stats_get_option_t;

/** DDM statistics */
typedef struct {
  /** DDM statistics header */
  stats_tlv_t        header;

  /** DDM statistics time stamp  */
  unsigned long long snapshot_time;

  /** DDM statistics flow/extended counters */
  atlk_flow_counters_t stats;
} ddm_stats_t;

/**
   Return statistic total size.

   @param[in] stats_header_ptr Pointer to statistic header

   @return statistic size in bytes
*/
static inline size_t
ddm_stats_tlv_total_length(const stats_tlv_t *stats_header_ptr)
{
  if ((stats_header_ptr == NULL) || (stats_header_ptr->length == 0U)) {
    return 0U;
  }

  return stats_header_ptr->length + sizeof(*stats_header_ptr);
}

/**
   Return pointer to the next TLV in the list.

   @param[in] stats_header_ptr Pointer to statistic header

   @return Pointer to the next statistic or NULL if no more statistics
*/
static inline void*
ddm_stats_tlv_next(const void *stats_header_ptr)
{
  size_t stats_size = ddm_stats_tlv_total_length((const stats_tlv_t *)stats_header_ptr);

  if (stats_size == 0U)  {
    return NULL;
  }

  /* parasoft suppress MISRA2012-RULE-11_8-2 */
  return ((uint8_t*)stats_header_ptr) + stats_size;
  /* parasoft unsuppress MISRA2012-RULE-11_8-2 */
}

/**
   Check if stats_ptr is the last stats in the list.

   @param[in] stats_ptr Pointer to ddm_stats_t instance

   @return 1 if stats instance is the last, 0 otherwise
*/
/* parasoft-begin-suppress BD-PB-UCMETH-4 "This function is only used in applications that are excluded from MISRA build" */
static inline int
ddm_stats_is_end_of_list(const ddm_stats_t *stats_ptr)
{
  if (stats_ptr == NULL) {
    return 0;
  }

  return stats_ptr->header.length == 0U ? 1 : 0;
}
/* parasoft-end-suppress BD-PB-UCMETH-4 */

/**
   Returning application's own statistics.

   @param[in]  type_bitmap Bitmap of services to request, consisting of
                           several bitmaps, each corresponding to a service
   @param[out] buffer      Pointer to memory for statistics
   @param[in]  buffer_size Size of allocated memory for statistics

   @retval None
*/
void
ddm_stats_session_get(uint8_t type_bitmap[DDM_STATISTICS_BITMAP_TYPE_SIZE],
                      uint8_t buffer[],
                      size_t  buffer_size);

/**
   Obtain total system-level statistics per service.

   @param[in]  type_bitmap                   Bitmap of services to request, consisting of
                                             Several bitmaps, each corresponding to a service
   @param[out] buffer                        Buffer for statistics
   @param[in]  buffer_size                   Buffer size
   @param[in]  need_device_stats             Specify getter behavior
   @param[in]  accumulate_from_all_processes If set statistic from all process will be accumulated to this process"
   @param[in]  clear_stats                   Clear statistics"

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_stats_total_get(uint8_t               type_bitmap[DDM_STATISTICS_BITMAP_TYPE_SIZE],
                    ddm_stats_t            buffer[],
                    size_t                 buffer_size,
                    ddm_stats_get_option_t need_device_stats,
                    uint8_t                accumulate_from_all_processes,
                    uint8_t                clear_stats);

/**
   Returns the minimal buffer size to hold statistics.

   @param[in] need_device_stats Specify getter behavior
   @param[in] type_bitmap       Bitmap of services to request, consisting of
                                several bitmaps, each corresponding to a service

   @return Size of statistics in bytes, 0 on error
*/
size_t
ddm_stats_min_size_get(ddm_stats_get_option_t need_device_stats,
                       uint8_t type_bitmap[DDM_STATISTICS_BITMAP_TYPE_SIZE]);

/**
   Converts service type to service name.

   Maximum len of the returned string is ::DSM_NAME_MAX_LEN

   @param[in] type Service type

   @return constant pointer to service name
*/
const char*
ddm_service_str(dsm_service_type_t type);

/**
   Converts service statistic type to service statistic name.

   Maximum len of the returned string is ::DSM_NAME_MAX_LEN

   @param[in] type Service statistic type

   @return constant pointer to service statistic name
*/
const char*
ddm_stats_service_str(stats_service_type_t type);

/**
   Converts layer type to layer name.

   Maximum len of the returned string is ::DSM_NAME_MAX_LEN

   @param[in] type Layer type

   @return constant pointer to layer name
*/
const char*
ddm_stats_layer_str(stats_layer_type_t type);

/**
  Reset device CPU Profiler counters

  @param[in]  service_ptr: DDM service instance

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_cpu_profiler_reset(ddm_service_t *service_ptr);

/**
  Get device CPU Profiler report

  @param[in]  service_ptr  : DDM service instance
  @param[out] report_ptr   : pointer to CPU Profiler report
  @param[in]  clear_on_read: flag - set to non zero to clear profiler's
                             counters right after the read.

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_cpu_profiler_report_get(ddm_service_t *service_ptr,
                           ddm_cpu_profiler_report_t *report_ptr,
                           uint32_t clear_on_read);

/**
  Get host to device per-service message rate for the last second

  @param[in]  service_ptr  : DDM service instance
  @param[out] msg_rate_ptr : pointer to message rate structure

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t
ddm_msg_rate_get(ddm_service_t *service_ptr,
                 ddm_msg_rate_t *msg_rate_ptr);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_DDM_SERVICE_H */
