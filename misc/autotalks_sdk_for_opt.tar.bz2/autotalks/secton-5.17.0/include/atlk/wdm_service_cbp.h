/** Copyright (C) 2019 Autotalks Ltd. */
#ifndef _ATLK_WDM_SERVICE_CBP_H
#define _ATLK_WDM_SERVICE_CBP_H

#include <atlk/wdm_service.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   WDM Context-Based Prioritization (CBP) Header file
 */

/**
   Initializes and reset the CBP filters array and hash table

   @param[in] service_ptr  WDM service instance
   @param[in] cbp_init_ptr Pointer to wdm_cbp_config_t struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_cbp_init(wdm_service_t *service_ptr, wdm_cbp_config_t *cbp_init_ptr);

/**
   Add an filter with address <<id_ptr>> to the CBP table.
   Any frame received by the LMAC with the corresponding address will be dropped
   unless <<interval_ms>> milliseconds passed since last frame.

   @param[in] service_ptr           Pointer to WDM service instance
   @param[in] filter_id_ptr         Pointer to wdm_cbp_filter_id_t struct
   @param[in] min_frame_interval_ms Min time in ms between frames before dropping frame

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_cbp_filter_add(wdm_service_t *service_ptr,wdm_cbp_filter_id_t *filter_id_ptr, uint16_t min_frame_interval_ms);

/**
   Remove filter with key <<id_ptr>> from list of CBP Entries Array.

   @param[in] service_ptr   Pointer to WDM service instance
   @param[in] filter_id_ptr Pointer to wdm_cbp_filter_id_t struct

   @note: If the filter update interval is less than frame_interval_ms, no messages will ever be received
          as this API reset the internal filter frame interval time

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_cbp_filter_remove(wdm_service_t *service_ptr, wdm_cbp_filter_id_t *filter_id_ptr);

/**
   Get CBP status.

   @note this call resets the counters of discarded messages & total sent messages.

   @param[in] service_ptr Pointer WDM service instance
   @param[out] status_ptr Pointer to wdm_cbp_status_t struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_cbp_status_get(wdm_service_t *service_ptr, wdm_cbp_status_t *status_ptr);


/**
   Get CBP statistics.

   @note Triggers a call to garbage collection, all values are for after the garbage collection.

   @param[in] service_ptr     Pointer to WDM service instance
   @param[out] statistics_ptr Pointer to wdm_cbp_statistics_t struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_cbp_statistics_get(wdm_service_t *service_ptr, wdm_cbp_statistics_t *statistics_ptr);

/**
   Reset the CBP filter table and hash table.

   @param[in] service_ptr Pointer to WDM service instance

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_cbp_reset(wdm_service_t *service_ptr);

/**
   Retrieves the CBP filter information associated with <<id_ptr>>.

   @param[in] service_ptr   WDM service instance
   @param[in] filter_id_ptr Pointer to wdm_cbp_filter_id_t struct
   @param[out] filter_ptr   Pointer to wdm_cbp_filter_information_t struct)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_cbp_filter_get(wdm_service_t *service_ptr, wdm_cbp_filter_id_t *filter_id_ptr, wdm_cbp_filter_information_t *filter_ptr);

/**
   Retrieves the CBP filter information at index <<index>>.

   @param[in] service_ptr  WDM service instance
   @param[in] index        Filter index
   @param[out] filter_ptr  Pointer to wdm_cbp_filter_information_t

   @retval ::ATLK_OK if succeeded
   If filter is empty the function returns ATLK_E_EMPTY (22)
   If the index is above bounds the function returns ATLK_E_OUT_OF_BOUNDS (17)
   @return Error code if failed
*/
atlk_rc_t
wdm_cbp_filter_at_index_get(wdm_service_t *service_ptr, uint16_t index, wdm_cbp_filter_information_t *filter_ptr);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_WDM_SERVICE_CBP_H */
