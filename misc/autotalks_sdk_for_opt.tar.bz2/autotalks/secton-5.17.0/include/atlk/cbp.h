/* Copyright (C) 2012-2019 Autotalks Ltd. */
#ifndef _ATLK_CBP_H
#define _ATLK_CBP_H

#include <atlk/wdm_service_cbp.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   CBP Header
*/

/** Max number of CBP Entries, should be coordinated with the number in the device */
#define MAX_CBP_ENTRIES 3000

/** Min/Max values */
#define MAX_INTERVAL_TIME_MS (10000U) /* 10000 msec */
#define MIN_INTERVAL_TIME_MS (50U)    /* 50 msec */

#define MIN_AGE_TIME_MS (4U * MIN_INTERVAL_TIME_MS)
#define MAX_AGE_TIME_MS (2U * MAX_INTERVAL_TIME_MS)

/* Disable CBP priority all packets will be proceeds by CBP */
#define CBP_PRIORITY_NA (0xFF)

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_CBP_H */
