/* Copyright (C) 2016 Autotalks Ltd. */
#ifndef _ATLK_OBJECT_H
#define _ATLK_OBJECT_H

/**
   @file
   Generic object definitions
*/

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Object description flags */
typedef enum {
  /** No flags set */
  ATLK_OBJECT_FLAGS_NA = 0,

  /** Object is empty */
  ATLK_OBJECT_FLAGS_EMPTY,

  /** Object value is referenced by opaque pointer */
  ATLK_OBJECT_FLAGS_OPAQUE,

  /** Object value is of type int8_t */
  ATLK_OBJECT_FLAGS_INTEGER8,

  /** Object value is of type uint8_t */
  ATLK_OBJECT_FLAGS_UNSIGNED8,

  /** Object value is of type int16_t */
  ATLK_OBJECT_FLAGS_INTEGER16,

  /** Object value is of type uint16_t */
  ATLK_OBJECT_FLAGS_UNSIGNED16,

  /** Object value is of type int32_t */
  ATLK_OBJECT_FLAGS_INTEGER32,

  /** Object value is of type uint32_t */
  ATLK_OBJECT_FLAGS_UNSIGNED32,

  /** Object value is of type int64_t */
  ATLK_OBJECT_FLAGS_INTEGER64,

  /** Object value is of type uint64_t */
  ATLK_OBJECT_FLAGS_UNSIGNED64,

} atlk_object_flags_t;

/** Generic object descriptor */
typedef struct {
  /** Flags that describe the object */
  uint16_t flags;

  /** Object type */
  uint16_t type;

  /** Object instance index (e.g. interface index) */
  uint32_t index;

  /** Additional index storage input variable */
  uint32_t uint32_key;

  /** Pointer storage input variable  */
  uintptr_t uintpr_key;

  /** Union of value types */
  union {
    /** Value of int8_t object */
    int8_t int8;

    /** Value of uint8_t object */
    uint8_t uint8;

    /** Value of int16_t object */
    int16_t int16;

    /** Value of uint16_t object */
    uint16_t uint16;

    /** Value of int32_t object */
    int32_t int32;

    /** Value of uint32_t object */
    uint32_t uint32;

    /** Value of int64_t object */
    int64_t int64;

    /** Value of uint64_t object */
    uint64_t uint64;

    /** Reference to an opaque object */
    struct {
      /** Pointer to an opaque object not containing pointers only data */
      void *ptr;

      /** Size of opaque object in bytes */
      size_t size;

    } opaque;

  } value;

} atlk_object_t;

  /** Opaque object initialization macro */
#define ATLK_OBJECT_OPAQUE(_type, _index, _lvalue) {  \
    .flags = (uint16_t)ATLK_OBJECT_FLAGS_OPAQUE,      \
    .type = (uint16_t)(_type),                        \
    .index = (uint32_t)(_index),                      \
    .value.opaque = {                                 \
    .ptr = &(_lvalue),                                \
    .size = sizeof(_lvalue)                           \
  }                                                   \
}

  /** Empty object initialization macro */
#define ATLK_OBJECT_EMPTY(_type, _index) {            \
    .flags = (uint16_t)ATLK_OBJECT_FLAGS_EMPTY,       \
    .type = (uint16_t)(_type),                        \
    .index = (uint32_t)(_index)                       \
  }

  /** int32_t object initialization macro */
#define ATLK_OBJECT_INT32(_type, _index, _rvalue) {   \
    .flags = (uint16_t)ATLK_OBJECT_FLAGS_INTEGER32,   \
    .type = (uint16_t)(_type),                        \
    .index = (uint32_t)(_index),                      \
    .value.int32 = (_rvalue)                          \
  }

  /** uint32_t object initialization macro */
#define ATLK_OBJECT_UINT32(_type, _index, _rvalue) {  \
    .flags = (uint16_t)ATLK_OBJECT_FLAGS_UNSIGNED32,  \
    .type = (uint16_t)(_type),                        \
    .index = (uint32_t)(_index),                      \
    .value.uint32 = (uint32_t)(_rvalue)               \
  }

  /** int64_t object initialization macro */
#define ATLK_OBJECT_INT64(_type, _index, _rvalue) {   \
    .flags = (uint16_t)ATLK_OBJECT_FLAGS_INTEGER64,   \
    .type = (uint16_t)(_type),                        \
    .index = (uint32_t)(_index),                      \
    .value.int64 = (_rvalue)                          \
  }

  /** uint64_t object initialization macro */
#define ATLK_OBJECT_UINT64(_type, _index, _rvalue) {  \
    .flags = (uint16_t)ATLK_OBJECT_FLAGS_UNSIGNED64,  \
    .type = (uint16_t)(_type),                        \
    .index = (uint32_t)(_index),                      \
    .value.uint64 = (_rvalue)                         \
  }

#ifdef __cplusplus
}
#endif

#endif // _ATLK_OBJECT_H
