/** Copyright (C) 2018 Autotalks Ltd. */
#ifndef _ATLK_IVN_SERVICE_H
#define _ATLK_IVN_SERVICE_H

#include <atlk/sdk.h>
#include <atlk/ivn.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   IVN service API
*/

/**
   Get pointer to IVN service.

   @param[in] service_name Name of service (NULL for default)
   @param[out] service_pptr Pointer to IVN service

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ivn_service_get(const char *service_name,
                ivn_service_t **service_pptr);

/** IVN device configuration */
typedef struct
{
  /** IVN baudrate */
  ivn_baudrate_t ivn_baudrate;

} ivn_device_config_t;

#define IVN_DEVICE_CONFIG_INIT {                \
  .ivn_baudrate = IVN_BAUDRATE_NA,              \
}

/** IVN socket */
typedef atlk_handle_t ivn_socket_t;

/** IVN socket configuration parameters */
typedef struct {
  /** Ingress/egress IVN device ID */
  ivn_device_id_t device_id;

} ivn_socket_config_t;

/** IVN socket configuration parameters default initializer */
#define IVN_SOCKET_CONFIG_INIT {    \
  .device_id = IVN_DEVICE_ID_NA,    \
}

/**
   Configure IVN device.

   @param[in] service_ptr IVN service instance
   @param[in] device_id Device identifier
   @param[in] config_ptr IVN configuration

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ivn_device_config_set(ivn_service_t *service_ptr,
                      ivn_device_id_t device_id,
                      const ivn_device_config_t *config_ptr);

/**
   Create IVN socket.

   When ::ivn_socket_config_t::device_id is set to ::IVN_DEVICE_ID_NA,
   ::ivn_receive will receive frames from both IVN devices and ::ivn_send
   ivnnot be used.

   @param[in] service_ptr IVN service instance
   @param[out] socket_ptr IVN socket pointer
   @param[in] config IVN socket configuration

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ivn_socket_create(ivn_service_t *service_ptr,
                  ivn_socket_t **socket_ptr,
                  const ivn_socket_config_t *config);

/**
   Delete existing IVN socket.

   @param[in] socket_ptr IVN socket pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ivn_socket_delete(ivn_socket_t *socket_ptr);

/**
   Send IVN frame.

   @note For extended frame format, bitwise OR ivn_id with IVN_EXTENDED_FORMAT_ID_MASK

   @param[in] socket_ptr IVN socket
   @param[in] data_ptr Pointer to start of data
   @param[in] data_size Size of data in bytes
   @param[in] ivn_id IVN ID of frame
   @param[in] wait_ptr Wait specification

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ivn_send(ivn_socket_t *socket_ptr,
         const void *data_ptr,
         size_t data_size,
         ivn_message_id_t ivn_id,
         const atlk_wait_t *wait_ptr);

/**
   Receive IVN frame.

   @note ivn_id ID bitwise AND with IVN_EXTENDED_FORMAT_ID_MASK indicates extended frame format

   @param[in] socket_ptr IVN socket
   @param[out] data_ptr Pointer to start of frame data
   @param[in,out] data_size_ptr
            Maximum (in) and actual (out) frame data size in bytes
   @param[out] ivn_id_ptr Pointer to received frame's IVN ID
   @param[in] wait_ptr Wait specification (optional)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ivn_receive(ivn_socket_t *socket_ptr,
            void *data_ptr,
            size_t *data_size_ptr,
            ivn_message_id_t *ivn_id_ptr,
            const atlk_wait_t *wait_ptr);

/**
   Get IVN subsystem statistics.

   @param[in] service_ptr IVN service instance
   @param[in] device_id Device identifier
   @param[out] stats_ptr IVN statistics structure pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ivn_statistics_get(ivn_service_t *service_ptr,
                   ivn_device_id_t device_id,
                   ivn_stats_t *stats_ptr);

/**
   Set IVN filter table

   @note For accepting all IVN IDs, set filter_tbl_ptr->filter_num to IVN_FILTER_ANY
   @note For extended frame format, bitwise OR filter_tbl_ptr->filters[entry] with IVN_EXTENDED_FORMAT_ID_MASK

   @param[in] service_ptr IVN service instance
   @param[in] device_id Device identifier
   @param[in] filter_tbl_ptr IVN filter table structure pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ivn_filter_tbl_set(ivn_service_t *service_ptr,
                   ivn_device_id_t device_id,
                   const ivn_filter_tbl_t *filter_tbl_ptr);

/**
   Get IVN filter table

   @note A filter_tbl_ptr->filter_num value of IVN_FILTER_ANY indicates acceptance of all IVN IDs
   @note filter_tbl_ptr->filters[entry] bitwise AND with IVN_EXTENDED_FORMAT_ID_MASK indicates
   extended frame format

   @param[in] service_ptr IVN service instance
   @param[in] device_id Device identifier
   @param[out] filter_tbl_ptr IVN filter table structure pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ivn_filter_tbl_get(ivn_service_t *service_ptr,
                   ivn_device_id_t device_id,
                   ivn_filter_tbl_t *filter_tbl_ptr);

/**
   Get IVN protocol

   @note Protocol is fetched from M3 core on driver initialization, the value is used by this API
   @note Only M3 core can set the protocol, this assumed do be done only on M3 initialization

   @param[in] service_ptr IVN service instance
   @param[in] device_id Device identifier
   @param[out] protocol_ptr IVN protocol pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ivn_protocol_get(ivn_service_t *service_ptr,
                 ivn_device_id_t device_id,
                 uint32_t *protocol_ptr);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_IVN_SERVICE_H */
