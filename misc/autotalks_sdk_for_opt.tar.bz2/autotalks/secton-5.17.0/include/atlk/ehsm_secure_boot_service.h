/** Copyright (C) 2018 Autotalks Ltd. */
#ifndef _ATLK_EHSM_BOOT_SECURE_SERVICE_H
#define _ATLK_EHSM_BOOT_SECURE_SERVICE_H

#include <atlk/sdk.h>
#include <atlk/ecc.h>
#include <atlk/hash.h>
#include <atlk/ehsm.h>

/**
  Get fall through disabled value

  @param[in] service_ptr Embedded HSM service instance
  @param[out] disabled_ptr Fall through disabled value

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_fall_through_disabled_get(ehsm_service_t *service_ptr,
                                    int *disabled_ptr);

/**
  Disable fall through

  @remark Fall through is enabled by default
          After it is disabled, it cannot be enabled back

  @param[in] service_ptr Embedded HSM service instance

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_fall_through_disable(ehsm_service_t *service_ptr);

/**
  Get UART3 disabled value

  @remark Default state is enabled
          After it is disabled, it cannot be enabled back

  @param[in] service_ptr Embedded HSM service instance
  @param[out] disabled_ptr UART3 disabled value

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_uart3_disabled_get(ehsm_service_t *service_ptr,
                             int *disabled_ptr);

/**
  Disable UART3

 @remark UART3 is enabled by default
         After it is disabled, it cannot be enabled back

  @param[in] service_ptr Embedded HSM service instance

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_uart3_disable(ehsm_service_t *service_ptr);

/**
  Get secure boot enabled value

  @param[in] service_ptr Embedded HSM service instance
  @param[out] enabled_ptr Secure boot enabled value

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_secure_boot_enabled_get(ehsm_service_t *service_ptr,
                                  int *enabled_ptr);

/**
  Enable secure boot

  @remark Once secure boot is enabled, it can not be undone.

  @param[in] service_ptr Embedded HSM service instance

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_secure_boot_enabled_set(ehsm_service_t *service_ptr);

/**
  Get minimal FW rollback version

  @param[in] service_ptr Embedded HSM service instance
  @param[out] version_ptr Security version level

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_security_version_level_get(ehsm_service_t *service_ptr,
                                     ehsm_secure_boot_security_version_level_t *version_ptr);

/**
  Set minimal FW rollback version

  @p version must be increasing with respect to current OTP setting

  @param[in] service_ptr Embedded HSM service instance
  @param[in] level Security version level

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_security_version_level_set(ehsm_service_t *service_ptr,
                                     ehsm_secure_boot_security_version_level_t level);

/**
  Get certification revision level

  @param[in] service_ptr Embedded HSM service instance
  @param[out] level_ptr Certification revision level

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_certificate_revision_level_get(ehsm_service_t *service_ptr,
                                         ehsm_secure_boot_certificate_revision_level_t *level_ptr);

/**
  Set certificate revision level

  @p revision must be increasing with respect to current OTP

  @param[in] service_ptr Embedded HSM service instance
  @param[in] level Certification revision level

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_certificate_revision_level_set(ehsm_service_t *service_ptr,
                                         ehsm_secure_boot_certificate_revision_level_t level);

/**
  Set alternative HASH

  @param[in] service_ptr Embedded HSM service instance
  @param[in] alt_hash_ptr Alternate HASH pointer
  @param[in] alt_hash_size Alternate HASH size in bytes
  @param[in] selected_hash_alg Selected algorithm

  @remark @p alt_hash_bytes_size must match @p selected_hash_alg

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_alternate_certificate_hash_set(ehsm_service_t *service_ptr,
                                         uint8_t *alt_hash_ptr,
                                         uint8_t alt_hash_size,
                                         hash_algorithm_t selected_hash_alg);

/**
  Set alternative Key

  @param[in] service_ptr Embedded HSM service instance
  @param[in] alt_key_ptr Alternate key pointer
  @param[in] alt_key_size Alternate key size in bytes
  @param[in] selected_key_type Selected key type

  @remark @p alt_key_bytes_size must match @p selected_key_type

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_alternate_certificate_key_set(ehsm_service_t *service_ptr,
                                        uint8_t *alt_key_ptr,
                                        uint8_t alt_key_size,
                                        ecc_curve_t selected_key_type);

/**
   Get customer ID

   @param[in] service_ptr Embedded HSM service instance
   @param[out] customer_id_ptr 32 bit Customer ID

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_customer_id_get(ehsm_service_t *service_ptr,
                          uint32_t *customer_id_ptr);

/**
   Set customer ID

   @remark Once set value cannot be changed

   @param[in] service_ptr Embedded HSM service instance
   @param[in] customer_id 32 bit Customer ID

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_boot_customer_id_set(ehsm_service_t *service_ptr,
                          uint32_t customer_id);

#endif /* _ATLK_EHSM_BOOT_SECURE_SERVICE_H */
