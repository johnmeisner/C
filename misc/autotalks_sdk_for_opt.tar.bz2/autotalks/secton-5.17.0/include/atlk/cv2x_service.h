/**
   @file      cv2x_service.h
   @brief     CV2X service API
   @copyright Copyright (C) 2018-2020 Autotalks Ltd.
*/

#ifndef ATLK_CV2X_SERVICE_H
#define ATLK_CV2X_SERVICE_H

#include <atlk/cv2x.h>
#include "cv2x_rrc_pre_config.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
   @brief      Get CV2X version info

   @param[out] major_ver_ptr    Major version number
   @param[out] minor_ver_ptr    Minor version number
   @param[out] revision_ver_ptr Revision version number

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t
cv2x_version_get(CV2X_OUT uint32_t * const major_ver_ptr,
                 CV2X_OUT uint32_t * const minor_ver_ptr,
                 CV2X_OUT uint32_t * const revision_ver_ptr);

/**
   @brief      Get CV2X get version info

   @param[out] build_num_ptr Build number for version

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t
cv2x_build_version_get(CV2X_OUT uint32_t * const build_num_ptr);

/**
   @brief      Get service instance

   @param[in]  service_name_ptr Name of service (NULL for default)
   @param[out] service_pptr     CV2X service instance

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_service_get(CV2X_IN  const char *         const service_name_ptr,
                 CV2X_OUT       cv2x_service_t       **service_pptr);

/**
   @brief     Deinit CV2X service

   @note      In order for deinit function to succeed, service must be initialized.
              Service must first be disabled, and all sockets must be deleted.

   @param[in] service_ptr CV2X service instance

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t
cv2x_service_deinit(cv2x_service_t *service_ptr);

/**
   @brief     Enable CV2X service

   @param[in] service_ptr CV2X service instance

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_service_enable(cv2x_service_t *service_ptr);

/**
   @brief     Disable CV2X service

   @param[in] service_ptr CV2X service instance

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_service_disable(cv2x_service_t *service_ptr);

/**
   @brief      Create CV2X socket, must also call cv2x_socket_policy_set for semi persistent sockets

   @param[in]  service_ptr       CV2X service instance
   @param[in]  socket_type       CV2X socket type (tx, ah, rx)
   @param[in]  socket_config_ptr CV2X socket configuration
   @param[out] socket_pptr       CV2X socket pointer

   @retval     ATLK_OK if succeeded
   @return     Error code if failed. ATLK_E_EXISTS is returned if limits of sockets (per socket_type and overall) have exceeded.
*/
atlk_rc_t atlk_must_check
cv2x_socket_create(cv2x_service_t              *service_ptr,
                   cv2x_socket_type_t           socket_type,
                   const cv2x_socket_config_t  *socket_config_ptr,
                   cv2x_socket_t               **socket_pptr);

/**
   @brief      Create SPS socket

   @param[in]  service_ptr       CV2X service instance
   @param[in]  socket_config_ptr Socket configuration
   @param[in]  socket_policy_ptr Socket policy
   @param[out] socket_pptr       Pointer to keep the new socket pointer

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
#define cv2x_sps_socket_create(service_ptr, socket_config_ptr, socket_policy_ptr, socket_pptr) \
        ((cv2x_socket_create((service_ptr),                                                    \
                             CV2X_SOCKET_TYPE_SEMI_PERSISTENT_TX,                              \
                             (socket_config_ptr),                                              \
                             (socket_pptr)) == ATLK_OK) ?                                      \
         cv2x_socket_policy_set(*(socket_pptr), (socket_policy_ptr)) : ATLK_E_IO_ERROR)

/**
   @brief Create Rx socket

   @param[in]  service_ptr       CV2X service instance
   @param[in]  socket_config_ptr Socket configuration
   @param[out] socket_pptr       Pointer to keep the new socket pointer

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
#define cv2x_rx_socket_create(service_ptr, socket_config_ptr, socket_pptr) \
         cv2x_socket_create((service_ptr), CV2X_SOCKET_TYPE_RX, (socket_config_ptr), (socket_pptr))

/**
   @brief Create adhoc Tx socket

   @param[in]  service_ptr       CV2X service instance
   @param[in]  socket_config_ptr Socket configuration
   @param[out] socket_pptr       Pointer to keep the new socket pointer

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
#define cv2x_adhoc_socket_create(service_ptr, socket_config_ptr, socket_pptr) \
         cv2x_socket_create((service_ptr), CV2X_SOCKET_TYPE_AD_HOC_TX, (socket_config_ptr), (socket_pptr))

/**
   @brief     Delete CV2X socket

   @param[in] socket_ptr CV2X socket pointer

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t
cv2x_socket_delete(cv2x_socket_t *socket_ptr);

/**
   @brief     Sets (updates) socket RR policy

   @param[in] socket_ptr        CV2X socket pointer
   @param[in] socket_policy_ptr CV2X socket configuration

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_socket_policy_set(CV2X_IN       cv2x_socket_t        *socket_ptr,
                       CV2X_IN const cv2x_socket_policy_t *socket_policy_ptr);


/**
   @brief      Gets RR socket policy

   @param[in]  socket_ptr        CV2X socket pointer
   @param[out] socket_policy_ptr CV2X socket configuration

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_socket_policy_get(CV2X_IN  cv2x_socket_t        *socket_ptr,
                       CV2X_OUT cv2x_socket_policy_t *socket_policy_ptr);


/**
   @brief      Gets CV2X socket information

   @param[in]  socket_ptr CV2X socket opaque pointer
   @param[out] socket_info_ptr Pointer to CV2X socket information to be filled in

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_socket_info_get(CV2X_IN  cv2x_socket_t           *socket_ptr,
                     CV2X_OUT cv2x_socket_user_info_t *socket_info_ptr);


/**
   @brief     Sets (updates) cv2x configuration.

   @param[in] configuration_ptr CV2X socket configuration
   @param[in] rrc_config_ptr    CV2X RRC configuration

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_configuration_set(CV2X_IN cv2x_configuration_t *configuration_ptr, CV2X_IN cv2x_rrc_pre_config_t *rrc_config_ptr);

/**
   @brief      Gets cv2x configuration

   @param[in]  service_ptr       CV2X service pointer
   @param[out] configuration_ptr CV2X socket configuration

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_configuration_get(CV2X_IN  cv2x_service_t       *service_ptr,
                       CV2X_OUT cv2x_configuration_t *configuration_ptr);

/**
   @brief     Updates PDB in cv2x configuration.

   @param[in] pppp PPPP value key
   @param[in] pdb  PDB value

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_pdb_update(CV2X_IN cv2x_pppp_t pppp, CV2X_IN uint32_t pdb);

/**
   @brief   Checks if service is ready to transmit packets.

   @retval  true if system is ready
   @return  false if system is not ready
*/
bool
cv2x_tx_is_ready(void);

/**
   @brief     Send SPS CV2X message.

   @param[in] sps_socket_ptr CV2X semi persistent socket pointer
   @param[in] data_ptr       Pointer to start of data
   @param[in] data_size      Size of data in bytes
   @param[in] params_ptr     Input parameters of send operation

   @retval    ATLK_OK if succeeded
   @return    Error code if failed. For the first (only!) sps message for a socket,
              ATLK_E_OUT_OF_BOUNDS maybe returned if internal RR Module has too many
              processes ongoing. In such case it is possible to retry
              after a while.
*/
atlk_rc_t atlk_must_check
cv2x_sps_send(CV2X_IN cv2x_socket_t            *sps_socket_ptr,
              CV2X_IN const uint8_t            *data_ptr,
              CV2X_IN size_t                   data_size,
              CV2X_IN const cv2x_send_params_t *params_ptr);

#define cv2x_send cv2x_sps_send

/**
   @brief     Send Adhoc CV2X message.

   @param[in] ah_socket_ptr    CV2X adhoc socket pointer
   @param[in] data_ptr         Pointer to start of data
   @param[in] data_size        Size of data in bytes
   @param[in] pppp             Adhoc message priority
   @param[in] adhoc_params_ptr Input parameters of send operation

   @retval    ATLK_OK if succeeded
   @return    Error code if failed. ATLK_E_OUT_OF_BOUNDS maybe returned if internal RR
              Module has too many processes ongoing. In such case it is possible to retry
              after a while.
*/
atlk_rc_t atlk_must_check
cv2x_adhoc_send(CV2X_IN       cv2x_socket_t            *ah_socket_ptr,
                CV2X_IN const uint8_t                  *data_ptr,
                CV2X_IN       size_t                   data_size,
                CV2X_IN       cv2x_pppp_t              pppp,
                CV2X_IN const cv2x_adhoc_send_params_t *adhoc_params_ptr);

/**
   @brief         Receive CV2X frame.

   @param[in]     socket_ptr    CV2X socket pointer
   @param[out]    data_ptr      Pointer to start of data
   @param[in,out] data_size_ptr Maximum (in) and actual (out) data size in bytes
   @param[out]    params_ptr    Output parameters of receive operation
   @param[in]     wait_ptr      Wait specification (optional)

   @retval        ATLK_OK if succeeded
   @return        Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_receive(CV2X_IN          cv2x_socket_t         *socket_ptr,
             CV2X_OUT         uint8_t               *data_ptr,
             CV2X_INOUT       size_t                *data_size_ptr,
             CV2X_OUT         cv2x_receive_params_t *params_ptr,
             CV2X_IN    const atlk_wait_t           *wait_ptr);

/**
   @brief      Get CV2X message status per the message ID provided in the send parameters.
               The message status is kept for 1 second after the message is completely sent.
               A message sent can be split into fragments and duplicated by MAC-HARQ,
               therefore an index should be provided to distinguish between messages.
               An index of zero gets the message overall status

   @param[in]  service_ptr        CV2X service pointer
   @param[in]  socket_ptr         CV2X socket pointer
   @param[in]  message_id         message ID to get a status for
   @param[in]  sent_message_index Index of the sent message
                                  Starts with 1 (in case more than one fragment / duplicate were sent)
                                  Index value of 0 asks for the message overall status, not a specific fragment / copy
   @param[out] status_ptr         Output parameter of status

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_message_status_get(CV2X_IN  cv2x_service_t        *service_ptr,
                        CV2X_IN  cv2x_socket_t         *socket_ptr,
                        CV2X_IN  uint32_t              message_id,
                        CV2X_IN  uint32_t              sent_message_index,
                        CV2X_OUT cv2x_message_status_t *status_ptr);

/**
   @brief      Get CV2X socket statistics

   @param[in]  service_ptr      CV2X service pointer
   @param[in]  socket_ptr       CV2X socket. If NULL - all sockets
   @param[in]  millisec         Number of milliseconds to get the status for (0 for all).
                                        **  Limited to: configuration. message_tx_lease_time_ms
                                        *** Stats for messages dropped before MAC layer are unavailable
   @param[out] socket_stats_ptr Pointer to socket statistics struct

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_socket_stats_get(CV2X_IN  cv2x_service_t      *service_ptr,
                      CV2X_IN  cv2x_socket_t       *socket_ptr,
                      CV2X_IN  uint32_t            millisec,
                      CV2X_OUT cv2x_socket_stats_t *socket_stats_ptr);

/**
   @brief      Get CV2X Rx statistics

   @param[in]  service_ptr  CV2X service pointer
   @param[out] rx_stats_ptr Pointer to Rx statistics struct

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_rx_stats_get(CV2X_IN cv2x_service_t *service_ptr, CV2X_OUT cv2x_rx_stats_t *rx_stats_ptr);

/**
   @brief  Clear CV2X socket statistics

   @retval ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
cv2x_socket_stats_reset(void);

/**
   @brief  Clear CV2X service statistics

   @retval ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
cv2x_service_stats_reset(void);

/**
   @brief      Get CV2X service statistics

   @param[in]  service_ptr       CV2X service pointer
   @param[out] service_stats_ptr Statistics pointer

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_service_stats_get(CV2X_IN  cv2x_service_t       *service_ptr,
                       CV2X_OUT cv2x_service_stats_t *service_stats_ptr);

/**
   @brief      Get latest available CV2X service CBR level in percentage for a Tx pool

   @param[in]  service_ptr       CV2X service pointer
   @param[in]  tx_pool_id        Tx pool ID
   @param[out] cbr_percent_ptr   CBR percent pointer
   @param[out] subframe_time_ptr CBR time pointer

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_cbr_get(CV2X_IN  const cv2x_service_t * const service_ptr,
             CV2X_IN        uint32_t               tx_pool_id,
             CV2X_OUT       uint8_t                *cbr_percent_ptr,
             CV2X_OUT       cv2x_time_t    * const subframe_time_ptr);

/**
   @brief      Get the current CV2X service source layer 2 ID

   @param[in]  service_ptr  CV2X service ptr
   @param[out] src_l2id_ptr Source layer 2 ID pointer (24 bits only)

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_src_l2id_get(CV2X_IN  cv2x_service_t *service_ptr,
                  CV2X_OUT uint32_t       *src_l2id_ptr);

/**
   @brief      Set the current CV2X service source layer 2 ID

   @param[in]  service_ptr CV2X service ptr
   @param[out] src_l2id    Source layer 2 ID (24 bits only)

   @retval     ATLK_OK if succeeded
   @return     Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_src_l2id_set(CV2X_IN  cv2x_service_t *service_ptr,
                  CV2X_OUT uint32_t       src_l2id);

/**
   @brief       Set current speed in KPH

   @param[in]   service_ptr A pointer to CV2X service
   @param[in]   speed       Speed to set, in KPH

   @retval      ATLK_OK if succeeded
   @return      Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_speed_set(CV2X_IN const cv2x_service_t *const service_ptr, CV2X_IN uint32_t speed);


/**
   @brief       Get the current speed in KPH

   @param[in]   service_ptr A pointer to CV2X service
   @param[in]   speed_ptr   An address to be filled in with current speed in KPH

   @retval      ATLK_OK if succeeded
   @return      Error code if failed
*/
atlk_rc_t atlk_must_check
cv2x_speed_get(CV2X_IN const cv2x_service_t *const service_ptr, CV2X_OUT uint32_t *const speed_ptr);


#ifdef __cplusplus
}
#endif

#endif /* ATLK_CV2X_SERVICE_H */
