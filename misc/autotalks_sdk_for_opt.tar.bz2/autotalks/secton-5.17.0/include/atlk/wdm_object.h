#ifndef _ATLK_WDM_OBJECT_H
#define _ATLK_WDM_OBJECT_H

/** WDM object type */
typedef enum {
  /**
     Get/Set WLAN frequency
     Methods: GET, SET
     Type:    uint32
     Units:   MHz
  */
  WDM_FREQUENCY_MHZ = 0,

  /**
     Get last measured TSSI result
     Methods: Get
     Type:    uint32
  */
  WDM_TSSI_DETECTOR_RESULT,

  /**
     Enable/Disable TSSI loop
     Methods: SET ,GET
     Type:    uint32
  */
  WDM_TSSI_LOOP_ENABLE,

  /**
    Access RSSI results
    Methods: GET
    Type:    uint64 (8 values of single byte)
  */
  WDM_RSSI_CALIB_RESULT,

  /**
     Get WLAN version number
     Methods: Get
     Type:    Opaque (wdm_dsp_version_t)
  */
  WDM_WLAN_DSP_VERSION,

  /**
     Get WLAN statistics
     Methods: Get
     Type:    Opaque (wdm_stats_t)
  */
  WDM_WLAN_STATS,

  /**
     Set/Get EDCA configuration
     Methods: Get, Set
     Type:    Opaque (wdm_edca_config_t)
  */
  WDM_WLAN_EDCA_CONFIG,

  /**
     Set/Get WLAN BW
     Methods: Get, Set
     Type:    uint32
  */
  WDM_BANDWIDTH,

  /**
     Set/Get WLAN Phy mode
     Methods: Get, Set
     Type:    uint32
  */
  WDM_WLAN_PHY_MODE,

  /**
     Set/Get WLAN diversity
     Methods: Get, Set
     Type:    int32
  */
  WDM_WLAN_DIVERSITY,

  /**
     Set/Get WLAN CSD11P
     Methods: Get, Set
     Type:    int32
  */
  WDM_WLAN_CSD11P,

  /**
     Get WLAN DCOC status
     Methods: Get
     Type:    int32
  */
  WDM_WLAN_DCOC,

  /**
     Set/Get WLAN periodic task interval
     Methods: Get, Set
     Type:    uint32
  */
  WDM_WLAN_PERIODIC_TASK_INTERVAL,

  /**
     Set/Get WLAN channel busy ratio samples interval
     Methods: Get, Set
     Type:    uint32
  */
  WDM_WLAN_CBR_SAMPLE_INTERVAL,

  /**
     Attach WLAN interface state
     Methods: Set
     Type:    uint32
  */
  WDM_WLAN_IF_ATTACH,

  /**
     Detach WLAN interface state
     Methods: Set
     Type:    empty
  */
  WDM_WLAN_IF_DETACH,

  /**
     Get WLAN interface status (attached state, mode)
     Methods: Get
     Type:    Opaque (wdm_interface_status_t)
  */
  WDM_WLAN_IF_STATUS,

  /**
     Get WLAN RF status
     Methods: Get
     Type:    Opaque (wdm_rf_status_t)
  */
  WDM_WLAN_RF_STATUS,

  /**
     Set/Get RF temperature offset
     Methods: Get, Set
     Type:    int32
  */
  WDM_RF_TEMPERATURE_OFFSET,

  /**
     Get Compensator status
     Methods: Get
     Type:    Opaque (wdm_compensator_status_t)
  */
  WDM_WLAN_COMPENSATOR_STATUS,

  /**
     Set/Get WLAN mac address
     Methods: Get, Set
     Type:    eui48_t
  */
  WDM_WLAN_MAC,

  /**
     Set/Get  RF test mode configuration
     Methods: Get, Set
     Type:    Opaque (wdm_rf_test_mode_config_t)
   */
  WDM_WLAN_RF_TEST_MODE,

  /**
     Set/Get WLAN Diversity Scheme
     Methods: Get, Set
     Type:    uint32
  */
  WDM_WLAN_TX_DIVERSITY_SCHEME,

  /**
     Get/Set WLAN control frames TX power
     Methods: GET, SET
     Type:    uint32
     Units:   dBm
  */
  WDM_WLAN_CTRL_TX_POWER,

  /**
     Get compensator version
     Methods: Get
     Type:    Opaque (wdm_compensator_version_t)
  */
  WDM_COMPENSATOR_VERSION,

  /**
     Get compensator stats
     Methods: Get
     Type:    Opaque (wdm_compensator_stats_t)
  */
  WDM_COMPENSATOR_STATS,

  /**
     Get compensator last messages
     Methods: Get
     Type:    Opaque (wdm_compensator_last_messages_t)
  */
  WDM_COMPENSATOR_LAST_MESSAGES,

  /**
     Trigger compensator calibration data downloading
     Methods: Set
  */
  WDM_COMPENSATOR_CALIBRATION_DOWNLOAD,

  /**
     Get last compensator fault code
     Methods: Get
     Type:    uint32
  */
  WDM_COMPENSATOR_FAULT_CODE,

  /**
     Get compensator raw calibration data
     Methods: Get
     Type:    Opaque (wdm_compensator_raw_calibration_data_t)
  */
  WDM_COMPENSATOR_RAW_DATA,
  /**
     Set/Get WLAN Primary Index
     Methods: Get, Set
     Type:    uint32
  */
  WDM_WLAN_PRIMARY_INDEX,

  /**
     Get PLUTON2 revision ID
     Methods: Get
     Type:    Opaque (string)
  */
  WDM_PLUTON2_REVISION_ID,

  /**
     Get PLUTON2 unique ID
     Methods: Get
     Type:    Opaque (16 byte)
  */
  WDM_PLUTON2_UNIQUE_ID,

  /**
     Set/Get WLAN BAND
     Methods: Get, Set
     Type:    uint32
  */
  WDM_BAND,

  /**
     Set/Get WLAN EXTERNAL
     Methods: Get, Set
     Type:    Opaque (external)
  */
  WDM_EXTERNAL,

 /**
     Init CBP sets the address mode and reset internal structures max entry aging
     Methods: Set
  */
  WDM_CBP_INIT,

  /**
      Reset CBP tables
      Methods: Set
      Type: Opaque
  */
  WDM_CBP_RESET,

   /**
       Add filter to CBP tables
       Methods: Set
       Type: Opaque
    */
   WDM_CBP_FILTER_ADD,

   /**
       Remove filter from CBP tables
       Methods: Set
       Type: Opaque
    */
   WDM_CBP_FILTER_REMOVE,

  /**
      CBP counters get
      Methods: Get
      Type: Opaque
  */
   WDM_CBP_STATISTICS_GET,

  /**
      CBP status get
      Methods: Get
      Type: Opaque
  */
  WDM_CBP_STATUS_GET,

  /**
      Set/Get a filter information using filter id
      Methods: Get
      Type: Opaque
  */
  WDM_CBP_ID_FILTER_GET,

  /**
      Set/Get a filter information using filter index
      Methods: Get
      Type: Opaque
  */
  WDM_CBP_INDEX_FILTER_GET,

  /**
     Start TSSI calibration mode
     Methods: set
     Type:    empty
  */
  WDM_TSSI_CALIBRATION_MODE_START,

  /**
     Stop TSSI calibration mode
     Methods: set
     Type:    empty
  */
  WDM_TSSI_CALIBRATION_MODE_STOP,

  /**
     Set compensator data without transmission
     Methods: Set
     Type: Opaque
  */
  WDM_GENERIC_COMPENSATOR_DATA_SET,

  /** Max number of WDM objects */
  WDM_OBJECT_TYPE_MAX,

} wdm_object_type_t;

#define WDM_OBJECT_TYPE_NA (-1)
#define WDM_OBJECT_TYPE_COUNT (WDM_OBJECT_TYPE_MAX)

#endif /* _ATLK_WDM_OBJECT_H */
