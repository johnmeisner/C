/** Copyright (C) 2014-2019 Autotalks Ltd. */
#ifndef _ATLK_HASH_H
#define _ATLK_HASH_H

#include <atlk/sdk.h>
#include <extern/target_type.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   HASH common definitions
*/

/** HASH service instance */
typedef atlk_handle_t hash_service_t;

/** HASH context */
typedef uint32_t hash_context_t;

/** HASH-224 digest size in octets */
#define HASH_224_DIGEST_SIZE 28U

/** HASH-256 digest size in octets */
#define HASH_256_DIGEST_SIZE 32U

/** HASH-384 digest size in octets */
#define HASH_384_DIGEST_SIZE 48U

/** HASH-512 digest size in octets */
#define HASH_512_DIGEST_SIZE 64U

/** HASH-SM3 digest size in octets */
#define HASH_SM3_DIGEST_SIZE 32U

/** Maximum HASH digest size in octets */
#define HASH_DIGEST_MAX_SIZE HASH_384_DIGEST_SIZE

/** All HASH chunks must be multiple of 4 bytes except the last chunk */
#define HASH_UPDATE_LENGTH_ALIGNMENT 4U

/** HASH Socket */
typedef atlk_handle_t hash_socket_t;

/** HASH Request ID */
typedef uint32_t hash_request_id_t;

/** HASH digest */
typedef struct {
  uint8_t value[HASH_DIGEST_MAX_SIZE];
  size_t value_size;
} hash_digest_t;

/** HASH digest default initializer */
#define HASH_DIGEST_INIT { \
  .value = { 0 },         \
  .value_size = 0         \
}

/** HASH algorithm */
typedef enum {
  /** SHA-224 */
  HASH_ALGORITHM_SHA_224 = 0,

  /** SHA-256 */
  HASH_ALGORITHM_SHA_256 = 1,

  /** SHA-384 */
  HASH_ALGORITHM_SHA_384 = 2,

  /** SHA-512 */
  HASH_ALGORITHM_SHA_512 = 3,

  /** SHA-SM3 */
  HASH_ALGORITHM_SM3     = 4,

  /** Invalid HASH Algorithm */
  HASH_ALGORITHM_INVALID = 0xFF,
} hash_algorithm_t;

/** HASH HW acceleration */
typedef enum {
  /** HW acceleration enabled */
  HASH_HW_ACCELERATION_ENABLED,

  /** HW acceleration disabled - use SW instead */
  HASH_HW_ACCELERATION_DISABLED
} hash_hw_acceleration_t;

/** HASH Request Type */
typedef enum {
  /** HASH Request Sub Type Compute */
  HASH_REQUEST_SUB_TYPE_COMPUTE,

  /** HASH Request Invalid Sub Type */
  HASH_REQUEST_SUB_TYPE_INVALID,
} hash_request_sub_type_t;

/** HASH Compute Request Parameters */
typedef struct {
  /** HASH Algorithm */
  hash_algorithm_t algorithm;

  /** Data Length */
  size_t data_size;

  /** Data Pointer */
  const void *data_ptr;
} hash_compute_request_params_t;

/** HASH Compute Request Parameters Default Initializer */
#define HASH_COMPUTE_REQUEST_PARAMS_INIT {  \
  .algorithm = HASH_ALGORITHM_INVALID,      \
  .data_size = 0,                           \
  .data_ptr = NULL,                         \
}

/** HASH Asynchronous Request */
typedef struct {
  /** Request ID */
  hash_request_id_t request_id;

  /** Request Sub Type */
  hash_request_sub_type_t sub_type;

  union {
    /** HASH Compute Request Parameters */
    hash_compute_request_params_t compute_params;
  } request_params;
} hash_async_request_t;

/** HASH Asynchronous Request Default Initializer */
#define HASH_ASYNC_REQUEST_INIT {                                    \
  .request_id = 0,                                                   \
  .sub_type = HASH_REQUEST_SUB_TYPE_INVALID,                         \
  .request_params.compute_params = HASH_COMPUTE_REQUEST_PARAMS_INIT, \
}

/** Sha Compute Response Parameters */
typedef struct {
  /** Calculated Digest */
  hash_digest_t digest;
} hash_compute_response_params_t;

/** Define HASH Compute Response Parameters Default Initializer */
#define HASH_COMPUTE_RESPONSE_PARAMS_INIT {  \
  .digest = HASH_DIGEST_INIT,                \
}

/** HASH Asynchronous Response */
typedef struct {
  /** Response ID */
  hash_request_id_t response_id;

  /** Response Sub Type */
  hash_request_sub_type_t sub_type;

  /** Response Return Code */
  atlk_rc_t rc;

  union {
    /** HASH Compute Response Parameters */
    hash_compute_response_params_t compute_params;
  } response_params;

} hash_async_response_t;

/** HASH Asynchronous Response Default Initializer */
#define HASH_ASYNC_RESPONSE_INIT {                                     \
  .response_id = 0,                                                    \
  .sub_type = HASH_REQUEST_SUB_TYPE_INVALID,                           \
  .rc = ATLK_OK,                                                       \
  .response_params.compute_params = HASH_COMPUTE_RESPONSE_PARAMS_INIT, \
}

#if 0 // Obsolete
/**
   Check if a given HASH algorithm is valid.

   @param[in] algorithm HASH algorithm

   @return 1 if HASH algorithm is valid, 0 otherwise
*/
atlk_inline int
hash_algorithm_valid(hash_algorithm_t algorithm)
{
  switch (algorithm) {
    case HASH_ALGORITHM_SHA_224:
    case HASH_ALGORITHM_SHA_256:
    case HASH_ALGORITHM_SHA_384:
    case HASH_ALGORITHM_SHA_512:
    case HASH_ALGORITHM_SM3:
      return 1;
    case HASH_ALGORITHM_INVALID:
    default:
      return 0;
  }
}
#endif

/* parasoft-begin-suppress BD-PB-UCMETH-4 "These functions are only used in applications that are excluded from MISRA build" */
/**
   Get HASH digest size for a given HASH algorithm.

   @param[in] algorithm HASH algorithm

   @return HASH digest size for a valid HASH algorithm, 0 otherwise
*/
atlk_inline size_t
hash_algorithm_digest_size(hash_algorithm_t algorithm)
{
  switch (algorithm) {
    case HASH_ALGORITHM_SHA_224: return HASH_224_DIGEST_SIZE;
    case HASH_ALGORITHM_SHA_256: return HASH_256_DIGEST_SIZE;
    case HASH_ALGORITHM_SHA_384: return HASH_384_DIGEST_SIZE;
    case HASH_ALGORITHM_SHA_512: return HASH_512_DIGEST_SIZE;
    case HASH_ALGORITHM_SM3:     return HASH_SM3_DIGEST_SIZE;
    case HASH_ALGORITHM_INVALID:
    default: return 0;
  }
}

atlk_inline const char *
hash_algorithm_name_get(hash_algorithm_t algorithm)
{
  switch (algorithm) {
    case HASH_ALGORITHM_SHA_224:
      return "SHA-224";
    case HASH_ALGORITHM_SHA_256:
      return "SHA-256";
    case HASH_ALGORITHM_SHA_384:
      return "SHA-384";
    case HASH_ALGORITHM_SHA_512:
      return "SHA-512";
    case HASH_ALGORITHM_SM3:
      return "SM3";
    case HASH_ALGORITHM_INVALID:
    default:
      return "invalid hash algorithm";
  }
}
/* parasoft-end-suppress BD-PB-UCMETH-4 "These functions are only used in applications that are excluded from MISRA build" */

atlk_inline atlk_rc_t
hash_hw_acceleration_is_valid(hash_algorithm_t algorithm,
                              hash_hw_acceleration_t hw_acceleration)
{
  /* SECTON: HW is not enabled */
  /* parasoft suppress MISRA2012-RULE-14_3_zc */
  if ( (target_type_get() == TARGET_TYPE_SECTON) || (device_type_get() == DEVICE_TYPE_ON_M3) ) {
    if (hw_acceleration == HASH_HW_ACCELERATION_ENABLED) {
      return ATLK_E_INVALID_ARG;
    }
  }
  else {
    /* CRATON: only SHA_256 and SHA_384 are HW enabled */
    switch (algorithm) {
      case HASH_ALGORITHM_SHA_256:
      case HASH_ALGORITHM_SHA_384:
        return ATLK_OK;
      default:
        if (hw_acceleration == HASH_HW_ACCELERATION_ENABLED) {
          return ATLK_E_INVALID_ARG;
        }
    }
  }
  /* parasoft unsuppress MISRA2012-RULE-14_3_zc */
  return ATLK_OK;
}

/* parasoft-begin-suppress BD-PB-UCMETH-4 "This function is only used in applications that are excluded from MISRA build" */
// Obsolete
atlk_inline hash_hw_acceleration_t
hash_best_hw_acceleration_for_algorithm_get(hash_algorithm_t algorithm)
{
  /* SECTON: HW is not enabled */
  /* parasoft suppress MISRA2012-RULE-14_3_zc */
  if ( (target_type_get() == TARGET_TYPE_SECTON) || (device_type_get() == DEVICE_TYPE_ON_M3) ) {
    return HASH_HW_ACCELERATION_DISABLED;
  }
  else {
    /* CRATON: only SHA_256 and SHA_384 are HW enabled */
    switch (algorithm) {
      case HASH_ALGORITHM_SHA_256:
      case HASH_ALGORITHM_SHA_384:
        return HASH_HW_ACCELERATION_ENABLED;
      default:
        return HASH_HW_ACCELERATION_DISABLED;
    }
  }
  /* parasoft unsuppress MISRA2012-RULE-14_3_zc */
}
/* parasoft-end-suppress BD-PB-UCMETH-4 "This function is only used in applications that are excluded from MISRA build" */

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_HASH_H */
