/* Copyright (C) 2016 Autotalks Ltd. */
#ifndef _ATLK_WDM_SERVICE_INTERNAL_H
#define _ATLK_WDM_SERVICE_INTERNAL_H

#include <atlk/sdk.h>
#include <atlk/object.h>
#include <atlk/wdm.h>

/**
   Get WDM Primary Index

   @param[in]  service_ptr WDM service instance
   @param[in]  if_index WLAN Interface index
   @param[out] primary_index_ptr index [0 - 0, 1 - 20U, 2 - 20UU, 3 - 20L,
                                        4 - 20LL, 5 - 40U, 6 - 40L]

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_primary_index_get(wdm_service_t *service_ptr,
                      if_index_t if_index,
                      uint32_t *primary_index_ptr);

/**
   Set WDM Primary Index

   @param[in]  service_ptr WDM service instance
   @param[in]  if_index WLAN Interface index
   @param[in]  primary_index index [0 - 0, 1 - 20U, 2 - 20UU, 3 - 20L,
                                    4 - 20LL, 5 - 40U, 6 - 40L]

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_primary_index_set(wdm_service_t *service_ptr,
                      if_index_t if_index,
                      uint32_t primary_index);

/**
   Get last TSSI detector reading.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[out] tssi_value_ptr TSSI detector value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_phy_mode_get(wdm_service_t *service_ptr,
                 if_index_t if_index,
                 uint32_t *phy_mode_ptr);

/**
   Set last TSSI detector reading.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] tssi_value_ptr TSSI detector value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_phy_mode_set(wdm_service_t *service_ptr,
                 if_index_t if_index,
                 uint32_t phy_mode);

/**
   Set WDM objects

   @param[in] service_ptr WDM service instance
   @param[in] object_array_ptr WDM objects array
   @param[in] object_array_count Number of element in WDM objects array

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_object_set(wdm_service_t *service_ptr,
               const atlk_object_t *object_array_ptr,
               size_t object_array_count);


/**
   Get WDM objects

   @param[in] service_ptr WDM service instance
   @param[out] object_array_ptr WDM objects array
   @param[in] object_array_count Number of element in WDM objects array

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_object_get(wdm_service_t *service_ptr,
               atlk_object_t *object_array_ptr,
               size_t object_array_count);

#endif /* _ATLK_WDM_SERVICE_INTERNAL_H */
