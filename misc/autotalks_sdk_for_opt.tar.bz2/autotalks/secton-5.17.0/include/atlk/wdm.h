/** Copyright (C) 2016 Autotalks Ltd. */
#ifndef _ATLK_WDM_H
#define _ATLK_WDM_H

#include <common/eui48.h>
#include <common/eui24.h>
#include <common/types.h>

#include <atlk/sdk.h>
#include <atlk/generic_compensator.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   WLAN Diagnostics and Management API
*/

/** Number of RSSI values returned prior calibration */
#define WDM_RSSI_VALUES_COUNT 8U

/** WDM DSP revision ID length */
#define WDM_DSP_REV_ID_LEN 20U

typedef power_dbm8_t wdm_power_dbm8_t;
#define WDM_POWER_DBM8_NA POWER_DBM8_NA

/** Value that shows MCS value is not available */
#define WDM_MCS_NA INT16_MIN

/** WDM service instance */
typedef atlk_handle_t wdm_service_t;

/** PLUTON2 revision ID string length */
#define WDM_PLUTON2_REVISION_ID_LEN 10U

/** PLUTON2 unique ID string length */
#define WDM_PLUTON2_UNIQUE_ID_LEN 16U

/* Invalid temperature value */
#define WDM_TEMPERATURE_READING_INVALID INT32_MIN

/* Invalid compensator temperature value */
#define WDM_COMPENSATOR_TEMPERATURE_READING_INVALID INT8_MIN

/* Compensator max raw calibration data buffer size */
#define WDM_COMPENSATOR_RAW_DATA_BUFFER_SIZE  1024U

/* Compensator last messages buffer size */
#define WDM_COMPENSATOR_LAST_MESSAGES_BUFFER_SIZE  64U

/* EDCA CW minimum value*/
#define WDM_EDCA_CWMIN_MIN 3U

/* EDCA CW maximum value*/
#define WDM_EDCA_CWMIN_MAX 255U

/* EDCA CW minimum value*/
#define WDM_EDCA_CWMAX_MIN 3U

/* EDCA CW maximum value*/
#define WDM_EDCA_CWMAX_MAX 1023U

/* EDCA AIFSN minimum value*/
#define WDM_EDCA_AIFSN_MIN 1U

/* EDCA AIFSN maximum value*/
#define WDM_EDCA_AIFSN_MAX 15U

/* EDCA TxOP maximum value*/
#define WDM_EDCA_TXOP_MAX 9U

/* 802.11 access categories count */
#define WDM_AC_COUNT 5U

/* V2X user priority count */
#define WDM_V2X_USRP_COUNT 8U

/** WDM RF test mode */
typedef enum {
  /** RF test mode disabled */
  WDM_RF_TEST_MODE_DISABLED = 0,

  /** Carrier Wave (CW) */
  WDM_RF_TEST_MODE_CW,

  /** Continuous OFDM */
  WDM_RF_TEST_MODE_CONTINUOS_OFDM
} wdm_rf_test_mode_t;

/** WDM bandwidth */
typedef enum {
  /** 5 MHz bandwidth */
  WDM_BANDWIDTH_5MZ = 0,

  /** 10 MHz bandwidth */
  WDM_BANDWIDTH_10MZ,

  /** 20 MHz bandwidth */
  WDM_BANDWIDTH_20MZ,

  /** 40 MHz bandwidth */
  WDM_BANDWIDTH_40MZ,

  /** 80 MHz bandwidth */
  WDM_BANDWIDTH_80MZ,
} wdm_bandwidth_t;


/** WDM interface modes */
typedef enum {
  /** CV2X mode */
  WDM_INTERFACE_MODE_CV2X = 0,

  /** DSRC mode */
  WDM_INTERFACE_MODE_DSRC,

  /** WIFI mode */
  WDM_INTERFACE_MODE_WIFI,

  /** Special mode for diag-cli */
  WDM_INTERFACE_MODE_SERVICE,

  /** Max number of interface modes */
  WDM_INTERFACE_MODE_MAX,
} wdm_interface_mode_t;

/** WDM interface states */
typedef enum {
  /** Detached interface state */
  WDM_INTERFACE_STATE_DETACHED = 0,

  /** Attached interface state */
  WDM_INTERFACE_STATE_ATTACHED,
} wdm_interface_state_t;

/** WDM status */
typedef enum {
  /** Status is OK */
  WDM_STATUS_OK = 0,

  /** Status is not OK */
  WDM_STATUS_FAILED
} wdm_status_t;

/** WDM diversity modes */
typedef enum {
  /** Diversity is disabled */
  WDM_DIVERSITY_MODE_OFF = 0,

  /** TX diversity only. Currently not supported */
  WDM_DIVERSITY_MODE_TX_ONLY,

  /** RX diversity only. Currently not supported */
  WDM_DIVERSITY_MODE_RX_ONLY,

  /** TX and RX diversity */
  WDM_DIVERSITY_MODE_TX_AND_RX
} wdm_diversity_mode_t;

/** TSSI detector value type */
typedef enum {
  /** TSSI detector value is a "raw" value */
  WDM_TSSI_DETECTOR_VALUE_TYPE_RAW = 0,

  /** TSSI detector value in units of 1/8dBm */
  WDM_TSSI_DETECTOR_VALUE_TYPE_DBM8

} wdm_tssi_detector_value_type_t;

/** WLAN TX diversity scheme */
typedef enum {
  /** Cyclic Shift Diversity scheme */
  WDM_TX_DIVERSITY_SCHEME_CSD = 0,

  /** Phase Shift Diversity scheme. Currently not supported */
  WDM_TX_DIVERSITY_SCHEME_PSD
} wdm_tx_diversity_scheme_t;

/** WDM compensator state */
typedef enum {
  /** Compensator is operational */
  WDM_COMPENSATOR_STATE_ENABLED = 0,

  /** Compensator is disabled or not connected */
  WDM_COMPENSATOR_STATE_DISABLED,

  /** Compensator calibration file downloading is in progress */
  WDM_COMPENSATOR_STATE_CALIBRATION_DOWNLOADING,

  /** Failed to download compensator calibration file */
  WDM_COMPENSATOR_STATE_DOWNLOAD_FAIL,

  /** Compensator is not operational due to some error */
  WDM_COMPENSATOR_STATE_FAILURE,

  /** Not a valid state. Used for array size and index checks */
  WDM_COMPENSATOR_STATE_MAX

} wdm_compensator_state_t;

/** Compensator cable loss calculation status */
typedef enum {
  WDM_COMPENSATOR_CABLE_LOSS_CALCULATION_NOT_READY = 0,
  WDM_COMPENSATOR_CABLE_LOSS_CALCULATION_SUBOPTIMAL,
  WDM_COMPENSATOR_CABLE_LOSS_CALCULATION_OPTIMAL,
  WDM_COMPENSATOR_CABLE_LOSS_CALCULATION_MAX,
} wdm_compensator_cable_loss_calculation_status_t;

/** CBP Addressing mode */
typedef enum {
  /** no addressing mode */
  WDM_CBP_ADDRESS_NONE = 0,

  /** L2ID addressing mode, of 24 bit address length */
  WDM_CBP_ADDRESS_24_BIT,

  /** MAC addressing mode, of 48 bit address length */
  WDM_CBP_ADDRESS_48_BIT,
} wdm_cbp_address_mode_t;

/** CBP Addressing mode */
typedef enum {
  WDM_CBP_OFF = 0,
  WDM_CBP_INITIALIZED,
} wdm_cbp_state_t;

/**
   LMAC (Lower MAC) statistics.

   Counters are per WLAN interface (whether 802.11p or WiFi).
*/
typedef struct {
  /**
      Number of frames dropped due to CRC error (FCS checksum fail).

      Note: Count can be larger than actual frames dropped due to CRC errors
      (due to false packet detect events). This is normal expected behavior.
  */
  uint32_t frames_received_crc_error;

  /** Number of frames successfully transmitted */
  uint32_t frames_sent_successful;

  /** Number of frames successfully received at Device from DSP */
  uint32_t frames_received_total;

  /** Number of frames successfully transmitted by access category */
  uint32_t frames_sent_successful_by_ac[WDM_AC_COUNT];

  /** Number of frames successfully received by access category */
  uint32_t frames_received_by_ac[WDM_AC_COUNT];

  /** Number of frames successfully transmitted by user priority */
  uint32_t frames_sent_successful_by_usrp[WDM_V2X_USRP_COUNT];

  /** Number of frames successfully received by user priority */
  uint32_t frames_received_by_usrp[WDM_V2X_USRP_COUNT];
} wdm_lmac_counters_t;

typedef struct {
  /** Successful RTS counter */
  uint32_t success_rts;

  /** Missed Ack counter */
  uint32_t missed_ack;

  /** Missed CTS counter */
  uint32_t missed_cts;

  /** Missed block ack counter */
  uint32_t missed_back;
} wdm_lmac_wifi_counters_t;

/** WLAN Diagnostics statistics */
typedef struct {
  /** LMAC counters */
  wdm_lmac_counters_t lmac_counters;

  /** LMAC Wi-Fi counters */
  wdm_lmac_wifi_counters_t lmac_wifi_counters;

  /** Input power of last frame in units of 1/8 dBm */
  wdm_power_dbm8_t last_power_dbm8;

  /** Minimum Input power of frame in units of 1/8 dBm */
  wdm_power_dbm8_t min_power_dbm8;

  /** Maximum Input power of frame in units of 1/8 dBm */
  wdm_power_dbm8_t max_power_dbm8;

  /** Last receive EVM value in units of dB */
  float last_rx_evm_db;

  /** MIN receive EVM value in units of dB */
  float min_rx_evm_db;

  /** MAX receive EVM value in units of dB */
  float max_rx_evm_db;

  /** MIN received MCS value */
  int16_t min_mcs;

  /** MAX received MCS value */
  int16_t max_mcs;

  /** Last received frame source address */
  eui48_t last_received_rx_sa;

  /** Last received frame destination address */
  eui48_t last_received_rx_da;
} wdm_stats_t;

/** WDM DSP version */
typedef struct {
  /** Major */
  uint8_t major;

  /** Minor */
  uint8_t minor;

  /** SW revision */
  uint8_t sw_revision;

  /** Revision id (19 Bytes + Null terminated) */
  char dsp_rev_id[WDM_DSP_REV_ID_LEN];
} wdm_dsp_version_t;

/** WDM RF test mode configuration */
typedef struct {
  /** RF test mode */
  uint32_t rf_test_mode;

  /** Frequency offset in units of KHz (CW only) */
  uint32_t freq_offset_khz;

  /** TX power in units of 1/2 dBm (CW only) */
  uint32_t tx_power_dbm2;
} wdm_rf_test_mode_config_t;

/** RSSI calibration result */
typedef struct {
  /** RSSI values */
  int8_t values[WDM_RSSI_VALUES_COUNT];
} wdm_rssi_calibration_result_t;

/** Interface status */
typedef struct {
  /** Interface state */
  wdm_interface_state_t state;

  /** Interface mode */
  wdm_interface_mode_t mode;
} wdm_interface_status_t;

/** RF status */
typedef struct {
  /** Status of AFE PLL */
  wdm_status_t afe_pll;

  /** Status of RF PLL */
  wdm_status_t rf_pll[RF_INDEX_MAX];

  /** Status of calibration status */
  wdm_status_t calibration_status[RF_INDEX_MAX];

  /** RFIC chip temperature  */
  int32_t temperature_celsius;

  /** Modem status */
  wdm_status_t modem_status;

  /** RF configuration status */
  wdm_status_t rf_config_status[RF_INDEX_MAX];

  /** Modem recovery counter */
  uint32_t modem_recovery_counter;
} wdm_rf_status_t;

/** WLAN RX frame info */
typedef struct {

  /** MAC interface index */
  if_index_t if_index;

  /** MAC User Priority */
  user_priority_t user_priority;

  /** Data rate */
  datarate_t datarate;

  /** Input power of frame in units of 1/8 dBm */
  power_dbm8_t power_dbm8;

  /**
     Input power of frame received on second antenna in units of
     1/8 dBm, when RX diversity is enabled.
  */
  power_dbm8_t receive_diversity_power_dbm8;

  /**
     Receive time in microseconds

     Format: number of TAI microseconds since 2004-01-01T00:00:00Z (UTC).
  */
  uint64_t receive_time_us;

} wdm_rx_frame_info;

/** WLAN RX frame info default initializer */
#define WDM_RX_FRAME_INFO_INIT {                 \
  .if_index = 0,                                 \
  .datarate = DATARATE_NA,                       \
  .power_dbm8 = POWER_DBM8_NA,                   \
  .receive_diversity_power_dbm8 = POWER_DBM8_NA, \
  .receive_time_us = 0,                          \
}

/** WLAN TX frame info */
typedef struct {

  /** MAC interface index */
  if_index_t if_index;

  /** MAC User Priority */
  user_priority_t user_priority;

  /** Data rate */
  datarate_t datarate;

  /** Transmission power level in units of 1/8 dBm */
  power_dbm8_t power_dbm8;

  /**
    Transmission power level of frame transmitted on second antenna in units
    of 1/8 dBm, when TX diversity is enabled.
   */
  power_dbm8_t transmit_diversity_power_dbm8;

} wdm_tx_frame_info;

/** WLAN TX frame info default initializer */
#define WDM_TX_FRAME_INFO_INIT {                  \
  .if_index = 0,                                  \
  .datarate = DATARATE_NA,                        \
  .power_dbm8 = POWER_DBM8_NA,                    \
  .transmit_diversity_power_dbm8 = POWER_DBM8_NA, \
}

typedef struct {
  /** Compensator state */
  wdm_compensator_state_t state;

  /** Compensator temperature */
  int8_t temperature_celsius;

  /** Compensator cable loss value [1/8 dB] */
  int8_t cable_loss_db8;

  /** Compensator cable loss status */
  wdm_compensator_cable_loss_calculation_status_t cable_loss_status;

} wdm_compensator_status_t;

/** Compensator version */
typedef struct {
  /** Hardware version, 4 MSB of MAJOR / 4 LSB of MINOR version number */
  uint8_t hw_version;

  /** Software version, 4 MSB of MAJOR / 4 LSB of MINOR version number */
  uint8_t sw_version;

  /** UART protocol version, 4 MSB of MAJOR / 4 LSB of MINOR version number */
  uint8_t protocol_version;

} wdm_compensator_version_t;

/** Compensator statistics */
typedef struct {
  /** Total messages counter */
  uint32_t total_messages_counter;

  /** Error messages counter */
  uint32_t error_messages_counter;

} wdm_compensator_stats_t;

/** Compensator raw calibration data */
typedef struct {
  /** Raw calibration data size */
  uint32_t actual_raw_data_size;

  /** Raw calibration data */
  uint8_t raw_data_buffer[WDM_COMPENSATOR_RAW_DATA_BUFFER_SIZE];

} wdm_compensator_raw_calibration_data_t;

/** Generic compensator data per antenna */
typedef struct {
  compensator_data_t comp_data[RF_INDEX_MAX];
} wdm_generic_compensator_data_t;

/** Compensator last messages */
typedef struct {
  /** Last messages buffer */
  uint16_t last_messages_buffer[WDM_COMPENSATOR_LAST_MESSAGES_BUFFER_SIZE];

} wdm_compensator_last_messages_t;

typedef struct {
  /** MAC addressing mode, of 48 bit address length, in case 24 mode bit this parameter is ignored */
  eui48_t v2x_mac_address;

  /** L2ID addressing mode, of 24 bit address length, in case 48 mode bit this parameter is ignored */
  uint32_t cv2x_l2id;
} wdm_cbp_filter_id_t;

/** CBP filter information get */
typedef struct {
  /** Filter's Key */
  uint32_t key;

  /** Time passed from the last time the filter was accessed in msec */
  uint32_t time_from_last_message_ms;

  /** Min time in ms between frames before dropping frame in msec */
  uint16_t min_frame_interval_ms;

  /** Number of frames that passed the filter and where processed */
  uint16_t unfiltered_frames;

  /** Number of frames that where dropped due to filtering */
  uint16_t filtered_frames;
} wdm_cbp_filter_information_t;

/** CBP config */
typedef struct {
  /** The address mode that will be used */
  wdm_cbp_address_mode_t address_mode;

  /**  Max time in msec since last frame before removing filter */
  uint16_t filter_aging_ms;

  /**
       High priority messages DSRC:EDCA(0..3)/CV2X:PPPP(0..7).
       In DSRC 0..3 represents access category (0:high)VO,VI,BE,BK(3:low)
       In CV2X (high)0..7(low)

       A high priority packet, is a packet whose priority is equal or above the defined threshold.
       In this case, the packet will not be limited by the CBP function, and will always be forwarded to upper layers.
       The special value CBP_PRIORITY_NA(0xFF) indicates that all packets will be considered low priority,
       and will be limited by the CBP function.
    */
  uint8_t high_priority;
} wdm_cbp_config_t;

/** CBP statistics */
typedef struct {
  /** Total number of frames that passed the filter and where processed */
  uint32_t total_unfiltered_frames;

  /** Total number of frames that where dropped due to filtering */
  uint32_t total_filtered_frames;
} wdm_cbp_statistics_t;

/** CBP status */
typedef struct {
  /** Number of available filters to use in the table */
  uint16_t number_of_filters_available;

  /** Number of used filters */
  uint16_t number_of_filters_in_use;

  /** Is CBP was initialized */
  wdm_cbp_state_t is_cbp_initialized;
} wdm_cbp_status_t;

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_WDM_H */
