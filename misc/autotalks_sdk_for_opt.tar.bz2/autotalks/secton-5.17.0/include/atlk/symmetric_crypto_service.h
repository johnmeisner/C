/** Copyright (C) 2018 Autotalks Ltd. */
#ifndef _ATLK_SYMMETRIC_CRYPTO_SERVICE_H
#define _ATLK_SYMMETRIC_CRYPTO_SERVICE_H

#include <atlk/sdk.h>
#include <atlk/symmetric_crypto.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   Autotalks Symmetric Crypto Service API
*/

/**
   Get Symmetric Crypto service instance.

   @param[in] service_name Name of service (NULL for default)
   @param[out] service_pptr Symmetric Crypto service instance

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
symmetric_crypto_service_get(const char *service_name,
                             symmetric_crypto_service_t **service_pptr);

/**
   Encrypt with ECB.

   @attention @p text_size must be a muliple of ::SYMMETRIC_CRYPTO_BLOCK_SIZE

   @param[in] service_ptr Symmetric Crypto service instance
   @param[in] cipher Cipher used for the operation
   @param[in] hw_acceleration HW acceleration
   @param[in] key_ptr Encryption key
   @param[in] key_size Size of the key in octets
   @param[in] plaintext_ptr Plaintext to encrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] ciphertext_ptr Ciphertext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
symmetric_crypto_ecb_encrypt(symmetric_crypto_service_t *service_ptr,
                             symmetric_crypto_cipher_t cipher,
                             symmetric_crypto_hw_acceleration_t hw_acceleration,
                             const void *key_ptr,
                             size_t key_size,
                             const void *plaintext_ptr,
                             size_t text_size,
                             void *ciphertext_ptr);

/**
   Decrypt with ECB.

   @attention @p text_size must be a muliple of ::SYMMETRIC_CRYPTO_BLOCK_SIZE

   @param[in] service_ptr Symmetric Crypto service instance
   @param[in] cipher Cipher used for the operation
   @param[in] hw_acceleration HW acceleration
   @param[in] key_ptr Decryption key
   @param[in] key_size Size of the key in octets
   @param[in] ciphertext_ptr Ciphertext to decrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] plaintext_ptr Plaintext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
symmetric_crypto_ecb_decrypt(symmetric_crypto_service_t *service_ptr,
                             symmetric_crypto_cipher_t cipher,
                             symmetric_crypto_hw_acceleration_t hw_acceleration,
                             const void *key_ptr,
                             size_t key_size,
                             const void *ciphertext_ptr,
                             size_t text_size,
                             void *plaintext_ptr);

/**
   Encrypt with CBC.

   @attention text_size must be a muliple of ::SYMMETRIC_CRYPTO_BLOCK_SIZE
   @attention Initialization vector size must be equal to ::SYMMETRIC_CRYPTO_BLOCK_SIZE

   @param[in] service_ptr Symmetric Crypto service instance
   @param[in] cipher Cipher used for the operation
   @param[in] hw_acceleration HW acceleration
   @param[in] key_ptr Encryption key
   @param[in] key_size Size of the key in octets
   @param[in] iv_ptr Initialization vector
   @param[in] plaintext_ptr Plaintext to encrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] ciphertext_ptr Ciphertext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
symmetric_crypto_cbc_encrypt(symmetric_crypto_service_t *service_ptr,
                             symmetric_crypto_cipher_t cipher,
                             symmetric_crypto_hw_acceleration_t hw_acceleration,
                             const void *key_ptr,
                             size_t key_size,
                             const void *iv_ptr,
                             const void *plaintext_ptr,
                             size_t text_size,
                             void *ciphertext_ptr);

/**
   Decrypt with CBC.

   @attention Initialization vector size must be equal to ::SYMMETRIC_CRYPTO_BLOCK_SIZE

   @param[in] service_ptr Symmetric Crypto service instance
   @param[in] cipher Cipher used for the operation
   @param[in] hw_acceleration HW acceleration
   @param[in] key_ptr Decryption key
   @param[in] key_size Size of the key in octets
   @param[in] iv_ptr Initialization vector
   @param[in] ciphertext_ptr Ciphertext to decrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] plaintext_ptr Plaintext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
symmetric_crypto_cbc_decrypt(symmetric_crypto_service_t *service_ptr,
                             symmetric_crypto_cipher_t cipher,
                             symmetric_crypto_hw_acceleration_t hw_acceleration,
                             const void *key_ptr,
                             size_t key_size,
                             const void *iv_ptr,
                             const void *ciphertext_ptr,
                             size_t text_size,
                             void *plaintext_ptr);

/**
   Encrypt with CCM.

   @param[in] service_ptr Symmetric Crypto service instance
   @param[in] cipher Cipher used for the operation
   @param[in] hw_acceleration HW acceleration
   @param[in] key_ptr Encryption key
   @param[in] key_size Size of the key in octets
   @param[in] nonce_ptr Session nonce (must be used once!)
   @param[in] nonce_size Session nonce size in octets
   @param[in] header_ptr Session header (optional)
   @param[in] header_size Size of the session header in octets
   @param[in] plaintext_ptr Plaintext to encrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] ciphertext_ptr Ciphertext
   @param[out] tag_ptr Authentication tag
   @param[in,out] tag_size
      The maximum size (in) and resulting size (out) of the
      authentication tag in octets

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
symmetric_crypto_ccm_encrypt(symmetric_crypto_service_t *service_ptr,
                             symmetric_crypto_cipher_t cipher,
                             symmetric_crypto_hw_acceleration_t hw_acceleration,
                             const void *key_ptr,
                             size_t key_size,
                             const void *nonce_ptr,
                             size_t nonce_size,
                             const void *header_ptr,
                             size_t header_size,
                             const void *plaintext_ptr,
                             size_t text_size,
                             void *ciphertext_ptr,
                             void *tag_ptr,
                             size_t *tag_size);

/**
   Decrypt with CCM.

   @param[in] service_ptr Symmetric Crypto service instance
   @param[in] cipher Cipher used for the operation
   @param[in] hw_acceleration HW acceleration
   @param[in] key_ptr Encryption key
   @param[in] key_size Size of the key in octets
   @param[in] nonce_ptr Session nonce (must be used once!)
   @param[in] nonce_size Session nonce size in octets
   @param[in] header_ptr Session header (optional)
   @param[in] header_size Size of the session header in octets
   @param[in] ciphertext_ptr Ciphertext to decrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] plaintext_ptr Plaintext
   @param[out] tag_ptr Authentication tag
   @param[in,out] tag_size
      The maximum size (in) and resulting size (out) of the
      authentication tag in octets

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
symmetric_crypto_ccm_decrypt(symmetric_crypto_service_t *service_ptr,
                             symmetric_crypto_cipher_t cipher,
                             symmetric_crypto_hw_acceleration_t hw_acceleration,
                             const void *key_ptr,
                             size_t key_size,
                             const void *nonce_ptr,
                             size_t nonce_size,
                             const void *header_ptr,
                             size_t header_size,
                             const void *ciphertext_ptr,
                             size_t text_size,
                             void *plaintext_ptr,
                             void *tag_ptr,
                             size_t *tag_size);

/**
   Encrypt with GCM.

   @param[in] service_ptr Symmetric Crypto service instance
   @param[in] cipher Cipher used for the operation
   @param[in] hw_acceleration HW acceleration
   @param[in] key_ptr Encryption key
   @param[in] key_size Size of the key in octets
   @param[in] iv_ptr Initialization vector
   @param[in] iv_size Size of the IV in octets
   @param[in] header_ptr Session header (optional)
   @param[in] header_size Size of the session header in octets
   @param[in] plaintext_ptr Plaintext to encrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] ciphertext_ptr Ciphertext
   @param[out] tag_ptr Authentication tag
   @param[in,out] tag_size
      The maximum size (in) and resulting size (out) of the
      authentication tag in octets

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
symmetric_crypto_gcm_encrypt(symmetric_crypto_service_t *service_ptr,
                             symmetric_crypto_cipher_t cipher,
                             symmetric_crypto_hw_acceleration_t hw_acceleration,
                             const void *key_ptr,
                             size_t key_size,
                             const void *iv_ptr,
                             size_t iv_size,
                             const void *header_ptr,
                             size_t header_size,
                             const void *plaintext_ptr,
                             size_t text_size,
                             void *ciphertext_ptr,
                             void *tag_ptr,
                             size_t *tag_size);

/**
   Decrypt with GCM.

   @param[in] service_ptr Symmetric Crypto service instance
   @param[in] cipher Cipher used for the operation
   @param[in] hw_acceleration HW acceleration
   @param[in] key_ptr Encryption key
   @param[in] key_size Size of the key in octets
   @param[in] iv_ptr Initialization vector
   @param[in] iv_size Size of the IV in octets
   @param[in] header_ptr Session header (optional)
   @param[in] header_size Size of the session header in octets
   @param[in] ciphertext_ptr Ciphertext to decrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] plaintext_ptr Plaintext
   @param[out] tag_ptr Authentication tag
   @param[in,out] tag_size
      The maximum size (in) and resulting size (out) of the
      authentication tag in octets

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
symmetric_crypto_gcm_decrypt(symmetric_crypto_service_t *service_ptr,
                             symmetric_crypto_cipher_t cipher,
                             symmetric_crypto_hw_acceleration_t hw_acceleration,
                             const void *key_ptr,
                             size_t key_size,
                             const void *iv_ptr,
                             size_t iv_size,
                             const void *header_ptr,
                             size_t header_size,
                             const void *ciphertext_ptr,
                             size_t text_size,
                             void *plaintext_ptr,
                             void *tag_ptr,
                             size_t *tag_size);

/**
   Compute CMAC authentication tag.

   @param[in] service_ptr Symmetric Crypto service instance
   @param[in] cipher Cipher used for the operation
   @param[in] hw_acceleration HW acceleration
   @param[in] key_ptr Secret key
   @param[in] key_size Size of the key in octets
   @param[in] message_ptr Message to compute CMAC
   @param[in] message_size Size of the message in octets
   @param[out] tag_ptr Authentication tag
   @param[in,out] tag_size
      The maximum size (in) and resulting size (out) of the
      authentication tag in octets

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
symmetric_crypto_cmac_compute(symmetric_crypto_service_t *service_ptr,
                              symmetric_crypto_cipher_t cipher,
                              symmetric_crypto_hw_acceleration_t hw_acceleration,
                              const void *key_ptr,
                              size_t key_size,
                              const void *message_ptr,
                              size_t message_size,
                              void *tag_ptr,
                              size_t *tag_size);

/**
   Compute GMAC authentication tag.

   @param[in] service_ptr Symmetric Crypto service instance
   @param[in] cipher Cipher used for the operation
   @param[in] hw_acceleration HW acceleration
   @param[in] key_ptr Secret key
   @param[in] key_size Size of the key in octets
   @param[in] iv_ptr Initialization vector
   @param[in] iv_size Size of the IV in octets
   @param[in] header_ptr Session header (optional)
   @param[in] header_size Size of the session header in octets
   @param[out] tag_ptr Authentication tag
   @param[in,out] tag_size
      The maximum size (in) and resulting size (out) of the
      authentication tag in octets

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
symmetric_crypto_gmac_compute(symmetric_crypto_service_t *service_ptr,
                              symmetric_crypto_cipher_t cipher,
                              symmetric_crypto_hw_acceleration_t hw_acceleration,
                              const void *key_ptr,
                              size_t key_size,
                              const void *iv_ptr,
                              size_t iv_size,
                              const void *header_ptr,
                              size_t header_size,
                              void *tag_ptr,
                              size_t *tag_size);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_SYMMETRIC_CRYPTO_SERVICE_H */
