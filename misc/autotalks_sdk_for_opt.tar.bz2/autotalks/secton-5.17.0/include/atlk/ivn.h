/** Copyright (C) 2018 Autotalks Ltd. */
#ifndef _ATLK_IVN_H
#define _ATLK_IVN_H

#include <atlk/sdk.h>
#include <common/counters.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   IVN common definitions
*/

/** IVN device ID (starts at zero) */
typedef uint8_t ivn_device_id_t;

/** Value indicating that IVN device ID is N/A */
#define IVN_DEVICE_ID_NA 0xFFU

/* CAN maximum payload size */
#define IVN_CAN_DATA_SIZE_MAX    8U

/* CAN FD maximum payload size */
#define IVN_CAN_FD_DATA_SIZE_MAX 64U

/** IVN message ID */
typedef uint32_t ivn_message_id_t;

/** IVN baudrate */
typedef uint32_t ivn_baudrate_t;

#define IVN_BAUDRATE_NA 0U

/** IVN ID length for standard frame format */
#define IVN_ID_NUM_BITS_BASE 11U

/** IVN ID length for extended frame format */
#define IVN_ID_NUM_BITS_EXTENDED 29U

/** IVN service instance */
typedef atlk_handle_t ivn_service_t;

/** IVN statistics */
typedef struct {

  /** IVN host statistics */
  atlk_counters_t host_stats;

  /** IVN device statistics */
  atlk_counters_t device_stats;

  /** IVN M3 statistics */
  atlk_counters_t m3_stats;

  /** IVN controller statistics */
  atlk_counters_t controller_stats;
} ivn_stats_t;

#define IVN_STATS_INIT {                    \
  .host_stats = ATLK_COUNTERS_INIT,         \
  .device_stats = ATLK_COUNTERS_INIT,       \
  .m3_stats = ATLK_COUNTERS_INIT,           \
  .controller_stats = ATLK_COUNTERS_INIT,   \
}

/** IVN acceptance filters */

/** IVN ID filter */
typedef ivn_message_id_t ivn_id_filter_t;

/** Bit 31 of IVN CAN ID field indicates extended frame format **/
#define IVN_EXTENDED_FORMAT_ID_MASK 0x80000000

/** IVN protocol */
typedef enum {
  IVN_PROTOCOL_CAN = 0,
  IVN_PROTOCOL_CAN_FD,
  IVN_PROTOCOL_MAX,
} ivn_protocol_t;

/** IVN filter type */
typedef enum {
  IVN_FILTER_TYPE_SW = 0,
  IVN_FILTER_TYPE_HW,
  IVN_FILTER_TYPE_MAX
} ivn_filter_type_t;

/* Maximum number of IVN filters per interface */
#define IVN_FILTERS_NUM_MAX 60U

/* IVN accept all received frame */
#define IVN_FILTER_ACCEPT_ALL 0U

/* IVN acceptance filters table

White list approach: IVN filter table defines acceptance filters

@note If value of filter_num field is IVN_FILTER_ACCEPT_ALL, all packets are accepted */
typedef struct {
  uint8_t filters_type;
  uint8_t filters_num;
  ivn_id_filter_t filters[IVN_FILTERS_NUM_MAX];
} ivn_filter_tbl_t;

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_IVN_H */
