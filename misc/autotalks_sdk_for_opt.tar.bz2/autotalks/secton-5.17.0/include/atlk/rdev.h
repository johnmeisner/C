/** Copyright (C) 2016 Autotalks Ltd. */
#ifndef _ATLK_RDEV_H
#define _ATLK_RDEV_H

#include <common/eui48.h>

#include <atlk/sdk.h>
#include <atlk_packet.h>

#ifdef __cplusplus
extern "C" {
#endif

/* TSF update callback function prototype */
typedef atlk_rc_t (*tsf_update_cb_t)(uint64_t tsf_time, uint8_t lock_status, uint64_t local_time, uint8_t update_source);

/**
   @file
   Remote Device API

   Interfaces that should be implemented by a host system in order to
   work with an Autotalks remote device
*/

/** Maximum remote device link PDU size */
#define RDEV_LINK_PDU_MAX_SIZE 2560U

/**
   Remote device link operations.

   All functions defined below may be called from different threads
   concurrently.

   All sent/received link layer PDUs shall be formatted as follows:
   +----------+---------+-----------+---------------+
   | DestAddr | SrcAddr | Ethertype | Payload       |
   | 6 bytes  | 6 bytes | 2 bytes   | 50-1500 bytes |
   +----------+---------+-----------+---------------+
   The underlying implementation may use an Ethernet MAC or an Ethernet
   emulation layer, such as USB CDC-ECM.
*/
typedef struct {
  /**
     Acquire link

     Called before invoking any other function in ::rdev_link_ops_t.
     May be called more than once.

     @param[in] context_ptr Link context
  */
  atlk_rc_t
  (*acquire)(void *context_ptr);

  /**
     Release link

     For each call to ::rdev_link_ops_t::acquire at remote device
     initialization time, this function shall be called once at remote
     device termination time.

     @param[in] context_ptr Link context
  */
  atlk_rc_t
  (*release)(void *context_ptr);

  /**
     Send link layer PDU

     @param[in] context_ptr Link context
     @param[in] send_params_ptr Parameters for sending
     @param[in] packet_ptr Packet to send

     @remark @p pdu_size shall be at most RDEV_LINK_PDU_MAX_SIZE.
  */
  atlk_rc_t
  (*send)(void *context_ptr,
          void *send_params_ptr,
          atlk_packet_t *packet_ptr);

  /**
     Receive link layer PDU

     @param[in] context_ptr Link context
     @param[in] receive_params_ptr Parameters for reception
     @param[in] packet_ptr Packet to fill with received data

     @remark @p *packet_ptr shall be at most RDEV_LINK_PDU_MAX_SIZE.
  */
  atlk_rc_t
  (*receive)(void *context_ptr,
             void *receive_params_ptr,
             atlk_packet_t *packet_ptr);

  /**
     link layer init function

     @param[in] pointer to interface name
     @param[in] pointer to link layer configuration struct
  */
  atlk_rc_t
  (*init)(const char *dev_name,
          void *config_ptr);

  /**
     link layer de-init function
  */
  atlk_rc_t
  (*deinit)(void);

  /**
     link layer init function

     @param[in] context_ptr Link context
     @param[out] params_ptr pointer to to link layer type parameters
  */
  atlk_rc_t
  (*params_get)(void *context_ptr,
                void *params_ptr);

  /**
     link layer has context

     @param[in] pointer to interface name
  */
  atlk_rc_t
  (*has_context)(const char *dev_name_ptr);

  /**
     Link layer current available space

     @param[in] Pointer to interface name
  */
  uint32_t
  (*current_available_space_get)(const char *dev_name_ptr);

  /**
     Link layer WLAN TSF reg address map get

     @param[out] Pointer TSF reg base address map
  */
  atlk_rc_t
  (*tsf_reg_address_get)(uint32_t **tsf_base_pptr);

  /**
     TSF update callback function registration

     @param[in] callback        Pointer tsf callback
     @param[in] update_source   Update source
  */
  atlk_rc_t
  (*tsf_time_callback_register)(tsf_update_cb_t callback, uint8_t update_source);

} rdev_link_ops_t;

/** Remote device hardware operations */
typedef struct {
  /**
     Acquire hardware

     Called before invoking any other function in ::rdev_hw_ops_t.
     May be called more than once.

     @param[in] context_ptr Hardware context
  */
  atlk_rc_t
  (*acquire)(void *context_ptr);

  /**
     Release hardware

     For each call to ::rdev_hw_ops_t::acquire at remote device
     initialization time, this function shall be called once at remote
     device termination time.

     @param[in] context_ptr Hardware context
  */
  atlk_rc_t
  (*release)(void *context_ptr);

  /**
     Reset remote device

     @param[in] context_ptr Remote device hardware context
  */
  atlk_rc_t
  (*rdev_reset)(void *context_ptr);

} rdev_hw_ops_t;

/** Remote device descriptor */
typedef struct {
  /** Remote device link address */
  eui48_t rdev_address;

  /** Remote device interface name */
  const char *rdev_interface_name;

  /** Remote device link operations */
  const rdev_link_ops_t *link_ops_ptr;

  /** Remote device link context */
  void *link_context_ptr;

  /** Remote device hardware operations */
  const rdev_hw_ops_t *hw_ops_ptr;

  /** Remote device hardware context */
  void *hw_context_ptr;

} rdev_desc_t;

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_RDEV_H */
