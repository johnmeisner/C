/** Copyright (C) 2016 Autotalks Ltd. */
#ifndef _ATLK_DDM_H
#define _ATLK_DDM_H

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   Device Diagnostics and Management API
*/

#include <atlk/wdm.h>
#include <atlk/dsm.h>

/** GPIO offset ranges from 0 to 31 */
#define DDM_GPIO_PIN_OFFSET_MAX 31

/** BSP component version string length */
#define DDM_BSP_COMPONENT_VERSION_MAX_LEN 100

/** DDM state */
typedef enum {
  /** Device disconnected */
  DDM_STATE_DISCONNECTED = 0,

  /** Device not initialized */
  DDM_STATE_UNINITIALIZED,

  /** Device ready */
  DDM_STATE_READY,

} ddm_state_t;

/** TSF lock status */
typedef enum {
  /** TIME SYNC is not synchronized*/
  DDM_TSF_LOCK_STATUS_UNLOCKED = 0,

  /** TIME SYNC PPS is locked*/
  DDM_TSF_LOCK_STATUS_LOCKED,

  /** TIME SYNC is synchronized */
  DDM_TSF_LOCK_STATUS_UTC_SYNCED

} ddm_tsf_lock_status_t;

/** PPS lock status */
typedef enum {
  /** PPS is unlocked */
  DDM_PPS_LOCK_STATUS_UNLOCKED = 0,

  /** PPS is locked */
  DDM_PPS_LOCK_STATUS_LOCKED

} ddm_pps_lock_status_t;

#define DDM_TEMPERATURE_READING_INVALID INT32_MIN

/** DDM status */
typedef struct {
  /** Device temperature */
  int32_t temperature_celsius;

} ddm_status_t;

#define DDM_CPU_PROFILER_THREAD_NAME_MAX_LEN 32U
#define DDM_CPU_PROFILER_THREAD_MAX_NUMBER   32U

/** Thread state */
typedef enum {
  DDM_THREAD_STATE_READY,
  DDM_THREAD_STATE_COMPLETED,
  DDM_THREAD_STATE_TERMINATED,
  DDM_THREAD_STATE_SUSPENDED,
  DDM_THREAD_STATE_SLEEP,
  DDM_THREAD_STATE_QUEUE_SUSP,
  DDM_THREAD_STATE_SEMAPHORE_SUSP,
  DDM_THREAD_STATE_EVENT_FLAG,
  DDM_THREAD_STATE_BLOCK_MEMORY,
  DDM_THREAD_STATE_BYTE_MEMORY,
  DDM_THREAD_STATE_IO_DRIVER,
  DDM_THREAD_STATE_FILE,
  DDM_THREAD_STATE_TCP_IP,
  DDM_THREAD_STATE_MUTEX_SUSP,
  DDM_THREAD_STATE_LAST
} ddm_cpu_profiler_thread_state_t;

typedef struct {
  uint64_t cpu_cycles;
  uint8_t  state;
  char     name[DDM_CPU_PROFILER_THREAD_NAME_MAX_LEN];
} ddm_cpu_profiler_thread_entry_t;

typedef struct {
  uint64_t idle_cpu_cycles;
  uint64_t isr_cpu_cycles;
  uint64_t total_cycles;
  uint8_t  number_of_threads;
  ddm_cpu_profiler_thread_entry_t threads_list[DDM_CPU_PROFILER_THREAD_MAX_NUMBER];
} ddm_cpu_profiler_report_t;

/** Device calibration structure */
typedef struct {
  /** Calibration buffer */
  char *calibration_buffer_ptr;
  /** Calibration size */
  size_t calibration_size;
} ddm_calibration_t;

/** Device RF CONFIG structure */
typedef struct {
  /** RF CONFIG buffer */
  char *rf_config_buffer_ptr;
  /** RF CONFIG size */
  size_t rf_config_size;
} ddm_rf_config_t;

/** DDM service instance */
typedef atlk_handle_t ddm_service_t;

/** Number of SOC OTP registers */
#define DDM_UNIQUE_ID_LEN 8
/** Device SOC OTP registers structure */
typedef struct {
  uint32_t id[DDM_UNIQUE_ID_LEN];
} ddm_unique_id_t;

/** DDM GPIO banks */
typedef enum {
  /** GPIO0 bank */
  DDM_GPIO0_BANK = 0,

  /** GPIO1 bank */
  DDM_GPIO1_BANK,

  /** GPIO2 bank */
  DDM_GPIO2_BANK,

  /** GPIO3 bank */
  DDM_GPIO3_BANK,

  /** S_GPIO bank */
  DDM_S_GPIO_BANK,

  /** M3_GPIO bank */
  DDM_M3_GPIO_BANK
} ddm_gpio_bank_t;

/** GPIO pin offset in bank */
typedef uint8_t ddm_gpio_pin_offset_t;

/** DDM GPIO modes */
typedef enum {
  /** Software */
  DDM_GPIO_SW = 0,

  /** Alternate Function A */
  DDM_GPIO_ALT_A,

  /** Alternate Function B */
  DDM_GPIO_ALT_B,

  /** Alternate Function C */
  DDM_GPIO_ALT_C
} ddm_gpio_mode_t;

/** DDM GPIO directions (Software mode only) */
typedef enum {
  /** Input */
  DDM_GPIO_DIR_IN = 0,

  /** Output */
  DDM_GPIO_DIR_OUT
} ddm_gpio_direction_t;

/** DDM GPIO values (Software mode only) */
typedef enum {
  /** Logical '0' */
  DDM_GPIO_VAL_0 = 0,

  /** Logical '1' */
  DDM_GPIO_VAL_1
} ddm_gpio_value_t;

/** Host to device (SECTON) per-service message rates. Additional rate for invalid service id. */
typedef struct {
  uint32_t rate[(uint32_t)DSM_SERVICE_TYPE_MAX + 1U];
} ddm_msg_rate_t;

/** DDM baseband V2X HW revision */
typedef struct {
  /** Baseband V2X HW revision major */
  uint32_t bb_v2x_hw_rev_major;

  /** Baseband V2X HW revision minor */
  uint32_t bb_v2x_hw_rev_minor;

} ddm_baseband_v2x_hw_revision_t;

/** BSP components version */
typedef struct {
  /** Version of M3 loader */
  char m3_loader_version[DDM_BSP_COMPONENT_VERSION_MAX_LEN];

  /** Version of M3 OS */
  char m3_os_version[DDM_BSP_COMPONENT_VERSION_MAX_LEN];

  /** Version of AP loader */
  char ap_loader_version[DDM_BSP_COMPONENT_VERSION_MAX_LEN];

  /** Version of AP OS */
  char ap_os_version[DDM_BSP_COMPONENT_VERSION_MAX_LEN];
} ddm_bsp_version_t;

/** Device SW configuration structure */
typedef struct {
  /** Calibration file location */
  int32_t lmac_calib_file_location;
  /** RF CONFIG file location */
  int32_t lmac_rf_config_file_location;
  /** If set to '1' server do not forward v2x indications to other clients */
  int32_t v2x_service_broadcast_disable;
  /** If set to '1' server do not forward IVN indications to other clients */
  int32_t ivn_service_broadcast_disable;
  /** Force CSK generation, if not already programmed */
  int32_t force_csk_generate;
  /* Device log level */
  int32_t log_level_device;
} ddm_sw_config_t;

typedef struct {
  uint8_t device_version_major;
  uint8_t device_version_minor;
  uint8_t device_version_patch;
  uint8_t host_version_major;
  uint8_t host_version_minor;
  uint8_t host_version_patch;

  uint32_t dsp_actual_common_version;
  uint32_t dsp_actual_specific_version;
  uint32_t dsp_expected_common_version;
  uint32_t dsp_expected_specific_version;

  uint32_t platform_actual_version;
  uint32_t platform_expected_version;
} ddm_system_versions_t;

/**
  Device internal SW configuration structure.
  For Auto-Talks internal use only.
*/
typedef struct {
  /** loopback enable */
  int32_t lmac_loopback_enable;

  /** phy loopback enable */
  int32_t lmac_phy_loopback_enable;

  /** trace verbosity enable */
  int32_t lmac_trace_verbose;

  /** SW configuration file version */
  int32_t swc_version;

  /** Ranging enable */
  int32_t ranging_enable;

  /** Decentralized congestion control TX complete indication */
  int32_t dcc_indication_enable;

  /** Physical interfaces in use */
  int32_t physical_interfaces_in_use;

  /** Link layer SPI clock [Hz] */
  int32_t ll_spi_clock;

  /** Link layer SPI element data number of bits, 8, 16 or 32 */
  int32_t ll_spi_element_data_bits;

  /** SPI (0, 1, 2, 3) -> CPOL/CPHA bits (0/0, 0/1, 1/0, 1/1) */
  int32_t ll_spi_mode;

  /** Link layer SPI delay between two transactions [us] */
  int32_t ll_spi_transaction_delay;

  /** Link layer SPI recovery delay between two transactions [us] */
  int32_t ll_spi_recovery_delay;

  /** Link layer SPI page size */
  int32_t ll_spi_page_size;

  /** Link layer SPI single transfer size (slave mode only) */
  int32_t ll_spi_slave_transfer_size;

  /** Diversity enable */
  int32_t lmac_diversity_enable;

  /** Recovery enable */
  int32_t lmac_recovery_enable;

  /* DSP memory dump in case of recovery */
  int32_t lmac_recovery_mem_dump_enable;

  /** Behavior when version check fails: 0 - exit with error, 1 - just warning */
  int32_t system_versions_bypass;

  /** Apply affinity mode: This will fix pre-selected threads or entire process to run only on a certain CPU/CPUs: 0 - no affinity, 1 - only specific threads, 2 - the entire process */
  int32_t affinity_mode;

  /** Affinity CPU mask, if enabled the process or threads will run only on the enabled mask CPU/CPUs */
  int32_t affinity_cpu_mask;
} ddm_sw_config_internal_t;

/** Device configuration structure */
typedef struct {
  /** Binary buffer */
  char *binary_buffer_ptr;
  /** Binary size */
  size_t binary_size;
  /** module parameters buffer */
  /** Calib info buffer */
  char *calib_buffer_ptr;
  /** Calib size */
  size_t calib_size;
  /** Cache buffer */
  char *calib_buffer_extended_ptr;
  /** Cache size */
  size_t calib_extended_size;
  /** RF CONFIG buffer */
  char *rf_config_buffer_ptr;
  /** RF CONFIG size */
  size_t rf_config_size;
  /** DDM configuration module parameters */
  ddm_sw_config_t sw_config;
  /** DDM internal configuration module parameters */
  ddm_sw_config_internal_t sw_config_internal;
} ddm_configure_t;

/** DDM configuration default initializer */
#define DDM_CONFIGURE_INIT           \
{                                    \
  .binary_buffer_ptr = NULL,         \
  .binary_size = 0,                  \
  .calib_buffer_ptr = NULL,          \
  .calib_size = 0,                   \
  .calib_buffer_extended_ptr = NULL, \
  .calib_extended_size = 0,          \
  .rf_config_buffer_ptr = NULL,      \
  .rf_config_size = 0,               \
  .sw_config = {0},                  \
  .sw_config_internal = {0},         \
}

/**
  Set baseband V2X hardware revision (set once on DSM initializing)

  @param[in] revision_ptr Baseband V2X hardware revision

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_static_baseband_v2x_hw_revision_set_once(const ddm_baseband_v2x_hw_revision_t *bb_v2x_hw_rev_ptr);

/**
  Get baseband V2X hardware revision

  @param[out] revision_ptr Baseband V2X hardware revision

  @retval ::ATLK_OK if succeeded
  @return Error code if failed
*/
atlk_rc_t atlk_must_check
ddm_static_baseband_v2x_hw_revision_get(ddm_baseband_v2x_hw_revision_t *bb_v2x_hw_rev_ptr);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_DDM_H */
