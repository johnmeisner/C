/** Copyright (C) 2014-2016 Autotalks Ltd. */
#ifndef _ATLK_V2X_SERVICE_H
#define _ATLK_V2X_SERVICE_H

#include <atlk/sdk.h>
#include <atlk/v2x.h>
#include <atlk/v2x_dot4.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   V2X service API
*/

/**
   Get V2X service instance.

   @param[in] service_name Name of service (NULL for default)
   @param[out] service_pptr V2X service instance

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_service_get(const char *service_name,
                v2x_service_t **service_pptr);

/**
   Set v2x_sockets_passthrough_set
   Setting pass-through mode will tell v2x module not to assume v2x headers.
   Default mode is regular mode = dsrc mode = not pass-through mode.

   @param[in] mode (1 = pass through, 0 = regular mode)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
v2x_sockets_passthrough_set(int on_off);

/** V2X socket */
typedef atlk_handle_t v2x_socket_t;

/** V2X socket configuration */
typedef struct {
  /** Ingress/egress physical interface index */
  if_index_t if_index;

  /** V2X protocol descriptor */
  v2x_protocol_t protocol;

} v2x_socket_config_t;

/** V2X socket configuration default initializer */
#define V2X_SOCKET_CONFIG_INIT {            \
  .if_index = IF_INDEX_NA,                  \
  .protocol = V2X_PROTOCOL_INIT,            \
}

/**
   Create V2X socket.

   @param[in] service_ptr V2X service instance
   @param[out] socket_pptr V2X socket pointer
   @param[in] config_ptr V2X socket configuration

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_socket_create(v2x_service_t *service_ptr,
                  v2x_socket_t **socket_pptr,
                  const v2x_socket_config_t *config_ptr);

/**
   Delete V2X socket.

   @param[in] socket_ptr V2X socket pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
v2x_socket_delete(v2x_socket_t *socket_ptr);

/** V2X send parameters */
typedef struct {
  /**
     Source MAC address

     In case of all zero source MAC address, device will set it according
     to actual MAC interface address.  */
  eui48_t source_address;

  /** Destination MAC address

      If (and only if) destination address is broadcast address, transmitted frame
     shall not request acknowledgment of reception.
  */
  eui48_t dest_address;

  /**
     MAC User Priority
  */
  user_priority_t user_priority;

  /**
     Radio channel on which the frame should be transmitted.

     @note When channel access is set to continous, channel_id.time_slot
     value is ignored.
  */
  v2x_channel_id_t channel_id;

  /** Transmission data rate */
  datarate_t datarate;

  /**
     Transmission power level in units of 1/8 dBm.

     Users should transmit at power level which is within TSSI calibration
     range, with a margin of 3dB on each side. System behavior when
     transmitting at other power levels is undefined.

     Example: In a system that was calibrated in range [7..26]dBm, users
     should transmit at power level in range [10..23]dBm. In this case,
     system behavior when transmitting at 7dBm is undefined.

     TSSI loop convergence is expected within few transmitted frames. Tx power
     is expected to be less accurate before TSSI loop convergence.
  */
  power_dbm8_t power_dbm8;

  /**
     Transmission power level of frame transmitted on second antenna in units
     of 1/8 dBm, when TX diversity is enabled.
  */
  power_dbm8_t transmit_diversity_power_dbm8;

  /**
     Expiration time in milliseconds.

     @todo Currently not supported.
  */
  v2x_expiry_time_ms_t expiry_time_ms;

  /**
     Compensator data per antenna.
  */
  compensator_data_t comp_data[RF_INDEX_MAX];
} v2x_send_params_t;

/** V2X send parameters default initializer */
#define V2X_SEND_PARAMS_INIT {                      \
  .source_address = EUI48_ZERO_INIT,                \
  .dest_address = EUI48_BCAST_INIT,                 \
  .user_priority = USER_PRIORITY_NA,                \
  .channel_id = V2X_CHANNEL_ID_INIT,                \
  .datarate = DATARATE_NA,                          \
  .power_dbm8 = POWER_DBM8_NA,                      \
  .transmit_diversity_power_dbm8 = POWER_DBM8_NA,   \
  .expiry_time_ms = V2X_EXPIRY_TIME_MS_NA,          \
  .comp_data = { [0 ... RF_INDEX_MAX - 1] =         \
                          COMPENSATOR_DATA_INIT },  \
}

/**
   Send V2X frame.

   @param[in] socket_ptr V2X socket pointer
   @param[in] data_ptr Pointer to start of data
   @param[in] data_size Size of data in bytes
   @param[in] params_ptr Input parameters of send operation
   @param[in] wait_ptr Wait specification (optional)

   @note Only supported wait option is NULL which is non blocking mode

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_send(v2x_socket_t *socket_ptr,
         const void *data_ptr,
         size_t data_size,
         const v2x_send_params_t *params_ptr,
         const atlk_wait_t *wait_ptr);

/** V2X receive parameters */
typedef struct {
  /** Source MAC address */
  eui48_t source_address;

  /** Destination MAC address */
  eui48_t dest_address;

  /** MAC User Priority */
  user_priority_t user_priority;

  /** Radio channel on which the frame was received. */
  v2x_channel_id_t channel_id;

  /** Data rate */
  datarate_t datarate;

  /** Input power of frame in units of 1/8 dBm */
  power_dbm8_t power_dbm8;

  /**
     Input power of frame received on second antenna in units of
     1/8 dBm, when RX diversity is enabled.
  */
  power_dbm8_t receive_diversity_power_dbm8;

  /**
     Receive time in microseconds

     Format: number of TAI microseconds since 2004-01-01T00:00:00Z (UTC).
  */
  uint64_t receive_time_us;

} v2x_receive_params_t;

/** V2X receive parameters default initializer */
#define V2X_RECEIVE_PARAMS_INIT {                    \
  .source_address = EUI48_ZERO_INIT,                 \
  .dest_address = EUI48_ZERO_INIT,                   \
  .user_priority = USER_PRIORITY_NA,                 \
  .channel_id = V2X_CHANNEL_ID_INIT,                 \
  .datarate = DATARATE_NA,                           \
  .power_dbm8 = POWER_DBM8_NA,                       \
  .receive_diversity_power_dbm8 = POWER_DBM8_NA,     \
  .receive_time_us = 0,                              \
}

/**
   Receive V2X frame.

   @param[in] socket_ptr V2X socket pointer
   @param[out] data_ptr Pointer to start of data
   @param[in,out] data_size_ptr Maximum (in) and actual (out) data size in bytes
   @param[out] params_ptr Output parameters of receive operation
   @param[in] wait Wait specification (optional)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_receive(v2x_socket_t *socket_ptr,
            void *data_ptr,
            size_t *data_size_ptr,
            v2x_receive_params_t *params_ptr,
            const atlk_wait_t *wait_ptr);

/**
   Get V2X socket statistics

   @param[in] socket_ptr V2X socket
   @param[out] stats_ptr Statistics pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_socket_stats_get(v2x_socket_t *socket_ptr,
                     v2x_socket_stats_t *stats_ptr);

/**
   Create V2X CBR sample subscriber.

   @param[in] service_ptr V2X service instance
   @param[in] if_index MAC interface index
   @param[out] subscriber_pptr V2X sample subscriber pointer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_cbr_subscriber_create(v2x_service_t *service_ptr,
                          if_index_t if_index,
                          v2x_sample_subscriber_t **subscriber_pptr);

/**
   Delete V2X sample subscriber.

   @param[in] subscriber_ptr V2X sample subscriber to delete

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
v2x_sample_subscriber_delete(v2x_sample_subscriber_t *subscriber_ptr);

/**
   Receive a V2X CBR sample.

   @note This API waits for the next valid CBR measurement. If such measurement
   is not available within the wait duration specified, the function will
   return ::ATLK_E_TIMEOUT.

   @note If wait type is ::ATLK_WAIT_TYPE_INTERVAL, then wait duration must be
   larger than zero.

   @param[in] subscriber_ptr V2X sample subscriber instance
   @param[out] sample_ptr CBR sample
   @param[in] wait_ptr Wait specification (optional)

   @retval ::ATLK_OK if succeeded
   @retval ::ATLK_E_TIMEOUT if sample is not available during wait duration
   @retval ::ATLK_E_UNSUPPORTED if wait duration is zero
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_cbr_sample_receive(v2x_sample_subscriber_t *subscriber_ptr,
                       v2x_cbr_sample_t *sample_ptr,
                       const atlk_wait_t *wait_ptr);


/**
   Get decentralized congestion control according packet user priority.

   @note This information can be used for controlling v2x packet transmit rate as the DCC
   table holds the actual time of the last transmitted/failed packet to the air.

   @param[out] dcc_ptr         Pointer to decentralized congestion control struct
   @param[in]  user_priority   The relevant data to retrieve according user priority
   @param[in] if_index         MAC interface index

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
v2x_dcc_get(v2x_dcc_t *dcc_ptr, uint8_t user_priority, if_index_t if_index);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_V2X_SERVICE_H */
