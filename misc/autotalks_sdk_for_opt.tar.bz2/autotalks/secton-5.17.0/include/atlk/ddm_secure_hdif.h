/** Copyright (C) 2016 Autotalks Ltd. */
#ifndef _ATLK_DDM_SECURE_HDIF_H_
#define _ATLK_DDM_SECURE_HDIF_H_

#include <atlk/dsm.h>
#include <atlk/ddm_service.h>
#include <atlk/ehsm.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DDM_SECURE_HDIF_SERVICE_MAX_ID            64U /* Need to be same as REMOTE_DDM_SECURE_HDIF_SERVICE_MAX_ID */

#define SECURE_HDIF_AES_256_KEY_SIZE              EHSM_SYMMETRIC_KEY_SIZE  /* 256 bit */
#define SECURE_HDIF_AES_128_KEY_SIZE              16U                      /* 128 bit */

#define SECURE_HDIF_MAX_KEY_SIZE                  SECURE_HDIF_AES_256_KEY_SIZE
#define SECURE_HDIF_MAC_TAG_SIZE                  EHSM_SYMMETRIC_TAG_SIZE
#define SECURE_HDIF_IV_SIZE                       16U /* Need to be same as REMOTE_DDM_SECURE_HDIF_IV_SIZE */
#define SECURE_HDIF_SYMMETRIC_BLOB_SIZE           (EHSM_SYMMETRIC_BLOB_SIZE - 4U) /* No need for header in our case, so -4*/
#define SECURE_HDIF_STORAGE_BLOB_SIZE             48U
#define SECURE_HDIF_MASTER_KEY_MAGIC_NUMBER_SIZE  16U
#define SECURE_HDIF_MASTER_KEYS_BLOB_SIZE         SECURE_HDIF_MASTER_KEY_MAGIC_NUMBER_SIZE + \
                                                  SECURE_HDIF_STORAGE_BLOB_SIZE + \
                                                  SECURE_HDIF_SYMMETRIC_BLOB_SIZE + \
                                                  SECURE_HDIF_SYMMETRIC_BLOB_SIZE


typedef struct {
uint8_t levels[DDM_SECURE_HDIF_SERVICE_MAX_ID];
} ddm_secure_hdif_service_security_levels_t;

/* All DDM secure hdif structs need to be aligned with device remote_ddm.h */
typedef struct {
  uint8_t buffer[SECURE_HDIF_MASTER_KEYS_BLOB_SIZE];
} ddm_secure_hdif_master_keys_blob_t;

/* All remote DDM secure HDIF structs are in use only at the device */
typedef struct {
  /** Master key to be used for encryption in plain text */
  uint8_t encryption_key_plain_text[SECURE_HDIF_MAX_KEY_SIZE];

  /** Master key to be used for authentication in plain text */
  uint8_t authentication_key_plain_text[SECURE_HDIF_MAX_KEY_SIZE];

  /** Master keys blob */
  ddm_secure_hdif_master_keys_blob_t blob;
} ddm_secure_hdif_master_keys_t;

typedef struct {
  uint8_t encryption_key[SECURE_HDIF_MAX_KEY_SIZE];
  uint8_t authentication_key[SECURE_HDIF_MAX_KEY_SIZE];
  /** Initialization vector key that will be used at the host for IV encryption making it unpredictable */
  uint8_t iv_key[SECURE_HDIF_IV_SIZE];
} ddm_secure_hdif_keys_t;

typedef struct {
  /** Initialization vector that was used at the device for ciphertext encryption */
  uint8_t iv[SECURE_HDIF_IV_SIZE];

  /** Session key that are generated at the device and encrypt using master key with above IV */
  ddm_secure_hdif_keys_t ciphertext;
} ddm_secure_hdif_session_keys_element_t;

typedef struct {
  /** MAC is computed with Master Key at the device */
  uint8_t mac_tag[SECURE_HDIF_MAC_TAG_SIZE];

  /** Session key that are generated at the device and was encrypted using master key */
  ddm_secure_hdif_session_keys_element_t keys;
} ddm_secure_hdif_session_keys_ciphertext_t;

typedef struct {
  /** Number of packets that where received and authenticated successfully */
  uint32_t packets_authenticated;

  /** Number of packets that where encrypted successfully */
  uint32_t packets_encrypted;

  /** Number of packets that where received and decrypted successfully */
  uint32_t packets_decrypted;

  /** Number of packets that where received and resulted with authenticated error */
  uint32_t authentication_errors;

  /** Number of tag computed attempts that ended with error */
  uint32_t tag_compute_errors;

  /** Number of packet encryption attempts that ended with error */
  uint32_t encrypt_errors;

  /** Number of packet decryption attempts that ended with error */
  uint32_t decrypt_errors;

  /** The total number of blocks that where processed by the crypto engine */
  uint32_t total_number_of_secure_blocks;

  /** The total number of session key that where used */
  uint32_t number_of_session_keys_used;

  /** Number of blocks that the current session key was used by the crypto engine */
  uint32_t current_session_key_wear_down_counter;

  /** Number of failed crypto cooperations due to expired key */
  uint32_t session_key_wear_down_errors;
} ddm_secure_hdif_statistics_get_t;

/** Function prototype for secure HDIF session keys expire notify callback */
typedef void (*ddm_secure_hdif_session_keys_expire_notify)(ddm_service_t *service_ptr,
                                                           uint32_t session_key_counter,
                                                           uint32_t session_key_counter_max);
/**
   Init secure HDIF

   @param[in] ddm_service_ptr  Pointer to DDM service struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t atlk_must_check
ddm_secure_hdif_init(ddm_service_t *ddm_service_ptr);

/**
   Gets secure HDIF security levels table

   @param[in] ddm_service_ptr       Pointer to DDM service struct
   @param[in] service_type          The service ID to retrieve security levels
   @param[out] security_levels_ptr  Size of encr_key and auth_key returns the actual size used

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
ddm_secure_hdif_security_levels_get(ddm_service_t *ddm_service_ptr,
                                    dsm_service_type_t service_type,
                                    ddm_secure_hdif_service_security_levels_t *security_levels_ptr);

/**
   Starts a new session, and provides the session key

   @note To start secure communication a session should be started once a master key was set.
         A new AES key is generated by Device and provided,
         The key is encrypted and tagged using the master key.

   @param[in] ddm_service_ptr         Pointer to DDM service struct
   @param[in] key_size                the session key size to be generated
   @param[out] session_keys_blob_ptr  Pointer to the session key blob that contains the encrypted keys and the tag

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
atlk_rc_t
ddm_secure_hdif_session_start(ddm_service_t *ddm_service_ptr,
                              uint32_t key_size,
                              ddm_secure_hdif_session_keys_ciphertext_t *session_keys_blob_ptr);

/**
   Return Device configuration status of secure HDIF functionality

   @param[in] ddm_service_ptr Pointer to DDM service struct
   @param[out] status_ptr     Pointer to parameter that indicates if the device is secured or not

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
 atlk_rc_t atlk_must_check
ddm_secure_hdif_status_get(ddm_service_t *ddm_service_ptr, uint32_t *status_ptr);

/**
   Return Device configuration status of secure HDIF functionality

   @param[in] ddm_service_ptr Pointer to DDM service struct
   @param[in] clear_on_read   If set to 1 all statistics will be cleared after read
   @param[out] statistics_ptr Pointer secure hdif ststistics

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
  */
 atlk_rc_t atlk_must_check
ddm_secure_hdif_statistics_get(ddm_service_t *ddm_service_ptr, uint32_t clear_on_read, ddm_secure_hdif_statistics_get_t *statistics_ptr);

 /**
    @brief Send to the device the master keys blob
    @param[in] ddm_service_ptr Pointer to DDM service struct
    @param[in] blob_ptr    Pointer to master keys blob that was saved on the secure storage
    @param[in] key_size    Master key size
    @param[in] blob_size   The size of blob ptr

    @retval ::ATLK_OK if succeeded
    @return Error code if failed
   */
atlk_rc_t atlk_must_check
ddm_secure_hdif_master_key_blob_set(ddm_service_t *ddm_service_ptr, uint8_t *blob_ptr, uint32_t key_size, uint32_t blob_size);

/**
  Register to DDM secure HDIF session keys expire notifier

  @param[in] ddm_service_ptr DDM service instance
  @param[in] handler Expire notify handler

  @retval ::ATLK_OK if succeeded
  @return Error code if failed

*/
atlk_rc_t
ddm_secure_hdif_session_keys_expire_notify_register(ddm_service_t *ddm_service_ptr,
                                                    ddm_secure_hdif_session_keys_expire_notify handler);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_DDM_SECURE_HDIF_H_ */
