/** Copyright (C) 2021-2022 Autotalks Ltd. */
#ifndef _ATLK_GENERIC_COMPENSATOR_H
#define _ATLK_GENERIC_COMPENSATOR_H

#include <inttypes.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   Generic compensator data declarations
*/

/** Maximum size of compensator data */
#define COMPENSATOR_DATA_SIZE_MAX 8

/** Generic compensator data */
typedef struct compensator_data {
  uint8_t data[COMPENSATOR_DATA_SIZE_MAX];
  uint8_t len;
  uint8_t reserved;
} compensator_data_t;

/** Generic compensator data default initialiser */
#define COMPENSATOR_DATA_INIT { \
  .data     = {0},              \
  .len      = 0,                \
  .reserved = 0,                \
}


#endif /* _ATLK_GENERIC_COMPENSATOR_H */
