/** Copyright (C) 2018 Autotalks Ltd. */
#ifndef _ATLK_SYMMETRIC_CRYPTO_H
#define _ATLK_SYMMETRIC_CRYPTO_H

#include <atlk/sdk.h>
#include <extern/target_type.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   Symmetric Crypto API declarations
*/

/** Symmetric Crypto service instance */
typedef atlk_handle_t symmetric_crypto_service_t;

/* Symmetric crypto cipher */
typedef enum {
  /** AES */
  SYMMETRIC_CRYPTO_CIPHER_AES,

  /** SM4 */
  SYMMETRIC_CRYPTO_CIPHER_SM4,

  /** Invalid symmetric crypto cipher */
  SYMMETRIC_CRYPTO_CIPHER_INVALID = 0xFF
} symmetric_crypto_cipher_t;

/** Symmetric crypto HW acceleration */
typedef enum {
  /** HW acceleration enabled */
  SYMMETRIC_CRYPTO_HW_ACCELERATION_ENABLED,

  /** HW acceleration disabled - use SW instead */
  SYMMETRIC_CRYPTO_HW_ACCELERATION_DISABLED
} symmetric_crypto_hw_acceleration_t;

/** Symmetric Crypto 128 secret key size in octets */
#define SYMMETRIC_CRYPTO_128_KEY_SIZE 16U

/** Symmetric Crypto 256 secret key size in octets */
#define SYMMETRIC_CRYPTO_256_KEY_SIZE 32U

/** Symmetric Crypto block size in octets */
#define SYMMETRIC_CRYPTO_BLOCK_SIZE 16U

atlk_inline atlk_rc_t
symmetric_crypto_hw_acceleration_is_valid(symmetric_crypto_cipher_t cipher,
                                          symmetric_crypto_hw_acceleration_t hw_acceleration)
{
  /* parasoft suppress MISRA2012-RULE-14_3_zc */
  if ( (target_type_get() == TARGET_TYPE_SECTON) || (device_type_get() == DEVICE_TYPE_ON_M3) ) {
    /* SECTON: HW is not enabled */
    if (hw_acceleration == SYMMETRIC_CRYPTO_HW_ACCELERATION_ENABLED) {
      return ATLK_E_INVALID_ARG;
    }
  }
  else {
    /* CRATON */
    switch (cipher) {
      case SYMMETRIC_CRYPTO_CIPHER_AES:
        return ATLK_OK;
      default:
        if (hw_acceleration == SYMMETRIC_CRYPTO_HW_ACCELERATION_ENABLED) {
          return ATLK_E_INVALID_ARG;
        }
    }
  }
  /* parasoft unsuppress MISRA2012-RULE-14_3_zc */
  return ATLK_OK;
}

/* parasoft-begin-suppress BD-PB-UCMETH-4 "This function is only used in applications that are excluded from MISRA build" */
atlk_inline symmetric_crypto_hw_acceleration_t
symmetric_crypto_best_hw_acceleration_for_algorithm_get(symmetric_crypto_cipher_t cipher)
{
  /* parasoft suppress MISRA2012-RULE-14_3_zc */
  if ( (target_type_get() == TARGET_TYPE_SECTON) || (device_type_get() == DEVICE_TYPE_ON_M3) ) {
    /* SECTON: HW is not enabled */
    return SYMMETRIC_CRYPTO_HW_ACCELERATION_DISABLED;
  }
  else {
    /* CRATON */
    switch (cipher) {
      case SYMMETRIC_CRYPTO_CIPHER_AES:
        return SYMMETRIC_CRYPTO_HW_ACCELERATION_ENABLED;
      default:
        return SYMMETRIC_CRYPTO_HW_ACCELERATION_DISABLED;
    }
  }
  /* parasoft unsuppress MISRA2012-RULE-14_3_zc */
}
/* parasoft-end-suppress BD-PB-UCMETH-4 "This function is only used in applications that are excluded from MISRA build" */

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_SYMMETRIC_CRYPTO_H */
