/** Copyright (C) 2016 Autotalks Ltd. */
#ifndef _ATLK_V2X_H
#define _ATLK_V2X_H

#include <inttypes.h>
#include <common/eui48.h>
#include <common/types.h>
#include <atlk/sdk.h>
#include <atlk/generic_compensator.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   V2X API declarations
*/

/** V2X expiration time in milliseconds */
typedef uint16_t v2x_expiry_time_ms_t;

/** Value indicating maximum allowed expiration time in milliseconds */
#define V2X_EXPIRY_TIME_MS_MAX 0x7FFF

/** Value indicating that V2X expiration time is N/A */
#define V2X_EXPIRY_TIME_MS_NA 0

/** V2X packet access options if_index 0 [0-4], if_ndex 1 [5-9] */
#define V2X_IF_INDEX_0_ACCESS_PRIORITY_0 0
#define V2X_IF_INDEX_0_ACCESS_PRIORITY_1 1
#define V2X_IF_INDEX_0_ACCESS_PRIORITY_2 2
#define V2X_IF_INDEX_0_ACCESS_PRIORITY_3 3
#define V2X_IF_INDEX_0_ACCESS_PRIORITY_4 4
#define V2X_IF_INDEX_1_ACCESS_PRIORITY_0 5
#define V2X_IF_INDEX_1_ACCESS_PRIORITY_1 6
#define V2X_IF_INDEX_1_ACCESS_PRIORITY_2 7
#define V2X_IF_INDEX_1_ACCESS_PRIORITY_3 8
#define V2X_IF_INDEX_1_ACCESS_PRIORITY_4 9

#define V2X_POWER_DBM_MAX 30
#define V2X_POWER_DBM8_MAX (V2X_POWER_DBM_MAX * POWER_DBM8_PER_DBM)

#define V2X_POWER_DBM_MIN (-30)
#define V2X_POWER_DBM8_MIN (V2X_POWER_DBM_MIN * POWER_DBM8_PER_DBM)

/** Maximum size of V2X MAC frame payload size */
#define V2X_FRAME_PAYLOAD_SIZE_MAX 2304U

/** V2X MAC frame type */
typedef enum  {
  /** Frame type N/A */
  V2X_FRAME_TYPE_NA = 0,

  /** Data frame with LLC/SNAP payload and OUI=00-00-00 */
  V2X_FRAME_TYPE_DATA_LPD_ETHERTYPE,

  /** Data frame with EPD payload */
  V2X_FRAME_TYPE_DATA_EPD_ETHERTYPE

} v2x_frame_type_t;

/** V2X protocol descriptor */
typedef struct {
  /** V2X MAC frame type */
  v2x_frame_type_t frame_type;

  /** Protocol identifier (e.g. EtherType) */
  uint16_t protocol_id;

} v2x_protocol_t;

/** Default protocol descriptor initializer */
#define V2X_PROTOCOL_INIT {             \
  .frame_type = V2X_FRAME_TYPE_NA,      \
  .protocol_id = 0                      \
}

/** V2X service instance */
typedef atlk_handle_t v2x_service_t;

/** V2X sample subscriber */
typedef struct v2x_sample_subscriber v2x_sample_subscriber_t;

/** Decentralized congestion control table index */
typedef enum  {
  DCC_PRIORITY_TABLE_INDEX_0 = 0,
  DCC_PRIORITY_TABLE_INDEX_1,
  DCC_PRIORITY_TABLE_INDEX_2,
  DCC_PRIORITY_TABLE_INDEX_3,

  DCC_PRIORITY_TABLE_MAX
} dcc_priority_table_index_t;

/** V2X CBR sample */
typedef struct {
  /** CBR value */
  int32_t cbr_value;

  /** Diversity CBR value */
  int32_t cbr_diversity_value;
} v2x_cbr_sample_t;

/**
   V2X socket statistics.

   Counters are per socket, hence implemented Host-side (since protocol
   classification is done at Host).
*/
typedef struct {
  /** Number of frames successfully sent */
  uint64_t frames_sent_successful;

  /** Number of frames which failed to be sent */
  uint64_t frames_sent_failure;

  /** Total number of frames sent */
  uint64_t frames_send_request_total;

  /** Number of frames successfully received from Device */
  uint64_t frames_received_successful;

  /** Number of frames received from Device which were dropped at Host */
  uint64_t frames_received_dropped;

  /** Total number of frames received from Device */
  uint64_t frames_received_total;

} v2x_socket_stats_t;

/** V2X decentralized congestion control TX complete indication */
typedef struct {
  /** Value of TSF when packet was transmitted, MSB */
  uint32_t tsf_msb_usec;

  /** Value of TSF when packet was transmitted, LSB */
  uint32_t tsf_lsb_usec;

  /** Transmit status [0]success, [1]failed */
  uint8_t transmit_status;

  /** packet priority */
  uint8_t packet_priority;

  /** MAC interface index */
  uint8_t if_index;

} v2x_dcc_tx_indication_t;

/** Decentralized congestion control can be used for transmit rate control */
typedef struct {
  /** Value of TSF when packet was transmitted, MSB */
  uint32_t tsf_msb_usec;

  /** Value of TSF when packet was transmitted, LSB */
  uint32_t tsf_lsb_usec;

  /** Transmit status [0]success, [1]failed */
  uint8_t transmit_status;

} v2x_dcc_t;

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_V2X_H */
