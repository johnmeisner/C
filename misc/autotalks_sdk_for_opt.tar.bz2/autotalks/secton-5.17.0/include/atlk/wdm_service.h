/** Copyright (C) 2016 Autotalks Ltd. */
#ifndef _ATLK_WDM_SERVICE_H
#define _ATLK_WDM_SERVICE_H

#include <atlk/sdk.h>
#include <atlk/wdm.h>

#include <common/types.h>
#include <common/edca.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   WLAN Diagnostics and Management service API
*/

/**
   WDM RX callback function

   @param[in] frame_ptr Pointer to the frame
   @param[in] frame_size RX Frame size
   @param[in] frame_info_ptr RX frame info

   @remark The frame includes 802.11 and EPD/LPD headers
*/
typedef void (*wdm_rx_traffic_monitor_t)(const uint8_t *frame_ptr,
                                         size_t frame_size,
                                         wdm_rx_frame_info *frame_info_ptr);

/**
   WDM TX callback function

   @param[in] frame_ptr Pointer to the frame
   @param[in] frame_size TX Frame size
   @param[in] frame_info_ptr TX frame info

   @remark The frame includes 802.11 and EPD/LPD headers
*/
typedef void (*wdm_tx_traffic_monitor_t)(const uint8_t *frame_ptr,
                                         size_t frame_size,
                                         wdm_tx_frame_info *frame_info_ptr);

/**
   Get WDM service instance.

   @param[in] service_name Name of service (NULL for default)
   @param[out] service_pptr WDM service instance

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_service_get(const char *service_name,
                wdm_service_t **service_pptr);

/**
   Set WDM frequency.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] frequency WDM frequency in units of MHz

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_frequency_set(wdm_service_t *service_ptr,
                  if_index_t if_index,
                  uint32_t frequency);

/**
   Get WDM frequency.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[out] frequency_ptr WDM frequency in units of MHz

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_frequency_get(wdm_service_t *service_ptr,
                  if_index_t if_index,
                  uint32_t *frequency_ptr);

/**
   Set WDM Diversity Scheme.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] diversity_scheme WDM Diversity Scheme (PSD/CSD)

   @todo Currently diversity scheme API is not supported. Default scheme is CSD

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_diversity_scheme_set(wdm_service_t *service_ptr,
                         if_index_t if_index,
                         wdm_tx_diversity_scheme_t diversity_scheme);

/**
   Get WDM Diversity Scheme.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[out] diversity_scheme_ptr WDM Diversity Scheme (PSD/CSD)

   @todo Currently diversity scheme API is not supported. Default scheme is CSD

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_diversity_scheme_get(wdm_service_t *service_ptr,
                         if_index_t if_index,
                         wdm_tx_diversity_scheme_t *diversity_scheme_ptr);

/**
   Get WDM DSP version.

   @param[in] service_ptr WDM service instance
   @param[out] dsp_version_ptr WDM DSP version

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_dsp_version_get(wdm_service_t *service_ptr,
                    wdm_dsp_version_t *dsp_version_ptr);

/**
   Get WDM bandwidth.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[out] bandwidth_ptr MAC interface bandwidth

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_bandwidth_get(wdm_service_t *service_ptr,
                  if_index_t if_index,
                  wdm_bandwidth_t *bandwidth_ptr);
/**
   Set WDM Bandwidth.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] bandwidth MAC interface bandwidth

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_bandwidth_set(wdm_service_t *service_ptr,
                  if_index_t if_index,
                  wdm_bandwidth_t bandwidth);

/**
   Get last TSSI detector value

   Last value is cleared upon function call (error ::ATLK_E_NOT_READY is
   returned when new value is not available).

   Retrievable type of TSSI detector value is system-dependent.

   @note: value_type::WDM_TSSI_DETECTOR_VALUE_TYPE_DBM8 is only relevant for compensator UART protocol V1.4 and below

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] value_type TSSI value type to get
   @param[out] value_ptr TSSI detector value

   @retval ::ATLK_OK if succeeded
   @retval ::ATLK_E_NOT_READY if new value is not available
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_tssi_detector_value_get(wdm_service_t *service_ptr,
                            if_index_t if_index,
                            wdm_tssi_detector_value_type_t value_type,
                            int32_t *value_ptr);

/**
   Get WDM TSSI loop enabled value.

   Whether TSSI loop is enabled.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[out] enabled_ptr TSSI enabled value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_tssi_loop_enabled_get(wdm_service_t *service_ptr,
                          if_index_t if_index,
                          int *enabled_ptr);
/**
   Set WDM TSSI loop enabled value.

   Whether TSSI loop is enabled.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] enabled TSSI enabled value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_tssi_loop_enabled_set(wdm_service_t *service_ptr,
                          if_index_t if_index,
                          int enabled);

/**
   Get CBR sample interval.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[out] sample_interval_ms_ptr CBR Sample interval in miiliseconds

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_cbr_sample_interval_get(wdm_service_t *service_ptr,
                            if_index_t if_index,
                            uint32_t *sample_interval_ms_ptr);

/**
   Set CBR sample interval.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] sample_interval_ms CBR Sample interval in miiliseconds

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_cbr_sample_interval_set(wdm_service_t *service_ptr,
                            if_index_t if_index,
                            uint32_t sample_rate_ms);


/**
   Get WDM statistics.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[out] wdm_stats_ptr WDM statistics

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_stats_get(wdm_service_t *service_ptr,
              if_index_t if_index,
              wdm_stats_t *wdm_stats_ptr);

/**
   Set WDM EDCA configuration.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] access_category Access category
   @param[in] edca_config_ptr WDM statistics

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_edca_config_set(wdm_service_t *service_ptr,
                    if_index_t if_index,
                    edca_ac_t access_category,
                    edca_config_t *edca_config_ptr);

/**
   Get WDM EDCA configuration.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] access_category Access category
   @param[out] edca_config_ptr WDM statistics

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_edca_config_get(wdm_service_t *service_ptr,
                    if_index_t if_index,
                    edca_ac_t access_category,
                    edca_config_t *edca_config_ptr);

/**
   Get WLAN MAC address.

   @param[in]  service_ptr WDM service instance
   @param[in]  if_index MAC interface index
   @param[out] mac_address_ptr WLAN MAC address

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_mac_address_get(wdm_service_t *service_ptr,
                    if_index_t if_index,
                    eui48_t *mac_address_ptr);

/**
   Set WLAN MAC address.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] mac_address WLAN MAC address

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_mac_address_set(wdm_service_t *service_ptr,
                    if_index_t if_index,
                    eui48_t mac_address);

/**
   Perform RSSI calibration.

   @param[in] service_ptr WDM service instance
   @param[in] rf_index RF antenna index
   @param[out] result_ptr RSSI calibration result

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_rssi_calibrate(wdm_service_t *service_ptr,
                   rf_index_t rf_index,
                   wdm_rssi_calibration_result_t *result_ptr);

/**
   Start TSSI calibration mode.

   @param[in] service_ptr WDM service instance
   @param[in] rf_index RF antenna index

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_tssi_calibration_mode_start(wdm_service_t *service_ptr,
                                rf_index_t rf_index);

/**
   Start TSSI open-loop calibration mode.

   @param[in] service_ptr  WDM service instance
   @param[in] rf_index     RF antenna index
   @param[in] mode         Open-loop mode (0,1,2,3)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_tssi_openloop_calibration_mode_start(wdm_service_t *service_ptr,
                                         rf_index_t rf_index,
                                         int8_t mode);

/**
   Stop TSSI calibration mode.

   @param[in] service_ptr WDM service instance

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_tssi_calibration_mode_stop(wdm_service_t *service_ptr);

/**
   Attach WDM interface in a given mode

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] mode MAC Mode to be attached in

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_interface_attach(wdm_service_t *service_ptr,
                     if_index_t if_index,
                     wdm_interface_mode_t mode);

/**
   Detach WDM interface

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_interface_detach(wdm_service_t *service_ptr, if_index_t if_index);

/**
   Get WDM interface status

   status_ptr->mode contains:
     1. inteface mode, if interface state == WDM_INTERFACE_STATE_ATTACHED
     2. invalid value, if interface state == WDM_INTERFACE_STATE_DETACHED

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[out] status_ptr MAC interface status

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_interface_status_get(wdm_service_t *service_ptr,
                         if_index_t if_index,
                         wdm_interface_status_t *status_ptr);

/**
   Set WDM diversity mode

   @param[in] service_ptr WDM service instance
   @param[in] mode Diversity mode

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_diversity_set(wdm_service_t *service_ptr,
                  wdm_diversity_mode_t mode);

/**
   Get WDM diversity mode

   @param[in] service_ptr WDM service instance
   @param[out] mode_ptr Diversity mode

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_diversity_get(wdm_service_t *service_ptr,
                  wdm_diversity_mode_t *mode_ptr);

/**
   Set RF test mode

   @note Setting ::WDM_RF_TEST_MODE_CW will cause automatic
     packet transmission
     Setting ::WDM_RF_TEST_MODE_CONTINUOS_OFDM won't cause
     automatic packet transmission

   @param[in] service_ptr WDM service instance
   @param[in] rf_index RF interface index
   @param[in] rf_test_mode_config_ptr Test mode configuration

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_rf_test_mode_set(wdm_service_t *service_ptr,
                     rf_index_t rf_index,
                     const wdm_rf_test_mode_config_t *rf_test_mode_config_ptr);

/**
   Get RF test mode

   @param[in] service_ptr WDM service instance
   @param[in] rf_index RF interface index
   @param[out] rf_test_mode_config_ptr Test mode configuration

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_rf_test_mode_get(wdm_service_t *service_ptr,
                     rf_index_t rf_index,
                     wdm_rf_test_mode_config_t *rf_test_mode_config_ptr);

/**
   Set WLAN TX callback.

   TX callback is called for each MPDU transmitted.

   @remark Callbacks for different interfaces might be called simultaneously.
   Hence, callbacks should be designed to be reentrant.

   @remark When a callback is set to NULL, it clears previously set callback.

   @param[in] if_index WLAN MAC interface
   @param[in] tx_callback TX callback function

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_tx_traffic_monitor_set(if_index_t if_index,
                           wdm_tx_traffic_monitor_t tx_callback);

/**
   Set WLAN RX callback.

   RX callback is called for each MPDU received (even when there are no open
   V2X sockets).

   @remark Callbacks for different interfaces might be called simultaneously.
   Hence, callbacks should be designed to be reentrant.

   @remark When a callback is set to NULL, it clears previously set callback.

   @param[in] if_index WLAN MAC interface
   @param[in] rx_callback RX callback function

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_rx_traffic_monitor_set(if_index_t if_index,
                           wdm_rx_traffic_monitor_t rx_callback);

/**
   Set TX power of control frames.

   @param[in] service_ptr WDM service instance
   @param[in] if_index MAC interface index
   @param[in] value TX power of control frames in dBm

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_ctrl_tx_power_set(wdm_service_t *service_ptr,
                      if_index_t if_index,
                      power_dbm_t power_dbm);

/**
   Get compensator status

   @param[in]  service_ptr    WDM service instance
   @param[in]  rf_index       RF index
   @param[out] status_ptr     Pointer to compensator status struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_compensator_status_get(wdm_service_t *service_ptr,
                           rf_index_t rf_index,
                           wdm_compensator_status_t *status_ptr);

/**
   Get compensator version

   @param[in]  service_ptr    WDM service instance
   @param[in]  rf_index       RF index
   @param[out] version_ptr    Pointer to compensator version struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_compensator_version_get(wdm_service_t *service_ptr,
                            rf_index_t rf_index,
                            wdm_compensator_version_t *version_ptr);

/**
   Get compensator fault code

   Last fault code is cleared upon function call (error ::ATLK_E_NOT_READY is
   returned when new fault code is not available).

   Please refer to 'Phantom Power RF Compensator UART Protocol' manual for
   more information.

   @param[in] service_ptr WDM service instance
   @param[in] rf_index RF index
   @param[out] fault_code_ptr Compensator fault code

   @retval ::ATLK_OK if succeeded
   @retval ::ATLK_E_NOT_READY if new fault code is not available (or compensator is disabled)
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_compensator_fault_code_get(wdm_service_t *service_ptr,
                               rf_index_t rf_index,
                               uint32_t *fault_code_ptr);

/**
   Get compensator statistics

   @param[in]  service_ptr   WDM service instance
   @param[in]  rf_index      RF index
   @param[out] stats_ptr     Pointer to compensator stats struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_compensator_stats_get(wdm_service_t *service_ptr,
                          rf_index_t rf_index,
                          wdm_compensator_stats_t *stats_ptr);

/**
   Get compensator last messages

   @param[in]  service_ptr       WDM service instance
   @param[in]  rf_index          RF index
   @param[out] last_messages_ptr Pointer to compensator last messages array

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_compensator_last_messages_get(wdm_service_t *service_ptr,
                                  rf_index_t rf_index,
                                  wdm_compensator_last_messages_t *last_messages_ptr);

/**
   Trigger compensator calibration data downloading

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_compensator_calibration_download_trigger(wdm_service_t *service_ptr);

/**
   Set generic compensator data silently (without RF transmission)

   @param[in]  service_ptr       WDM service instance
   @param[in]  compensator_data  Array of per-antenns generic compensator data strucures.

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_generic_compensator_data_set(wdm_service_t *service_ptr, const wdm_generic_compensator_data_t *compensator_data_ptr);

/**
   Get PLUTON2 revision ID.

   @note Valid only for PLUTON2.

   @param[in] service_ptr WDM service instance
   @param[out] pluton2_rev_id_ptr PLUTON2 revision ID, length must be at least WDM_PLUTON2_REVISION_ID_LEN

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_pluton2_revision_id_get(wdm_service_t *service_ptr, char *pluton2_rev_id_ptr);

/**
   Get PLUTON2 unique ID.

   @note Valid only for PLUTON2.

   @param[in] service_ptr WDM service instance
   @param[out] pluton2_unique_id_ptr Pointer to 16 byte unique ID

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
wdm_pluton2_unique_id_get(wdm_service_t *service_ptr, uint8_t *pluton2_unique_id_ptr);

/**
   Get RF status.

   @param[in]  service_ptr WDM service instance
   @param[out] status_ptr  Pointer to RF status struct

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
wdm_rf_status_get(wdm_service_t *service_ptr, wdm_rf_status_t *status_ptr);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_WDM_SERVICE_H */
