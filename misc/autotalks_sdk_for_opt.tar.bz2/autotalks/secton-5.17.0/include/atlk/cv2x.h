/**
   @file cv2x.h
   @brief CV2X API structures declarations

   @copyright Copyright (C) 2018-2022 Autotalks Ltd.
*/
#ifndef ATLK_CV2X_H
#define ATLK_CV2X_H

#include <atlk/sdk.h>
#include <common/types.h>
#include "atlk/v2x.h"

#ifdef __cplusplus
extern "C" {
#endif

/** CV2X version major */
#define CV2X_VERSION_MAJOR     3
/** CV2X version minor */
#define CV2X_VERSION_MINOR     9
/** CV2X version revision */
#define CV2X_VERSION_REVISION  0
/** CV2X build number */
#define CV2X_BUILD_NUMBER      0

/** CV2X function out parameter */
#define CV2X_OUT
/** CV2X function in parameter */
#define CV2X_IN
/** CV2X function in and out parameter */
#define CV2X_INOUT

/** max number of carriers */
#define CV2X_CARRIER_POOL_MAX_NUM_CARRIERS 2U
/** Max number of Rx pools (within a carrier) */
#define CV2X_CARRIER_POOL_MAX_NUM_RX_POOLS 4U
/** Max number of Tx pools (within a carrier) */
#define CV2X_CARRIER_POOL_MAX_NUM_TX_POOLS 4U

/** CV2X Priority enum, i.e. PPPP values from 0 to 7 */
typedef enum {
  CV2X_PPPP_0 = 0,
  CV2X_PPPP_1,
  CV2X_PPPP_2,
  CV2X_PPPP_3,
  CV2X_PPPP_4,
  CV2X_PPPP_5,
  CV2X_PPPP_6,
  CV2X_PPPP_7,
  CV2X_INVALID_PPPP /** Invalid priority */
} cv2x_pppp_t;

/** Min priority */
#define CV2X_PPPP_MIN         CV2X_PPPP_0
/** Max priority */
#define CV2X_PPPP_MAX         CV2X_PPPP_7
/** Number of Priorities */
#define CV2X_PPPP_NUM         (uint32_t)CV2X_INVALID_PPPP

/** CV2X priority validation */
#define CV2X_PPPP_IS_VALID(p) (((p) <= CV2X_PPPP_MAX)) // ((p)>=CV2X_PPPP_MIN) &&

/** Invalid source layer 2 ID */
#define CV2X_INVALID_SRC_L2ID 0xFFFFFFFF
/** Broadcast layer 2 ID */
#define CV2X_BROADCAST_L2ID   0xffffffU

/** CV2X Modulation Cosing Scheme (MCS) enum, i.e. MCS values from 0 to 31 */
typedef int8_t cv2x_mcs_t;

/** Min MCS value */
#define CV2X_MCS_MIN         0
/** Max MCS value */
#define CV2X_MCS_MAX         31
/** CV2X MCS validation */
#define CV2X_MCS_IS_VALID(p) (((p) <= CV2X_MCS_MAX) && ((p) >= CV2X_MCS_MIN))
/** Invalid MCS */
#define CV2X_INVALID_MCS     (-1)

/** Default Pool ID */
#define CV2X_DEFAULT_POOL_ID (-1)

/** Hybrid Automatic Repeat Request (HARQ) mode enum */
typedef enum {
  /** HARQ mode ON - HARQ delta determined internally */
  HARQ_MODE_STANDARD = 0,

  /** HARQ mode off */
  HARQ_MODE_OFF,

  /** HARQ mode ON - Use specific HARQ delta */
  HARQ_MODE_FORCED,

  /** HARQ mode is determined according to RRC Pre-Configuration */
  HARQ_MODE_BY_RRC,

  /** Invalid HARQ mode value */
  HARQ_MODE_INVALID,
} harq_mode_t;

/** Maximum transmission power level in dBm */
#define CV2X_MAX_TX_POWER_DBM            26

/** {-128,...,-0.5}dbm in 0.5dbm steps */
#define CV2X_PREFERRED_SIGNAL_POWER_DBM2 40

/** 1/2 dBm to dBm conversion factor */
#define POWER_DBM2_PER_DBM  2

/** 1/8 dBm to 1/2 dBm conversion factor */
#define POWER_DBM8_PER_DBM2 4


/** Minimum Tx power offset value in dBm8 */
#define CV2X_TX_POWER_OFFSET_DBM8_MIN -40

/** Maximum Tx power offset value in dBm8 */
#define CV2X_TX_POWER_OFFSET_DBM8_MAX 40


/** Maximum number of subchannels per frame */
#define MAX_SUBCHANNELS_IN_FRAME  20U

/** CV2X default configuration values */

/** Default shift value, in 30.72 Mbps samples */
#define CV2X_LMAC_TX_CSD_DEFAULT                              0

/** Default number of HARQ re-Tx allowed */
#define CV2X_LMAC_ALLOWED_RETX_NUMBER_PSSCH_DEFAULT           0

/** Default value of 'allow CRC-error packets' flag */
#define CV2X_LMAC_PASS_CRC_FAIL_PACKETS_DEFAULT               0

/** Default value of RX duplication */
#define CV2X_RX_DUPLICATION_DEFAULT                           0U

/** Default value of 'rx_l2id_filtering_mode' flag */
#define RX_L2ID_FILTERING_MODE_DEFAULT                        0

/** Default lmac_measurements_rssi_threshold_for_sci */
#define CV2X_LMAC_MEASUREMENTS_RSSI_THRESHOLD_FOR_SCI_DEFAULT (-96)

/** Default offset in milliseconds to add to RRC offset_dfn in DFN/SFN calculations */
#define CV2X_HACK_OFFSET_DFN_MS_DEFAULT                       0U

/** Default log prints rate limit */
#define LOGGER_RATE_LIMIT_DEFAULT                             5U

/** Default log prints rate limit time threshold in milliseconds */
#define LOGGER_RATE_LIMIT_TIME_THRESHOLD_MS_DEFAULT           1000U

/** Default maximal log_level_t for which to apply logger rate limit */
#define LOGGER_RATE_LIMIT_MAX_LOG_LEVEL_DEFAULT               3U

/**  */
#define CV2X_CUSTOMER_CBR_LOG_GAP_MS_DEFAULT                  1000U

/** Default time Tx message's metadata is kept in milliesec */
#define CV2X_SERVICE_MESSAGE_TX_LEASE_TIME_MS_DEFAULT         200U

/** Default time Tx message's garbage collection operation in milliesec (min interval between collections) */
#define CV2X_MSG_GARBAGE_COLLECTION_MIN_TIME_MS_DEFAULT       10U

/**  */
#define CV2X_RR_PROB_RESOURCE_KEEP_ALWAYS_DEFAULT             0

/** (MACPT) Default CV2X MAC packet processing time, im microseconds */
#define CV2X_RR_MAC_TIME_AHEAD_USEC_DEFAULT                   1000U

/** (RRPT) Default resource reservation processing time, in microseconds */
#define CV2X_RR_MIN_TIME_AHEAD_USEC_DEFAULT                   2000U

/** Default application sps send jitter, in millisecond */
#define CV2X_RR_APP_SPS_SEND_JITTER_MSEC_DEFAULT              1U

/** Default maximum gap allowed for HARQ, in milliesec */
#define CV2X_RR_HARQ_WINDOW_SUBFRAMES_DEFAULT                 15U

/** Default minimum gap allowed between Tx subframes */
#define CV2X_RR_DSP_MIN_SUBFRAMES_DIFF_DEFAULT                1U

/** Missing measurements expected due to Tx in specific subframe */
#define CV2X_RR_MISSING_MEASUREMENTS_DUE_TX_DEFAULT           1

/** One Shot Counter range configuration  */
#define CV2X_RR_MIN_ONE_SHOT_COUNTER_DEFAULT                  2U

#define CV2X_RR_MAX_ONE_SHOT_COUNTER_DEFAULT                  0U

/** Default Single Measurement Processing Time (SMPT) value in msec */
#define CV2X_SMPT_MSEC_DEFAULT                                3U

/** Min SMPT value in msec */
#define CV2X_SMPT_MSEC_MIN                                    1U

/** Max SMPT value in msec */
#define CV2X_SMPT_MSEC_MAX                                    10U

/** The maximum size of the allowed burst of consecutive frames */
#define CV2X_MAX_BURST_SIZE                                   1U

/** (H2DPT) Default host to device packet processing time in microseconds */
#define CV2X_DISPATCHER_TIME_AHEAD_USEC_DEFAULT               5000U

/** Default MCS for policy */
#define CV2X_RR_POLICY_MCS_DEFAULT                            CV2X_INVALID_MCS

/** Default policy direct frame number */
#define CV2X_RR_POLICY_DIRECT_FRAME_NO_DEFAULT                0

/** Default policy subframe number */
#define CV2X_RR_POLICY_SUB_FRAME_NO_DEFAULT                   0

/** Default first subchannel allowed (0 - 20, -1 for N/A) */
#define CV2X_RR_POLICY_START_SUBCHANNEL_DEFAULT               (-1)

/** Default number of subchannels */
#define CV2X_RR_POLICY_NUM_OF_SUBCHANNELS_DEFAULT             0

/** Default maximum drift time allowed before resetting the RR, in milliesec */
#define CV2X_TIME_SYNC_RR_RESET_GAP_MS_DEFAULT                1000U

/** Default MAC internal clock sync interval in milliesec */
#define CV2X_TIME_SYNC_POLLING_INTERVAL_MS_DEFAULT            1000U

/** (PHYPT) Default DSP packet processing time, in microseconds */
#define CV2X_LMAC_TIME_AHEAD_USEC_DEFAULT                     2000U

/** Default enable / disable measurements indication from device to host */
#define CV2X_LMAC_MEASUREMENTS_DEFAULT                        1U

/** Default device logging flags value */
#define CV2X_LMAC_VERBOSE_DEFAULT                             0U

/** Default DSP flags */
#define CV2X_LMAC_FLAGS_DEFAULT                               0x200U

/** Default Rx only mode flag value (0 - Tx enabled, 1 - Tx disabled) */
#define CV2X_RX_ONLY_MODE_DEFAULT                             0

/** Default value for enable / disable Non-IP header (0 - disabled, 1 - enabled) */
#define CV2X_ENABLE_NON_IP_HEADER_DEFAULT                     0U

/** Default diversity mode - Tx and Rx diversity enabled */
#define CV2X_DIVERSITY_MODE_DEFAULT                           3 // WDM_DIVERSITY_MODE_TX_AND_RX

/** Max number of Tx SPS sockets */
#define CV2X_MAX_TX_SPS_SOCKETS_DEFAULT                       2U

/** Max number of Tx sockets */
#define CV2X_MAX_TX_SOCKETS_DEFAULT                           8U

/**
    Max number of RR internal policies. Shall be equal to CV2X_MAX_TX_SOCKETS_DEFAULT.
*/
#define CV2X_RR_MAX_POLICIES_DEFAULT	                        CV2X_MAX_TX_SOCKETS_DEFAULT

/** Continuous time in sync mode to get "enough" measurements, before allowing Tx */
#define CV2X_RR_DEFAULT_MEASUREMENT_THRESHOLD_TIME_USEC       1000000U

/** MCS's-Sizes bitmap is for optimal usage for single tx, from DSP algo perspective*/
#define CV2X_SUBCHANNEL_BITMAP_MCS_SINGLE_DEFAULT {                                                                           \
  0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0x0U,  \
  0x0U,        0xFFFFFU,    0xFFFFFU,    0x3FFFFU,    0xFFFFU,     0x3FFFU,     0x1FFFU,     0xFFFU,      0x0U,        0x0U,  \
  0x0U,        0x0U,        0x0U,        0x0U,        0x0U,        0x0U,        0x0U,        0x0U,        0x0U,        0x0U,  \
  0x0U,        0x0U}

/** MCS's-Sizes bitmap is for optimal usage when using harq, from DSP algo perspective*/
#define CV2X_SUBCHANNEL_BITMAP_MCS_HARQ_DEFAULT {                                                                             \
  0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0xFFFFFFFFU, 0x0U,  \
  0x0U,        0xFFFFFU,    0xFFFFFU,    0x3FFFFU,    0xFFFFU,     0x3FFFU,     0x1FFFU,     0xFFFU,      0x0U,        0x0U,  \
  0x0U,        0x0U,        0x0U,        0x0U,        0x0U,        0x0U,        0x0U,        0x0U,        0x0U,        0x0U,  \
  0x0U,        0x0U}

/** Default Packet Delay Budget (PDB) by priority */
#define CV2X_PDB_BY_PPPP_DEFAULT {100U,     /*0*/ \
                                  100U,     /*1*/ \
                                  100U,     /*2*/ \
                                  100U,     /*3*/ \
                                  100U,     /*4*/ \
                                  100U,     /*5*/ \
                                  100U,     /*6*/ \
                                  100U}     /*7*/

/** Default Tx code index */
#define CV2X_TX_CODEBOOK_IDX_DEFAULT 6U

/** Default Tx code index per Tx pool */
#define CV2X_TX_CODEBOOK_IDX_PER_POOL_DEFAULT {CV2X_TX_CODEBOOK_IDX_DEFAULT, CV2X_TX_CODEBOOK_IDX_DEFAULT, CV2X_TX_CODEBOOK_IDX_DEFAULT, CV2X_TX_CODEBOOK_IDX_DEFAULT}

/** Default Tx code index per Tx pool */
#define CV2X_TX_CODEBOOK_IDX_PER_CARRIER_DEFAULT {CV2X_TX_CODEBOOK_IDX_PER_POOL_DEFAULT, CV2X_TX_CODEBOOK_IDX_PER_POOL_DEFAULT}

/** Default maximum CR future window in milliseconds */
#define CV2X_MAX_CR_FUTURE_SUBFRAMES_DEFAULT 0U

/** Min CV2X processing time, in usec */
#define CV2X_TIME_AHEAD_USEC_MIN 0

/** Max CV2X processing time, in usec */
#define CV2X_TIME_AHEAD_USEC_MAX 10000

/** Min rssi_threshold, in DB */
#define CV2X_LMAC_MEASUREMENT_RSSI_MIN_THRESHOLD -120

/** Max rssi_threshold, in DB */
#define CV2X_LMAC_MEASUREMENT_RSSI_MAX_THRESHOLD -30

/** Default vehicle speed in KPH */
#define CV2X_SPEED_MGR_DEFAULT_SPEED_KPH          0

/** Maximum vehicle speed in KPH */
#define CV2X_SPEED_MGR_MAX_SPEED_KPH              999U

/** CV2X Max processes. A process is defined as the time a message and all its segments and HARQ's are sent.
 *  cv2x_rr_max_policies should be lower than CV2X_MAX_PROCESSES */
#define CV2X_MAX_PROCESSES                        100U

/** Stat dump period */
#define CV2X_STAT_LOG_PERIOD_MS                   10000U

/** Tx power offset in dBm8, {-5 ... +5 dB} in 0.5dB steps. Default value: 0dB. Will be translated into dBm2 for DSP use later on */
#define CV2X_TX_POWER_OFFSET_DBM8_DEFAULT         0

/** Default cyclic-shift score threshold for PSCCH decoding */
#define CV2X_DSP_CS_SCORE_THRESHOLD_DEFAULT       0U

/** Default Rx users selection configuration */
#define CV2X_DSP_RX_USERS_SELECTION_DEFAULT       0

/** Default RX processing time budget adjustment */
#define CV2X_DSP_RX_PROC_TIME_OFFSET_DEFAULT      0

/** Default number of UEs (PSCCH) detected in a SF before we start decoding only PSCCH and skip the PSSCH */
#define CV2X_DSP_NUM_PSCCH_ABOVE_THRESH_DEFAULT   0

/** Default gap from last successful message, that will invoke reselection */
#define CV2X_RESELECT_AFTER_GAP_FROM_LAST_MSG_MSEC   1000U

/** Default number of unused transmit opportunities, that will invoke reselection */
#define CV2X_RR_RESELECT_AFTER_UNUSED_SLOTS_DEFAULT  6U

/** Default number of maximum iterations during the reselection process */
#define CV2X_RR_RESELECTION_MAX_ITERATIONS_DEFAULT  1500U

/** Value to denote promiscuous mode is disabled */
#define RX_PROMISCUOUS_MODE_DEFAULT                  0U

/** Value to denote skipping Sensing Based Algorithm is disabled */
#define CV2X_RR_SKIP_SBA_DEFAULT                     0U

/** Value to denote US SAE profile is disabled */
#define CV2X_MCS_TBS_US_SAE_MODE_DISABLED            0U

/** Default mode (enabled / disabled) for US SAE profile */
#define CV2X_MCS_TBS_US_SAE_MODE_DEFAULT             CV2X_MCS_TBS_US_SAE_MODE_DISABLED

/** Invalid TBS value for US SAE profile */
#define CV2X_US_SAE_INVALID_TBS                      0xFFFFU

/** Default TBS thresholds for SPS transmission below speed threshold for US SAE profile */
#define CV2X_US_SAE_SPS_BELOW_THRESH_TBS_DEFAULT     { 193U, 233U, 277U, 389U, 421U, 597U, 775U, 1063U, 1239U, 1479U, 2124U, \
                                                       CV2X_US_SAE_INVALID_TBS, CV2X_US_SAE_INVALID_TBS,          \
                                                       CV2X_US_SAE_INVALID_TBS, CV2X_US_SAE_INVALID_TBS }

/** Default MCS values per TBS for SPS transmission below speed threshold for US SAE profile */
#define CV2X_US_SAE_SPS_BELOW_THRESH_MCS_DEFAULT     { 5,   6,   7,   11,  7,   11,  11,  11,   6,    7,    11,  \
                                                       CV2X_INVALID_MCS, CV2X_INVALID_MCS, CV2X_INVALID_MCS, CV2X_INVALID_MCS }


/** Default TBS thresholds per TBS for AD-HOC transmission below speed threshold for US SAE profile */
#define CV2X_US_SAE_ADHOC_BELOW_THRESH_TBS_DEFAULT   { 193U, 233U, 277U, 293, 349U, 421U, 597U, 775U, 1063U, 1239U, 1479U, 2124U,  \
                                                       CV2X_US_SAE_INVALID_TBS, CV2X_US_SAE_INVALID_TBS, CV2X_US_SAE_INVALID_TBS }

/** Default MCS values per TBS for AD-HOC transmission below speed threshold for US SAE profile */
#define CV2X_US_SAE_ADHOC_BELOW_THRESH_MCS_DEFAULT   { 5,   6,   7,   5,   6,   7,   11,  11,  11,   6,    7,    11,  \
                                                       CV2X_INVALID_MCS, CV2X_INVALID_MCS, CV2X_INVALID_MCS }

/** Default TBS thresholds for SPS / AD-HOC transmission above speed threshold for US SAE profile */
#define CV2X_US_SAE_ABOVE_THRESH_TBS_DEFAULT         { 193U, 233U, 277U, 293U, 349U, 421U, 469U, 549U, 621U, 749U, 1063U, 1239U, 1479U,  \
                                                       CV2X_US_SAE_INVALID_TBS, CV2X_US_SAE_INVALID_TBS }

/** Default MCS values per TBS for SPS / AD-HOC transmission above speed threshold for US SAE profile */
#define CV2X_US_SAE_ABOVE_THRESH_MCS_DEFAULT         { 5,   6,   7,   5,   6,   7,   6,   7,   6,   7,   5,    6,    7,  \
                                                       CV2X_INVALID_MCS, CV2X_INVALID_MCS }

/** Maximum number of elements in TBS-MCS arrays for US SAE profile */
#define CV2X_US_SAE_TBS_MCS_MAX_NUM_ELEMS            15U
/** Default configuration for US SAE */
#define CV2X_US_SAE_WIN_ADJUSTMENT_ENABLE_DEFAULT    0U
#define CV2X_US_SAE_CBR_THRESHOLD_1_DEFAULT          25U
#define CV2X_US_SAE_T2_1_DEFAULT                     20U
#define CV2X_US_SAE_CBR_THRESHOLD_2_DEFAULT          65U
#define CV2X_US_SAE_T2_2_DEFAULT                     50U
#define CV2X_US_SAE_PDB_REDUCTION_DEFAULT            10U

/** MLT Payload Length Threshold. Segments with the payload less or equal to the
    threshold will use selection window with dispatcher_ahead reduced by
    dispatcher_and_lmac_ahead_reduction_us.
  */
#define CV2X_MLT_PAYLOAD_LEN_THRESHOLD_BYTES_DEFAULT 400U
  /** Dispatcher ahead reduction when the segment payload length is less or equal
      to mlt_payload_len_threshold_bytes.
  */
#define CV2X_DISPATCHER_AHEAD_REDUCTION_USEC_DEFAULT   1000U

/** RR Max burst size, of Tx allocations
*/
#define CV2X_RR_MAX_BURST_SIZE_DEFAULT                 1U

/** MAC interface index */
typedef uint8_t if_index_t;

/** MAC packet type index */
typedef uint8_t packet_type_t;

/**
   CV2X time type.
   Format: number of microseconds since 2004-01-01T00:00:00Z (UTC) in 64 bits.
   i.e. > 512K years
*/
typedef unsigned long long cv2x_time_t;

/** CV2X US SAE configuration parameters */
typedef struct cv2x_mcs_tbs_us_sae_config_st {
  /** TBS thresholds for SPS transmission below speed threshold for US SAE profile */
  uint16_t   mcs_tbs_us_sae_sps_below_thresh_tbs[CV2X_US_SAE_TBS_MCS_MAX_NUM_ELEMS];

  /** MCS values per TBS for SPS transmission below speed threshold for US SAE profile */
  cv2x_mcs_t mcs_tbs_us_sae_sps_below_thresh_mcs[CV2X_US_SAE_TBS_MCS_MAX_NUM_ELEMS];

  /** TBS thresholds for AD-HOC transmission below speed threshold for US SAE profile */
  uint16_t   mcs_tbs_us_sae_adhoc_below_thresh_tbs[CV2X_US_SAE_TBS_MCS_MAX_NUM_ELEMS];

  /** MCS values per TBS for AD-HOC transmission below speed threshold for US SAE profile */
  cv2x_mcs_t mcs_tbs_us_sae_adhoc_below_thresh_mcs[CV2X_US_SAE_TBS_MCS_MAX_NUM_ELEMS];

  /** TBS thresholds for SPS / AD-HOC transmission above speed threshold for US SAE profile */
  uint16_t   mcs_tbs_us_sae_above_thresh_tbs[CV2X_US_SAE_TBS_MCS_MAX_NUM_ELEMS];

  /** MCS values per TBS for SPS / AD-HOC transmission above speed threshold for US SAE profile */
  cv2x_mcs_t mcs_tbs_us_sae_above_thresh_mcs[CV2X_US_SAE_TBS_MCS_MAX_NUM_ELEMS];

} cv2x_mcs_tbs_us_sae_config_t;

/** Default configuration initializer for CV2X TBS-MCS US SAE mode */
#define CV2X_MCS_TBS_US_SAE_CONFIG_INIT {                                                      \
  .mcs_tbs_us_sae_sps_below_thresh_tbs   = CV2X_US_SAE_SPS_BELOW_THRESH_TBS_DEFAULT,   \
  .mcs_tbs_us_sae_sps_below_thresh_mcs   = CV2X_US_SAE_SPS_BELOW_THRESH_MCS_DEFAULT,   \
  .mcs_tbs_us_sae_adhoc_below_thresh_tbs = CV2X_US_SAE_ADHOC_BELOW_THRESH_TBS_DEFAULT, \
  .mcs_tbs_us_sae_adhoc_below_thresh_mcs = CV2X_US_SAE_ADHOC_BELOW_THRESH_MCS_DEFAULT, \
  .mcs_tbs_us_sae_above_thresh_tbs       = CV2X_US_SAE_ABOVE_THRESH_TBS_DEFAULT,       \
  .mcs_tbs_us_sae_above_thresh_mcs       = CV2X_US_SAE_ABOVE_THRESH_MCS_DEFAULT,       \
}

/** CV2X configuration parameters */
typedef struct cv2x_configuration_st {
  /** {0,1,2,3,4} cyclic shift, in samples */
  int32_t                      lmac_tx_csd;

  /** {0,1} default value 0. */
  int32_t                      lmac_pass_crc_fail_packets;

  /** lmac threshold for passing measurements. units - DB. only measurements with higher narrow band rssi shall pass to host */
  int32_t                      lmac_measurements_rssi_threshold_for_sci;

  /** {0 - 10239} Milliseconds to add to RRC offset_dfn when calculating DFN / SFN */
  uint32_t                     cv2x_hack_offset_dfn_ms;

  /** Message lease time in milliesecs */
  uint32_t                     message_tx_lease_time_ms;

  /** CV2X RR configuration */
  int32_t                      cv2x_rr_prob_resource_keep_always;

  /** CV2X MAC packet processing time */
  uint32_t                     cv2x_rr_mac_time_ahead_usec;

  /** Resource reservation processing time */
  uint32_t                     cv2x_rr_min_time_ahead_usec;

  /** Maximum gap (in milliesec) allowed for HARQ. 0 to disable HARQ */
  uint32_t                     cv2x_rr_harq_window_subframes;

  /** The minimum gap allowed between Tx subframes */
  uint32_t                     cv2x_rr_dsp_min_subframes_diff;

  /**  */
  int32_t                      cv2x_rr_missing_measurements_due_tx;

  /** One Shot range configuration */
  uint32_t                     cv2x_rr_min_one_shot_counter;

  uint32_t                     cv2x_rr_max_one_shot_counter;

  /** Single Measurement Processing Time (SMPT) in msec */
  uint32_t                     smpt_msec;

  /** CV2X dispatcher configuration */
  uint32_t                     cv2x_dispatcher_time_ahead_usec;

  /** Maximum drift time allowed before resetting the RR, in milliesec */
  uint32_t                     cv2x_time_sync_rr_reset_gap_ms;

  /** MAC-internal clock sync interval in milliesec */
  uint32_t                     cv2x_time_sync_polling_interval_ms;

  /** DSP packet processing time */
  uint32_t                     cv2x_lmac_time_ahead_usec;

  /** Enable/Disable measurements indication from device to host (0 / 1) */
  uint32_t                     cv2x_lmac_measurements;

  /**
     Device logging flags:
     0x001 - Tx application level
     0x002 - Tx device confirmation
     0x004 - Tx device LMAC
     0x008 - Tx device IRQ
     0x010 - Tx / Rx host status
     0x100 - Rx application level
     0x200 - Rx device reception
     0x400 - Rx device measurement
   */
  uint32_t                     cv2x_lmac_verbose;

  /**
     DSP flags:
     0x040 - Force subframe number zero on Rx
     0x080 - Force subframe number zero on Tx
     0x100 - Tx only mode
     0x200 - Disable RSSI sorting feature
     0x400 - Decode HARQ second frame as well, if first was decoded successfully
     0x800 - Disable High Doppler feature
  */
  uint32_t                     cv2x_lmac_flags;

  /** Disable Tx in MAC layer (1 disable, 0 to enable) */
  int32_t                      cv2x_rx_only_mode;

  /** Enable Non-IP header in case of Non-IP traffic (0 - disabled, non 0 - enabled) */
  uint32_t                     cv2x_enable_non_ip_header;

  /**
     Subchannel bitmap MCS for single transmission (no HARQ).
     Will be used if no value different than 0x0 will be supplied by user via cv2x_sw_config.txt file.
     If even one value is supplied by user, it will be used, and the rest of the values (that were not supplied)
     will be set to 0x0.
  */
  uint32_t                     cv2x_subchannel_bitmap_mcs_single[CV2X_MCS_MAX + 1];

  /**
     Subchannel bitmap MCS for HARQ transmission.
     Will be used if no value different than 0x0 will be supplied by user via cv2x_sw_config.txt file
     for HARQ transmission OR for single transmission.
     If even one value is supplied by user, it will be used, and the rest of the values (that were not supplied)
     will be set to 0x0.
     If no value was supplied by user, but values for cv2x_subchannel_bitmap_mcs_single were supplied, values for
     cv2x_subchannel_bitmap_mcs_single shall be used for cv2x_subchannel_bitmap_mcs_harq as well.
  */
  uint32_t                     cv2x_subchannel_bitmap_mcs_harq[CV2X_MCS_MAX + 1];

  /** WDM diversity mode */
  int32_t                      cv2x_diversity_mode;

  /** Packet Delay Budget (PDB) by priority */
  uint32_t                     cv2x_pdb_by_pppp_array[(unsigned)CV2X_PPPP_MAX + 1U];

  /**  */
  uint32_t                     max_cr_future_subframes;

  /** Logs related configuration */
  uint32_t                     cv2x_customer_cbr_log_gap_ms;

  /**
     Rx L2ID filtering mode:
        0 - unfiltered (default), all L2IDs are forwarded to the application layer
        1 - filtered, only device's own source L2ID and broadcast L2ID are forwarded
  */
  int32_t                      rx_l2id_filtering_mode;

  /** CV2X max allowed Tx sockets */
  uint32_t                     cv2x_max_tx_sockets;

  /** CV2X max allowed SPS Tx sockets */
  uint32_t                     cv2x_max_tx_sps_sockets;

  /** RR max allowed policies */
  uint32_t                     cv2x_rr_max_policies;

  /** RR minimum measurements required before operation */
  uint32_t                     cv2x_rr_measurements_threshold_time_usec;

  /** Codebook index according to precoding matrix. {0,1,2,3,4,5,6,7}. 6, 7 are combinations of the 0-5. per carrier per pool */
  uint8_t                      cv2x_tx_codebook_idx_per_carrier_per_pool[CV2X_CARRIER_POOL_MAX_NUM_CARRIERS][CV2X_CARRIER_POOL_MAX_NUM_TX_POOLS];

  /** log statistics dump period */
  uint32_t                     log_stats_period_ms;

  /** Tx power offset in dBm8, {-5 ... +5 dB} in 0.5dB steps. Default value: 0dB. Will be translated into dBm2 for DSP use later on. */
  int8_t                       tx_power_offset_dbm8;

  /**
     Limit log prints to avoid log flooding.
     0 - disable.
     Any other positive number - number of past prints (records) to keep for rate limiting.
     Default - 2 records
  */
  uint16_t                     logger_rate_limit;

  /**
     Logger rate limit time threshold in milliseconds. Max threshold between last print and current time.
     0 - disable.
     Default value is 1,000 ms (1 second).
  */
  uint32_t                     logger_rate_limit_time_threshold_ms;

  /**
     Maximal log_level_t for which to apply logger rate limit.
     3 - LOG_LEVEL_ERROR
     4 - LOG_LEVEL_WARNING
     6 - LOG_LEVEL_INFO
     Default value is 3 (LOG_LEVEL_ERROR)
  */
  uint8_t                      logger_rate_limit_max_log_level;

  /**
     Cyclic-shift score threshold for PSCCH decoding.
     Default is 0 which means the DSP which will set its own default value
  */
  uint32_t                     cv2x_dsp_cs_score_threshold;

  /**
     Rx users selection configuration:
     Bits [0:7]   - ID of the V2I pool (the other is V2V): 0 - Not initialized; 1 - Pool-0; 2 - Pool-1
     Bits [8:15]  - V2I score factor (for prioritizing V2I over V2V)
     Bits [16:23] - RV2-combine score factor (for prioritizing HARQ copy)
     Bits [24:31] - Dense mode threshold (number of users before we start to operate in "dense mode")
     Default is 0 which means the DSP which will set its own default value
  */
  uint32_t                     cv2x_dsp_rx_users_selection_config;

  /**
     Adjustment to RX processing time budget.
     Default is 0 which means the DSP which will set its own default value
  */
  int32_t                      cv2x_dsp_rx_proc_time_offset;

  /**
     If we detect more UEs (PSCCH) in a SF than this threshold, we will decode only PSCCH and skip the PSSCH decoding.
     Default is 0 which means the DSP which will set its own default value
  */
  uint32_t                     cv2x_dsp_num_of_pscch_above_threshold;

  /**
     In sps, exceeding this gap from last successful message, will invoke reselection.
  */
  uint32_t                     cv2x_reselect_after_gap_from_last_msg_msec;

  /**
     In sps, exceeding this number of unused reservations, will invoke reselection.
     This value will be used by RR when reselect_after_r14 is not configured in RRC.
  */
  uint32_t                     cv2x_reselect_after_unused_slots;

  uint32_t                     rx_duplication_pps;

  /** Is MCS-TBS tables for US SAE profile enabled (0 - disabled, 1 - enabled) */
  uint32_t                     cv2x_mcs_tbs_us_sae_mode;

  /** US SAE TBS-MCS configuration */
  cv2x_mcs_tbs_us_sae_config_t cv2x_mcs_tbs_us_sae_config;
  /**
     US SAE Profile Allocation Window adjustment configuration.
     When operating in US SAE mode, the system shall set the resource selection window ([n+T1, n+T2]) as follows:

    T1 <= 4
    T2 = cv2x_us_sae_t2_1 if CBR <= cv2x_us_sae_cbr_threshold_1
    T2 = min(PDB-10, cv2x_us_sae_t2_2) if cv2x_us_sae_cbr_threshold_1 < CBR < cv2x_us_sae_cbr_threshold_2
    T2 = PDB - cv2x_us_sae_pdb_reduction if CBR >= cv2x_us_sae_cbr_threshold_2
  */
  uint32_t              cv2x_us_sae_win_adjustment_enable;
  uint32_t              cv2x_us_sae_cbr_threshold_1;
  uint32_t              cv2x_us_sae_t2_1;
  uint32_t              cv2x_us_sae_cbr_threshold_2;
  uint32_t              cv2x_us_sae_t2_2;
  uint32_t              cv2x_us_sae_pdb_reduction;

  /** Application SPS send jitter, in milliseconds */
  uint32_t              cv2x_rr_sps_send_jitter_msec;

  /** Maximum number of opperations(loops) during the reselection. */
  uint32_t              cv2x_rr_reselection_max_iterations;

  /**
     MLT Payload Length Threshold. Segments with the payload less or equal to the
     threshold will use selection window with dispatcher_ahead reduced by
     dispatcher_and_lmac_ahead_reduction_us.
   */
  uint32_t              cv2x_mlt_payload_len_threshold_bytes;
  /**
     Dispatcher ahead reduction when the segment payload length is less or equal
     to mlt_payload_len_threshold_bytes.
  */
  uint32_t              cv2x_dispatcher_ahead_reduction_usec;

  /**
     Flag to indicate if Rx promiscuous mode is enabled or not.
     When enabled - validity check of PDCP Rx header's fields (SN, PGK and PTK) is disabled.
     0 - Mode disabled, validity checks active (default)
     1 - Mode enabled, validy checked not active
  */
  uint8_t               rx_promiscuous_mode;

  /** Skip Sensing Based Algorithm and allocate the first available slot.
  */
  uint32_t              cv2x_rr_skip_sba;

  /** RR Max burst size, of Tx allocations
  */
  uint32_t              cv2x_rr_max_burst_size;

  /** Message garbage collection minimum timeout in milliesecs */
  uint32_t              msg_garbage_collector_min_time_ms;

} cv2x_configuration_t;

/** Default CV2X configuration initializer */
#define CV2X_CONFIGURATION_INIT {                                                                       \
  .lmac_tx_csd                                  = CV2X_LMAC_TX_CSD_DEFAULT,                             \
  .lmac_pass_crc_fail_packets                   = CV2X_LMAC_PASS_CRC_FAIL_PACKETS_DEFAULT,              \
  .lmac_measurements_rssi_threshold_for_sci     = CV2X_LMAC_MEASUREMENTS_RSSI_THRESHOLD_FOR_SCI_DEFAULT,\
  .cv2x_hack_offset_dfn_ms                      = CV2X_HACK_OFFSET_DFN_MS_DEFAULT,                      \
  .message_tx_lease_time_ms                     = CV2X_SERVICE_MESSAGE_TX_LEASE_TIME_MS_DEFAULT,        \
  .cv2x_rr_mac_time_ahead_usec                  = CV2X_RR_MAC_TIME_AHEAD_USEC_DEFAULT,                  \
  .cv2x_rr_min_time_ahead_usec                  = CV2X_RR_MIN_TIME_AHEAD_USEC_DEFAULT,                  \
  .cv2x_rr_sps_send_jitter_msec                 = CV2X_RR_APP_SPS_SEND_JITTER_MSEC_DEFAULT,             \
  .cv2x_rr_harq_window_subframes                = CV2X_RR_HARQ_WINDOW_SUBFRAMES_DEFAULT,                \
  .cv2x_rr_dsp_min_subframes_diff               = CV2X_RR_DSP_MIN_SUBFRAMES_DIFF_DEFAULT,               \
  .cv2x_rr_missing_measurements_due_tx          = CV2X_RR_MISSING_MEASUREMENTS_DUE_TX_DEFAULT,          \
  .cv2x_dispatcher_time_ahead_usec              = CV2X_DISPATCHER_TIME_AHEAD_USEC_DEFAULT,              \
  .cv2x_time_sync_rr_reset_gap_ms               = CV2X_TIME_SYNC_RR_RESET_GAP_MS_DEFAULT,               \
  .cv2x_time_sync_polling_interval_ms           = CV2X_TIME_SYNC_POLLING_INTERVAL_MS_DEFAULT,           \
  .cv2x_lmac_time_ahead_usec                    = CV2X_LMAC_TIME_AHEAD_USEC_DEFAULT,                    \
  .cv2x_lmac_measurements                       = CV2X_LMAC_MEASUREMENTS_DEFAULT,                       \
  .cv2x_lmac_verbose                            = CV2X_LMAC_VERBOSE_DEFAULT,                            \
  .cv2x_lmac_flags                              = CV2X_LMAC_FLAGS_DEFAULT,                              \
  .cv2x_rx_only_mode                            = CV2X_RX_ONLY_MODE_DEFAULT,                            \
  .cv2x_enable_non_ip_header                    = CV2X_ENABLE_NON_IP_HEADER_DEFAULT,                    \
  .cv2x_diversity_mode                          = CV2X_DIVERSITY_MODE_DEFAULT,                          \
  .cv2x_subchannel_bitmap_mcs_single            = CV2X_SUBCHANNEL_BITMAP_MCS_SINGLE_DEFAULT,            \
  .cv2x_subchannel_bitmap_mcs_harq              = CV2X_SUBCHANNEL_BITMAP_MCS_HARQ_DEFAULT,              \
  .cv2x_pdb_by_pppp_array                       = CV2X_PDB_BY_PPPP_DEFAULT,                             \
  .max_cr_future_subframes                      = CV2X_MAX_CR_FUTURE_SUBFRAMES_DEFAULT,                 \
  .cv2x_customer_cbr_log_gap_ms                 = CV2X_CUSTOMER_CBR_LOG_GAP_MS_DEFAULT,                 \
  .rx_l2id_filtering_mode                       = RX_L2ID_FILTERING_MODE_DEFAULT,                       \
  .cv2x_max_tx_sockets                          = CV2X_MAX_TX_SOCKETS_DEFAULT,                          \
  .cv2x_max_tx_sps_sockets                      = CV2X_MAX_TX_SPS_SOCKETS_DEFAULT,                      \
  .cv2x_rr_max_policies                         = CV2X_RR_MAX_POLICIES_DEFAULT,                         \
  .cv2x_rr_measurements_threshold_time_usec     = CV2X_RR_DEFAULT_MEASUREMENT_THRESHOLD_TIME_USEC,      \
  .cv2x_tx_codebook_idx_per_carrier_per_pool    = CV2X_TX_CODEBOOK_IDX_PER_CARRIER_DEFAULT,             \
  .log_stats_period_ms                          = CV2X_STAT_LOG_PERIOD_MS,                              \
  .tx_power_offset_dbm8                         = CV2X_TX_POWER_OFFSET_DBM8_DEFAULT,                    \
  .logger_rate_limit                            = LOGGER_RATE_LIMIT_DEFAULT,                            \
  .logger_rate_limit_time_threshold_ms          = LOGGER_RATE_LIMIT_TIME_THRESHOLD_MS_DEFAULT,          \
  .logger_rate_limit_max_log_level              = LOGGER_RATE_LIMIT_MAX_LOG_LEVEL_DEFAULT,              \
  .cv2x_reselect_after_gap_from_last_msg_msec   = CV2X_RESELECT_AFTER_GAP_FROM_LAST_MSG_MSEC,           \
  .cv2x_reselect_after_unused_slots             = CV2X_RR_RESELECT_AFTER_UNUSED_SLOTS_DEFAULT,          \
  .rx_duplication_pps                           = CV2X_RX_DUPLICATION_DEFAULT,                          \
  .cv2x_mcs_tbs_us_sae_mode                     = CV2X_MCS_TBS_US_SAE_MODE_DEFAULT,                     \
  .cv2x_mcs_tbs_us_sae_config                   = CV2X_MCS_TBS_US_SAE_CONFIG_INIT,                      \
  .cv2x_rr_min_one_shot_counter                 = CV2X_RR_MIN_ONE_SHOT_COUNTER_DEFAULT,                 \
  .cv2x_rr_max_one_shot_counter                 = CV2X_RR_MAX_ONE_SHOT_COUNTER_DEFAULT,                 \
  .smpt_msec                                    = CV2X_SMPT_MSEC_DEFAULT,                               \
  .cv2x_us_sae_win_adjustment_enable            = CV2X_US_SAE_WIN_ADJUSTMENT_ENABLE_DEFAULT,            \
  .cv2x_us_sae_cbr_threshold_1                  = CV2X_US_SAE_CBR_THRESHOLD_1_DEFAULT,                  \
  .cv2x_us_sae_t2_1                             = CV2X_US_SAE_T2_1_DEFAULT,                             \
  .cv2x_us_sae_cbr_threshold_2                  = CV2X_US_SAE_CBR_THRESHOLD_2_DEFAULT,                  \
  .cv2x_us_sae_t2_2                             = CV2X_US_SAE_T2_2_DEFAULT,                             \
  .cv2x_us_sae_pdb_reduction                    = CV2X_US_SAE_PDB_REDUCTION_DEFAULT,                    \
  .cv2x_rr_reselection_max_iterations           = CV2X_RR_RESELECTION_MAX_ITERATIONS_DEFAULT,           \
  .cv2x_mlt_payload_len_threshold_bytes         = CV2X_MLT_PAYLOAD_LEN_THRESHOLD_BYTES_DEFAULT,         \
  .cv2x_dispatcher_ahead_reduction_usec         = CV2X_DISPATCHER_AHEAD_REDUCTION_USEC_DEFAULT,         \
  .rx_promiscuous_mode                          = RX_PROMISCUOUS_MODE_DEFAULT,                          \
  .cv2x_rr_skip_sba                             = CV2X_RR_SKIP_SBA_DEFAULT,                             \
  .cv2x_rr_max_burst_size                       = CV2X_RR_MAX_BURST_SIZE_DEFAULT,                       \
  .msg_garbage_collector_min_time_ms            = CV2X_MSG_GARBAGE_COLLECTION_MIN_TIME_MS_DEFAULT,      \
}

/** CV2X send parameters */
typedef struct cv2x_send_params_st {
  /** Message ID */
  uint32_t      message_id;

  /** Source layer 2 ID */
  uint32_t      src_l2id;

  /** Destination layer 2 ID */
  uint32_t      dst_l2id;

  /** Message generation time by application */
  cv2x_time_t   generation_time;

  /** Transmission power level in units of 1/8 dBm Per Antenna */
  power_dbm8_t  power_dbm8[ATLK_INTERFACES_MAX];

  /** Compensator data per antenna.  */
  compensator_data_t comp_data[RF_INDEX_MAX];
} cv2x_send_params_t;

/** CV2X send parameters default initializer */
#define CV2X_SEND_PARAMS_INIT {                                                      \
  .message_id       = 0,                                                             \
  .src_l2id         = CV2X_INVALID_SRC_L2ID,                                         \
  .dst_l2id         = CV2X_BROADCAST_L2ID,                                           \
  .generation_time  = 0,                                                             \
  .power_dbm8       = { CV2X_PREFERRED_SIGNAL_POWER_DBM2 * POWER_DBM8_PER_DBM / 2,   \
                        CV2X_PREFERRED_SIGNAL_POWER_DBM2 * POWER_DBM8_PER_DBM / 2 }, \
  .comp_data        = { [0 ... RF_INDEX_MAX - 1] = COMPENSATOR_DATA_INIT},           \
}

/** CV2X send parameters */
typedef struct cv2x_adhoc_send_params_st {
  /** Message ID */
  uint32_t      message_id;

  /** Message generation time by application */
  cv2x_time_t   generation_time;

  /** Source layer 2 ID */
  uint32_t      src_l2id;

  /** Destination layer 2 ID */
  uint32_t      dst_l2id;

  /** Transmission power level in units of 1/8 dBm Per Antenna */
  power_dbm8_t  power_dbm8[ATLK_INTERFACES_MAX];

  /** Compensator data per antenna.  */
  compensator_data_t comp_data[RF_INDEX_MAX];
} cv2x_adhoc_send_params_t;

/** CV2X send parameters default initializer */
#define CV2X_ADHOC_SEND_PARAMS_INIT {                                                \
  .message_id       = 0,                                                             \
  .src_l2id         = CV2X_INVALID_SRC_L2ID,                                         \
  .dst_l2id         = CV2X_BROADCAST_L2ID,                                           \
  .generation_time  = 0,                                                             \
  .power_dbm8       = { CV2X_PREFERRED_SIGNAL_POWER_DBM2 * POWER_DBM8_PER_DBM / 2,   \
                        CV2X_PREFERRED_SIGNAL_POWER_DBM2 * POWER_DBM8_PER_DBM / 2 }, \
  .comp_data        = { [0 ... RF_INDEX_MAX - 1] = COMPENSATOR_DATA_INIT},           \
}

/** CV2X service instance obscure data type */
typedef struct cv2x_service_st cv2x_service_t;

/** CV2X socket obscure type */
typedef struct cv2x_socket_st cv2x_socket_t;


/** CV2X socket types enum */
typedef enum {
  /** No type */
  CV2X_SOCKET_TYPE_NONE = 0,

  /** Socket to transmit semi persistent messages */
  CV2X_SOCKET_TYPE_SEMI_PERSISTENT_TX,

  /** Socket to transmit ad hoc messages */
  CV2X_SOCKET_TYPE_AD_HOC_TX,

  /** Socket to receive messages */
  CV2X_SOCKET_TYPE_RX,

} cv2x_socket_type_t;

/** Maximum allowed value */
#define CV2X_SOCKET_TYPE_MAX CV2X_SOCKET_TYPE_RX


/** CV2X socket traffic type */
typedef enum {
  /** Not initialized */
  CV2X_SOCKET_TRAFFIC_NONE = 0,

  /** IP Traffic */
  CV2X_SOCKET_TRAFFIC_IP,

  /** NON-IP Traffic */
  CV2X_SOCKET_TRAFFIC_NON_IP,

} cv2x_socket_traffic_t;

/** Maximum allowed value */
#define CV2X_SOCKET_TRAFFIC_MAX CV2X_SOCKET_TRAFFIC_NON_IP

/** CV2X socket V2X family ID */
typedef enum {
  /** Not initialized */
  CV2X_SOCKET_V2X_FAMILY_ID_NONE = 0,

  /** IEEE_1609 */
  CV2X_SOCKET_V2X_FAMILY_ID_IEEE_1609,

  /** ISO */
  CV2X_SOCKET_V2X_FAMILY_ID_ISO,

  /** ETSI_ITS */
  CV2X_SOCKET_V2X_FAMILY_ID_ETSI_ITS,

} cv2x_socket_v2x_family_id_t;

/** Maximum allowed value */
#define CV2X_SOCKET_V2X_FAMILY_ID_MAX CV2X_SOCKET_V2X_FAMILY_ID_ETSI_ITS

/** CV2X socket user information */
typedef struct {
  /** Socket type */
  cv2x_socket_type_t          socket_type;

  /** Socket traffic type */
  cv2x_socket_traffic_t       traffic_type;

  /** V2X family ID - relevant only for traffic_type of NON_IP  */
  cv2x_socket_v2x_family_id_t v2x_family_id;

  /** Language Code Identifier (LCID) - relevant only for Tx socket */
  uint8_t                     lcid;
} cv2x_socket_user_info_t;

/**
   CV2X socket statistics.
   Counters are per socket
*/
typedef struct cv2x_socket_stats_st {
  /** Number of messages for tx */
  uint32_t    messages_count;

  /** Number of messages successfully sent */
  uint32_t    messages_sent_success;

  /** Number of messages which failed to be sent after reaching MAC Layer */
  uint32_t    messages_sent_failures;

  /** Number of messages which were dropped before reaching MAC Layer */
  uint32_t    messages_dropped;

  /** Number of skipped transmission slots due to missing tx message */
  uint32_t    skipped_resources;
} cv2x_socket_stats_t;

/** Default socket statistics initializer */
#define CV2X_SOCKETS_STATS_INIT {     \
  .messages_count               = 0U, \
  .messages_sent_success        = 0U, \
  .messages_sent_failures       = 0U, \
  .messages_dropped             = 0U, \
  .skipped_resources            = 0U, \
}

typedef struct {
  /** L2 */
  uint32_t l2_messages_received_successfully;
  uint32_t l2_messages_dropped_crc_errors;
  uint32_t l2_messages_dropped_queue_full;
  uint32_t l2_messages_dropped_exceeding_max_rx_size;
  uint32_t l2_messages_received_per_mcs[CV2X_MCS_MAX + 1];

  /** RLC */
  uint32_t rlc_messages_reassembled_successfully;
  uint32_t rlc_messages_reassembly_timed_out;
  uint32_t rlc_messages_duplicated;

  /** PDCP */
  uint32_t pdcp_messages_received_successfully;
  uint32_t pdcp_messages_dropped_parsing_error;

  /** SVC */
  uint32_t svc_messages_received_successfully;
  uint32_t svc_messages_dropped;

  /** MAC */
  uint32_t mac_messages_received_successfully;
  uint32_t mac_messages_dropped_invalid_destination_l2id;
  uint32_t mac_messages_dropped_queue_full;
  uint32_t mac_messages_dropped_invalid_struct;
  uint32_t mac_messages_dropped_invalid_version;
  uint32_t mac_messages_pending;
  uint32_t mac_messages_concatenated; // (PDUs which contain multiple SDUs)
} cv2x_rx_stats_t;

/** Default Rx socket statistics initializer */
#define CV2X_RX_SOCKET_STATS_INIT {                     \
  .l2_messages_received_successfully             = 0,   \
  .l2_messages_dropped_crc_errors                = 0,   \
  .l2_messages_dropped_queue_full                = 0,   \
  .l2_messages_dropped_exceeding_max_rx_size     = 0,   \
  .l2_messages_received_per_mcs                  = {0}, \
  .rlc_messages_reassembled_successfully         = 0,   \
  .rlc_messages_reassembly_timed_out             = 0,   \
  .rlc_messages_duplicated                       = 0,   \
  .pdcp_messages_received_successfully           = 0,   \
  .pdcp_messages_dropped_parsing_error           = 0,   \
  .svc_messages_received_successfully            = 0,   \
  .svc_messages_dropped                          = 0,   \
  .mac_messages_received_successfully            = 0,   \
  .mac_messages_dropped_invalid_destination_l2id = 0,   \
  .mac_messages_dropped_queue_full               = 0,   \
  .mac_messages_dropped_invalid_struct           = 0,   \
  .mac_messages_dropped_invalid_version          = 0,   \
  .mac_messages_pending                          = 0,   \
  .mac_messages_concatenated                     = 0,   \
}

/** CV2X socket configuration */
typedef struct cv2x_socket_config_st {
  /** Socket traffic type: IP / NON_IP */
  cv2x_socket_traffic_t       traffic_type;

  /** Family ID: IEEE_1609 / ISO / ETSI_ITS [Relevant only for traffic_type of NON_IP] */
  cv2x_socket_v2x_family_id_t v2x_family_id;
} cv2x_socket_config_t;

/** CV2X socket configuration default initializer */
#define CV2X_SOCKET_CONFIG_INIT {                       \
  .traffic_type  = CV2X_SOCKET_TRAFFIC_NON_IP,          \
  .v2x_family_id = CV2X_SOCKET_V2X_FAMILY_ID_IEEE_1609, \
}

/** CV2X policy / socket settings */
typedef struct cv2x_socket_policy_st {
  /** Policy message priority, i.e PPPP */
  cv2x_pppp_t priority;

  /** Policy message size (in bytes) */
  uint32_t    size;

  /** Policy control interval in millisec */
  uint32_t    control_interval_ms;
} cv2x_socket_policy_t;

/** Policy descriptor initializer.
    Params: c = control interval,
            p = PPPP,
            s = size
*/
#define CV2X_SOCKET_POLICY_ST(c, p, s) {  \
  .control_interval_ms  = (c),            \
  .priority             = (p),            \
  .size                 = (s),            \
}

/** Default policy descriptor initializer */
#define CV2X_SOCKET_POLICY_INIT CV2X_SOCKET_POLICY_ST(0, CV2X_PPPP_0, 0)

/** CV2X receive parameters */
typedef struct cv2x_receive_params_st {
  /** Receive time */
  cv2x_time_t                 receive_time;

  /** Measured total received power at antenna port. */
  power_dbm8_t                rssi[ATLK_INTERFACES_MAX];

  /** Priority */
  cv2x_pppp_t                 pppp;

  /** Source Layer-2 ID field, Identity of the source == ProSe UE ID */
  uint32_t                    l2id_src;

  /** Destination Layer-2 ID field, Identity of the source == ProSe UE ID */
  uint32_t                    l2id_dst;

  /** V2X family ID - relevant only for traffic_type of NON_IP */
  cv2x_socket_v2x_family_id_t v2x_family_id;

} cv2x_receive_params_t;

/** CV2X receive parameters default initializer */
#define CV2X_RECEIVE_PARAMS_INIT {                \
  .receive_time  = 0ULL,                          \
  .rssi[0]       = POWER_DBM8_NA,                 \
  .rssi[1]       = POWER_DBM8_NA,                 \
  .pppp          = CV2X_PPPP_0,                   \
  .l2id_src      = 0,                             \
  .l2id_dst      = 0,                             \
  .v2x_family_id = CV2X_SOCKET_V2X_FAMILY_ID_NONE \
}

/** Average RSSI factor */
#define CV2X_AVG_RSSI_FACTOR 1

/** CV2X channel statistics. */
typedef struct cv2x_channel_stats_st {
  /** Min RSSI value. units: measured RSSI over subchannel. {-128,...,-0.5}dbm in 0.5dbm steps. */
  uint8_t  min_rssi;

  /** Max RSSI value. units: measured RSSI over subchannel. {-128,...,-0.5}dbm in 0.5dbm steps. */
  uint8_t  max_rssi;

  /**
     Average value of RSSI. units: measured RSSI over subchannel.
     {-128,...,-0.5}dbm in 0.5dbm steps * CV2X_AVG_RSSI_FACTOR (for better accuracy).
  */
  uint16_t avg_rssi;

  /** Number RSSI values measured */
  uint32_t count_rssi;
} cv2x_channel_stats_t;

/** CV2X service statistics. */
typedef struct cv2x_service_stats_st {
  /** Number of Rx sockets successfully opened in total */
  uint32_t               total_rx_sockets;

  /** Number of SPS sockets successfully opened in total */
  uint32_t               total_sps_tx_sockets;

  /** Number of adhoc sockets successfully opened in total */
  uint32_t               total_adhoc_tx_sockets;

  /** Number of SPS sockets currently successfully opened */
  uint32_t               currently_opened_sps_tx_sockets;

  /** Number of adhoc sockets currently successfully opened */
  uint32_t               currently_opened_adhoc_tx_sockets;

  /** Number of Rx sockets currently successfully opened */
  uint32_t               currently_opened_rx_sockets;

  /** Tx sockets messages stats */
  cv2x_socket_stats_t    tx_sockets_stats;

  /** Number of subchannels per Rx pool */
  uint32_t               num_of_subchannels_per_pool[CV2X_CARRIER_POOL_MAX_NUM_RX_POOLS];

  /** Channel RSSI stats */
  cv2x_channel_stats_t   channel_stats[CV2X_CARRIER_POOL_MAX_NUM_RX_POOLS][MAX_SUBCHANNELS_IN_FRAME];
} cv2x_service_stats_t;

/** Default service statistics initializer */
#define CV2X_SERVICE_STATS_INIT {                                 \
  .total_rx_sockets                   = 0U,                       \
  .total_sps_tx_sockets               = 0U,                       \
  .total_adhoc_tx_sockets             = 0U,                       \
  .currently_opened_sps_tx_sockets    = 0U,                       \
  .currently_opened_adhoc_tx_sockets  = 0U,                       \
  .currently_opened_rx_sockets        = 0U,                       \
  .tx_sockets_stats                   = CV2X_SOCKETS_STATS_INIT,  \
}

/** Message status enum */
typedef enum {
  /** No message state */
  CV2X_MESSAGE_STATUS_NONE = 0,

  /** Message in processing in QUEUE */
  CV2X_MESSAGE_STATUS_PENDING,

  /** Message in processing in PDC Layer */
  CV2X_MESSAGE_STATUS_SENT,

  /** Message failed to be sent */
  CV2X_MESSAGE_STATUS_FAILED,

  /** Message expired and not sent */
  CV2X_MESSAGE_STATUS_EXPIRED,

  /** Message dropped due to passing of CR (Channel occupancy Ratio) limitation */
  CV2X_MESSAGE_STATUS_DROPPED_CR_LIMIT,

  /** Max enum value */
  CV2X_MESSAGE_STATUS_MAX,
} cv2x_message_status_enum_t;

/** CV2X message status */
typedef struct cv2x_message_status_st {
  /** Message ID, as specified in send params */
  uint32_t                   message_id;

  /**
     Index of this message from total messages sent, 1..total.
     index == 0 means, overall status of message
  */
  uint32_t                   index;

  /**
     Total number of message fragments & copies.
     This number may not be final depending on when it is requested.
     It is final when index == 0 and status >= CV2X_MESSAGE_STATUS_SENT
  */
  uint32_t                   total;

  /**
     Index number of this segment 1..(total/num of copies),
     when index == 0, contains total number of fragments
  */
  uint32_t                   segment_index;

  /**
     Index number of this copy (HARQ), 1..num_of_copies
     when index == 0, contains total number of copies
  */
  uint32_t                   copy_num;

  /**
     Message state.
     Status may change according to message progress
  */
  cv2x_message_status_enum_t status;

  /**
     Message state change time stamp.
     Time changes every time its status updates
  */
  cv2x_time_t                time_stamp;

  /** Generation time as specified in send params, or sent time in adhoc messages */
  cv2x_time_t                generation_time;

  /** RSRP value of message[index] per Antenna, if index == 0 average value of the RSRP */
  power_dbm8_t               RSRP_dbm8[ATLK_INTERFACES_MAX];

  /** The number of RB's used for Tx */
  uint32_t                   transmited_rbs;

  /**  MCS of the message */
  cv2x_mcs_t                 mcs;
} cv2x_message_status_t;


#ifdef __cplusplus
}
#endif

#endif /* ATLK_CV2X_H */
