/** Copyright (C) 2018 Autotalks Ltd. */
#ifndef _ATLK_V2X_DOT4_H
#define _ATLK_V2X_DOT4_H

#include <common/types.h>
#include <common/edca.h>

#include <atlk/v2x.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   V2X 1609.4 MAC extenstion API

   Current supported 1609.4 modes are:
   -# Alternate mode between two channels
   -# Continuous mode when only a single channel is active

   @note
   -# *Immediate Access is not implemented yet*
   -# *Slot 'either' is not implemented yet*
*/

/** Indefinite access */
#define V2X_DOT4_IMMEDIATE_ACCESS 255

/** Number of 1609.4 time slots */
#define V2X_DOT4_TIME_SLOT_NUM    2U

/**
   Operating class

   @see IEEE Std 802.11-2012, Annex E.

   @remark Operating class numbers intentionally don't follow the standard.
*/
typedef enum {
  /** No operating class selected */
  V2X_OP_CLASS_NA = 0,

  /** United States ITS 5 GHz, 10 MHz channel spacing */
  V2X_OP_CLASS_US_ITS_5GHZ_SPACING_10MHZ,

  /** United States ITS 5 GHz, 20 MHz channel spacing */
  V2X_OP_CLASS_US_ITS_5GHZ_SPACING_20MHZ,

  /** Europe ITS 5 GHz, 10 MHz channel spacing */
  V2X_OP_CLASS_EUROPE_ITS_5GHZ_SPACING_10MHZ,

  /** Europe ITS 5 GHz, 20 MHz channel spacing */
  V2X_OP_CLASS_EUROPE_ITS_5GHZ_SPACING_20MHZ

} v2x_op_class_t;

/** V2X radio channel number */
typedef uint8_t v2x_channel_num_t;

/** Value indicating that radio channel number is N/A */
#define V2X_CHANNEL_NUM_NA 0

/** A set of time slot */
typedef enum {
  /** No time slot selected */
  V2X_TIME_SLOT_NA = 0,

  /** Time slot #0 */
  V2X_TIME_SLOT_0,

  /** Time slot #1 */
  V2X_TIME_SLOT_1,

} v2x_time_slot_t;

#define V2X_CHANNEL_ID_INIT {        \
 .op_class = V2X_OP_CLASS_NA,        \
 .channel_num = V2X_CHANNEL_NUM_NA,  \
 .time_slot = V2X_TIME_SLOT_NA,      \
}

/** 1609.4 Current state */
typedef enum {
  /** 1609.4 is disabled */
  V2X_DOT4_STATE_DISABLE,

  /** 1609.4 is in continues state */
  V2X_DOT4_STATE_CONTINUOUS,

  /** 1609.4 is in immediate state */
  V2X_DOT4_STATE_IMMEDIATE,

  /** 1609.4 is in alternate state */
  V2X_DOT4_STATE_ALTERNATE,

} v2x_dot4_state_t;

/** 1609.4 Channel configuration */
typedef struct {
  /** Operating class */
  v2x_op_class_t op_class;

  /** Radio channel number */
  v2x_channel_num_t channel_num;

} v2x_dot4_channel_config_t;

/** 1609.4 Status */
typedef struct {
  /** 1609.4 state */
  v2x_dot4_state_t state;

  /** 1609.4 channel configuration per time slot */
  v2x_dot4_channel_config_t channel_config[V2X_DOT4_TIME_SLOT_NUM];

} v2x_dot4_status_t;

/** V2X radio channel identifier */
typedef struct {
  /** Operating class */
  v2x_op_class_t op_class;

  /** Radio channel number */
  v2x_channel_num_t channel_num;

  /** Time slot */
  v2x_time_slot_t time_slot;

} v2x_channel_id_t;

/** IEEE Std 1609.4-2016 service primitive MLMEX-CHSTART.request parameters */
typedef struct {
  /** V2X physical interface index on which access to channel is requested */
  if_index_t if_index;

  /** Radio channel identifier to be made available for communications */
  v2x_channel_id_t channel_id;

  /**
     Number of sync intervals to immediately remain on the selected channel
     before starting channel switching schedule.

     The value 0 means "immediate access not requested".
     The value 255 means "indefinite access".
  */
  uint8_t immediate_access;

  /** EDCA configuration set */
  edca_config_t edca_config[EDCA_AC_COUNT];

} v2x_dot4_channel_start_request_t;

#define V2X_DOT4_CHANNEL_START_REQUEST_INIT { \
  .if_index = IF_INDEX_NA,                    \
  .channel_id = V2X_CHANNEL_ID_INIT,          \
  .immediate_access = 0,                      \
  .edca_config = { WDM_EDCA_CONFIG_INIT,      \
                   WDM_EDCA_CONFIG_INIT,      \
                   WDM_EDCA_CONFIG_INIT,      \
                   WDM_EDCA_CONFIG_INIT},     \
}

/** IEEE Std 1609.4-2016 service primitive MLMEX-CHEND.request parameters */
typedef struct {
  /** V2X physical interface index on which access is no longer required */
  if_index_t if_index;

  /** Radio channel identifier for which access is no longer required */
  v2x_channel_id_t channel_id;

} v2x_dot4_channel_end_request_t;

#define V2X_DOT4_CHANNEL_END_REQUEST_INIT { \
  .if_index = IF_INDEX_NA,          \
  .channel_id = V2X_CHANNEL_ID_INIT,    \
}
/** Reason for ending access to an IEEE Std 1609.4-2016 channel */
typedef enum {
  /** Unspecified reason */
  V2X_DOT4_CHANNEL_END_REASON_UNSPECIFIED = 0,

  /** Loss of time synchronization */
  V2X_DOT4_CHANNEL_END_REASON_LOSS_OF_SYNC,

} v2x_dot4_channel_end_reason_t;

/** IEEE Std 1609.4-2016 service primitive MLMEX-CHEND.indication parameters */
typedef struct {
  /** V2X physical interface index on which access to channel was provided */
  if_index_t if_index;

  /** Radio channel identifier for which access is no longer provided */
  v2x_channel_id_t channel_id;

  /** Reason code */
  v2x_dot4_channel_end_reason_t reason;

} v2x_dot4_channel_end_indication_t;

/**
   Network interface V2X access profile.

   @see IEEE Std 1609.4-2016 MLMEX-REGISTERTXPROFILE.request and
   MLMEX-DELETETXPROFILE.request.
*/
typedef struct {
  /**
     V2X physical interface index to attach to.

     If equal to ::IF_INDEX_NA then the network interface is
     detached from any V2X physical interface it was attached to previously.
  */
  if_index_t if_index;

  /**
     Radio channel identifier to use.

     If @p channel_id.op_class is equal to ::V2X_OP_CLASS_NA, then the
     network interface will use not just one specific channel, but
     any channel accessed by the V2X physical interface.
  */
  v2x_channel_id_t channel_id;

  /** Transmission data rate for outgoing packets */
  datarate_t datarate;

  /** Transmission power level for outgoing packets */
  power_dbm8_t power_dbm8;

} v2x_netif_profile_t;


/** IEEE Std 802.11 service primitive MLME-SET.request switching parameters */
typedef struct {
  /** Time-slot 0 duration in msec */
  uint8_t ts0_duration_msec;

  /** Time-slot 1 duration in msec */
  uint8_t ts1_duration_msec;

  /** Sync tolerance time in msec */
  uint8_t sync_tolerance_msec;

  /** Maximum channel switch time in msec */
  uint8_t max_channel_switch_time_msec;

} v2x_dot4_switching_config_t;

/** Network interface V2X access profile default initializer. */
#define V2X_NETIF_PROFILE_INIT {         \
  .if_index = IF_INDEX_NA,           \
  .channel_id = V2X_CHANNEL_ID_NA,       \
  .datarate = DATARATE_NA,               \
  .power_dbm8 = POWER_DBM_NA             \
}

/**
   Send IEEE Std 1609.4-2016 service primitive MLMEX-CHSTART.request and
   receive MLMEX-CHSTART.confirm.

   @param[in] service_ptr V2X service instance
   @param[in] request_ptr DOT4 request parameters

   @retval ::ATLK_OK if succeeded
   @retval ::ATLK_E_INVALID_ARG if service_ptr or request_ptr are NULL
   @return Error code if failed

   @note In order to override the current channel configuration, user should
   invoke <B>`v2x_dot4_channel_end`</B> followed by
   <B>`v2x_dot4_channel_start`</B> again.
   Calling <B>`v2x_dot4_channel_start`</B> twice will result with an error.

*/
atlk_rc_t atlk_must_check
v2x_dot4_channel_start(v2x_service_t *service_ptr,
                       const v2x_dot4_channel_start_request_t *request_ptr);

/**
   Send IEEE Std 1609.4-2016 service primitive MLMEX-CHEND.request and receive
   MLMEX-CHEND.confirm.

   @param[in] service_ptr V2X service instance
   @param[in] request_ptr DOT4 request parameters

   @retval ::ATLK_OK if succeeded
   @retval ::ATLK_E_INVALID_ARG if service_ptr or request_ptr are NULL
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_dot4_channel_end(v2x_service_t *service_ptr,
                     const v2x_dot4_channel_end_request_t *request_ptr);

/**
   Receive IEEE Std 1609.4-2016 service primitive MLMEX-CHEND.indication.

   @param[in] service_ptr V2X service instance
   @param[out] indication_ptr Indicates DOT4 channel end and reason
   @param[in] wait_ptr Wait specification (optional)

   @retval ::ATLK_OK if succeeded
   @retval ::ATLK_E_INVALID_ARG if service_ptr or indication_ptr are NULL
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_dot4_channel_end_receive(v2x_service_t *service_ptr,
                             v2x_dot4_channel_end_indication_t *indication_ptr,
                             const atlk_wait_t *wait_ptr);

/**
   V2X dot4 statistics.

   Counters are per slot.
*/
typedef struct {
  /** Number of frames successfully transmitted */
  uint32_t frames_sent_successful;

  /** Number of frames successfully received at Device from DSP */
  uint32_t frames_received_successful;

  /** Number of frames dropped due to full DSP egress queue */
  uint32_t frames_dropped_queue_full;

  /**
      Number of frames dropped due to CRC error (FCS checksum fail).

      Note: Count can be larger than actual frames dropped due to CRC errors
      (due to false packet detect events). This is normal expected behavior.
  */
  uint32_t frames_received_crc_error;

  /* Number of frames dropped due to being received during time-slot switching */
  uint32_t frames_received_dropped_switching;

} v2x_dot4_stats_t;

/**
   Get 1609.4 V2X statistics

   @param[in] service_ptr V2X service instance
   @param[in] if_index MAC interface index
   @param[in] time_slot Time slot
   @param[out] stats_ptr V2X 1609.4 statistics structure

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_dot4_stats_get(v2x_service_t *service_ptr,
                   if_index_t if_index,
                   v2x_time_slot_t time_slot,
                   v2x_dot4_stats_t *stats_ptr);

/**
   Send IEEE Std 802.11 service primitive MLME-SET.request and receive
   MLME-SET.confirm, configuring the switching capability for IEEE Std 1609.4-2016

   @param[in] service_ptr V2X service instance
   @param[in] if_index MAC interface index
   @param[in] switching_config_ptr Pointer to 1609.4 switching config struct

   @retval ::ATLK_OK if succeeded
   @retval ::ATLK_E_INVALID_ARG if service_ptr or request_ptr are NULL
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_dot4_switching_config_set(v2x_service_t *service_ptr,
                              if_index_t if_index,
                              const v2x_dot4_switching_config_t *switching_config_ptr);

/**
   Send IEEE Std 802.11 service primitive MLME-GET.request and receive
   MLME-GET.confirm, retreiving the switching capability of IEEE Std 1609.4-2016

   @param[in] service_ptr V2X service instance
   @param[in] if_index MAC interface index
   @param[out] switching_config_ptr Pointer to 1609.4 switching config struct

   @retval ::ATLK_OK if succeeded
   @retval ::ATLK_E_INVALID_ARG if service_ptr or request_ptr are NULL
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_dot4_switching_config_get(v2x_service_t *service_ptr,
                              if_index_t if_index,
                              v2x_dot4_switching_config_t *switching_config_ptr);

/**
   Get 1609.4 current status

   @param[in] service_ptr V2X service instance
   @param[in] if_index MAC interface index
   @param[in] status_ptr pointer to V2X 1609.4 status structure

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
v2x_dot4_status_get(v2x_service_t *service_ptr,
                    if_index_t if_index,
                    v2x_dot4_status_t *status_ptr);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_V2X_DOT4_H */
