/** Copyright (C) 2018 Autotalks Ltd. */
#ifndef _ATLK_EHSM_SERVICE_H
#define _ATLK_EHSM_SERVICE_H

#include <atlk/sdk.h>
#include <atlk/ecc.h>
#include <atlk/hash.h>
#include <atlk/ehsm.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   Embedded HSM service API
*/

#define EHSM_OTP_WORDS_IN_BLOCK 8U

/**
   Get pointer to default Embedded HSM service.

   @param[in] service_name Name of service (NULL for default)
   @param[out] service_pptr Pointer to Embedded HSM service

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_service_get(const char *service_name,
                 ehsm_service_t **service_pptr);

/* Embedded HSM API Functions */

/* V2X API */

/**
   Generate ECC key pair.

   @remark @p private_key_info_ptr::key_type must be equal to one of
   ::EHSM_PRIVATE_KEY_TYPE_ISOLATED, ::EHSM_PRIVATE_KEY_TYPE_CSR_MEMBER,
   ::EHSM_PRIVATE_KEY_TYPE_CSR_SIGNER or ::EHSM_PRIVATE_KEY_TYPE_MA_INPUT.

   @remark If @p private_key_info_ptr::key_type is equal to
   ::EHSM_PRIVATE_KEY_TYPE_CSR_SIGNER then @p private_key_info_ptr::key_curve must
   be at least a 256-bit elliptic curve (e.g. NIST P-256) and
   @p private_key_info_ptr::key_algorithm must be equal to
   ::EHSM_PUBLIC_KEY_ALGORITHM_ECDSA.

   @remark @p blob_ptr must be at least ::EHSM_ECC_BLOB_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] private_key_info_ptr Key information
   @param[out] blob_ptr Private key blob
   @param[out] public_key_ptr Public key that matches the private key

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_ecc_key_pair_generate(ehsm_service_t *service_ptr,
                           const ehsm_ecc_private_key_info_t *private_key_info_ptr,
                           void *blob_ptr,
                           ecc_point_t *public_key_ptr);

/**
   Import ECC key pair.

   @remark @p private_key_info_ptr::key_type must be equal to
   ::EHSM_PRIVATE_KEY_TYPE_ISOLATED.

   @remark @p blob_ptr must be at least ::EHSM_ECC_BLOB_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] private_key_info_ptr Key information
   @param[in] private_key_ptr Private key value
   @param[out] blob_ptr Private key blob
   @param[out] public_key_ptr Public key that matches the private key

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_ecc_key_pair_import(ehsm_service_t *service_ptr,
                         const ehsm_ecc_private_key_info_t *private_key_info_ptr,
                         const ecc_scalar_t *private_key_ptr,
                         void *blob_ptr,
                         ecc_point_t *public_key_ptr);

/**
   Get private key information.

   @remark @p blob_ptr must be at least ::EHSM_ECC_BLOB_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Private key blob
   @param[out] private_key_info_ptr Key information

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_ecc_private_key_info_get(ehsm_service_t *service_ptr,
                              const void *blob_ptr,
                              ehsm_ecc_private_key_info_t *private_key_info_ptr);
/**
   Generate ECDSA signature from a given hash digest.

   @remark When implementing standard ECDSA variants:
   @remark if you use elliptic curve P-256 then @p digest_ptr should be computed using SHA-256
   @remark if you use P-384 then @p digest_ptr should be computed using SHA-384
   @remark if you use SM2 then @p digest_ptr should be computed using SHA-SM3 (::hash_sm3_compute_z and ::hash_sm3_compute_e)

   @remark ::ehsm_private_key_type_t of the key @p blob_ptr must be
   equal to one of ::EHSM_PRIVATE_KEY_TYPE_CSR_MEMBER,
   ::EHSM_PRIVATE_KEY_TYPE_MA_OUTPUT, or ::EHSM_PRIVATE_KEY_TYPE_ISOLATED.

   @remark ::ehsm_public_key_algorithm_t of the key @p blob_ptr must be
   equal to ::EHSM_PUBLIC_KEY_ALGORITHM_ECDSA.

   @remark @p blob_ptr must be at least ::EHSM_ECC_BLOB_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Private key blob
   @param[in] digest_ptr To-be-signed hash digest
   @param[out] signature_ptr ECDSA fast verification signature

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_ecdsa_sign(ehsm_service_t *service_ptr,
                const void *blob_ptr,
                const hash_digest_t *digest_ptr,
                ecc_fast_verification_signature_t *signature_ptr);

/**
   Derive ECIES key from a private key and peer public key.

   The ::ehsm_private_key_type_t of the key at @p blob_ptr must be
   equal to one of ::EHSM_PRIVATE_KEY_TYPE_CSR_MEMBER,
   ::EHSM_PRIVATE_KEY_TYPE_MA_OUTPUT, or ::EHSM_PRIVATE_KEY_TYPE_ISOLATED.

   The ::ehsm_public_key_algorithm_t of the key at @p blob_ptr must be
   equal to ::EHSM_PUBLIC_KEY_ALGORITHM_ECIES.

   @p kdf_param_ptr is an optional octet string used as a key derivation parameter.
   In order for the key derivation parameter to be the empty string,
   @p kdf_param_size must be 0.
   The key derivation parameter can be used to prevent misbinding attacks.
   Please refer to IEEE Std 1363a-2004 clause 11.3.2 where the key derivation
   parameter is denoted by P1.

   @remark @p blob_ptr must be at least EHSM_ECC_BLOB_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Private key blob
   @param[in] peer_public_key_ptr Public key of ECIES peer
   @param[in] kdf_param_ptr Key derivation parameter (optional)
   @param[in] kdf_param_size Key derivation parameter size in bytes
   @param[out] key_ptr Derived ECIES key
   @param[in] key_size ECIES key size in bytes

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_ecies_key_derive(ehsm_service_t *service_ptr,
                     const void *blob_ptr,
                     const ecc_point_t *peer_public_key_ptr,
                     const void *kdf_param_ptr,
                     size_t kdf_param_size,
                     void *key_ptr,
                     size_t key_size);

/**
   Encrypt with ECIES.

   @remark Overlapping input and output buffers would result in undefined behavior.
   @remark @p tag_size for SM2 must be 32 bytes (fixed).

   @remark shared_secret_size is the sum of the encryption key size and of the
           authentication key size. The encryption key size is the ciphertext_size
           and the authentication key size has to be between half of the chosen curve
           size and 128 bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] private_key_info_ptr Key information
   @param[in] peer_public_key_ptr Public key of ECIES peer
   @param[in] kdf_param_ptr Key derivation parameter (optional)
   @param[in] kdf_param_size Key derivation parameter size in bytes
   @param[in] shared_secret_size Shared secret size
   @param[in] plaintext_ptr Plaintext to encrypt
   @param[in] plaintext_size Size of the plaintext in bytes
   @param[out] ephemeral_public_key_ptr Temporal Public key
   @param[out] ciphertext_ptr Ciphertext
   @param[out] tag_ptr Message authentication tag
   @param[in] tag_size Size of authentication tag in bytes

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_ecies_encrypt(ehsm_service_t *service_ptr,
                   const ehsm_ecc_private_key_info_t *private_key_info_ptr,
                   const ecc_point_t *peer_public_key_ptr,
                   const void *kdf_param_ptr,
                   size_t kdf_param_size,
                   uint32_t shared_secret_size,
                   const void *plaintext_ptr,
                   size_t plaintext_size,
                   ecc_point_t *ephemeral_public_key_ptr,
                   void *ciphertext_ptr,
                   void *tag_ptr,
                   size_t tag_size);

/**
   Decrypt with ECIES.

   @remark Overlapping input and output buffers would result in undefined behavior.

   @remark @p tag_ptr for SM2 must be 32 bytes (fixed).

   @remark shared_secret_size is the addition of the encryption key size and of the
           authentication key size. The encryption key size is the ciphertext_size
           and the authentication key size has to be between half of the chosen curve
           size and 128 bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Private key blob
   @param[in] ephemeral_public_key_ptr Temporal Public key
   @param[in] kdf_param_ptr Key derivation parameter (optional)
   @param[in] kdf_param_size Key derivation parameter size in bytes
   @param[in] shared_secret_size Shared secret size
   @param[in] ciphertext_ptr Ciphertext
   @param[in] ciphertext_size Size of the ciphertext in bytes
   @param[in] tag_ptr Message authentication tag
   @param[in] tag_size Size of authentication tag in bytes
   @param[out] plaintext_ptr Plaintext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_ecies_decrypt(ehsm_service_t *service_ptr,
                   const void *blob_ptr,
                   const ecc_point_t *ephemeral_public_key_ptr,
                   const void *kdf_param_ptr,
                   size_t kdf_param_size,
                   uint32_t shared_secret_size,
                   const void *ciphertext_ptr,
                   size_t ciphertext_size,
                   const void *tag_ptr,
                   size_t tag_size,
                   void *plaintext_ptr);

/**
   Perform a modular multiply-add on stored private key and store the result.

   Does the following operation: k' := b + (a * k) mod n

   Where:
   * k is value at @p input_blob_ptr
   * k' is value at @p output_blob_ptr
   * b is @p key_addend_ptr
   * a is @p key_multiplier_ptr
   * n is order of the elliptic curve group that is specified by
     ::ecc_curve_t of the key at @p input_blob_ptr

   The ::ehsm_private_key_type_t of the key at @p input_blob_ptr must be
   ::EHSM_PRIVATE_KEY_TYPE_MA_INPUT.

   The newly created key at @p output_blob_ptr will have the same
   ::ecc_curve_t and ::ehsm_public_key_algorithm_t as the key at
   @p input_blob_ptr but will have ::ehsm_private_key_type_t equal to
   ::EHSM_PRIVATE_KEY_TYPE_MA_OUTPUT.

   This operation can be used to implement PKI schemes such as SCMS.

   @remark @p key_addend_ptr is not allowed to be zero modulo the elliptic
   curve order (n) since allowing it will provide a method for importing
   private keys with ::ehsm_private_key_type_t other than
   ::EHSM_PRIVATE_KEY_TYPE_ISOLATED.

   @remark @p input_blob_ptr is not allowed to be equal to @p output_blob_ptr
   due to the idempotency requirement; i.e. invoking a procedure once and
   invoking the same procedure twice or more with the same inputs (without any
   other intervening procedure invocations) should be indistinguishable
   to the user.

   @remark @p input_blob_ptr and @p output_blob_ptr must be at
   least ::EHSM_ECC_BLOB_SIZE bytes each.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] input_blob_ptr Private key blob
   @param[in] key_addend_ptr Scalar to add
   @param[in] key_multiplier_ptr Scalar to multiply
   @param[out] output_blob_ptr Private key blob
   @param[out] public_key_ptr Public key

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_ecc_private_key_multiply_add(ehsm_service_t *service_ptr,
                                  const void *input_blob_ptr,
                                  const ecc_scalar_t *key_addend_ptr,
                                  const ecc_scalar_t *key_multiplier_ptr,
                                  void *output_blob_ptr,
                                  ecc_point_t *public_key_ptr);

/**
   Derive ECC public key from blob.

   @remark @p blob_ptr must be at least ::EHSM_ECC_BLOB_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Private key blob
   @param[out] public_key_ptr Derived public key

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_ecc_public_key_derive(ehsm_service_t *service_ptr,
                           const void *blob_ptr,
                           ecc_point_t *public_key_ptr);

/** RNG API */

/**
   Generate random data.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] prediction_resistance Prediction resistance
              flag as specified in NIST SP 800-90A.
   @param[out] data_ptr Random bytes output buffer
   @param[in] data_size Random bytes requested size

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_rng_generate(ehsm_service_t *service_ptr,
                  uint32_t prediction_resistance,
                  void *data_ptr,
                  size_t data_size);

/** Diagnostics API */

/**
   Get Embedded HSM information.

   @param[in] service_ptr Embedded HSM service instance
   @param[out] info_ptr Embedded HSM information

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_info_get(ehsm_service_t *service_ptr,
              ehsm_info_t *info_ptr);

/** OTP API */

/**
   Changes OTP block mode from redundancy to ECC.

   ECC here means Error Correction Code.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] block_index Index of requested block

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_otp_block_ecc_enable(ehsm_service_t *service_ptr,
                          uint32_t block_index);

/**
   Read OTP word type.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] word_index Index of requested word
   @param[out] word_type_ptr Word type

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_otp_word_type_get(ehsm_service_t *service_ptr,
                       uint32_t word_index,
                       ehsm_otp_word_type_t *word_type_ptr);

/**
   Read OTP word.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] word_index Index of requested word
   @param[out] word_value_ptr Word value

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_otp_word_read(ehsm_service_t *service_ptr,
                   uint32_t word_index,
                   uint32_t *word_value_ptr);

/**
   Write OTP word.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] word_index Index of requested word
   @param[in] word_value Word value

   @remark If the block containing the word is configured with
   redundancy (default), then the 16 most significant word bits are ignored
   and used for redundancy.

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_otp_word_write(ehsm_service_t *service_ptr,
                    uint32_t word_index,
                    uint32_t word_value);

/**
   Lock OTP word.

   When the word is locked, it is no longer writable.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] word_index Index of requested word

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_otp_word_lock(ehsm_service_t *service_ptr,
                   uint32_t word_index);

/** Storage API */

/**
   Generate message authentication tag using AES-128.

   @remark @p tag_ptr must be at least EHSM_STORAGE_TAG_SIZE bytes.

   @param[in] service_ptr Embedded HSM Service instance
   @param[in] data_ptr Message to compute MAC
   @param[in] data_size Message size in bytes
   @param[out] tag_ptr Message authentication tag

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_aes128_mac_generate(ehsm_service_t *service_ptr,
                         const void *data_ptr,
                         size_t data_size,
                         void *tag_ptr);

/**
   Verify a previously generated AES-128 message authentication tag.

   @remark @p tag_ptr must be at least EHSM_STORAGE_TAG_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] data_ptr Message to compute MAC
   @param[in] data_size Message size in bytes
   @param[in] tag_ptr Message authentication tag

   @retval ::ATLK_OK if succeeded
   @return Error code if mismatch or failed
*/
atlk_rc_t atlk_must_check
ehsm_aes128_mac_verify(ehsm_service_t *service_ptr,
                       const void *data_ptr,
                       size_t data_size,
                       const void *tag_ptr);

/**
   Encrypt and authenticate data with AES-128.

   Intended use case is to provide confidentiality for data (e.g. pseudonym
   certificates) to be stored on a non-secure host NVM.

   It is allowed that @p plaintext_size be equal to @p ciphertext_ptr in order to
   encrypt data in-place. Any other overlapping input and output buffers
   would result in undefined behavior.

   @remark @p tag_ptr must be at least EHSM_STORAGE_TAG_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] plaintext_ptr Plaintext to encrypt
   @param[in] plaintext_size Size of the plaintext in bytes
   @param[out] ciphertext_ptr Ciphertext
   @param[out] tag_ptr Message authentication tag

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_aes128_encrypt(ehsm_service_t *service_ptr,
                    const void *plaintext_ptr,
                    size_t plaintext_size,
                    void *ciphertext_ptr,
                    void *tag_ptr);

/**
   Authenticate and decrypt data with AES-128.

   Intended use case is to provide confidentiality for data (e.g. pseudonym
   certificates) that is stored on a non-secure host NVM.

   It is allowed that @p ciphertext_ptr be equal to @p plaintext_ptr in order to
   decrypt data in-place. Any other overlapping input and output buffers
   would result in undefined behavior.

   @remark @p tag_ptr must be at least EHSM_STORAGE_TAG_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] ciphertext_ptr Ciphertext to decrypt
   @param[in] ciphertext_size Size of the ciphertext in bytes
   @param[in] tag_ptr Message authentication tag
   @param[out] plaintext_ptr Plaintext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_aes128_decrypt(ehsm_service_t *service_ptr,
                    const void *ciphertext_ptr,
                    size_t ciphertext_size,
                    const void *tag_ptr,
                    void *plaintext_ptr);

/**
   Generate message authentication tag using AES-256.

   @param[in] service_ptr Embedded HSM Service instance
   @param[in] data_ptr Message to compute MAC
   @param[in] data_size Message size in bytes
   @param[out] tag_ptr Message authentication tag

   @remark @p tag_ptr must be at least EHSM_STORAGE_TAG_SIZE bytes.

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_aes256_mac_generate(ehsm_service_t *service_ptr,
                         const void *data_ptr,
                         size_t data_size,
                         void *tag_ptr);

/**
   Verify a previously generated AES-256 message authentication tag.

   @param[in] service_ptr Embedded HSM Service instance
   @param[in] data_ptr Message to compute MAC
   @param[in] data_size Message size in bytes
   @param[in] tag_ptr Message authentication tag

   @remark @p tag_ptr must be at least EHSM_STORAGE_TAG_SIZE bytes.

   @retval ::ATLK_OK if succeeded
   @return Error code if mismatch or failed
*/
atlk_rc_t atlk_must_check
ehsm_aes256_mac_verify(ehsm_service_t *service_ptr,
                       const void *data_ptr,
                       size_t data_size,
                       const void *tag_ptr);

/**
   Encrypt and authenticate data with AES-256.

   Intended use case is to provide confidentiality for data (e.g. pseudonym
   certificates) to be stored on a non-secure host NVM.

   It is allowed that @p plaintext_size be equal to @p ciphertext_ptr in order to
   encrypt data in-place. Any other overlapping input and output buffers
   would result in undefined behavior.

   @remark @p tag_ptr must be at least EHSM_STORAGE_TAG_SIZE bytes.

   @param[in] service_ptr Embedded HSM Service instance
   @param[in] plaintext_ptr Plaintext to encrypt
   @param[in] plaintext_size Size of the plaintext in bytes
   @param[out] ciphertext_ptr Ciphertext
   @param[out] tag_ptr Message authentication tag

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_aes256_encrypt(ehsm_service_t *service_ptr,
                    const void *plaintext_ptr,
                    size_t plaintext_size,
                    void *ciphertext_ptr,
                    void *tag_ptr);

/**
   Authenticate and decrypt data with AES-256.

   Intended use case is to provide confidentiality for data (e.g. pseudonym
   certificates) that is stored on a non-secure host NVM.

   It is allowed that @p ciphertext_ptr be equal to @p plaintext_ptr in order to
   decrypt data in-place. Any other overlapping input and output buffers
   would result in undefined behavior.

   @remark @p tag_ptr must be at least EHSM_STORAGE_TAG_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] ciphertext_ptr Ciphertext to decrypt
   @param[in] ciphertext_size Size of the ciphertext in bytes
   @param[in] tag_ptr Message authentication tag
   @param[out] plaintext_ptr Plaintext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_aes256_decrypt(ehsm_service_t *service_ptr,
                    const void *ciphertext_ptr,
                    size_t ciphertext_size,
                    const void *tag_ptr,
                    void *plaintext_ptr);

/**
   Exchange key with SM2

   Intended use case is to get agreement on a secret key through alternate communications.

   @remark @p z_value_a_ptr must be equal to 32 bytes.
   @remark @p z_value_b_ptr must be equal to 32 bytes.
   @remark @p s1_a_ptr must be equal to 32 bytes.
   @remark @p s_a_ptr must be equal to 32 bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] role Sender or Receiver role
   @param[in] blob_a_ptr Sender's or receiver's private key
   @param[in] public_key_b_ptr Receiver's or sender's public key
   @param[in] temp_blob_a_ptr Sender's or receiver's temporary private key
   @param[in] temp_public_key_a_ptr Sender's or receiver's temporary public key
   @param[in] temp_public_key_b_ptr Receiver's or sender's temporary public key
   @param[in] z_value_a_ptr: Sender's or receiver's Z value
   @param[in] z_value_b_ptr Receiver's or sender's Z value
   @param[in] key_size Size of Key in bytes
   @param[out] key_ptr Key
   @param[out] s1_a_ptr Sender's S1 or receiver's SB
   @param[out] s_a_ptr: Sender's SA or receiver's S2

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_sm2_exchange_key(ehsm_service_t *service_ptr,
                      ehsm_exchange_role_t role,
                      const void *blob_a_ptr,
                      const ecc_point_t *public_key_b_ptr,
                      const void *temp_blob_a_ptr,
                      const ecc_point_t *temp_public_key_a_ptr,
                      const ecc_point_t *temp_public_key_b_ptr,
                      const void *z_value_a_ptr,
                      const void *z_value_b_ptr,
                      uint32_t key_size,
                      void *key_ptr,
                      void *s1_a_ptr,
                      void *s_a_ptr);

/**
   Generate Symmetric key.

   @remark @p blob_ptr must be at least EHSM_SYMMETRIC_BLOB_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] symmetric_key_info_ptr Symmetric key information
   @param[out] blob_ptr Symmetric key blob

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_symmetric_key_generate(ehsm_service_t *service_ptr,
                            const ehsm_symmetric_key_info_t *symmetric_key_info_ptr,
                            void *blob_ptr);

/**
   Import Symmetric key.

   @remark @p blob_ptr must be at least EHSM_SYMMETRIC_BLOB_SIZE bytes.

   @param[in] service_ptr Embedded HSM service instance
   @param[in] symmetric_key_info_ptr Symmetric key information
   @param[in] symmetric_key_ptr Symmetric key value
   @param[in] symmetric_key_size Symmetric key size in bytes
   @param[out] blob_ptr Symmetric key blob

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_symmetric_key_import(ehsm_service_t *service_ptr,
                          const ehsm_symmetric_key_info_t *symmetric_key_info_ptr,
                          const void *symmetric_key_ptr,
                          size_t symmetric_key_size,
                          void *blob_ptr);

/**
   Symmetric encryption with ECB.

   @remark @p text_size must be multiple of the used key size

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Symmetric key blob
   @param[in] plaintext_ptr Plaintext to encrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] ciphertext_ptr Ciphertext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_symmetric_ecb_encrypt(ehsm_service_t *service_ptr,
                           const void *blob_ptr,
                           const void *plaintext_ptr,
                           size_t text_size,
                           void *ciphertext_ptr);

/**
   Symmetric decryption with ECB.

   @remark @p text_size must be multiple of the used key size

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Symmetric key blob
   @param[in] ciphertext_ptr Ciphertext to decrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] plaintext_ptr Plaintext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_symmetric_ecb_decrypt(ehsm_service_t *service_ptr,
                           const void *blob_ptr,
                           const void *ciphertext_ptr,
                           size_t text_size,
                           void *plaintext_ptr);

/**
   Symmetric encryption with CBC.

   @remark @p text_size must be multiple of the used key size
   @remark @p iv_ptr buffer of initialization vector size must be equal to the used key size

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Symmetric key blob
   @param[in] iv_ptr Initialization vector
   @param[in] plaintext_ptr Plaintext to encrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] ciphertext_ptr Ciphertext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_symmetric_cbc_encrypt(ehsm_service_t *service_ptr,
                           const void *blob_ptr,
                           const void *iv_ptr,
                           const void *plaintext_ptr,
                           size_t text_size,
                           void *ciphertext_ptr);

/**
   Symmetric decryption with CBC.

   @remark @p text_size must be multiple of the used key size
   @remark @p iv_ptr buffer of initialization vector size must be equal to the used key size

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Symmetric key blob
   @param[in] iv_ptr Initialization vector
   @param[in] ciphertext_ptr Ciphertext to decrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] plaintext_ptr Plaintext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_symmetric_cbc_decrypt(ehsm_service_t *service_ptr,
                           const void *blob_ptr,
                           const void *iv_ptr,
                           const void *ciphertext_ptr,
                           size_t text_size,
                           void *plaintext_ptr);

/**
   Generate CMAC authentication tag.

   @remark @p tag_size must be equal to ::EHSM_SYMMETRIC_TAG_SIZE

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Symmetric key blob
   @param[in] message_ptr Message to compute CMAC
   @param[in] message_size Size of the message in octets
   @param[out] tag_ptr MAC Authentication tag
   @param[in] tag_size Size of MAC Authentication tag

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_symmetric_cmac_generate(ehsm_service_t *service_ptr,
                             const void *blob_ptr,
                             const void *message_ptr,
                             size_t message_size,
                             void *tag_ptr,
                             size_t tag_size);

/**
   Verify CMAC authentication tag.

   @remark @p tag_size must be equal to ::EHSM_SYMMETRIC_TAG_SIZE

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Symmetric key blob
   @param[in] message_ptr Message to compute CMAC
   @param[in] message_size Size of the message in octets
   @param[in] tag_ptr MAC Authentication tag
   @param[in] tag_size Size of MAC Authentication tag

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_symmetric_cmac_verify(ehsm_service_t *service_ptr,
                           const void *blob_ptr,
                           const void *message_ptr,
                           size_t message_size,
                           const void *tag_ptr,
                           size_t tag_size);

/**
   Symmetric encryption with CCM.

   @remark @p nonce_size for SM4 must be between ::EHSM_SYMMETRIC_SM4_NONCE_MIN_SIZE and ::EHSM_SYMMETRIC_SM4_NONCE_MAX_SIZE
   @remark @p adata_size for SM4 must be less than ::EHSM_SYMMETRIC_SM4_ADATA_MAX_SIZE
   @remark @p tag_size for SM4 must be between ::EHSM_SYMMETRIC_SM4_MAC_TAG_MIN_SIZE and ::EHSM_SYMMETRIC_SM4_MAC_TAG_MAX_SIZE

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Symmetric key blob
   @param[in] nonce_ptr Session nonce (must be used once!)
   @param[in] nonce_size Session nonce size in octets
   @param[in] adata_ptr Associated data
   @param[in] adata_size Size of associated data in octets
   @param[in] plaintext_ptr Plaintext to encrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[out] ciphertext_ptr Ciphertext
   @param[out] tag_ptr MAC Authentication tag
   @param[in] tag_size Size of MAC Authentication tag

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_symmetric_ccm_encrypt(ehsm_service_t *service_ptr,
                           const void *blob_ptr,
                           const void *nonce_ptr,
                           size_t nonce_size,
                           const void *adata_ptr,
                           size_t adata_size,
                           const void *plaintext_ptr,
                           size_t text_size,
                           void *ciphertext_ptr,
                           void *tag_ptr,
                           size_t tag_size);

/**
   Symmetric decryption with CCM.

   @remark @p nonce_size for SM4 must be between ::EHSM_SYMMETRIC_SM4_NONCE_MIN_SIZE and ::EHSM_SYMMETRIC_SM4_NONCE_MAX_SIZE
   @remark @p adata_size for SM4 must be less than ::EHSM_SYMMETRIC_SM4_ADATA_MAX_SIZE
   @remark @p tag_size for SM4 must be between ::EHSM_SYMMETRIC_SM4_MAC_TAG_MIN_SIZE and ::EHSM_SYMMETRIC_SM4_MAC_TAG_MAX_SIZE

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr Symmetric key blob
   @param[in] nonce_ptr Session nonce (must be used once!)
   @param[in] nonce_size Session nonce size in octets
   @param[in] adata_ptr Associated data
   @param[in] adata_size Size of associated data in octets
   @param[in] ciphertext_ptr Ciphertext to decrypt
   @param[in] text_size Size of the plain/cipher text in octets
   @param[in] tag_ptr MAC Authentication tag
   @param[in] tag_size Size of MAC Authentication tag
   @param[out] plaintext_ptr Plaintext

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_symmetric_ccm_decrypt(ehsm_service_t *service_ptr,
                           const void *blob_ptr,
                           const void *nonce_ptr,
                           size_t nonce_size,
                           const void *adata_ptr,
                           size_t adata_size,
                           const void *ciphertext_ptr,
                           size_t text_size,
                           const void *tag_ptr,
                           size_t tag_size,
                           void *plaintext_ptr);

/**
   Perform a self-test operation

   @param[in] ehsm_service_ptr Embedded HSM service instance
   @param[in] The test to perform

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_self_test_perform(ehsm_service_t *ehsm_service_ptr, ehsm_self_test_t test);

/**
   Generate MAC key

   @remark @p blob_ptr must be ::EHSM_MAC_BLOB_SIZE bytes long

   @param[in] service_ptr Embedded HSM service instance
   @param[in] mac_key_info_ptr MAC key information
   @param[out] blob_ptr MAC key blob

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_mac_key_generate(ehsm_service_t *service_ptr,
                      const ehsm_mac_key_info_t *mac_key_info_ptr,
                      void *blob_ptr);

/**
   Import MAC key

   @remark @p blob_ptr must be ::EHSM_MAC_BLOB_SIZE bytes
   @remark @p mac_key_size must be greater then or equal to half of hash digest size and less than or equal to ::EHSM_MAC_KEY_MAX_SIZE

   @param[in] service_ptr Embedded HSM service instance
   @param[in] mac_key_info_ptr MAC key information
   @param[in] mac_key_ptr Imported MAC key buffer
   @param[in] mac_key_size Imported MAC key size buffer in octets
   @param[out] blob_ptr MAC key blob

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_mac_key_import(ehsm_service_t *service_ptr,
                    const ehsm_mac_key_info_t *mac_key_info_ptr,
                    const void *mac_key_ptr,
                    size_t mac_key_size,
                    void *blob_ptr);

/**
   Generate MAC authentication tag

   @remark @p blob_ptr must be ::EHSM_MAC_BLOB_SIZE bytes
   @remark @p tag_size must be equal to hash digest size

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr MAC key blob
   @param[in] message_ptr Message to compute MAC
   @param[in] message_size Size of the message in octets
   @param[out] tag_ptr MAC Authentication tag buffer
   @param[in] tag_size Size of MAC Authentication tag buffer

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_mac_generate(ehsm_service_t *service_ptr,
                  const void *blob_ptr,
                  const void *message_ptr,
                  size_t message_size,
                  void *tag_ptr,
                  size_t tag_size);

/**
   Verify MAC authentication tag

   @remark @p blob_ptr must be ::EHSM_MAC_BLOB_SIZE bytes
   @remark @p tag_size must be equal to hash digest size

   @param[in] service_ptr Embedded HSM service instance
   @param[in] blob_ptr MAC key blob
   @param[in] message_ptr Message to compute MAC
   @param[in] message_size Size of the message in octets
   @param[in] tag_ptr MAC Authentication tag
   @param[in] tag_size Size of MAC Authentication tag

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
ehsm_mac_verify(ehsm_service_t *service_ptr,
                const void *blob_ptr,
                const void *message_ptr,
                size_t message_size,
                const void *tag_ptr,
                size_t tag_size);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_EHSM_SERVICE_H */
