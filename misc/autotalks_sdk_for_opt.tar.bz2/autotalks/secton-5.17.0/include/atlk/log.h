/** Copyright (C) 2020 Autotalks Ltd. */
#ifndef _ATLK_LOG_H
#define _ATLK_LOG_H

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   System log API data types
*/

/** Number of elements in the log version array */
#define LOG_VERSION_ELEMENTS            4U

/** Maximum entries for the log database, per file ID */
#define LOG_FILE_ID_MAX                 384U

/** Log Formatted message elements size breakdown */
#define LOG_TIMESTAMP_MAX_SIZE          16U
#define LOG_COMPONENT_NAME_MAX_SIZE     64U
#define LOG_FILE_NAME_MAX_SIZE          128U
#define LOG_LINE_NUMBER_MAX_SIZE        8U
#define LOG_MESSAGE_MAX_SIZE            384U
#define LOG_FORMATTED_MESSAGE_MAX_SIZE  (LOG_TIMESTAMP_MAX_SIZE      + \
                                         LOG_COMPONENT_NAME_MAX_SIZE + \
                                         LOG_FILE_NAME_MAX_SIZE      + \
                                         LOG_LINE_NUMBER_MAX_SIZE    + \
                                         LOG_MESSAGE_MAX_SIZE)

#define LOG_MESSAGE_INIT {    \
  .file_name      = "",       \
  .component_name = ""        \
}

/** Log levels */
typedef enum {
  /** Error log level */
  LOG_LEVEL_ERROR = 3U,

  /** Warning log level */
  LOG_LEVEL_WARNING,

  /** Info log level */
  LOG_LEVEL_INFO = 6U,

  /** Debug log level */
  LOG_LEVEL_DEBUG,

  /** Invalid log level */
  LOG_LEVEL_INVALID,
} log_level_t;

/** LOG service instance */
typedef atlk_handle_t log_service_t;

/** Log version */
typedef struct {
  uint32_t version[LOG_VERSION_ELEMENTS];
} log_version_t;

/** Log message strcut */
typedef struct {
  char        *component_name;
  char        *file_name;
  char        message[LOG_MESSAGE_MAX_SIZE];
  uint32_t    line_number;
  log_level_t level;
} log_message_t;

/** ATLK formatted log message */
typedef struct {
  /** message format: "[timestamp] [sequence number component name] [<level> file name:line number] message" */
  char        message[LOG_FORMATTED_MESSAGE_MAX_SIZE];
  log_level_t level;
} log_formatted_message_t;
#define LOG_FORMATTED_MESSAGE_INIT { .message[0] = '\0' }

/** Log reader list node */
typedef struct log_reader_node {
  uint32_t                line_number;
  uint32_t                message_id;
  char                    message[LOG_MESSAGE_MAX_SIZE];
  struct log_reader_node *next_ptr;
} log_reader_node_t;

/** Log reader list */
typedef struct {
  char              file_name[LOG_FILE_NAME_MAX_SIZE];
  log_reader_node_t *node_ptr;
} log_reader_list_t;

/** Log reader data base */
typedef struct {
  log_version_t     log_version;
  log_reader_list_t list_array[LOG_FILE_ID_MAX];
} log_reader_database_t;

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_LOG_H */
