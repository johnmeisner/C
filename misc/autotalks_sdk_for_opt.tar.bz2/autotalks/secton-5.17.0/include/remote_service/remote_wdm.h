/** Copyright (C) 2016-2019 Autotalks Ltd. */

/**
   @file
   Remote WDM protocol header
*/
#ifndef _REMOTE_WDM_PROTOCOL_H
#define _REMOTE_WDM_PROTOCOL_H

#include "remote_defs.h"
#include "remote_compensator.h"
#include <common/eui48.h>

#include "remote_object.h"

/* Value that indicates RSSI value is not available */
#define REMOTE_WDM_RSSI_NA                                INT16_MIN

/* Value that indicates MCS value is not available */
#define REMOTE_WDM_MCS_NA                                 INT16_MIN

/* Minimum length of PLUTON2 revision ID string */
#define REMOTE_WDM_PLUTON2_REVISION_ID_STR_LEN            10

/* Pluton2 unique id length in byte */
#define REMOTE_WDM_PLUTON2_UNIQUE_ID_LEN_BYTE             16

/* RF antenna count */
#define REMOTE_WDM_RF_COUNT                               2

/* Invalid temperature value */
#define REMOTE_WDM_TEMP_READING_INVALID                   INT32_MIN

/* Invalid compensator temperature value */
#define REMOTE_WDM_COMPENSATOR_TEMP_READING_INVALID       INT8_MIN

/* Compensator last messages buffer size */
#define REMOTE_WDM_COMPENSATOR_LAST_MESSAGES_BUFFER_SIZE  64U

/* 802.11 access categories count */
#define REMOTE_WDM_AC_COUNT                               5U

/* V2X user priorites count */
#define REMOTE_WDM_V2X_USRP_COUNT                         8U

#define REMOTE_WDM_DSP_LMAC_COUNTERS_INIT {                     \
  .crc_error = 0,                                               \
  .tx_total = 0,                                                \
  .tx_ampdu_total = 0,                                          \
  .rx_total = 0,                                                \
  .tx_ac = {0},                                                 \
  .rx_ac = {0},                                                 \
  .tx_usrp = {0},                                               \
  .rx_usrp = {0},                                               \
}

#define REMOTE_WDM_DSP_LMAC_WIFI_COUNTERS_INIT {                \
  .success_rts = 0,                                             \
  .missed_ack = 0,                                              \
  .missed_cts = 0,                                              \
  .missed_back = 0                                              \
}

#define REMOTE_WDM_EVM_FRACTION_INIT {                          \
  .numerator = 0,                                               \
  .denominator = 0                                              \
}

#define REMOTE_WDM_DSP_DEBUG_REPORT_INIT {                      \
  .function = {0},                                              \
  .line = 0                                                     \
}

#define REMOTE_WDM_WLAN_STATS_INIT {                            \
  .debug_report = REMOTE_WDM_DSP_DEBUG_REPORT_INIT,             \
  .lmac_counters = REMOTE_WDM_DSP_LMAC_COUNTERS_INIT,           \
  .lmac_wifi_counters = REMOTE_WDM_DSP_LMAC_WIFI_COUNTERS_INIT, \
  .last_rx_evm = REMOTE_WDM_EVM_FRACTION_INIT,                  \
  .min_rx_evm = REMOTE_WDM_EVM_FRACTION_INIT,                   \
  .max_rx_evm = REMOTE_WDM_EVM_FRACTION_INIT,                   \
  .last_rssi = 0,                                               \
  .min_rssi = 0,                                                \
  .max_rssi = 0,                                                \
}

#define REMOTE_WDM_EDCA_CONFIG_INIT {                           \
  .aifsn = 0,                                                   \
  .cwmin = 0,                                                   \
  .cwmax = 0,                                                   \
  .txop_limit = 0,                                              \
  .msdu_lifetime = 0,                                           \
}

#define REMOTE_WDM_RF_TEST_MODE_INIT {                          \
  .rf_test_mode = 0,                                            \
  .freq_offset = 0,                                             \
  .tx_power = 0                                                 \
}

#define REMOTE_WDM_DSP_VERSION_INIT {                           \
  .major = VALUE_INIT,                                          \
  .minor = VALUE_INIT,                                          \
  .sw_revision = VALUE_INIT,                                    \
  .hw_revision = VALUE_INIT,                                    \
  .dsp_rev_id = {0}                                             \
}

/** Remote WDM request type */
typedef enum {
  REMOTE_WDM_REQUEST_TYPE_OBJECT_SET = 0,
  REMOTE_WDM_REQUEST_TYPE_OBJECT_GET,
  REMOTE_WDM_REQUEST_TYPE_MAX,
} remote_wdm_request_type_t;

/** WDM object type */
typedef enum {
  REMOTE_WDM_OBJECT_TYPE_FREQUENCY_MHZ = REMOTE_WDM_REQUEST_TYPE_MAX,
  REMOTE_WDM_OBJECT_TYPE_TSSI_DETECTOR_RESULT,
  REMOTE_WDM_OBJECT_TYPE_TSSI_LOOP_ENABLE,
  REMOTE_WDM_OBJECT_TYPE_TSSI_CALIBRATION_MODE_START,
  REMOTE_WDM_OBJECT_TYPE_TSSI_CALIBRATION_MODE_STOP,
  REMOTE_WDM_OBJECT_TYPE_RSSI_CALIB_RESULT,
  REMOTE_WDM_OBJECT_TYPE_WLAN_DSP_VERSION,
  REMOTE_WDM_OBJECT_TYPE_WLAN_STATS,
  REMOTE_WDM_OBJECT_TYPE_BANDWIDTH,
  REMOTE_WDM_OBJECT_TYPE_PHY_MODE,
  REMOTE_WDM_OBJECT_TYPE_DIVERSITY,
  REMOTE_WDM_OBJECT_TYPE_EDCA_CONFIG,
  REMOTE_WDM_OBJECT_TYPE_CSD11P,
  REMOTE_WDM_OBJECT_TYPE_CBR_SAMPLE_INTERVAL,
  REMOTE_WDM_OBJECT_TYPE_IF_ATTACH,
  REMOTE_WDM_OBJECT_TYPE_IF_DETACH,
  REMOTE_WDM_OBJECT_TYPE_IF_STATUS,
  REMOTE_WDM_OBJECT_TYPE_RF_STATUS,
  REMOTE_WDM_OBJECT_TYPE_WLAN_MAC,
  REMOTE_WDM_OBJECT_TYPE_WLAN_RF_TEST_MODE,
  REMOTE_WDM_OBJECT_TYPE_RF_TEMPERATURE_OFFSET,
  REMOTE_WDM_OBJECT_TYPE_TX_DIVERSITY_SCHEME,
  REMOTE_WDM_OBJECT_TYPE_COMPENSATOR_STATUS,
  REMOTE_WDM_OBJECT_TYPE_COMPENSATOR_VERSION,
  REMOTE_WDM_OBJECT_TYPE_COMPENSATOR_STATS,
  REMOTE_WDM_OBJECT_TYPE_COMPENSATOR_FAULT_CODE,
  REMOTE_WDM_OBJECT_TYPE_COMPENSATOR_RAW_DATA,
  REMOTE_WDM_OBJECT_TYPE_COMPENSATOR_CALIBRATION_DOWNLOAD,
  REMOTE_WDM_OBJECT_TYPE_COMPENSATOR_LAST_MESSAGES,
  REMOTE_WDM_OBJECT_TYPE_CTRL_TX_POWER,
  REMOTE_WDM_OBJECT_TYPE_PRIMARY_INDEX,
  REMOTE_WDM_OBJECT_TYPE_PLUTON2_REVISION_ID,
  REMOTE_WDM_OBJECT_TYPE_PLUTON2_UNIQUE_ID,
  REMOTE_WDM_OBJECT_TYPE_EXTERNAL,
  REMOTE_WDM_OBJECT_TYPE_CBP_INIT,
  REMOTE_WDM_OBJECT_TYPE_CBP_RESET,
  REMOTE_WDM_OBJECT_TYPE_CBP_FILTER_ADD,
  REMOTE_WDM_OBJECT_TYPE_CBP_FILTER_REMOVE,
  REMOTE_WDM_OBJECT_TYPE_CBP_STATISTICS_GET,
  REMOTE_WDM_OBJECT_TYPE_CBP_STATUS_GET,
  REMOTE_WDM_OBJECT_TYPE_CBP_ID_FILTER_GET,
  REMOTE_WDM_OBJECT_TYPE_CBP_INDEX_FILTER_GET,
  REMOTE_WDM_OBJECT_TYPE_GENERIC_COMPENSATOR_DATA_SET,
  REMOTE_WDM_OBJECT_TYPE_MAX,
} remote_wdm_object_type_t;

/** WIFI bandwidth */
typedef enum {
  REMOTE_WDM_WIFI_BW_5MHZ = 0,
  REMOTE_WDM_WIFI_BW_10MHZ,
  REMOTE_WDM_WIFI_BW_20MHZ,
  REMOTE_WDM_WIFI_BW_40MHZ,
  REMOTE_WDM_WIFI_BW_80MHZ,
} remote_wdm_bw_t;

/** EDCA access category */
typedef enum {
  REMOTE_WDM_EDCA_AC_BK = 0,
  REMOTE_WDM_EDCA_AC_BE,
  REMOTE_WDM_EDCA_AC_VI,
  REMOTE_WDM_EDCA_AC_VO
} remote_wdm_edca_ac_t;

/** Diversity mode */
typedef enum {
  REMOTE_WDM_DIVERSITY_MODE_OFF = 0,
  REMOTE_WDM_DIVERSITY_MODE_TX,
  REMOTE_WDM_DIVERSITY_MODE_RX,
  REMOTE_WDM_DIVERSITY_MODE_BOTH,
} remote_wdm_diversity_mode_t;

/** Interface state */
typedef enum {
  REMOTE_WDM_INTERFACE_STATE_DETACHED = 0,
  REMOTE_WDM_INTERFACE_STATE_ATTACHED,
  REMOTE_WDM_INTERFACE_STATE_MAX,
} remote_wdm_interface_state_t;

/** Interface mode */
typedef enum {
  REMOTE_WDM_INTERFACE_MODE_CV2X = 0,
  REMOTE_WDM_INTERFACE_MODE_DSRC,
  REMOTE_WDM_INTERFACE_MODE_WIFI,
  REMOTE_WDM_INTERFACE_MODE_SERVICE,
  REMOTE_WDM_INTERFACE_MODE_MAX,
} remote_wdm_interface_mode_t;

/** WDM status */
typedef enum {
  REMOTE_WDM_STATUS_OK = 0,
  REMOTE_WDM_STATUS_FAILED,
} remote_wdm_status_t;

typedef enum {
  REMOTE_WDM_COMPENSATOR_STATE_ENABLED = 0,
  REMOTE_WDM_COMPENSATOR_STATE_DISABLED,
  REMOTE_WDM_COMPENSATOR_STATE_CALIBRATION_DOWNLOADING,
  REMOTE_WDM_COMPENSATOR_STATE_DOWNLOAD_FAIL,
  REMOTE_WDM_COMPENSATOR_STATE_FAILURE,
} remote_wdm_compensator_state_t;

/** Compensator cable loss calculation status */
typedef enum {
  REMOTE_WDM_COMPENSATOR_CABLE_LOSS_CALCULATION_NOT_READY = 0,
  REMOTE_WDM_COMPENSATOR_CABLE_LOSS_CALCULATION_SUBOPTIMAL,
  REMOTE_WDM_COMPENSATOR_CABLE_LOSS_CALCULATION_OPTIMAL,
} remote_wdm_compensator_cable_loss_calculation_status_t;

/** Interface status */
typedef remote_struct {
  uint8_t state;
  uint8_t mode;

  uint8_t padding[2];
} remote_wdm_interface_status_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_interface_status_t);

/** RF status */
typedef remote_struct {
  int32_t  temperature_celsius;
  uint32_t modem_recovery_counter;
  uint8_t  rf_pll_status[REMOTE_WDM_RF_COUNT];
  uint8_t  calibration_status[REMOTE_WDM_RF_COUNT];
  uint8_t  afe_pll_status;
  uint8_t  modem_status;
  uint8_t  rf_config_status[REMOTE_WDM_RF_COUNT];
} remote_wdm_rf_status_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_rf_status_t);

/** Compensator status */
typedef remote_struct {
  uint8_t compensator_status;
  int8_t temperature_celsius;
  int8_t cable_loss_db8;
  uint8_t cable_loss_status;
} remote_wdm_compensator_status_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_compensator_status_t);

/** Compensator version */
typedef remote_struct {
  uint8_t hw_version;       // 4 MSB of MAJOR / 4 LSB of MINOR version number
  uint8_t sw_version;       // 4 MSB of MAJOR / 4 LSB of MINOR version number
  uint8_t protocol_version; // 4 MSB of MAJOR / 4 LSB of MINOR version number

  uint8_t padding[1];
} remote_wdm_compensator_version_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_compensator_version_t);

/** Compensator statistics */
typedef remote_struct {
  uint32_t total_messages_counter;
  uint32_t error_messages_counter;
} remote_wdm_compensator_stats_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_compensator_stats_t);

/** Compensator last messages */
typedef remote_struct {
  uint16_t last_messages_buffer[REMOTE_WDM_COMPENSATOR_LAST_MESSAGES_BUFFER_SIZE];
} remote_wdm_compensator_last_messages_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_compensator_last_messages_t);

/** Generic compensator data per antenna */
typedef remote_struct {
  remote_compensator_data_t comp_data[REMOTE_WDM_RF_COUNT];
} remote_wdm_generic_compensator_data_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_generic_compensator_data_t);

/** Tx diversity scheme */
typedef enum {
  REMOTE_WDM_TX_DIVERSITY_SCHEME_CSD = 0,
  REMOTE_WDM_TX_DIVERSITY_SCHEME_PSD,
} remote_wdm_tx_diversity_scheme_t;

/** LMAC counters  */
typedef remote_struct {
  uint32_t crc_error;
  uint32_t tx_total;
  uint32_t tx_ampdu_total;
  uint32_t rx_total;
  uint32_t tx_ac[REMOTE_WDM_AC_COUNT];
  uint32_t rx_ac[REMOTE_WDM_AC_COUNT];
  uint32_t tx_usrp[REMOTE_WDM_V2X_USRP_COUNT];
  uint32_t rx_usrp[REMOTE_WDM_V2X_USRP_COUNT];
} remote_wdm_dsp_lmac_counters_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_dsp_lmac_counters_t);

/** LMAC WIFI counters */
typedef remote_struct {
  uint32_t success_rts;
  uint32_t missed_ack;
  uint32_t missed_cts;
  uint32_t missed_back;
} remote_wdm_dsp_lmac_wifi_counters_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_dsp_lmac_wifi_counters_t);

/** EVM fraction */
typedef remote_struct {
  /** numerator part */
  uint32_t numerator;

  /** denominator part */
  uint32_t denominator;

} remote_wdm_evm_fraction_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_evm_fraction_t);

/** DSP debug report */
typedef remote_struct {
  /** Module name in which assertion had failed  */
  uint8_t  function[32];

  /** Line number in which assertion had failed  */
  uint32_t line;

} remote_wdm_dsp_debug_report_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_dsp_debug_report_t);

typedef enum {
  REMOTE_WDM_RSSI_REAL_OFFSET_802_11 = 0,
  REMOTE_WDM_RSSI_REAL_OFFSET_CV2X,
  REMOTE_WDM_RSSI_REAL_OFFSET_MAX,
} remote_wdm_rssi_real_offset_t;

/** WLAN diagnostics statistics */
typedef remote_struct {
  /** DSP debug debug report */
  remote_wdm_dsp_debug_report_t debug_report;

  /** LMAC counters */
  remote_wdm_dsp_lmac_counters_t lmac_counters;
  remote_wdm_dsp_lmac_wifi_counters_t lmac_wifi_counters;

  /** PHY last receive EVM value */
  remote_wdm_evm_fraction_t last_rx_evm;

  /** PHY min receive EVM value */
  remote_wdm_evm_fraction_t min_rx_evm;

  /** PHY max receive EVM value */
  remote_wdm_evm_fraction_t max_rx_evm;

  /** Average last RSSI value */
  int16_t last_rssi;

  /** Average min RSSI value */
  int16_t min_rssi;

  /** Average max RSSI value */
  int16_t max_rssi;

  /** Minimum MCS value */
  int16_t min_mcs;

  /** Maximum MCS value */
  int16_t max_mcs;

  /** DSP to RSSI real offset */
  uint8_t rssi_real_offset;

  /** Last receive packet EUI source address */
  eui48_t last_rx_sa;

  /** Last receive packet EUI destination address */
  eui48_t last_rx_da;

  uint8_t padding[1];
} remote_wdm_wlan_stats_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_wlan_stats_t);

/** PHY counters  */
typedef remote_struct {
  uint32_t lsig_error;
  uint32_t htsig_error;
  uint32_t vhtsiga_error;
  uint32_t vhtsigb_error;
  uint32_t packet_over_packet;
} remote_wdm_phy_counters_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_phy_counters_t);

/** EDCA Function configuration */
typedef remote_struct {
  /** Arbitration interframe space number in the range 1..15 */
  uint32_t aifsn;

  /**
     Minimum contention window
     A value of the form 2^n-1 in the range 0..255
  */
  uint32_t cwmin;

  /**
     Maximum contention window
     A value of the form 2^n-1 in the range 0..65535
  */
  uint32_t cwmax;

  /**
     Maximum burst time (in units of 32usecs) in the range 0..65536
     0 means disabled
  */
  uint32_t txop_limit;

  /**
     Maximum duration (in time units) an MSDU would be retained
     before it is discarded. Value in the range 0..500
  */
  uint32_t msdu_lifetime;

} remote_wdm_edca_config_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_edca_config_t);

/** WDM RF test mode */
typedef enum {
  /** Disabled */
  REMOTE_WDM_RF_TEST_MODE_DISABLED = 0,

  /** Random OFDM */
  REMOTE_WDM_RF_TEST_MODE_OFDM,

  /** Carrier Wave (CW) */
  REMOTE_WDM_RF_TEST_MODE_CW
} remote_wdm_rf_test_mode_t;

/* Carrier Wave (CW) config */
typedef remote_struct {
  /** RF test mode */
  uint32_t rf_test_mode;

  /** Frequency offset in units of KHz */
  uint32_t freq_offset;

  /** TX power in units of 0.5 dBm */
  uint32_t tx_power;
} remote_wdm_rf_test_mode_config_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_rf_test_mode_config_t);

/** DSP version */
typedef remote_struct {
  /** Major */
  uint8_t major;

  /** Minor */
  uint8_t minor;

  /** SW revision */
  uint8_t sw_revision;

  /** HW revision */
  uint8_t hw_revision;

  /** Revision id (7 Bytes + Null terminated) */
  uint8_t dsp_rev_id[8];
} remote_wdm_dsp_version_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_dsp_version_t);

/** CBP Addressing mode */
typedef enum {
  /** no addressing mode */
  REMOTE_WDM_CBP_ADDRESS_NONE = 0,

  /** L2ID addressing mode, of 24 bit address length */
  REMOTE_WDM_CBP_ADDRESS_24_BIT,

  /** MAC addressing mode, of 48 bit address length */
  REMOTE_WDM_CBP_ADDRESS_48_BIT,
} remote_wdm_cbp_address_mode_t;

/** CBP state */
typedef enum {
  REMOTE_WDM_CBP_OFF = 0,
  REMOTE_WDM_CBP_INITIALIZED,
} remote_wdm_cbp_state_t;

/** CBP filter id used in v2x or in cv2x */
typedef remote_struct {
  /** MAC addressing mode, of 48 bit address length, in case 24 mode bit this parameter is ignored */
  eui48_t v2x_mac_address;

  /** L2ID addressing mode, of 24 bit address length, in case 48 mode bit this parameter is ignored */
  uint32_t cv2x_l2id;

  uint8_t padding[2];
} remote_wdm_cbp_filter_id_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_cbp_filter_id_t);

/** CBP filter information get */
typedef remote_struct {
  /** Filter's key */
  uint32_t key;

  /** Time passed from the last time the filter was accessed in msec */
  uint32_t time_from_last_message_ms;

  /** Min time in ms between frames before dropping frame in msec */
  uint16_t min_frame_interval_ms;

  /** Number of frames that passed the filter and where processed */
  uint16_t unfiltered_frames;

  /** Number of frames that where dropped due to filtering */
  uint16_t filtered_frames;

  uint8_t padding[2];
} remote_wdm_cbp_filter_information_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_cbp_filter_information_t);

/** CBP config */
typedef remote_struct {
  /** The address mode that will be used */
  uint32_t address_mode; /* remote_wdm_cbp_address_mode_t */

  /**  Max time in msec since last frame before removing filter */
  uint16_t filter_aging_ms;

  /**  High priority messages EDCA(0..3)/PPPP(0..7)*/
  uint8_t high_priority;

  uint8_t padding[1];
} remote_wdm_cbp_config_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_cbp_config_t);

/** CBP filter */
typedef remote_struct {
  /** MAC address or L2ID */
  remote_wdm_cbp_filter_id_t filter_id;

  /** Min time in ms between frames before dropping frame*/
  uint16_t min_frame_interval_ms;

  uint8_t padding[2];
} remote_wdm_cbp_filter_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_cbp_filter_t);

/** CBP statistics */
typedef remote_struct {
  /** Total number of frames that passed the filter and where processed */
  uint32_t total_unfiltered_frames;

  /** Total number of frames that where dropped due to filtering */
  uint32_t total_filtered_frames;
} remote_wdm_cbp_statistics_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_cbp_statistics_t);

/** CBP status */
typedef remote_struct {
  /** Number of available filters to use in the table */
  uint16_t number_of_filters_available;

  /** Number of used filters */
  uint16_t number_of_filters_in_use;

  /** Is CBP was initialized */
  uint32_t is_cbp_initialized; /* remote_wdm_cbp_state_t */
} remote_wdm_cbp_status_t;

REMOTE_CHECK_DATA_SIZE(remote_wdm_cbp_status_t);

#endif /* _REMOTE_WDM_PROTOCOL_H */
