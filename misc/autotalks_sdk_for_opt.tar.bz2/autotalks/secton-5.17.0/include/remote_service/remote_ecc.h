/* Copyright (C) 2012-2016 Autotalks Ltd. */
#ifndef _REMOTE_ECC_PROTOCOL_H
#define _REMOTE_ECC_PROTOCOL_H

#include <atlk/hash.h>
#include <atlk/ecc.h>
#include "remote_defs.h"

/** ecc_curve_t */
typedef uint8_t remote_ecc_curve_t;

/** ecc_scalar_t */
typedef remote_struct {
  uint32_t value[ECC_SCALAR_NUM_OF_UINT32];
} remote_ecc_scalar_t;

REMOTE_CHECK_DATA_SIZE(remote_ecc_scalar_t);

/** ecc_point_t */
typedef remote_struct {
  remote_ecc_scalar_t x_coordinate;
  remote_ecc_scalar_t y_coordinate;
  uint8_t point_type;
  uint8_t padding[3];
} remote_ecc_point_t;

REMOTE_CHECK_DATA_SIZE(remote_ecc_point_t);

/** hash_digest_t */
typedef remote_struct {
  uint8_t value[HASH_DIGEST_MAX_SIZE];
  uint8_t value_size;
  uint8_t padding[3];
} remote_hash_digest_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_digest_t);

/** ecc_signature_t */
typedef remote_struct {
  remote_ecc_scalar_t r_scalar;
  remote_ecc_scalar_t s_scalar;
} remote_ecdsa_signature_t;

REMOTE_CHECK_DATA_SIZE(remote_ecdsa_signature_t);

/** ecc_fast_verification_signature_t */
typedef remote_struct {
  remote_ecc_point_t R_point;
  remote_ecc_scalar_t r_scalar;
  remote_ecc_scalar_t s_scalar;
} remote_ecdsa_fast_verification_signature_t;

REMOTE_CHECK_DATA_SIZE(remote_ecdsa_fast_verification_signature_t);

/** ecc_core_socket_id_t */
typedef uint32_t remote_ecc_socket_id_t;

/** ecc_request_id_t */
typedef uint32_t remote_ecc_request_id_t;

/** ecc_request_type_t */
typedef uint8_t remote_ecc_request_type_t;

/** ecc_request_context_t */
typedef remote_struct {
  remote_ecc_socket_id_t socket_id;
  remote_ecc_request_id_t request_id;
  remote_ecc_request_type_t request_type;
  remote_ecc_curve_t curve;
  uint8_t padding[2];
} remote_ecc_request_context_t;

REMOTE_CHECK_DATA_SIZE(remote_ecc_request_context_t);

/** ecc_sign_params_t */
typedef remote_struct {
  remote_ecc_scalar_t private_key;
  remote_ecc_scalar_t random;
  remote_hash_digest_t digest;
} remote_ecc_sign_params_t;

REMOTE_CHECK_DATA_SIZE(remote_ecc_sign_params_t);

/** ecc_verify_params_t */
typedef remote_struct {
  remote_ecc_point_t public_key;
  remote_ecdsa_signature_t signature;
  remote_hash_digest_t digest;
} remote_ecc_verify_params_t;

REMOTE_CHECK_DATA_SIZE(remote_ecc_verify_params_t);

/** ecc_pma_params_t */
typedef remote_struct {
  remote_ecc_point_t point;
  remote_ecc_point_t addend;
  remote_ecc_scalar_t multiplier;
} remote_ecc_pma_params_t;

REMOTE_CHECK_DATA_SIZE(remote_ecc_pma_params_t);

/** ecc_decompress_params_t */
typedef remote_struct {
  remote_ecc_point_t point;
} remote_ecc_decompress_params_t;

REMOTE_CHECK_DATA_SIZE(remote_ecc_decompress_params_t);

/** ecc_request_t */
typedef remote_struct {
  remote_ecc_request_context_t context;

  remote_union {
    remote_ecc_verify_params_t verify_params;
    remote_ecc_sign_params_t sign_params;
    remote_ecc_pma_params_t pma_params;
    remote_ecc_decompress_params_t decompress_params;
  } params;
} remote_ecc_request_t;

REMOTE_CHECK_DATA_SIZE(remote_ecc_request_t);

/** ecc_response_t */
typedef remote_struct {
  remote_ecc_request_context_t context;
  uint8_t rc;
  uint8_t padding[3];
  remote_union {
    remote_ecdsa_fast_verification_signature_t sign_result;
    remote_ecc_point_t pma_result;
    remote_ecc_point_t decompress_result;
  } result;
} remote_ecc_response_t;

REMOTE_CHECK_DATA_SIZE(remote_ecc_response_t);

#endif /* _REMOTE_ECC_PROTOCOL_H */
