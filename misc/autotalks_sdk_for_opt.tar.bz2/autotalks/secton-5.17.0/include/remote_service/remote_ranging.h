/* Copyright (C) 2014-2019 Autotalks Ltd. */
#ifndef _ATLK_REMOTE_RANGING_H
#define _ATLK_REMOTE_RANGING_H

#include "remote_defs.h"
#include <atlk/sdk.h>

#define REMOTE_RANGING_IQ_SAMPLES_NUM   64U
#define REMOTE_RANGING_RF_COUNT         2U

/** Ranging data struct */
typedef remote_struct {
  uint32_t iq_samples[REMOTE_RANGING_IQ_SAMPLES_NUM];
  /** RX timestamp in usecs */
  uint32_t rx_tstamp;
  /** RX timestamp offset in nsecs */
  uint32_t rx_tstamp_offset;
  /** ACK Transmit timestamp LSB (TSF) (Relevant only for RX side) */
  uint32_t ack_tstamp_lsb;
  /** TX timestamp in us (LSB, TSF): actual packet for TX or ACK for RX */
  uint32_t tx_tstamp;
  int32_t doppler_shift;
  uint32_t flags;
  uint32_t ack_evm_num;
  uint32_t ack_evm_denom;
  uint32_t req_evm_num;
  uint32_t req_evm_denom;
  uint16_t agc_lock_offset;
  uint8_t  tssi[REMOTE_RANGING_RF_COUNT];
  uint8_t ack_rf_gain[REMOTE_RANGING_RF_COUNT];
  uint8_t ack_rssi[REMOTE_RANGING_RF_COUNT];
  uint8_t ack_tssi[REMOTE_RANGING_RF_COUNT];
  int8_t rssi;
  uint8_t rf_gain;
} remote_ranging_info_t;

REMOTE_CHECK_DATA_SIZE(remote_ranging_info_t);

#endif /* _ATLK_REMOTE_RANGING_H */
