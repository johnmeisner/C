/** Copyright (C) 2020 Autotalks Ltd. */
#ifndef _DEVICE_REMOTE_LINK_LAYER_H_
#define _DEVICE_REMOTE_LINK_LAYER_H_

#include "remote_defs.h"
#include <common/eui48.h>

/**
   @file
   Remote transport header file.
*/

#define ATLK_ETHERTYPE  0xA0A0

typedef remote_struct
{
  /** Destination MAC address */
  eui48_t dest_address;
  /** Source MAC address */
  eui48_t src_address;
  /** Ethertype, it is set as big endian to be aligned with standard
      @note Ethertype must follow src_address */
  uint16_t eth_type;
  /** Padding to 4 byte alignment */
  uint8_t padding[2];
} ll_ethernet_header_t;

REMOTE_CHECK_DATA_SIZE(ll_ethernet_header_t);

#endif /* _DEVICE_REMOTE_LINK_LAYER_H_ */
