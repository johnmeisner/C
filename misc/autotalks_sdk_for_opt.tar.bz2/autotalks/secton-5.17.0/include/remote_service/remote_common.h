#ifndef _DEVICE_REMOTE_COMMON_H_
#define _DEVICE_REMOTE_COMMON_H_

#include "remote_defs.h"
#include "remote_object.h"

#define REMOTE_COMMON_REQ_HEADER_INIT = {          \
  .request_type = 0                                \
}

#define REMOTE_COMMON_OBJECT_REQ_INIT {            \
  .header = REMOTE_COMMON_REQ_HEADER_INIT,         \
  .type = 0,                                       \
  .object = REMOTE_OBJ_HEADER_T_INIT               \
}

#define REMOTE_COMMON_RSP_HEADER_INIT {            \
  .result = 0                                      \
}

#define REMOTE_COMMON_OBJECT_SET_RSP_INIT {        \
  .header = REMOTE_COMMON_RSP_HEADER_INIT          \
}

#define REMOTE_COMMON_INT32_OBJECT_GET_RSP_INIT {  \
  .header = REMOTE_COMMON_RSP_HEADER_INIT,         \
  .value = 0                                       \
}

#define REMOTE_COMMON_UINT32_OBJECT_GET_RSP_INIT { \
  .header = REMOTE_COMMON_RSP_HEADER_INIT,         \
  .value = 0                                       \
}

#define REMOTE_COMMON_INT64_OBJECT_GET_RSP_INIT {  \
  .header = REMOTE_COMMON_RSP_HEADER_INIT,         \
  .value = 0                                       \
}

#define REMOTE_COMMON_UINT64_OBJECT_GET_RSP_INIT { \
  .header = REMOTE_COMMON_RSP_HEADER_INIT,         \
  .value = 0                                       \
}

#define REMOTE_COMMON_OPAQUE_OBJECT_GET_RSP_INIT { \
  .header = REMOTE_COMMON_RSP_HEADER_INIT,         \
  .size = 0                                        \
}

/** Service type indexes */
typedef enum {
  /** V2X service type */
  SERVICE_TYPE_V2X = 0,

  /** ECC service type */
  SERVICE_TYPE_ECC,

  /** HSM service type */
  SERVICE_TYPE_HSM,

  /** Wireless Diagnostics & Management service type */
  SERVICE_TYPE_WDM,

  /** Device Diagnostics & Management service type */
  SERVICE_TYPE_DDM,

  /** In-Vehicle Network service type */
  SERVICE_TYPE_IVN,

  /** Debug service type */
  SERVICE_TYPE_DBG,

  /** HASH service type */
  SERVICE_TYPE_HASH,

  /** Symmetric crypto service type */
  SERVICE_TYPE_SYMMETRIC_CRYPTO,

  /** LOG service type */
  SERVICE_TYPE_LOG,

  /** MAX service type. Must be always last */
  SERVICE_TYPE_MAX
} remote_common_service_type_t;

typedef remote_struct {
  uint8_t request_type;
  /* Padding for 64bits alignment - done since this struct is added separately to the packet prior to the payload struct*/
  uint8_t padding[7];
} remote_common_req_header_t;

REMOTE_CHECK_DATA_SIZE(remote_common_req_header_t);

/* Common for all object requests
   @note: header field must be first */
typedef remote_struct {
  remote_common_req_header_t header;
  uint16_t type;
  uint8_t padding[2];
  remote_obj_header_t object;
} remote_common_object_req_t;

REMOTE_CHECK_DATA_SIZE(remote_common_object_req_t);

/* Common for all sync responses */
typedef remote_struct {
  uint8_t result;
  /* Padding for 64bits alignment - done since this struct is added separately to the packet prior to the payload struct*/
  uint8_t padding[7];
} remote_common_rsp_header_t;

REMOTE_CHECK_DATA_SIZE(remote_common_rsp_header_t);

typedef remote_struct {
  remote_common_rsp_header_t header;
} remote_common_object_set_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_common_object_set_rsp_t);

typedef remote_struct {
  remote_common_rsp_header_t header;
  int32_t value;
} remote_common_int32_object_get_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_common_int32_object_get_rsp_t);

typedef remote_struct {
  remote_common_rsp_header_t header;
  uint32_t value;
} remote_common_uint32_object_get_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_common_uint32_object_get_rsp_t);

typedef remote_struct {
  remote_common_rsp_header_t header;
  int64_t value;
} remote_common_int64_object_get_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_common_int64_object_get_rsp_t);

typedef remote_struct {
  remote_common_rsp_header_t header;
  uint64_t value;
} remote_common_uint64_object_get_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_common_uint64_object_get_rsp_t);

typedef remote_struct {
  remote_common_rsp_header_t header;
  uint32_t size;
} remote_common_opaque_object_get_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_common_opaque_object_get_rsp_t);

atlk_rc_t
rsvc_common_encode_response(void *value,
                            remote_obj_type_t value_type,
                            uint32_t value_size,
                            atlk_rc_t rsp_rc,
                            remote_common_rsp_header_t *rsp_buffer,
                            uint32_t *rsp_size);

atlk_rc_t
rsvc_common_decode_request(remote_obj_header_t *object_header,
                           remote_obj_type_t value_type,
                           void *value);

#endif /* _DEVICE_REMOTE_COMMON_H_ */
