/* Copyright (C) 2020 Autotalks Ltd. */
#ifndef _REMOTE_LOG_PROTOCOL_H
#define _REMOTE_LOG_PROTOCOL_H

/**
   @file
   Remote LOG header file, for common structures between host and device.
*/

#include <atlk/sdk.h>
#include "remote_defs.h"

#define REMOTE_LOG_VERSION_ELEMENTS  4U
#define ARGUMENTS_NUMBER_MAX         6U

/** Log message ID */
typedef enum {
  REMOTE_LOG_MESSAGE_ID_VERSION_GET = 0,
  REMOTE_LOG_MESSAGE_ID_LOG_INDICATION,
  REMOTE_LOG_MESSAGE_ID_DESTINATION_SET,
} remote_log_message_id_t;

/** Log levels */
typedef enum {
  /** Error log level */
  REMOTE_LOG_LEVEL_ERROR = 3,

  /** Warning log level */
  REMOTE_LOG_LEVEL_WARNING,

  /** Info log level */
  REMOTE_LOG_LEVEL_INFO = 6,

  /** Debug log level */
  REMOTE_LOG_LEVEL_DEBUG,

  /** Invalid log level */
  REMOTE_LOG_LEVEL_INVALID,
} remote_log_level_t;

/** Log message descriptor

   ::encoded_parameters representation:
         [31..28] Message log level
         [27..24] Number of variable arguments
         [23..8]  File number
         [7..0]   String number
 */
typedef remote_struct {
  uint32_t  tsf_lsb;
  uint32_t  encoded_parameters;
  uint16_t  magic;
  uint8_t   sequence_number;
  uint8_t   reserved;
  uint32_t  args[ARGUMENTS_NUMBER_MAX]; // Must be last
} remote_log_descriptor_t;

REMOTE_CHECK_DATA_SIZE(remote_log_descriptor_t);

/**
   String number filed length in ::encoded_parameters

   @attention Must be aligned with compact_trace_generate.py script
 */
#define LOG_ENCODED_STRING_ID_BITS  12U

/**
   File number filed length in ::encoded_parameters

   @attention MUST BE ALIGNED TO 'compact_trace_generate.py' script
 */
#define LOG_ENCODED_FILE_ID_BITS    12U

/**
   Message log level position
 */
#define LOG_ENCODED_LOGLEVEL_POS    28U

/**
   Message log level mask
 */
#define LOG_ENCODED_LOGLEVEL_MASK   0x0FU

/**
   Message argument number position
 */
#define LOG_ENCODED_ARGNUM_POS      24U

/**
   Message argument number mask
 */
#define LOG_ENCODED_ARGNUM_MASK     0x0FU

/**
   Extract string number from the ::encoded_parameters

   @param[in] encoded_parameters Encoded log message parameters

   @return String number
 */
atlk_inline uint32_t
log_string_number_get(uint32_t encoded_parameters)
{
  return encoded_parameters &  ((1UL << LOG_ENCODED_STRING_ID_BITS) - 1UL);
}

/**
   Extract file number from the ::encoded_parameters

   @param[in] encoded_parameters Encoded log message parameters

   @return File number
 */
atlk_inline uint32_t
log_file_number_get(uint32_t encoded_parameters)
{
  return (encoded_parameters >> LOG_ENCODED_STRING_ID_BITS) & ((1UL << LOG_ENCODED_STRING_ID_BITS) - 1UL);
}

/**
   Extract number of arguments from the ::encoded_parameters

   @param[in] encoded_parameters Encoded log message parameters

   @return Number of arguments
 */
atlk_inline uint8_t
log_argnum_get(uint32_t encoded_parameters)
{
  return (uint8_t)((encoded_parameters >> LOG_ENCODED_ARGNUM_POS) & LOG_ENCODED_ARGNUM_MASK);
}

/**
   Extract message log level from the ::encoded_parameters

   @param[in] encoded_parameters Encoded log message parameters

   @return Message log level
 */
atlk_inline uint8_t
log_loglevel_get(uint32_t encoded_parameters)
{
  return (uint8_t)((encoded_parameters >> LOG_ENCODED_LOGLEVEL_POS) & LOG_ENCODED_LOGLEVEL_MASK);
}

/** Remote LOG header structure */
typedef remote_struct {
  /** Remote message ID */
  uint32_t message_id;
} remote_log_request_header_t;

REMOTE_CHECK_DATA_SIZE(remote_log_request_header_t);

/** Remote LOG response header structure */
typedef remote_struct {
  /** Return code */
  uint32_t return_code;
} remote_log_response_header_t;

REMOTE_CHECK_DATA_SIZE(remote_log_response_header_t);

/** Remote LOG version request */
typedef remote_struct {
  /** Remote LOG header */
  remote_log_request_header_t request_header;
} remote_log_version_request_t;

REMOTE_CHECK_DATA_SIZE(remote_log_version_request_t);

/** Remote LOG version response */
typedef remote_struct {
  /** Remote LOG version */
  uint32_t version[REMOTE_LOG_VERSION_ELEMENTS];
} remote_log_version_response_t;

REMOTE_CHECK_DATA_SIZE(remote_log_version_response_t);

#endif /* _REMOTE_LOG_PROTOCOL_H */
