/** Copyright (C) 2019 Autotalks Ltd. */
#ifndef _REMOTE_HASH_PROTOCOL
#define _REMOTE_HASH_PROTOCOL

#include "remote_defs.h"
#include <atlk/hash.h>

/**
   @file
   Remote HASH header file,
   for common structures between host and device.
*/

/* HASH digest maximum size */
#define REMOTE_HASH_DIGEST_SIZE_MAX 48

/** HASH request type */
typedef enum {
  /** Remote HASH init request */
  REMOTE_HASH_REQUEST_TYPE_INIT = 0,

  /** Remote HASH update request */
  REMOTE_HASH_REQUEST_TYPE_UPDATE,

  /** Remote HASH final request */
  REMOTE_HASH_REQUEST_TYPE_FINAL,

  /** Remote HASH reset request */
  REMOTE_HASH_REQUEST_TYPE_RESET,

  /** Remote HASH compute request */
  REMOTE_HASH_REQUEST_TYPE_COMPUTE,

  /** Remote HASH asynchronous request */
  REMOTE_HASH_REQUEST_TYPE_ASYNC_REQUEST,

  /** Remote HASH max */
  REMOTE_HASH_REQUEST_TYPE_MAX
} remote_hash_request_type_t;

/** Sha asynchronous request sub type */
typedef enum {
  /** Remote HASH asynchronous compute request */
  REMOTE_HASH_REQUEST_SUB_TYPE_COMPUTE,

  /** Invalid remote HASH sub type */
  REMOTE_HASH_REQUEST_SUB_TYPE_INVALID,
} remote_hash_request_sub_type_t;

/** HASH algorithm */
typedef enum {
  /** SHA_256 */
  REMOTE_HASH_ALGORITHM_SHA_256 = 0,

  /** SHA_384 */
  REMOTE_HASH_ALGORITHM_SHA_384,

  /** Max HASH algorithm */
  REMOTE_HASH_ALGORITHM_MAX
} remote_hash_algorithm_t;

/** HASH request header */
typedef remote_struct {
  /** HASH request type */
  uint16_t request_type;
  /** Padding to 4 byte alignment */
  uint8_t padding[2];
} remote_hash_request_header_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_request_header_t);

/** HASH response header */
typedef remote_struct {
  /** HASH result code */
  uint8_t result;
  /** Padding to 4 byte alignment */
  uint8_t padding[3];
} remote_hash_response_header_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_response_header_t);

/** HASH init request */
typedef remote_struct {
  /** HASH data total length */
  uint64_t total_length;

  /** HASH algorithm */
  uint16_t algorithm;

  uint8_t padding[2];
} remote_hash_init_request_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_init_request_t);

/** HASH init response */
typedef remote_struct {
  /** HASH request ID */
  uint32_t context;
} remote_hash_init_response_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_init_response_t);

/** HASH update request */
typedef remote_struct {
  /** HASH request ID */
  uint32_t context;

  /** HASH data chunk length */
  uint32_t chunk_length;
} remote_hash_update_request_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_update_request_t);

/** HASH final request */
typedef remote_struct {
  /** HASH request ID */
  uint32_t context;
} remote_hash_final_request_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_final_request_t);

/** HASH compute request */
typedef remote_struct {
  /** HASH data total length */
  uint64_t total_length;

  /** HASH algorithm */
  uint16_t algorithm;

  uint8_t padding[2];
} remote_hash_compute_request_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_compute_request_t);

/** HASH compute response */
typedef remote_struct {
  /** HASH result digest */
  uint8_t digest[REMOTE_HASH_DIGEST_SIZE_MAX];

  /** HASH result digest length */
  uint8_t digest_length;

  uint8_t padding[3];
} remote_hash_compute_response_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_compute_response_t);

/** HASH asynchronous request context */
typedef remote_struct {
  /** HASH asynchronous request socket ID */
  uint32_t socket_id;

  /** HASH asynchronous request ID */
  uint32_t request_id;

  /** HASH asynchronous request sub type */
  uint8_t sub_type;

  uint8_t padding[3];
} remote_hash_async_request_context_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_async_request_context_t);

/** HASH asynchronous request */
typedef remote_struct {
  /** HASH request context */
  remote_hash_async_request_context_t request_context;

  /** HASH sub type specific parameters */
  remote_union {
    /** HASH asynchronous compute request parameters */
    remote_hash_compute_request_t compute_params;
  } request_params;
} remote_hash_async_request_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_async_request_t);

/** HASH asynchronous response */
typedef remote_struct {
  /** HASH original request context */
  remote_hash_async_request_context_t response_context;

  /** HASH sub type specific parameters */
  remote_union {
    /** HASH asynchronous compute response parameters */
    remote_hash_compute_response_t compute_params;
  } response_params;
} remote_hash_async_response_t;

REMOTE_CHECK_DATA_SIZE(remote_hash_async_response_t);

#endif /* _REMOTE_HASH_PROTOCOL */
