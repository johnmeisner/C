/* Copyright (C) 2016-2019 Autotalks Ltd. */
#ifndef _REMOTE_V2X_EXTENDED_H
#define _REMOTE_V2X_EXTENDED_H

#include "remote_defs.h"
#include <atlk/sdk.h>

/**
   @file
   Remote V2X extended header file, for common structures
   between host and device.
*/

#define V2X_EXTENDED_PARAM_BW_NA          0xFF
#define V2X_EXTENDED_PARAM_MCS_NA         0xFF
#define V2X_EXTENDED_PARAM_FORMAT_NA      0xFF
#define V2X_EXTENDED_PARAM_RTSCTS_NA      0xFF
#define V2X_EXTENDED_PARAM_RATE_FLAGS_NA  0xFF
#define V2X_EXTENDED_PARAM_RING_NA        0xFF

typedef enum {
  /** Use MCS 0 regardless of bandwidth */
  REMOTE_V2X_EXTENDED_DATARATE_MCS_0 = 0,
  /** Use MCS 1 regardless of bandwidth */
  REMOTE_V2X_EXTENDED_DATARATE_MCS_1,
  /** Use MCS 2 regardless of bandwidth */
  REMOTE_V2X_EXTENDED_DATARATE_MCS_2,
  /** Use MCS 3 regardless of bandwidth */
  REMOTE_V2X_EXTENDED_DATARATE_MCS_3,
  /** Use MCS 4 regardless of bandwidth */
  REMOTE_V2X_EXTENDED_DATARATE_MCS_4,
  /** Use MCS 5 regardless of bandwidth */
  REMOTE_V2X_EXTENDED_DATARATE_MCS_5,
  /** Use MCS 6 regardless of bandwidth */
  REMOTE_V2X_EXTENDED_DATARATE_MCS_6,
  /** Use MCS 7 regardless of bandwidth */
  REMOTE_V2X_EXTENDED_DATARATE_MCS_7,
  /** Use MCS 8 regardless of bandwidth */
  REMOTE_V2X_EXTENDED_DATARATE_MCS_8,
  /** Use MCS 9 regardless of bandwidth */
  REMOTE_V2X_EXTENDED_DATARATE_MCS_9,

  /** Data rate is N/A */
  REMOTE_V2X_EXTENDED_DATARATE_MCS_NA,
} remote_v2x_extended_datarate_t;

/** V2X extended send parameters */
typedef remote_struct {
  /** Tx parameters - (For PGEN, see dsp_defs.h flags *_TX_F_*) */
  uint32_t tx_params_flags;

  /** Rate flags (For PGEN, see WLAN_RATE_F_* definitions) */
  uint16_t rate_flags;

  /** Rate format (For PGEN, see dsp_defs.h: wifi_format_t) */
  uint8_t format;

  /**
     Request to Send / Clear to Send (RTS/CTS)
     Modulation and Coding Scheme (MCS) (For PGEN)
  */
  uint8_t rtscts_mcs;

  /** Request to Send / Clear to Send (RTS/CTS) format (For PGEN) */
  uint8_t rtscts_format;

  /** MAC Protocol Data Unit (MPDU) spacing in units of 1/4 usec */
  uint8_t mpdu_spacing_0_25_usec;

  /** Bandwidth */
  uint8_t bw;

  /** Modulation and Coding Scheme (MCS) */
  uint8_t mcs;

  /**
     Maximum Aggregate MAC Protocol Data Unit (A-MPDU) length exponent
     for a target station, as described in 802.11-2016/9.4.2.56.3, Table 9-163.
  */
  uint8_t sta_ampdu_factor;

  /* This field allows to override a ring, while filling QoS header properly */
  uint8_t override_ring;

  /* Packet retries */
  uint8_t retries;

  uint8_t padding[1];
} remote_v2x_extended_send_params_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_extended_send_params_t);

#endif /* _REMOTE_V2X_EXTENDED_H */
