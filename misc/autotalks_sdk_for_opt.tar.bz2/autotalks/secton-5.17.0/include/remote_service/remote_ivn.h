/* Copyright (C) 2017 - 2019 Autotalks Ltd. */
#ifndef _REMOTE_IVN_PROTOCOL_H
#define _REMOTE_IVN_PROTOCOL_H

#include "remote_defs.h"
#include "remote_counters.h"

/**
   @file
   Define IVN common parameters to Host and Device.
*/

#define REMOTE_IVN_SEND_REQUEST_INIT {      \
  .device_id = 0,                           \
  .can_msg_id = 0,                          \
  .data_length = 0,                         \
}

#define REMOTE_IVN_STATS_INIT {             \
  .device_stats = {0},                      \
  .m3_stats = {0}                           \
  .controller_stats = {0},                  \
}

#define REMOTE_IVN_FILTER_TBL_INIT {        \
  .filters_num = IVN_FILTER_ACCEPT_ALL,     \
  .filters_type = IVN_FILTER_TYPE_SW,       \
}

#define REMOTE_IVN_FILTER_TBL_SET_INIT {    \
  .device_id = 0,                           \
  .filter_tbl = REMOTE_IVN_FILTER_TBL_INIT, \
}

#define REMOTE_IVN_FILTER_TBL_GET_INIT {    \
  .device_id = 0,                           \
}

/** IVN message ID types */
typedef enum {
  /** IVN send request  */
  REMOTE_IVN_MSG_ID_SEND_REQ = 0,

  /** IVN receive indication */
  REMOTE_IVN_MSG_ID_RECV_IND,

  /** IVN device configure request */
  REMOTE_IVN_MSG_ID_DEVICE_CONFIG,

  /** IVN device statistics request */
  REMOTE_IVN_MSG_ID_DEVICE_STATS,

  /** IVN filter table set request */
  REMOTE_IVN_MSG_ID_FILTER_TBL_SET,

  /** IVN filter table get request */
  REMOTE_IVN_MSG_ID_FILTER_TBL_GET,

  /** IVN protocol get request */
  REMOTE_IVN_MSG_ID_PROTOCOL_GET
} remote_ivn_msg_id_t;

/** IVN header structure */
typedef remote_struct {
  /** IVN request type */
  uint16_t message_id;
  /** Padding to 4 byte alignment */
  uint8_t padding[2];
} remote_ivn_header_t;

REMOTE_CHECK_DATA_SIZE(remote_ivn_header_t);

/** IVN send request */
typedef remote_struct {
  /** IVN CAN message ID */
  uint32_t can_msg_id;

  /** IVN message length */
  uint32_t data_length;

  /** IVN device channel */
  uint8_t device_id;

  uint8_t padding[3];

  /** data comes here */
} remote_ivn_send_recv_common_t;

REMOTE_CHECK_DATA_SIZE(remote_ivn_send_recv_common_t);

/** IVN send request */
typedef remote_ivn_send_recv_common_t remote_ivn_send_request_t;

/** IVN reception indication */
typedef remote_ivn_send_recv_common_t remote_ivn_rx_indication_t;

/** IVN device configuration structure */
typedef remote_struct {
  /** Device baud rate */
  uint32_t  baud_rate;

  /** IVN device identifire */
  uint8_t device_id;

  uint8_t padding[3];
} remote_ivn_device_open_request_t;

REMOTE_CHECK_DATA_SIZE(remote_ivn_device_open_request_t);

/** IVN device statistics */
typedef remote_struct {
  /** IVN device identifire */
  uint8_t device_id;

  uint8_t padding[3];
} remote_ivn_device_stats_request_t;

REMOTE_CHECK_DATA_SIZE(remote_ivn_device_stats_request_t);

/** IVN statistics */
typedef remote_struct {
  /** IVN device statistics */
  remote_atlk_counters_t device_stats;

  /** IVN M3 statistics */
  remote_atlk_counters_t m3_stats;

  /** IVN controller statistics */
  remote_atlk_counters_t controller_stats;
} remote_ivn_stats_t;

REMOTE_CHECK_DATA_SIZE(remote_ivn_stats_t);

/**
   IVN acceptance filter table
   White list approach: IVN filter table defines acceptance filters.

   @note If value of filter_num field is IVN_FILTER_ACCEPT_ALL, all packets are accepted
*/
typedef remote_struct {
  /** Filters SW/HW type */
  uint8_t filters_type;

  /** Number of filters */
  uint8_t filters_num;

  uint8_t padding[2];

  /** Flexible filters array */
  uint32_t filters[];
} remote_ivn_filter_tbl_t;

REMOTE_CHECK_DATA_SIZE(remote_ivn_filter_tbl_t);

/** IVN device filter table set */
typedef remote_struct {
  /** IVN device identifier */
  uint8_t device_id;

  uint8_t padding[3];

  /** Filters table */
  remote_ivn_filter_tbl_t filter_tbl;
} remote_ivn_filter_tbl_set_t;

REMOTE_CHECK_DATA_SIZE(remote_ivn_filter_tbl_set_t);

/** IVN device filter table get */
typedef remote_struct {
  /** IVN device identifier */
  uint8_t device_id;

  uint8_t padding[3];
} remote_ivn_filter_tbl_get_t;

REMOTE_CHECK_DATA_SIZE(remote_ivn_filter_tbl_get_t);

/** IVN protocol */
typedef remote_struct {
  uint8_t protocol;

  uint8_t padding[3];
} remote_ivn_protocol_t;

REMOTE_CHECK_DATA_SIZE(remote_ivn_protocol_t);

/** IVN device protocol get */
typedef remote_struct {
  /** IVN device identifier */
  uint8_t device_id;

  uint8_t padding[3];
} remote_ivn_protocol_get_t;

#endif /** _REMOTE_IVN_PROTOCOL_H */
