/* Copyright (C) 2021-2022 Autotalks Ltd. */
#ifndef _REMOTE_COMPENSATOR_H
#define _REMOTE_COMPENSATOR_H

/**
  @file
  Remote compensator generic data definition
*/

#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <stdint.h>
#endif /* __KERNEL__ */

/** Maximum size of compensator data */
#define REMOTE_COMPENSATOR_DATA_SIZE_MAX 8

/** UART data for Generic Compensator to be sent during packet TX */
typedef struct remote_compensator_data {
  uint8_t data[REMOTE_COMPENSATOR_DATA_SIZE_MAX];
  uint8_t len;
  uint8_t reserved;
} remote_compensator_data_t;

#endif /* _REMOTE_COMPENSATOR_H */
