/* Copyright (C) 2016 Autotalks Ltd. */
#ifndef _REMOTE_OBJ_PROTOCOL_H
#define _REMOTE_OBJ_PROTOCOL_H

#include "remote_defs.h"

#define REMOTE_OBJ_HEADER_T_INIT { \
  .index = 0,                      \
  .uint32_key = 0,                 \
  .value_type = 0,                 \
}

#define REMOTE_OBJ_INIT {          \
  .value = 0,                      \
}
#define REMOTE_OBJ_OPAQUE_T_INIT { \
  .size = 0,                       \
  .data = {0}                      \
}

typedef enum {
  REMOTE_OBJ_TYPE_INT32 = 0U,
  REMOTE_OBJ_TYPE_UINT32,
  REMOTE_OBJ_TYPE_INT64,
  REMOTE_OBJ_TYPE_UINT64,
  REMOTE_OBJ_TYPE_OPAQUE,
  REMOTE_OBJ_TYPE_EMPTY,
} remote_obj_type_t;

/* Common for all requests */
typedef remote_struct {
  uint32_t index;
  uint32_t uint32_key;
  uint16_t value_type;
  /* Padding for 32bits alignment - done since this struct is added separately to the packet prior to the payload struct*/
  uint8_t padding[2];
} remote_obj_header_t;

REMOTE_CHECK_DATA_SIZE(remote_obj_header_t);

typedef remote_struct {
  int32_t value;
} remote_obj_int32_t;

REMOTE_CHECK_DATA_SIZE(remote_obj_int32_t);

typedef remote_struct {
  uint32_t value;
} remote_obj_uint32_t;

REMOTE_CHECK_DATA_SIZE(remote_obj_uint32_t);

typedef remote_struct {
  int64_t value;
} remote_obj_int64_t;

REMOTE_CHECK_DATA_SIZE(remote_obj_int64_t);

typedef remote_struct {
  uint64_t value;
} remote_obj_uint64_t;

REMOTE_CHECK_DATA_SIZE(remote_obj_uint64_t);

typedef remote_struct {
  uint32_t size;
  uint8_t data[0];
} remote_obj_opaque_t;

REMOTE_CHECK_DATA_SIZE(remote_obj_opaque_t);

#endif /* _REMOTE_OBJ_PROTOCOL_H */
