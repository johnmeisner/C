/** Copyright (C) 2017 - 2019 Autotalks Ltd. */
#ifndef _REMOTE_EHSM_PROTOCOL_H
#define _REMOTE_EHSM_PROTOCOL_H

#include "remote_defs.h"

/**
   @file
   Define common eHSM structures for host and device
*/

/** eHSM scalar octet parameter maximum size in bytes */
#define REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE   64U

/** eHSM ECC blob parameter maximum size in bytes */
#define REMOTE_EHSM_ECC_BLOB_SIZE          (48U + REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE)

/** eHSM blob parameter maximum size in bytes */
#define REMOTE_EHSM_STORAGE_BLOB_SIZE       48U

/** eHSM Symmetric key parameter maximum size in bytes */
#define REMOTE_EHSM_SYMMETRIC_KEY_SIZE      32U

/** eHSM Symmetric blob parameter maximum size in bytes */
#define REMOTE_EHSM_SYMMETRIC_BLOB_SIZE     80U

/** eHSM Symmetric tag size in bytes */
#define REMOTE_EHSM_SYMMETRIC_TAG_SIZE      16U

/** eHSM KDF parameter maximum size in bytes */
#define REMOTE_EHSM_KDF_PARAM_MAX_SIZE      128U

/** eHSM ECIES key maximum size in bytes */
#define REMOTE_EHSM_ECIES_KEY_MAX_SIZE      128U

/** eHSM ECIES tag minimum size in bytes */
#define REMOTE_EHSM_ECIES_TAG_MIN_SIZE      4U

/** eHSM ECIES tag maximum size in bytes */
#define REMOTE_EHSM_ECIES_TAG_MAX_SIZE      64U

/** eHSM ECIES data maximum size in bytes */
#define REMOTE_EHSM_ECIES_DATA_MAX_SIZE     64U

/** eHSM random data maximum size in bytes */
#define REMOTE_EHSM_RANDOM_DATA_MAX_SIZE    512U

/** eHSM associated data (AAD) maximum size in bytes */
#define REMOTE_EHSM_ASSOCIATED_DATA_MAX_SIZE 256U

/** eHSM plaintext / data maximum size in bytes */
#define REMOTE_EHSM_DATA_MAX_SIZE           1024U

/** eHSM MAC blob parameter maximum size in bytes */
#define REMOTE_EHSM_MAC_BLOB_SIZE           176U

/** eHSM MAC key maximum size in bytes */
#define REMOTE_EHSM_MAC_KEY_MAX_SIZE        128U

/** eHSM MAC tag maximum size in bytes */
#define REMOTE_EHSM_MAC_TAG_MAX_SIZE        64U

/** Used at secure HDIF when master key is generated */
#define REMOTE_EHSM_SECURE_HDIF_MASTER_KEY_MAGIC_NUMBER_SIZE   16U

#define REMOTE_EHSM_SECURE_HDIF_MASTER_KEYS_BLOB_SIZE  REMOTE_EHSM_SECURE_HDIF_MASTER_KEY_MAGIC_NUMBER_SIZE + \
                                                       REMOTE_EHSM_STORAGE_BLOB_SIZE + \
                                                       REMOTE_EHSM_SYMMETRIC_BLOB_SIZE + \
                                                       REMOTE_EHSM_SYMMETRIC_BLOB_SIZE \

/** eHSM request header */
typedef remote_struct {
  /** eHSM message type */
  uint32_t message_id;
} remote_ehsm_header_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_header_t);

/** eHSM response header */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;
} remote_ehsm_error_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_error_t);

/** Blob remote cipher */
typedef enum {
  /** Blob Cipher AES */
  REMOTE_EHSM_BLOB_INFO_CIPHER_AES = 0,

  /** Blob Cipher SM4 */
  REMOTE_EHSM_BLOB_INFO_CIPHER_SM4 = 1

} remote_ehsm_blob_info_cipher_type_t;

/** Blob remote family type */
typedef enum {
  /** Blob type V2X */
  REMOTE_EHSM_BLOB_INFO_FAMILY_V2X = 0,

  /** Blob type Storage */
  REMOTE_EHSM_BLOB_INFO_FAMILY_STORAGE = 1,

  /** Blob type Pairing */
  REMOTE_EHSM_BLOB_INFO_FAMILY_PAIRING = 2,

  /** Blob type Symmetric */
  REMOTE_EHSM_BLOB_INFO_FAMILY_SYMMETRIC = 3,

  /** Blob type Importing */
  REMOTE_EHSM_BLOB_INFO_FAMILY_IMPORTING = 4,

  /** Blob type MAC */
  REMOTE_EHSM_BLOB_INFO_FAMILY_MAC = 5,

} remote_ehsm_blob_info_family_type_t;

/** AES Blob mode */
typedef enum {
  /** AES Blob BEK CCM auth only */
  REMOTE_EHSM_BLOB_INFO_AES_BEK_CCM_AUTH_ONLY = 0,

  /** AES Blob BEK CCM authenticated encryption */
  REMOTE_EHSM_BLOB_INFO_AES_BEK_CCM_AUTH_ENCRYPTION = 1,

} remote_ehsm_blob_info_aes_bek_mode_t;

/** Blob remote V2X suite type */
typedef enum {
  /** User defined domain with SHA 256 */
  REMOTE_EHSM_BLOB_INFO_ECC_USER_DEFINED_DOMAIN_SHA_256 = 0,

  /** User defined domain with SHA 384 */
  REMOTE_EHSM_BLOB_INFO_ECC_USER_DEFINED_DOMAIN_SHA_384,

  /** User defined domain with SHA 512 */
  REMOTE_EHSM_BLOB_INFO_ECC_USER_DEFINED_DOMAIN_SHA_512,

  /** NIST P-256 with SHA 256 */
  REMOTE_EHSM_BLOB_INFO_ECC_CURVE_NIST_P256,

  /** NIST P-384 with SHA 384 */
  REMOTE_EHSM_BLOB_INFO_ECC_CURVE_NIST_P384,

  /** Brainpool P-256t1 */
  REMOTE_EHSM_BLOB_INFO_ECC_CURVE_BRAINPOOL_P256t1,

  /** Brainpool P-384t1 */
  REMOTE_EHSM_BLOB_INFO_ECC_CURVE_BRAINPOOL_P384t1,

  /** Brainpool P-256r1 */
  REMOTE_EHSM_BLOB_INFO_ECC_CURVE_BRAINPOOL_P256r1,

  /** Brainpool P-384r1 */
  REMOTE_EHSM_BLOB_INFO_ECC_CURVE_BRAINPOOL_P384r1,

  /** NIST P-224 with SHA 224 */
  REMOTE_EHSM_BLOB_INFO_ECC_CURVE_NIST_P224,

  /** SM2 2010 with SM3-256 */
  REMOTE_EHSM_BLOB_INFO_ECC_CURVE_SM2_2010,

  /** SM2 2012 with SM3-256 */
  REMOTE_EHSM_BLOB_INFO_ECC_CURVE_SM2_2012,

  /** Invalid magic number (must be just one byte) */
  REMOTE_EHSM_BLOB_INFO_ECC_CURVE_INVALID = 0xff

} remote_ehsm_blob_info_v2x_suite_type_t;

/** Embedded HSM blob info */
typedef remote_union
{
    remote_struct
    {
      /** Restriction */
      uint8_t restriction;

      /** Mode/Algorithm */
      uint8_t mode_algorithm;

      /** Suite/Size */
      uint8_t suite_size;

      /** Family */
      uint8_t family :7;

      /** Blob Cipher */
      uint8_t cipher :1;
    } fields;
    uint32_t value;
} remote_ehsm_blob_info_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_blob_info_t);

/** V2X API */

/** eHSM ECC key pair generate request */
typedef remote_struct {
  /** Blob info */
  remote_ehsm_blob_info_t blob_info;
} remote_ehsm_ecc_key_pair_generate_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecc_key_pair_generate_req_t);

/** eHSM ECC key pair generate response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Private key blob */
  uint8_t blob[REMOTE_EHSM_ECC_BLOB_SIZE];

  /** ECC x coordinate of public key */
  uint8_t public_x[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** ECC y coordinate of public key */
  uint8_t public_y[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

} remote_ehsm_ecc_key_pair_generate_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecc_key_pair_generate_rsp_t);

/** eHSM ECC key pair import request */
typedef remote_struct {
  /** Private key value */
  uint8_t private_key[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;
} remote_ehsm_ecc_key_pair_import_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecc_key_pair_import_req_t);

/** eHSM ECC key pair import response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Private key blob */
  uint8_t blob[REMOTE_EHSM_ECC_BLOB_SIZE];

  /** ECC x coordinate of public key */
  uint8_t public_x[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** ECC y coordinate of public key */
  uint8_t public_y[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];
} remote_ehsm_ecc_key_pair_import_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecc_key_pair_import_rsp_t);

/** eHSM ECDSA signature generate request */
typedef remote_struct {
  /** Private key blob */
  uint8_t blob[REMOTE_EHSM_ECC_BLOB_SIZE];

  /** Message to digest */
  uint8_t message_digest[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

 /** Blob info */
  remote_ehsm_blob_info_t blob_info;
} remote_ehsm_ecdsa_signature_generate_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecdsa_signature_generate_req_t);

/** eHSM ECDSA signature generate response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** ECDSA signature R x coordinate */
  uint8_t ecdsa_sign_rx[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** ECDSA signature R y coordinate */
  uint8_t ecdsa_sign_ry[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** ECDSA signature r scalar */
  uint8_t ecdsa_sign_r[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** ECDSA signature s scalar */
  uint8_t ecdsa_sign_s[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];
} remote_ehsm_ecdsa_signature_generate_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecdsa_signature_generate_rsp_t);

/** eHSM ECIES decryption key generate request */
typedef remote_struct {
  /** Key derivation parameter */
  uint8_t kdf[REMOTE_EHSM_KDF_PARAM_MAX_SIZE];

  /** Private key blob */
  uint8_t blob[REMOTE_EHSM_ECC_BLOB_SIZE];

  /** ECC x coordinate of public key */
  uint8_t public_x[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** ECC y coordinate of public key */
  uint8_t public_y[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** ECIES key size in bytes */
  uint32_t kdf_size;

  /** Request decryption key size */
  uint32_t decryption_key_size;
} remote_ehsm_ecies_decryption_key_generate_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecies_decryption_key_generate_req_t);

/** eHSM ECIES decryption key generate response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Derived ECIES key */
  uint8_t ecies[REMOTE_EHSM_ECIES_KEY_MAX_SIZE];
} remote_ehsm_ecies_decryption_key_generate_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecies_decryption_key_generate_rsp_t);

/** eHSM ECIES encrypt request */
typedef remote_struct {
  /** Plaintext to encrypt */
  uint8_t plaintext[REMOTE_EHSM_ECIES_DATA_MAX_SIZE];

  /** Key derivation parameter */
  uint8_t kdf_param[REMOTE_EHSM_KDF_PARAM_MAX_SIZE];

  /** ECC x coordinate of peer public key */
  uint8_t peer_public_x[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** ECC y coordinate of peer public key */
  uint8_t peer_public_y[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** ECIES key size in bytes */
  uint32_t kdf_param_size;

  /** Shared secret size */
  uint32_t shared_secret_size;

  /** Size of the plaintext in bytes */
  uint32_t plaintext_size;

  /** Size of the tag in bytes */
  uint32_t tag_size;
} remote_ehsm_ecies_encrypt_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecies_encrypt_req_t);

/** eHSM ECIES encrypt response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Ciphertext */
  uint8_t ciphertext[REMOTE_EHSM_ECIES_DATA_MAX_SIZE];

  /** Ephemeral public key X coordinate */
  uint8_t ephemeral_public_key_x[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** Ephemeral public key Y coordinate */
  uint8_t ephemeral_public_key_y[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** Message authentication tag */
  uint8_t tag[REMOTE_EHSM_ECIES_TAG_MAX_SIZE];
} remote_ehsm_ecies_encrypt_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecies_encrypt_rsp_t);

/** eHSM ECIES decrypt request */
typedef remote_struct {
  /** Ciphertext to decrypt */
  uint8_t ciphertext[REMOTE_EHSM_ECIES_DATA_MAX_SIZE];

  /** Key derivation parameter */
  uint8_t kdf_param[REMOTE_EHSM_KDF_PARAM_MAX_SIZE];

  /** Private key blob */
  uint8_t blob[REMOTE_EHSM_ECC_BLOB_SIZE];

  /** Ephemeral public key X coordinate */
  uint8_t ephemeral_public_key_x[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** Ephemeral public key Y coordinate */
  uint8_t ephemeral_public_key_y[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** Message authentication tag */
  uint8_t tag[REMOTE_EHSM_ECIES_TAG_MAX_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** ECIES key size in bytes */
  uint32_t kdf_param_size;

  /** Shared secret size */
  uint32_t shared_secret_size;

  /** Size of the ciphertext in bytes */
  uint32_t ciphertext_size;

  /** Size of the tag in bytes */
  uint32_t tag_size;
} remote_ehsm_ecies_decrypt_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecies_decrypt_req_t);

/** eHSM ECIES decrypt response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Plaintext */
  uint8_t plaintext[REMOTE_EHSM_ECIES_DATA_MAX_SIZE];
} remote_ehsm_ecies_decrypt_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecies_decrypt_rsp_t);

/** eHSM ECC private key multiply-add request */
typedef remote_struct {
  /** Private key blob */
  uint8_t blob[REMOTE_EHSM_ECC_BLOB_SIZE];

  /** Scalar add */
  uint8_t ecc_scalar_addend[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** Scalar multiplier */
  uint8_t ecc_scalar_mul[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** Request blob info */
  remote_ehsm_blob_info_t blob_info;
} remote_ehsm_ecc_private_key_mul_add_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecc_private_key_mul_add_req_t);

/** eHSM ECC private key multiply-add response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Private key blob */
  uint8_t blob[REMOTE_EHSM_ECC_BLOB_SIZE];

  /** Response public x coordinate */
  uint8_t public_x[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** Response public y coordinate */
  uint8_t public_y[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;
} remote_ehsm_ecc_private_key_mul_add_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecc_private_key_mul_add_rsp_t);

/** eHSM ECC public key derive request */
typedef remote_struct {
  /** Private key blob */
  uint8_t blob[REMOTE_EHSM_ECC_BLOB_SIZE];

  /** Request blob info */
  remote_ehsm_blob_info_t blob_info;
} remote_ehsm_ecc_public_key_derive_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecc_public_key_derive_req_t);

/** eHSM ECC public key derive response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** ECC x coordinate of public key */
  uint8_t public_x[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];

  /** ECC y coordinate of public key */
  uint8_t public_y[REMOTE_EHSM_ECC_SCALAR_OCTET_SIZE];
} remote_ehsm_ecc_public_key_derive_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_ecc_public_key_derive_rsp_t);

/** Random Number Generator API */

/** eHSM random generate request */
typedef remote_struct {
  /** Prediction resistance */
  uint32_t prediction_resistance;

  /** Number of random words to generate */
  uint32_t rand_words;
} remote_ehsm_random_generate_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_random_generate_req_t);

/** eHSM random generate response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Random buffer */
  uint8_t random[REMOTE_EHSM_RANDOM_DATA_MAX_SIZE];
} remote_ehsm_random_generate_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_random_generate_rsp_t);

/** Diagnostics API */

/** eHSM information struct */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Firmware version */
  uint32_t version;

  /** ROM integrity test counter */
  uint32_t rom_integrity_test_counter;

  /** Tamper counter */
  uint32_t tamper_counter;

  /** Lifecycle status */
  uint32_t lifecycle_status;

  /** Cryptographic key management status */
  uint32_t cryptographic_key_management_status;

  /** CSK status */
  uint32_t csk_status;

  /** System status */
  uint32_t system_status;

  /** SHE status */
  uint8_t she_status;

  /** OTP status */
  uint8_t otp_status;

  /** FIPS mode */
  uint8_t fips_mode;

  uint8_t padding[1];
} remote_ehsm_information_get_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_information_get_rsp_t);

/** eHSM CSK generate response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;
} remote_ehsm_diag_csk_generate_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_diag_csk_generate_rsp_t);

/** OTP API */

/** eHSM block ECC enable request */
typedef remote_struct {
  /** Index of requested block */
  uint32_t block_offset;
} remote_ehsm_otp_block_ecc_enable_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_otp_block_ecc_enable_req_t);

/** eHSM block ECC enable response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;
} remote_ehsm_otp_block_ecc_enable_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_otp_block_ecc_enable_rsp_t);

/** eHSM word type read request */
typedef remote_struct {
  /** Word offset */
  uint32_t word_offset;
} remote_ehsm_otp_word_type_read_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_otp_word_type_read_req_t);

/** eHSM word type read response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Word type */
  uint32_t word_type;
} remote_ehsm_otp_word_type_read_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_otp_word_type_read_rsp_t);

/** eHSM word read request */
typedef remote_struct {
  /** Offset of requested word  */
  uint32_t word_offset;
} remote_ehsm_otp_word_read_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_otp_word_read_req_t);

/** eHSM word read response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** The word value */
  uint32_t word;
} remote_ehsm_otp_word_read_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_otp_word_read_rsp_t);

/** eHSM word write request */
typedef remote_struct {
  /** Offset of requested word */
  uint32_t word_offset;

  /** The word value to write */
  uint32_t word;
} remote_ehsm_otp_word_write_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_otp_word_write_req_t);

/** eHSM word write response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;
} remote_ehsm_otp_word_write_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_otp_word_write_rsp_t);

/** eHSM word lock request */
typedef remote_struct {
  /** Offset of requested word */
  uint32_t word_offset;
} remote_ehsm_otp_word_lock_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_otp_word_lock_req_t);

/** eHSM word lock response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;
} remote_ehsm_otp_word_lock_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_otp_word_lock_rsp_t);

/** Storage API */

/** eHSM MAC generate request */
typedef remote_struct {
  /** Message to compute */
  uint8_t data[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Message size in bytes */
  uint32_t data_size;
} remote_ehsm_storage_mac_generate_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_storage_mac_generate_req_t);

/** eHSM MAC generate response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Message authentication tag */
  uint8_t blob[REMOTE_EHSM_STORAGE_BLOB_SIZE];
} remote_ehsm_storage_mac_generate_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_storage_mac_generate_rsp_t);

/** eHSM MAC verify request */
typedef remote_struct {
  /** Message to compute MAC */
  uint8_t data[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Message authentication tag */
  uint8_t blob[REMOTE_EHSM_STORAGE_BLOB_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Message size in bytes */
  uint32_t data_size;
} remote_ehsm_storage_mac_verify_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_storage_mac_verify_req_t);

/** eHSM MAC verify response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;
} remote_ehsm_storage_mac_verify_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_storage_mac_verify_rsp_t);

/** eHSM authenticate and encrypt request */
typedef remote_struct {
  /** Plaintext to encrypt */
  uint8_t plaintext[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Size of the plaintext in bytes */
  uint32_t plaintext_size;
} remote_ehsm_storage_auth_and_encrypt_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_storage_auth_and_encrypt_req_t);

/** eHSM authenticate and encrypt response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Encrypt ciphertext */
  uint8_t ciphertext[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Message authentication tag */
  uint8_t blob[REMOTE_EHSM_STORAGE_BLOB_SIZE];
} remote_ehsm_storage_auth_and_encrypt_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_storage_auth_and_encrypt_rsp_t);

/** eHSM authenticate and decrypt request */
typedef remote_struct {
  /** Ciphertext to decrypt */
  uint8_t ciphertext[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Message authentication tag */
  uint8_t blob[REMOTE_EHSM_STORAGE_BLOB_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Size of the ciphertext in bytes */
  uint32_t ciphertext_size;
} remote_ehsm_storage_auth_and_decrypt_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_storage_auth_and_decrypt_req_t);

/** eHSM authenticate and decrypt response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Decrypt plaintext */
  uint8_t plaintext[REMOTE_EHSM_DATA_MAX_SIZE];
} remote_ehsm_storage_auth_and_decrypt_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_storage_auth_and_decrypt_rsp_t);

/** eHSM symmetric key generate request */
typedef remote_struct {
  /** Blob info */
  remote_ehsm_blob_info_t blob_info;
} remote_ehsm_symmetric_key_generate_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_key_generate_req_t);

/** eHSM symmetric key generate response */
typedef remote_struct {
  /** Symmetric key blob */
  uint8_t blob[REMOTE_EHSM_SYMMETRIC_BLOB_SIZE];

  /** Response error code */
  uint32_t error_code;
} remote_ehsm_symmetric_key_generate_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_key_generate_rsp_t);

/** eHSM symmetric key import request */
typedef remote_struct {
  /** Symmetric key value */
  uint8_t key[REMOTE_EHSM_SYMMETRIC_KEY_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;
} remote_ehsm_symmetric_key_import_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_key_import_req_t);

/** eHSM symmetric key import response */
typedef remote_struct {
  /** Symmetric key blob */
  uint8_t blob[REMOTE_EHSM_SYMMETRIC_BLOB_SIZE];

  /** Response error code */
  uint32_t error_code;
} remote_ehsm_symmetric_key_import_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_key_import_rsp_t);

/** eHSM symmetric crypto ECB encrypt request */
typedef remote_struct {
  /** Plaintext to encrypt */
  uint8_t plaintext[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Symmetric key blob */
  uint8_t blob[REMOTE_EHSM_SYMMETRIC_BLOB_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Size of the plaintext in bytes */
  uint32_t plaintext_size;
} remote_ehsm_symmetric_ecb_encrypt_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_ecb_encrypt_req_t);

/** eHSM symmetric crypto ECB encrypt response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Ciphertext */
  uint8_t ciphertext[REMOTE_EHSM_DATA_MAX_SIZE];
} remote_ehsm_symmetric_ecb_encrypt_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_ecb_encrypt_rsp_t);

/** eHSM symmetric crypto ECB decrypt request */
typedef remote_struct {
  /** Ciphertext to decrypt */
  uint8_t ciphertext[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Symmetric key blob */
  uint8_t blob[REMOTE_EHSM_SYMMETRIC_BLOB_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Size of the ciphertext in bytes */
  uint32_t ciphertext_size;
} remote_ehsm_symmetric_ecb_decrypt_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_ecb_decrypt_req_t);

/** eHSM symmetric crypto ECB decrypt response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Plaintext */
  uint8_t plaintext[REMOTE_EHSM_DATA_MAX_SIZE];
} remote_ehsm_symmetric_ecb_decrypt_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_ecb_decrypt_rsp_t);

/** eHSM symmetric crypto CBC encrypt request */
typedef remote_struct {
  /** Plaintext to encrypt */
  uint8_t plaintext[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Symmetric key blob */
  uint8_t blob[REMOTE_EHSM_SYMMETRIC_BLOB_SIZE];

  /* Initialization Vector */
  uint8_t iv[REMOTE_EHSM_SYMMETRIC_KEY_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Size of the plaintext in bytes */
  uint32_t plaintext_size;
} remote_ehsm_symmetric_cbc_encrypt_req_t;

/** eHSM symmetric crypto CBC encrypt response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Ciphertext */
  uint8_t ciphertext[REMOTE_EHSM_DATA_MAX_SIZE];
} remote_ehsm_symmetric_cbc_encrypt_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_cbc_encrypt_rsp_t);

/** eHSM symmetric crypto CBC decrypt request */
typedef remote_struct {
  /** Ciphertext to decrypt */
  uint8_t ciphertext[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Symmetric key blob */
  uint8_t blob[REMOTE_EHSM_SYMMETRIC_BLOB_SIZE];

  /* Initialization Vector */
  uint8_t iv[REMOTE_EHSM_SYMMETRIC_KEY_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Size of the ciphertext in bytes */
  uint32_t ciphertext_size;
} remote_ehsm_symmetric_cbc_decrypt_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_cbc_decrypt_req_t);

/** eHSM symmetric crypto CBC decrypt response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Plaintext */
  uint8_t plaintext[REMOTE_EHSM_DATA_MAX_SIZE];
} remote_ehsm_symmetric_cbc_decrypt_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_cbc_decrypt_rsp_t);

/** eHSM symmetric CMAC generate request */
typedef remote_struct {
  /** Message to compute */
  uint8_t data[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Symmetric key blob */
  uint8_t blob[REMOTE_EHSM_SYMMETRIC_BLOB_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Message size in bytes */
  uint32_t data_size;
} remote_ehsm_symmetric_cmac_generate_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_cmac_generate_req_t);

/** eHSM symmetric CMAC generate response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Message authentication tag */
  uint8_t tag[REMOTE_EHSM_SYMMETRIC_TAG_SIZE];
} remote_ehsm_symmetric_cmac_generate_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_cmac_generate_rsp_t);

/** eHSM symmetric CMAC verify request */
typedef remote_struct {
  /** Message to compute MAC */
  uint8_t data[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Symmetric key blob */
  uint8_t blob[REMOTE_EHSM_SYMMETRIC_BLOB_SIZE];

  /** Message authentication tag */
  uint8_t tag[REMOTE_EHSM_SYMMETRIC_TAG_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Message size in bytes */
  uint32_t data_size;
} remote_ehsm_symmetric_cmac_verify_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_cmac_verify_req_t);

/** eHSM symmetric CMAC verify response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;
} remote_ehsm_symmetric_cmac_verify_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_cmac_verify_rsp_t);

/** eHSM symmetric crypto CCM encrypt request */
typedef remote_struct {
  /** Plaintext to encrypt */
  uint8_t plaintext[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Symmetric key blob */
  uint8_t blob[REMOTE_EHSM_SYMMETRIC_BLOB_SIZE];

  /* Initialization Vector */
  uint8_t nonce[REMOTE_EHSM_SYMMETRIC_KEY_SIZE];

  /** Associated data */
  uint8_t associated_data[REMOTE_EHSM_ASSOCIATED_DATA_MAX_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Size of the plaintext in bytes */
  uint32_t plaintext_size;

  /** Size of the nonce in bytes */
  uint32_t nonce_size;

  /** Size of the associated data in bytes */
  uint32_t associated_data_size;

  /** Size of the tag in bytes */
  uint32_t tag_size;
} remote_ehsm_symmetric_ccm_encrypt_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_ccm_encrypt_req_t);

/** eHSM symmetric crypto CCM encrypt response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Ciphertext */
  uint8_t ciphertext[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Message authentication tag */
  uint8_t tag[REMOTE_EHSM_SYMMETRIC_TAG_SIZE];
} remote_ehsm_symmetric_ccm_encrypt_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_ccm_encrypt_rsp_t);

/** eHSM symmetric crypto CCM decrypt request */
typedef remote_struct {
  /** Ciphertext to decrypt */
  uint8_t ciphertext[REMOTE_EHSM_DATA_MAX_SIZE];

  /** Symmetric key blob */
  uint8_t blob[REMOTE_EHSM_SYMMETRIC_BLOB_SIZE];

  /* Initialization Vector */
  uint8_t nonce[REMOTE_EHSM_SYMMETRIC_KEY_SIZE];

  /** Associated data */
  uint8_t associated_data[REMOTE_EHSM_ASSOCIATED_DATA_MAX_SIZE];

  /** Message authentication tag */
  uint8_t tag[REMOTE_EHSM_SYMMETRIC_TAG_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Size of the ciphertext in bytes */
  uint32_t ciphertext_size;

  /** Size of the nonce in bytes */
  uint32_t nonce_size;

  /** Size of the associated data in bytes */
  uint32_t associated_data_size;

  /** Size of the tag in bytes */
  uint32_t tag_size;
} remote_ehsm_symmetric_ccm_decrypt_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_ccm_decrypt_req_t);

/** eHSM symmetric crypto CCM decrypt response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Plaintext */
  uint8_t plaintext[REMOTE_EHSM_DATA_MAX_SIZE];
} remote_ehsm_symmetric_ccm_decrypt_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_symmetric_ccm_decrypt_rsp_t);

/** eHSM self-test request */
typedef remote_struct {
  /** Test */
  uint32_t test;
} remote_ehsm_self_test_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_self_test_req_t);

/** eHSM self-test response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;
} remote_ehsm_self_test_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_self_test_rsp_t);

/** eHSM lifecycle set request */
typedef remote_struct {
  /** Fields bitmask */
  uint32_t bitmask;
} remote_ehsm_lifecycle_set_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_lifecycle_set_req_t);

/** eHSM lifecycle set response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;
} remote_ehsm_lifecycle_set_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_lifecycle_set_rsp_t);

/** eHSM MAC key generate request */
typedef remote_struct {
  /** Blob info */
  remote_ehsm_blob_info_t blob_info;
} remote_ehsm_mac_key_generate_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_mac_key_generate_req_t);

/** eHSM MAC key generate response */
typedef remote_struct {
  /** MAC key blob */
  uint8_t blob[REMOTE_EHSM_MAC_BLOB_SIZE];

  /** Response error code */
  uint32_t error_code;
} remote_ehsm_mac_key_generate_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_mac_key_generate_rsp_t);

/** eHSM MAC key import request */
typedef remote_struct {
  /** MAC key value */
  uint8_t key[REMOTE_EHSM_MAC_KEY_MAX_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;
} remote_ehsm_mac_key_import_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_mac_key_import_req_t);

/** eHSM MAC key import response */
typedef remote_struct {
  /** MAC key blob */
  uint8_t blob[REMOTE_EHSM_MAC_BLOB_SIZE];

  /** Response error code */
  uint32_t error_code;
} remote_ehsm_mac_key_import_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_mac_key_import_rsp_t);

/** eHSM MAC generate request */
typedef remote_struct {
  /** Message to compute */
  uint8_t data[REMOTE_EHSM_DATA_MAX_SIZE];

  /** MAC key blob */
  uint8_t blob[REMOTE_EHSM_MAC_BLOB_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Message size in bytes */
  uint32_t data_size;
} remote_ehsm_mac_generate_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_mac_generate_req_t);

/** eHSM MAC generate response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;

  /** Message authentication tag */
  uint8_t tag[REMOTE_EHSM_MAC_TAG_MAX_SIZE];
} remote_ehsm_mac_generate_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_mac_generate_rsp_t);

/** eHSM MAC verify request */
typedef remote_struct {
  /** Message to compute MAC */
  uint8_t data[REMOTE_EHSM_DATA_MAX_SIZE];

  /** MAC key blob */
  uint8_t blob[REMOTE_EHSM_MAC_BLOB_SIZE];

  /** Message authentication tag */
  uint8_t tag[REMOTE_EHSM_MAC_TAG_MAX_SIZE];

  /** Blob info */
  remote_ehsm_blob_info_t blob_info;

  /** Message size in bytes */
  uint32_t data_size;
} remote_ehsm_mac_verify_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_mac_verify_req_t);

/** eHSM MAC verify response */
typedef remote_struct {
  /** Response error code */
  uint32_t error_code;
} remote_ehsm_mac_verify_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ehsm_mac_verify_rsp_t);

/** Message IDs */
typedef enum {
  /** Diagnostics API */
  REMOTE_EHSM_CMD_INFORMATION_GET = 0,

  /** CSK generation */
  /** Remote eHSM CSK generate */
  REMOTE_EHSM_CMD_CSK_GENERATE,

  /** V2X API */
  /** Remote eHSM ECC key pair generate */
  REMOTE_EHSM_CMD_ECC_KEY_PAIR_GENERATE,

  /** Remote eHSM ECC key pair import */
  REMOTE_EHSM_CMD_ECC_KEY_PAIR_IMPORT,

  /** Remote eHSM ECIES signature generate */
  REMOTE_EHSM_CMD_ECDSA_SIGNATURE_GENERATE,

  /** Remote eHSM ECIES decryption key generate */
  REMOTE_EHSM_CMD_ECIES_DECRYPTION_KEY_GENERATE,

  /** Remote eHSM ECIES encrypt */
  REMOTE_EHSM_CMD_ECIES_ENCRYPT,

  /** Remote eHSM ECIES decrypt */
  REMOTE_EHSM_CMD_ECIES_DECRYPT,

  /** Remote eHSM ECC key private multiply-add */
  REMOTE_EHSM_CMD_ECC_PRIVATE_KEY_MUL_ADD,

  /** Remote eHSM ECC public key derive */
  REMOTE_EHSM_CMD_ECC_PUBLIC_KEY_DERIVE,

  /** RNG API */
  /** Remote eHSM random generate */
  REMOTE_EHSM_CMD_RANDOM_GENERATE,

  /** OTP API */
  /** Remote eHSM block ECC enable */
  REMOTE_EHSM_CMD_OTP_BLOCK_ECC_ENABLE,

  /** Remote eHSM word type read */
  REMOTE_EHSM_CMD_OTP_WORD_TYPE_READ,

  /** Remote eHSM word read */
  REMOTE_EHSM_CMD_OTP_WORD_READ,

  /** Remote eHSM word write */
  REMOTE_EHSM_CMD_OTP_WORD_WRITE,

  /** Remote eHSM word lock */
  REMOTE_EHSM_CMD_OTP_WORD_LOCK,

  /** Storage API */
  /** Remote eHSM MAC generate */
  REMOTE_EHSM_CMD_STORAGE_MAC_GENERATE,

  /** Remote eHSM MAC verify */
  REMOTE_EHSM_CMD_STORAGE_MAC_VERIFY,

  /** Remote eHSM authenticate and enecrypt */
  REMOTE_EHSM_CMD_STORAGE_AUTH_AND_ENCRYPT,

  /** Remote eHSM authenticate and decrypt */
  REMOTE_EHSM_CMD_STORAGE_AUTH_AND_DECRYPT,

  /** Symmetric API */
  /** Remote eHSM symmetric key generate */
  REMOTE_EHSM_CMD_SYMMETRIC_KEY_GENERATE,

  /** Remote eHSM symmetric key import */
  REMOTE_EHSM_CMD_SYMMETRIC_KEY_IMPORT,

  /** Remote eHSM symmetric ECB encrypt */
  REMOTE_EHSM_CMD_SYMMETRIC_ECB_ENCRYPT,

  /** Remote eHSM symmetric ECB decrypt */
  REMOTE_EHSM_CMD_SYMMETRIC_ECB_DECRYPT,

  /** Remote eHSM symmetric CBC encrypt */
  REMOTE_EHSM_CMD_SYMMETRIC_CBC_ENCRYPT,

  /** Remote eHSM symmetric CBC decrypt */
  REMOTE_EHSM_CMD_SYMMETRIC_CBC_DECRYPT,

  /** Remote eHSM symmetric CMAC generate */
  REMOTE_EHSM_CMD_SYMMETRIC_CMAC_GENERATE,

  /** Remote eHSM symmetric CMAC verify */
  REMOTE_EHSM_CMD_SYMMETRIC_CMAC_VERIFY,

  /** Remote eHSM symmetric CCM encrypt */
  REMOTE_EHSM_CMD_SYMMETRIC_CCM_ENCRYPT,

  /** Remote eHSM symmetric CCM decrypt */
  REMOTE_EHSM_CMD_SYMMETRIC_CCM_DECRYPT,

  /** Self-test API */
  /** Remote eHSM self-test */
  REMOTE_EHSM_CMD_SELF_TEST,

  /** Lifecycle set API */
  /** Remote eHSM lifecycle set */
  REMOTE_EHSM_CMD_LIFECYCLE_SET,

  /** MAC API */
  /** Remote eHSM MAC key generate */
  REMOTE_EHSM_CMD_MAC_KEY_GENERATE,

  /** Remote eHSM MAC key import */
  REMOTE_EHSM_CMD_MAC_KEY_IMPORT,

  /** Remote eHSM MAC generate */
  REMOTE_EHSM_CMD_MAC_GENERATE,

  /** Remote eHSM MAC verify */
  REMOTE_EHSM_CMD_MAC_VERIFY,

  /** Keep last */
  REMOTE_EHSM_CMD_INVALID
} remote_ehsm_msg_id_t;

/** eHSM error code enum */
typedef enum {
  /** No error */
  REMOTE_EHSM_ERC_NO_ERROR = 0x0,

  /**
     Error numbers between 0x1-0xf00
     are reserved for HW driver errors
  */

  /** Invalid argument */
  REMOTE_EHSM_ERC_INVALID_ARG = 0xf01,

  /** Unsupported command */
  REMOTE_EHSM_ERC_UNSUPPORTED_CMD = 0xf02,

  /** Invalid state */
  REMOTE_EHSM_ERC_INVALID_STATE = 0xf03,

  /** Unexpected error */
  REMOTE_EHSM_ERC_UNSPEC = 0xf04,

  /** CSK already programmed */
  REMOTE_EHSM_ERC_EXISTS = 0xf05,

  /** CSK not programmed */
  REMOTE_EHSM_CSK_NOT_PROGRAMMED = 0xf06,

  /** Operation is blocked */
  REMOTE_EHSM_WOULD_BLOCK = 0xf07,

  /** eHSM Panic notifier */
  REMOTE_EHSM_ERC_PANIC = 0xfff,
} remote_ehsm_error_code_t;

#endif /** _REMOTE_EHSM_PROTOCOL_H */
