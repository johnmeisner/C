/* Copyright (C) 2018 Autotalks Ltd. */
#ifndef _REMOTE_SYMMETRIC_CRYPTO_PROTOCOL_H
#define _REMOTE_SYMMETRIC_CRYPTO_PROTOCOL_H

#include "remote_defs.h"

#define REMOTE_SYMMETRIC_CRYPTO_TAG_SIZE_MAX 16U

/** Symmetric Crypto request */
typedef enum {
  REMOTE_SYMMETRIC_CRYPTO_REQUEST_ECB_ENCRYPT = 0,
  REMOTE_SYMMETRIC_CRYPTO_REQUEST_ECB_DECRYPT,
  REMOTE_SYMMETRIC_CRYPTO_REQUEST_CBC_ENCRYPT,
  REMOTE_SYMMETRIC_CRYPTO_REQUEST_CBC_DECRYPT,
  REMOTE_SYMMETRIC_CRYPTO_REQUEST_CCM_ENCRYPT,
  REMOTE_SYMMETRIC_CRYPTO_REQUEST_CCM_DECRYPT,
  REMOTE_SYMMETRIC_CRYPTO_REQUEST_GCM_ENCRYPT,
  REMOTE_SYMMETRIC_CRYPTO_REQUEST_GCM_DECRYPT,
  REMOTE_SYMMETRIC_CRYPTO_REQUEST_CMAC,
  REMOTE_SYMMETRIC_CRYPTO_REQUEST_GMAC
} remote_symmetric_crypto_request_t;

/** Symmetric Crypto key type */
typedef enum {
  REMOTE_SYMMETRIC_CRYPTO_KEY_TYPE_128 = 0,
  REMOTE_SYMMETRIC_CRYPTO_KEY_TYPE_256
} remote_symmetric_crypto_key_type_t;

/** Symmetric Crypto common structure */
typedef remote_struct {
  uint16_t request_id;
  uint16_t key_type;
} remote_symmetric_crypto_common_t;

REMOTE_CHECK_DATA_SIZE(remote_symmetric_crypto_common_t);

/*
+--------------+
+- Request ID -+
+--------------+
+-- Key Type --+
+--------------+
+-- Key Value -+
+--------------+
*/

/** Symmetric Crypto dx_size */
typedef remote_struct {
  uint32_t size;
} remote_symmetric_crypto_size_t;

REMOTE_CHECK_DATA_SIZE(remote_symmetric_crypto_size_t);


/** Symmetric Crypto ECB request */
/*
+--------------+
+- Text size  -+
+--------------+
+- Text value -+
+--------------+
*/

/** Symmetric Crypto CBC request */
/*
+--------------+
+- Text size  -+
+--------------+
+- Text value -+
+--------------+
+-  IV value  -+
+--------------+
*/

/** Symmetric Crypto CCM request */
/*
+----------------+
+- Text size    -+
+----------------+
+- Text value   -+
+----------------+
+- NONCE size   -+
+----------------+
+- NONCE value  -+
+----------------+
+- Header size  -+
+----------------+
+- Header value -+
+----------------+
+- Tag size     -+
+----------------+
*/

/** Symmetric Crypto GCM request */
/*
+----------------+
+- Text size    -+
+----------------+
+- Text value   -+
+----------------+
+- IV size      -+
+----------------+
+- IV value     -+
+----------------+
+- Header size  -+
+----------------+
+- Header value -+
+----------------+
+- Tag size     -+
+----------------+
*/

/** Symmetric Crypto CMAC request */
/*
+-----------------+
+- Message size  -+
+-----------------+
+- Message value -+
+-----------------+
+- Tag size      -+
+-----------------+
*/

/** Symmetric Crypto GMAC request */
/*
+----------------+
+- Header size  -+
+----------------+
+- Header value -+
+----------------+
+-   IV size    -+
+----------------+
+-   IV value   -+
+----------------+
+-   Tag size   -+
+----------------+
*/

/** Symmetric Crypto result */
typedef remote_struct {
  uint8_t result;

  uint8_t padding[3];
} remote_symmetric_crypto_result_t;

REMOTE_CHECK_DATA_SIZE(remote_symmetric_crypto_result_t);

/** Symmetric Crypto ECB response */
/*
+----------------+
+- Result value -+
+----------------+
+- Text size    -+
+----------------+
+-  Text value  -+
+----------------+
*/

/** Symmetric Crypto CBC response */
/*
+----------------+
+- Result value -+
+----------------+
+- Text size    -+
+----------------+
+-  Text value  -+
+----------------+
*/

/** Symmetric Crypto CCM response */
/*
+----------------+
+- Result value -+
+----------------+
+- Tag size     -+
+----------------+
+-  Tag value   -+
+----------------+
+- Text size    -+
+----------------+
+-  Text value  -+
+----------------+
*/

/** Symmetric Crypto GCM response */
/*
+----------------+
+- Result value -+
+----------------+
+- Tag size     -+
+----------------+
+-   Tag value  -+
+----------------+
+- Text size    -+
+----------------+
+-  Text value  -+
+----------------+
*/

/** Symmetric Crypto CMAC response */
/*
+----------------+
+- Result value -+
+----------------+
+- Tag size     -+
+----------------+
+-   Tag value  -+
+----------------+
*/

/** Symmetric Crypto GMAC response */
/*
+----------------+
+- Result value -+
+----------------+
+- Tag size     -+
+----------------+
+-   Tag value  -+
+----------------+
*/

#endif /** _REMOTE_SYMMETRIC_CRYPTO_PROTOCOL_H */
