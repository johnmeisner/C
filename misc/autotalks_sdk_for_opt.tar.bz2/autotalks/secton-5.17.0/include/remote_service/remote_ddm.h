/* Copyright (C) 2016-2019 Autotalks Ltd. */
#ifndef _REMOTE_DDM_PROTOCOL_H
#define _REMOTE_DDM_PROTOCOL_H

#include <atlk/hash.h>

#include "remote_defs.h"
#include "remote_object.h"
#include "remote_common.h"
#include "remote_ehsm.h"

/**
   @file
   Remote service DDM Definitions: types, states
   and request/response data structures.
*/

#define REMOTE_DDM_CEVA_BYTE_ALIGN                  16U
#define REMOTE_DDM_CEVA_MAX_CHUNK_SIZE              2300U
#define REMOTE_DDM_HB_DEFAULT_INTERVAL_MS           1000U
#define REMOTE_DDM_VERSION_STR_LEN                  128U
#define REMOTE_DDM_MAC_STR_LEN                      32U
#define REMOTE_DDM_TEMP_SENSOR_POWER_UP_MASK        0xFFFFU
#define REMOTE_DDM_TEMP_SENSOR_POWER_DOWN_OFFSET    16U
#define REMOTE_DDM_TEMP_READING_INVALID             INT32_MIN
#define REMOTE_DDM_SOC_OTP_REGISTERS                8U
#define REMOTE_DDM_BSP_COMPONENT_VERSION_MAX_LEN    100U
#define REMOTE_DDM_CPU_PROFILER_MAX_THREADS         32U
#define REMOTE_DDM_CPU_PROFILER_THREAD_NAME_MAX_LEN 32U

#define REMOTE_DDM_SECURE_HDIF_SERVICE_MAX_ID       64U

/* DDM statistics type bitmap size */
#define REMOTE_DDM_STATISTICS_BITMAP_TYPE_SIZE      16U

#define REMOTE_DDM_SECURE_HDIF_IV_SIZE              16U

/* BSP components versioning (m3_xl, m3_os, ap_xl, ap_os) */
#define REMOTE_DDM_BSP_COMPONENTS_NUM               4U
#define REMOTE_DDM_BSP_VER_STR_MAX_LEN              (REMOTE_DDM_BSP_COMPONENTS_NUM * REMOTE_DDM_BSP_COMPONENT_VERSION_MAX_LEN)

#define DDM_BLOB_START_WRITE_INIT {          \
  .size = 0                                  \
  .type = REMOTE_DDM_BLOB_TYPE_MAX,          \
}

#define DDM_BLOB_READ_INIT {                 \
  .size = 0,                                 \
  .offset = 0,                               \
  .type = REMOTE_DDM_BLOB_TYPE_MAX,          \
}

#define DDM_BLOB_CHUNK_INIT {                \
  .offset = 0,                               \
  .size = 0,                                 \
  .type = REMOTE_DDM_BLOB_TYPE_MAX,          \
}

#define DDM_BLOB_FINISH_INIT {               \
  .digest = {0}                              \
  .type = REMOTE_DDM_BLOB_TYPE_MAX,          \
}

typedef enum {
  REMOTE_DDM_REQUEST_TYPE_BLOB_START_WRITE = 0,
  REMOTE_DDM_REQUEST_TYPE_BLOB_WRITE_CHUNK,
  REMOTE_DDM_REQUEST_TYPE_BLOB_FINISH_WRITE,
  REMOTE_DDM_REQUEST_TYPE_OBJECT_GET,
  REMOTE_DDM_REQUEST_TYPE_OBJECT_SET,
  REMOTE_DDM_REQUEST_TYPE_RESET_WD,
  REMOTE_DDM_REQUEST_TYPE_BLOB_START_READ,
  REMOTE_DDM_REQUEST_TYPE_BLOB_READ_CHUNK,
  REMOTE_DDM_REQUEST_TYPE_SW_CONFIG_SEND,
  REMOTE_DDM_REQUEST_TYPE_TSF_SET,
  REMOTE_DDM_REQUEST_TYPE_TSF_GET,
  REMOTE_DDM_REQUEST_TYPE_STATUS_GET,
  REMOTE_DDM_REQUEST_TYPE_SOC_OTP_REGISTERS_GET,
  REMOTE_DDM_REQUEST_TYPE_PPS_COUNTER_GET,
  REMOTE_DDM_REQUEST_TYPE_CPU_PROFILER_RESET,
  REMOTE_DDM_REQUEST_TYPE_CPU_PROFILER_GET,
  REMOTE_DDM_REQUEST_TYPE_CPU_PROFILER_GET_AND_CLEAR,
  REMOTE_DDM_REQUEST_TYPE_SYSTEM_VERSIONS_GET,
  REMOTE_DDM_REQUEST_TYPE_MAX
} remote_ddm_request_type_t;

typedef enum {
  REMOTE_DDM_INDICATION_TYPE_HB = REMOTE_DDM_REQUEST_TYPE_MAX,
  REMOTE_DDM_INDICATION_TYPE_TIME_SYNC,
  REMOTE_DDM_INDICATION_TYPE_STATISTICS,
  REMOTE_DDM_INDICATION_TYPE_SECURE_HDIF_STATUS,
  REMOTE_DDM_INDICATION_TYPE_MAX
} remote_ddm_indication_type_t;

typedef enum {
  REMOTE_DDM_OBJECT_TYPE_VERSION_GET = REMOTE_DDM_INDICATION_TYPE_MAX,
  REMOTE_DDM_OBJECT_TYPE_ETH_MAC,
  REMOTE_DDM_OBJECT_TYPE_TEMPERATURE_GET,
  REMOTE_DDM_OBJECT_TYPE_TSF,
  REMOTE_DDM_OBJECT_TYPE_APP_INFO,
  REMOTE_DDM_OBJECT_TYPE_GPIO_MODE,
  REMOTE_DDM_OBJECT_TYPE_GPIO_DIRECTION,
  REMOTE_DDM_OBJECT_TYPE_GPIO_VALUE,
  REMOTE_DDM_OBJECT_TYPE_BASEBAND_V2X_HW_REV,
  REMOTE_DDM_OBJECT_TYPE_RESET_WD,
  REMOTE_DDM_OBJECT_TYPE_CALIB_RELOAD,
  REMOTE_DDM_OBJECT_TYPE_BSP_VERSION,
  REMOTE_DDM_OBJECT_TYPE_EEPROM_WRITE,
  REMOTE_DDM_OBJECT_TYPE_EEPROM_READ,
  REMOTE_DDM_OBJECT_TYPE_PPS_VALIDITY_SET,
  REMOTE_DDM_OBJECT_TYPE_PPS_UNSYNC_SET,
  REMOTE_DDM_OBJECT_TYPE_RX_HOLD_OVER,
  REMOTE_DDM_OBJECT_TYPE_TX_HOLD_OVER,
  REMOTE_DDM_OBJECT_TYPE_PPS_LAST_TIMING_OFFSET,
  REMOTE_DDM_OBJECT_TYPE_EXTERNAL,
  REMOTE_DDM_OBJECT_TYPE_STATISTICS,
  REMOTE_DDM_OBJECT_TYPE_SECURE_HDIF_INIT,
  REMOTE_DDM_OBJECT_TYPE_SECURE_HDIF_STATUS_GET,
  REMOTE_DDM_OBJECT_TYPE_SECURE_HDIF_STATISTICS_GET,
  REMOTE_DDM_OBJECT_TYPE_SECURE_HDIF_MASTER_KEY_GENERATE,
  REMOTE_DDM_OBJECT_TYPE_SECURE_HDIF_MASTER_KEY_BLOB_SET,
  REMOTE_DDM_OBJECT_TYPE_SECURE_HDIF_SECURITY_LEVELS_GET,
  REMOTE_DDM_OBJECT_TYPE_SECURE_HDIF_SESSION_KEYS_GENERATE,
  REMOTE_DDM_OBJECT_TYPE_MSG_RATE_GET,
  REMOTE_DDM_OBJECT_TYPE_NOR_FLASH_CUSTOMER_PARTITION_READ,
  REMOTE_DDM_OBJECT_TYPE_MAX
} remote_ddm_object_type_t;

typedef enum {
  REMOTE_DDM_BLOB_TYPE_CODE = 0,
  REMOTE_DDM_BLOB_TYPE_DATA,
  REMOTE_DDM_BLOB_TYPE_CACHE,
  REMOTE_DDM_BLOB_TYPE_M0_BUFFER,
  REMOTE_DDM_BLOB_TYPE_CALIB_AT_INIT,
  REMOTE_DDM_BLOB_TYPE_CALIB_MAIN,
  REMOTE_DDM_BLOB_TYPE_CALIB_MAIN_NVM,
  REMOTE_DDM_BLOB_TYPE_CALIB_EXT,
  REMOTE_DDM_BLOB_TYPE_RF_CONFIG_AT_INIT,
  REMOTE_DDM_BLOB_TYPE_RF_CONFIG_MAIN,
  REMOTE_DDM_BLOB_TYPE_RF_CONFIG_MAIN_NVM,
  REMOTE_DDM_BLOB_TYPE_MAX
} remote_ddm_blob_type_t;

typedef enum {
  REMOTE_DDM_STATE_INIT = 0,
  REMOTE_DDM_STATE_WAIT_FOR_CEVA_PROG,
  REMOTE_DDM_STATE_WAIT_FOR_CEVA_DATA,
  REMOTE_DDM_STATE_WAIT_FOR_CEVA_PROG_CACHE,
  REMOTE_DDM_STATE_WAIT_FOR_M0_BUFFER,
  REMOTE_DDM_STATE_WAIT_FOR_CONFIG,
  REMOTE_DDM_STATE_WAIT_FOR_CALIB,
  REMOTE_DDM_STATE_WAIT_FOR_RF_CONFIG,
  REMOTE_DDM_STATE_READY,
  DDM_STATE_MAX
} ddm_hb_state_t;

typedef enum {
  REMOTE_DDM_TSF_LOCK_STATUS_UNLOCKED = 0,
  REMOTE_DDM_TSF_LOCK_STATUS_LOCKED,
  REMOTE_DDM_TSF_LOCK_STATUS_UTC_SYNCED
} remote_ddm_tsf_lock_status_t;

typedef enum {
  REMOTE_DDM_BB_V2X_HW_REV_1_0,
  REMOTE_DDM_BB_V2X_HW_REV_1_1,
  REMOTE_DDM_BB_V2X_HW_REV_2_0,
  REMOTE_DDM_BB_V2X_HW_REV_2_1,
  REMOTE_DDM_BB_V2X_HW_REV_3_0
} remote_ddm_baseband_v2x_hw_rev_t;

typedef remote_struct {
  uint8_t indication_type;
  /** Padding to 4 byte alignment */
  uint8_t padding[3];
} remote_ddm_ind_header_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_ind_header_t);

typedef remote_struct {
  remote_ddm_ind_header_t header;
  uint64_t tsf_timestamp;
  uint64_t local_timestamp;
  uint8_t tsf_lock_status;
  uint8_t hb_state;
  uint8_t padding[2];
} remote_ddm_hb_ind_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_hb_ind_t);

typedef remote_struct {
  remote_ddm_ind_header_t header;
  uint32_t time_sync_state;
} remote_ddm_time_sync_ind_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_time_sync_ind_t);

typedef remote_struct {
  remote_ddm_ind_header_t header;
  uint32_t session_key_counter;
  uint32_t session_key_counter_max;
} remote_ddm_secure_hdif_ind_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_secure_hdif_ind_t);

typedef remote_struct {
  uint32_t size;
  uint8_t type;
  uint8_t padding[3];
} remote_ddm_blob_start_write_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_blob_start_write_t);

typedef remote_struct {
  remote_common_req_header_t header;
  remote_ddm_blob_start_write_t blob_start_write;
} remote_ddm_blob_start_write_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_blob_start_write_req_t);

typedef remote_struct {
  uint32_t size;
  uint32_t offset;
  uint8_t type;
  uint8_t padding[3];
} remote_ddm_blob_read_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_blob_read_t);

typedef remote_struct {
  remote_common_req_header_t header;
  remote_ddm_blob_read_t blob_start_read;
} remote_ddm_blob_start_read_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_blob_start_read_req_t);

typedef remote_struct {
  uint32_t offset;
  uint16_t size;
  uint8_t type;
  uint8_t padding[1];
} remote_ddm_blob_chunk_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_blob_chunk_t);

typedef remote_struct {
  remote_common_req_header_t header;
  remote_ddm_blob_chunk_t blob_chunk;
} remote_ddm_blob_chunk_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_blob_chunk_req_t);

typedef remote_struct {
  uint8_t digest[HASH_256_DIGEST_SIZE];
  uint8_t type;
  uint8_t padding[3];
} remote_ddm_blob_finish_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_blob_finish_t);

typedef remote_struct {
  remote_common_req_header_t header;
  remote_ddm_blob_finish_t blob_finish_write;
} remote_ddm_blob_finish_write_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_blob_finish_write_req_t);

#define MSG_RATES (SERVICE_TYPE_MAX + 1)
typedef remote_struct {
  uint32_t rate[MSG_RATES];
} remote_ddm_msg_rate_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_msg_rate_t);

typedef remote_struct {
  remote_common_req_header_t header;
  int32_t lmac_loopback_enable;
  int32_t lmac_phy_loopback_enable;
  int32_t lmac_trace_verbose;
  uint32_t lmac_calib_file_location;
  uint32_t lmac_rf_config_file_location;
  uint32_t ranging_enable;
  uint32_t dcc_indication_enable;
  uint32_t physical_interfaces_in_use;
  uint32_t lmac_diversity_enable;
  uint32_t force_csk_generate;
  uint32_t log_level_device;
  uint32_t lmac_recovery_enable;
  uint32_t lmac_recovery_mem_dump_enable;
} remote_ddm_sw_config_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_sw_config_req_t);

typedef remote_struct {
  remote_common_rsp_header_t header;
} remote_ddm_blob_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_blob_rsp_t);

typedef remote_struct {
  uint8_t sha_256[HASH_256_DIGEST_SIZE];
  uint32_t actual_size;
} remote_ddm_blob_start_read_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_blob_start_read_rsp_t);

typedef remote_struct {
  uint64_t time_usec_tai_2004;
  uint64_t time_usec_error;
  uint32_t tsf_lock_status;
} remote_ddm_tsf_get_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_tsf_get_rsp_t);

typedef remote_struct {
  int32_t temperature_celsius;
} remote_ddm_status_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_status_rsp_t);

typedef remote_struct {
  uint32_t soc_otp_registers[REMOTE_DDM_SOC_OTP_REGISTERS];
} remote_ddm_soc_otp_registers_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_soc_otp_registers_rsp_t);

typedef remote_struct {
  uint32_t pps_counter;
} remote_ddm_pps_counter_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_pps_counter_rsp_t);

typedef remote_struct {
  uint8_t type_bitmap[REMOTE_DDM_STATISTICS_BITMAP_TYPE_SIZE];
} remote_ddm_stats_req_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_stats_req_t);

typedef remote_struct {
  /** Thread name */
  char thread_name[REMOTE_DDM_CPU_PROFILER_THREAD_NAME_MAX_LEN];
  /** Thread CPU usage in cycles */
  uint64_t cpu_cycles;
  /** Thread execution state */
  uint8_t state;
  uint8_t padding[3];
} remote_ddm_cpu_profiler_thread_entry_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_cpu_profiler_thread_entry_t);

/** @note: Must be packed */
typedef remote_struct {
  /** Array of threads: names, the corresponding usage(in cycles) and state */
  remote_ddm_cpu_profiler_thread_entry_t threads_list[REMOTE_DDM_CPU_PROFILER_MAX_THREADS];
  uint64_t idle_cpu_cycles;
  uint64_t isr_cpu_cycles;
  uint64_t total_cycles;
  /** Actual number of scanned threads */
  uint8_t threads_count;
  uint8_t padding[3];
} remote_ddm_cpu_profiler_get_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_cpu_profiler_get_rsp_t);

/* All remote DDM secure HDIF structs are in use only at the device */
typedef remote_struct {
  /** Holds master keys blob that need to be sent to the device */
  uint8_t buffer[REMOTE_EHSM_SECURE_HDIF_MASTER_KEYS_BLOB_SIZE];
} remote_ddm_secure_hdif_master_keys_blob_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_secure_hdif_master_keys_blob_t);

/* All remote DDM secure HDIF structs are in use only at the device */
typedef remote_struct {
  /** Master key to be used for encryption in plain text */
  uint8_t encryption_key_plain_text[REMOTE_EHSM_SYMMETRIC_KEY_SIZE];

  /** Master key to be used for authentication in plain text */
  uint8_t authentication_key_plain_text[REMOTE_EHSM_SYMMETRIC_KEY_SIZE];

  /** Master keys blob */
  remote_ddm_secure_hdif_master_keys_blob_t blob;
} remote_ddm_secure_hdif_master_keys_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_secure_hdif_master_keys_t);

typedef remote_struct {
  uint8_t security_levels[REMOTE_DDM_SECURE_HDIF_SERVICE_MAX_ID];
} remote_ddm_secure_hdif_security_level_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_secure_hdif_security_level_t);

typedef remote_struct {
  uint8_t encryption_key[REMOTE_EHSM_SYMMETRIC_KEY_SIZE];
  uint8_t authentication_key[REMOTE_EHSM_SYMMETRIC_KEY_SIZE];
  /** Initialization vector key that will be used at the host for IV encryption making it unpredictable */
  uint8_t iv_key[REMOTE_DDM_SECURE_HDIF_IV_SIZE];
} remote_ddm_secure_hdif_keys_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_secure_hdif_keys_t);

typedef remote_struct {
  /** Initialization vector that was used at the device for ciphertext encryption */
  uint8_t iv[REMOTE_DDM_SECURE_HDIF_IV_SIZE];

  /** Session key that are generated at the device and encrypt using master key with above IV */
  remote_ddm_secure_hdif_keys_t ciphertext;
} remote_ddm_secure_hdif_session_keys_element_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_secure_hdif_session_keys_element_t);

typedef remote_struct {
  /** MAC is computed with Master Key at the device */
  uint8_t mac_tag[REMOTE_EHSM_SYMMETRIC_TAG_SIZE];

  /** Session key that are generated at the device and was encrypted using master key */
  remote_ddm_secure_hdif_session_keys_element_t keys;
} remote_ddm_secure_hdif_session_keys_ciphertext_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_secure_hdif_session_keys_ciphertext_t);

typedef remote_struct {
  /** Number of packets that where received and authenticated successfully */
  uint32_t packets_authenticated;

  /** Number of packets that where encrypted successfully */
  uint32_t packets_encrypted;

  /** Number of packets that where received and decrypted successfully */
  uint32_t packets_decrypted;

  /** Number of packets that where received and resulted with authenticated error */
  uint32_t authentication_errors;

  /** Number of tag computed attempts that ended with error */
  uint32_t tag_compute_errors;

  /** Number of packet encryption attempts that ended with error */
  uint32_t encrypt_errors;

  /** Number of packet decryption attempts that ended with error */
  uint32_t decrypt_errors;

  /** The total number of blocks that where processed by the crypto engine */
  uint32_t total_number_of_secure_blocks;

  /** The total number of session key that where used */
  uint32_t number_of_session_keys_used;

  /** Number of blocks that the current session key was used by the crypto engine */
  uint32_t current_session_key_wear_down_counter;

  /** Number of failed crypto cooperations due to expired key */
  uint32_t session_key_wear_down_errors;
} remote_ddm_secure_hdif_statistics_get_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_secure_hdif_statistics_get_t);

typedef remote_struct {
  uint8_t sdk_major;
  uint8_t sdk_minor;
  uint8_t sdk_patch;
  uint8_t padding[1];

  uint32_t dsp_actual_common_version;
  uint32_t dsp_actual_specific_version;
  uint32_t dsp_expected_common_version;
  uint32_t dsp_expected_specific_version;

  uint32_t platform_actual_version;
  uint32_t platform_expected_version;
} remote_ddm_system_versions_get_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_ddm_system_versions_get_rsp_t);

#endif /* _REMOTE_DDM_PROTOCOL_H */
