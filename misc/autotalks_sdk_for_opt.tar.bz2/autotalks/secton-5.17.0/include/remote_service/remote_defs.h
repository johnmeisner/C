#ifndef _REMOTE_DEFS_H_
#define _REMOTE_DEFS_H_

#if defined __CC_ARM
  #define remote_struct __packed struct
  #define remote_union __packed union
#elif defined __GNUC__
  #define remote_struct struct __attribute__((packed, aligned(4)))
  #define remote_union union __attribute__((packed, aligned(4)))
#else
  #error "Unknown compiler; structure packing unsupported"
#endif

#define REMOTE_CHECK_DATA_SIZE(s) \
  struct __build_bug_check_ ## s { \
    char negative_size_on_build_bug[(sizeof(s) % 4 != 0) ? -1 : 0]; \
  }

#endif /* _REMOTE_DEFS_H_ */
