/* Copyright (C) 2019 Autotalks Ltd. */

#ifndef _REMOTE_CDDM_PROTOCOL_H
#define _REMOTE_CDDM_PROTOCOL_H

#include "remote_object.h"

/**
   @file
   Remote C-DDM header.
*/

typedef enum {
  REMOTE_CDDM_REQUEST_TYPE_MAX = 0,
} remote_cddm_request_type_t;

/** C-DDM object type */
typedef enum {
  REMOTE_CDDM_OBJECT_TYPE_MAX = REMOTE_CDDM_REQUEST_TYPE_MAX,
} remote_cddm_object_type_t;

#endif /* _REMOTE_CDDM_PROTOCOL_H */
