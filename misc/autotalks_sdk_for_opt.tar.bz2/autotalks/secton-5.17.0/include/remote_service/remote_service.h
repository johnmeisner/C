#ifndef _DEVICE_REMOTE_SERVICE_H_
#define _DEVICE_REMOTE_SERVICE_H_

#include "remote_defs.h"
#include <atlk/sdk.h>

#define REMOTE_SERVICE_ID_V2X               0x56325800
#define REMOTE_SERVICE_ID_WDM               0x57444D00
#define REMOTE_SERVICE_ID_HSM               0x48534D00
#define REMOTE_SERVICE_ID_ECC               0x45434300
#define REMOTE_SERVICE_ID_DDM               0x44444D00
#define REMOTE_SERVICE_ID_DBG               0x44424700
#define REMOTE_SERVICE_ID_IVN               0x49564E00
#define REMOTE_SERVICE_ID_HASH              0x53484100
#define REMOTE_SERVICE_ID_SYMMETRIC_CRYPTO  0x41455300
#define REMOTE_SERVICE_ID_LOG               0x5132DB00

#define REMOTE_SERVICE_INIT { \
  .destination_service = 0,   \
  .service_context = 0        \
}

typedef remote_struct {
  uint32_t destination_service;
  uint32_t service_context;
} remote_service_t;

REMOTE_CHECK_DATA_SIZE(remote_service_t);

#endif /* _DEVICE_REMOTE_SERVICE_H_ */
