#ifndef _ATLK_REMOTE_COUNTERS_H
#define _ATLK_REMOTE_COUNTERS_H

#include "remote_defs.h"

#define REMOTE_COUNTERS_INIT { \
  .rx_packets = 0,             \
  .tx_packets = 0,             \
  .rx_bytes = 0,               \
  .tx_bytes = 0,               \
  .rx_errors = 0,              \
  .tx_errors = 0,              \
  .rx_dropped = 0,             \
  .tx_dropped = 0,             \
}

typedef uint32_t remote_atlk_counter_t;

/**
   Counters Statistics
*/
typedef remote_struct {
  /** Total successfully received packets */
  uint64_t rx_packets;

  /** Total successfully sent packets */
  uint64_t tx_packets;

  /** Total successfully received bytes */
  uint64_t rx_bytes;

  /** Total successfully sent bytes */
  uint64_t tx_bytes;

  /** Total failure packets upon receive */
  uint64_t rx_errors;

  /** Total failure packets upon send */
  uint64_t tx_errors;

  /** Total dropped packets upon receive */
  uint64_t rx_dropped;

  /** Total dropped packets upon send */
  uint64_t tx_dropped;
} remote_atlk_counters_t;

REMOTE_CHECK_DATA_SIZE(remote_atlk_counters_t);

typedef struct {
  /** Ingress from lower layer */
  remote_atlk_counter_t il_success;
  remote_atlk_counter_t il_fail;
  remote_atlk_counter_t il_bytes;

  /** Ingress from upper layer */
  remote_atlk_counter_t iu_success;
  remote_atlk_counter_t iu_fail;
  remote_atlk_counter_t iu_bytes;

  /** Egress counters */
  remote_atlk_counter_t el_success;
  remote_atlk_counter_t el_bytes;
  remote_atlk_counter_t eu_success;
  remote_atlk_counter_t eu_bytes;

  /** Operation errors */
  remote_atlk_counter_t op_up_error;
  remote_atlk_counter_t op_down_error;

  /**
     Data area for custom statistics.
     Must be last.
  */
  uint32_t custom_counters[0];
} remote_atlk_flow_counters_t;

REMOTE_CHECK_DATA_SIZE(remote_atlk_flow_counters_t);

#endif /* _ATLK_REMOTE_COUNTERS_H */
