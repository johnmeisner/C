/* Copyright (C) 2016-2019 Autotalks Ltd. */
#ifndef _REMOTE_V2X_PROTOCOL_H
#define _REMOTE_V2X_PROTOCOL_H

#include "remote_defs.h"
#include "remote_compensator.h"
#include <common/eui48.h>

/**
   @file
   Remote V2X header file, for common structures between host and device.
*/

#define REMOTE_V2X_DOT4_TIME_SLOT_NUM   2

/** Remote V2X send parameters default initializer */
#define REMOTE_V2X_SEND_PARAMS_INIT {                 \
  .datarate = REMOTE_V2X_DATARATE_NA,                 \
  .power_dbm8 = V2X_POWER_DBM8_NA,                    \
  .transmit_diversity_power_dbm8 = V2X_POWER_DBM8_NA, \
  .expiry_time_ms = V2X_EXPIRY_TIME_MS_NA,            \
  .channel_num = V2X_CHANNEL_NUM_NA,                  \
  .op_class = REMOTE_V2X_OP_CLASS_NA,                 \
  .time_slot = REMOTE_V2X_TIME_SLOT_NA,               \
}

/** Remote V2X socket configuration default initializer */
#define REMOTE_V2X_SOCKET_CONFIG_INIT {               \
  .if_index = V2X_IF_INDEX_NA,                        \
}

/** Remote V2X user data default initializer */
#define REMOTE_V2X_USER_DATA_INIT {                   \
  .length = 0,                                        \
}

/** Remote V2X send default initializer */
#define REMOTE_V2X_SEND_INIT {                        \
  .v2x_send_params = REMOTE_V2X_SEND_PARAMS_INIT,     \
  .config = REMOTE_V2X_SOCKET_CONFIG_INIT,            \
  .user_data = REMOTE_V2X_USER_DATA_INIT              \
}

/** V2X MAC user priority minimum value */
#define V2X_USER_PRIORITY_MIN 0

/** V2X MAC user priority maximum value */
#define V2X_USER_PRIORITY_MAX 7U

/** V2X user priorities */
#define V2X_USER_PRIORITY_0 V2X_USER_PRIORITY_MIN
#define V2X_USER_PRIORITY_1 1
#define V2X_USER_PRIORITY_2 2
#define V2X_USER_PRIORITY_3 3
#define V2X_USER_PRIORITY_4 4
#define V2X_USER_PRIORITY_5 5
#define V2X_USER_PRIORITY_6 6
#define V2X_USER_PRIORITY_7 V2X_USER_PRIORITY_MAX

/** Amount of V2X user priorites */
#define V2X_USER_PRIORITY_COUNT (V2X_USER_PRIORITY_MAX + 1)

/** Remote V2X data rate */
typedef enum {
  /** Data rate is N/A */
  REMOTE_V2X_DATARATE_NA = 0,

  /** 3 Mbps */
  REMOTE_V2X_DATARATE_3MBPS,

  /** 4.5 Mbps */
  REMOTE_V2X_DATARATE_4_5MBPS,

  /** 6 Mbps */
  REMOTE_V2X_DATARATE_6MBPS,

  /** 9 Mbps */
  REMOTE_V2X_DATARATE_9MBPS,

  /** 12 Mbps */
  REMOTE_V2X_DATARATE_12MBPS,

  /** 18 Mbps */
  REMOTE_V2X_DATARATE_18MBPS,

  /** 24 Mbps */
  REMOTE_V2X_DATARATE_24MBPS,

  /** 27 Mbps */
  REMOTE_V2X_DATARATE_27MBPS,

  /** 36 Mbps */
  REMOTE_V2X_DATARATE_36MBPS,

  /** 48 Mbps */
  REMOTE_V2X_DATARATE_48MBPS,

  /** 54 Mbps */
  REMOTE_V2X_DATARATE_54MBPS,

  /** MCS 0 */
  REMOTE_V2X_DATARATE_MCS_0,

  /** MCS 1 */
  REMOTE_V2X_DATARATE_MCS_1,

  /** MCS 2 */
  REMOTE_V2X_DATARATE_MCS_2,

  /** MCS 3 */
  REMOTE_V2X_DATARATE_MCS_3,

  /** MCS 4 */
  REMOTE_V2X_DATARATE_MCS_4,

  /** MCS 5 */
  REMOTE_V2X_DATARATE_MCS_5,

  /** MCS 6 */
  REMOTE_V2X_DATARATE_MCS_6,

  /** MCS 7 */
  REMOTE_V2X_DATARATE_MCS_7,
} remote_v2x_datarate_t;

/** Remote V2X message ID */
typedef enum {
  /** Send request */
  REMOTE_V2X_MSG_ID_SEND_REQ = 0,

  /** Receive indication */
  REMOTE_V2X_MSG_ID_RECV_IND,

  /** Channel start request */
  REMOTE_V2X_MSG_DOT4_CHANEL_START_REQ,

  /** Channel end request */
  REMOTE_V2X_MSG_DOT4_CHANEL_END_REQ,

  /** Channel end indication */
  REMOTE_V2X_MSG_DOT4_CHANEL_END_IND,

  /** Channel Busy Ratio (CBR) sampling create */
  REMOTE_V2X_MSG_ID_CBR_CREATE,

  /** Channel Busy Ratio (CBR) sampling delete */
  REMOTE_V2X_MSG_ID_CBR_DELETE,

  /** Channel Busy Ratio (CBR) sampling indication */
  REMOTE_V2X_MSG_ID_CBR_IND,

  /** Measurement sampling create */
  REMOTE_V2X_MSG_ID_MEASUREMENT_CREATE,

  /** Measurement sampling delete */
  REMOTE_V2X_MSG_ID_MEASUREMENT_DELETE,

  /** Measurement sampling indication */
  REMOTE_V2X_MSG_ID_MEASUREMENT_IND,

  /** Get DOT4 statistics */
  REMOTE_V2X_MSG_DOT4_STATS_GET,

  /** Set DOT4 switching configuration */
  REMOTE_V2X_MSG_DOT4_SWITCHING_CONFIG_SET,

  /** Get DOT4 switching configuration */
  REMOTE_V2X_MSG_DOT4_SWITCHING_CONFIG_GET,

  /** Get DOT4 status */
  REMOTE_V2X_MSG_DOT4_STATUS_GET,

  /** Send synchronous request */
  REMOTE_V2X_MSG_ID_SYNC_SEND_REQ,

  /** Transmit complete indication create */
  REMOTE_V2X_MSG_ID_TX_IND_CREATE,

  /** Transmit complete indication delete */
  REMOTE_V2X_MSG_ID_TX_IND_DELETE,

  /** Transmit complete indication */
  REMOTE_V2X_MSG_ID_TX_IND,

  /** V2X packet transmit decentralized congestion control complete indication */
  REMOTE_V2X_MSG_DCC_ID_TX_IND,

} remote_v2x_msg_id_t;

/* Remote Enhanced Distributed Channel Access (EDCA) Access Categories (AC) */
typedef enum {
  /** Background */
  REMOTE_V2X_EDCA_AC_BK = 0,

  /** Best effort */
  REMOTE_V2X_EDCA_AC_BE,

  /** Video */
  REMOTE_V2X_EDCA_AC_VI,

  /** Voice */
  REMOTE_V2X_EDCA_AC_VO,

  /** Number of EDCA ACs */
  REMOTE_V2X_EDCA_AC_COUNT
} remote_v2x_edca_ac_t;

/* Remote V2X operating class */
typedef enum {
  /** No operating class selected */
  REMOTE_V2X_OP_CLASS_NA = 0,

  /** United States ITS 5 GHz, 10 MHz channel spacing */
  REMOTE_V2X_OP_CLASS_US_ITS_5GHZ_SPACING_10MHZ,

  /** United States ITS 5 GHz, 20 MHz channel spacing */
  REMOTE_V2X_OP_CLASS_US_ITS_5GHZ_SPACING_20MHZ,

  /** Europe ITS 5 GHz, 10 MHz channel spacing */
  REMOTE_V2X_OP_CLASS_EUROPE_ITS_5GHZ_SPACING_10MHZ,

  /** Europe ITS 5 GHz, 20 MHz channel spacing */
  REMOTE_V2X_OP_CLASS_EUROPE_ITS_5GHZ_SPACING_20MHZ
} remote_v2x_op_class_t;

/** Remote V2X time slot */
typedef enum {
  /** No time slot selected */
  REMOTE_V2X_TIME_SLOT_NA = 0,

  /** Time slot #0 */
  REMOTE_V2X_TIME_SLOT_0,

  /** Time slot #1 */
  REMOTE_V2X_TIME_SLOT_1,
} remote_v2x_time_slot_t;

/** Remote V2X 48-bit Extended Unique Identifier (EUI) */
typedef remote_struct {
  /** 48-bit Extended Unique Identifier (EUI) */
  uint8_t octets[EUI48_LEN];

  uint8_t padding[2];
} remote_v2x_eui48_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_eui48_t);

/** Remote V2X header structure */
typedef remote_struct {
  /** Remote message ID */
  uint16_t message_id;
  /** Padding to 4 byte alignment */
  uint8_t padding[2];
} remote_v2x_header_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_header_t);

/** Remote V2X response header structure */
typedef remote_struct {
  /** Return code */
  uint8_t result;
  /** Padding to 4 byte alignment */
  uint8_t padding[3];
} remote_v2x_rsp_header_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_rsp_header_t);

/** Remote V2X Channel Busy Ratio (CBR) request */
typedef remote_struct {
  /** Remote V2X header */
  remote_v2x_header_t header;

  /** Interface index */
  uint8_t if_index;

  uint8_t padding[3];
} remote_v2x_cbr_req_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_cbr_req_t);

/** Remote V2X Channel Busy Ratio (CBR) indication */
typedef remote_struct {
  /** Number of busy slots */
  uint32_t slots_busy;

  /** Total number of slots */
  uint32_t slots_total;

  /** Number of busy diversity slots */
  uint32_t slots_busy_diversity;

  /** Total number of diversity slots */
  uint32_t slots_total_diversity;

  /** Interface index */
  uint8_t if_index;

  /** Diversity flag */
  uint8_t is_diversity;

  uint8_t padding[2];
} remote_v2x_cbr_ind_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_cbr_ind_t);

/** Remote V2X measurement indication */
typedef remote_struct {
  /** Interface index */
  uint8_t if_index;

  /** Data size */
  uint16_t data_size;

  uint8_t padding[1];

  /** Data */
  remote_union {
    uint32_t data_ptr; /** Data pointer used by device (a 32bit CPU) */
    uint8_t data_array[0]; /** Data array used by host */
  };
} remote_v2x_measurement_ind_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_measurement_ind_t);

/** Remote V2X send parameters */
typedef remote_struct remote_v2x_send_params {
  /** Transmission data rate */
  uint32_t datarate; /* v2x_datarate_t */

  /** Transmission power level in units of 1/8 dBm */
  int16_t power_dbm8; /* v2x_power_dbm8_t */

  /**
     Transmission power level of frame transmitted on second antenna in units
     of 1/8 dBm, when TX diversity is enabled.
  */
  int16_t transmit_diversity_power_dbm8;

  /**
     Expiration time in milliseconds

     Given ::v2x_send is called at time t0, frames which were not transmitted
     until t0 + expiry_time_ms will be dropped.

     @note Only supported when non-blocking wait option is used.

     @todo Currently not supported in remote V2X server.
  */
  uint16_t expiry_time_ms;

  /** Physical channel number */
  uint8_t channel_num; /* v2x_channel_num_t */

  /** Operation class */
  uint8_t op_class;

  /** Time slot */
  uint8_t time_slot;

  /** Compensator data per antenna */
  remote_compensator_data_t comp_data[2];

  uint8_t padding[3];
} remote_v2x_send_params_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_send_params_t);

/** Remote V2X receive parameters */
typedef remote_struct {
  /**
     Receive time in microseconds, Most Significant Bit (MSB)
     Format: number of TAI microseconds since 2004-01-01T00:00:00Z (UTC).
  */
  uint32_t receive_time_us_msb;

  /**
     Receive time in microseconds, Least Significant Bit (LSB)
     Format: number of TAI microseconds since 2004-01-01T00:00:00Z (UTC).
  */
  uint32_t receive_time_us_lsb;

  /** Data rate */
  uint32_t datarate; /* v2x_datarate_t */

  /** Physical channel number, v2x_channel_num_t */
  uint8_t channel_num;

  /** Operation class */
  uint8_t op_class;

  /** Time slot */
  uint8_t time_slot;

  /** Received Signal Strength Indication (RSSI) */
  uint8_t rssi;

  /** Received Signal Strength Indication (RSSI) channel B (diversity) */
  uint8_t diversity_rssi;

  uint8_t padding[3];

} remote_v2x_receive_params_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_receive_params_t);

/** Remote V2X configuration structure */
typedef remote_struct {
  /** Ingress/egress physical interface index */
  uint8_t if_index;

  uint8_t padding[3];
} remote_v2x_config_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_config_t);

/** Remote V2X user data */
typedef remote_struct {
  /** Data length */
  uint16_t length;

  uint8_t padding[2];
} remote_v2x_user_data_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_user_data_t);

/** Remote V2X send request */
typedef remote_struct {
  /** V2X send params */
  remote_v2x_send_params_t v2x_send_params;

  /** V2X configuration */
  remote_v2x_config_t config;

  /** V2X user data */
  remote_v2x_user_data_t user_data;
} remote_v2x_send_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_send_t);

/** Remote V2X receive request */
typedef remote_struct {
  /* V2X receive params */
  remote_v2x_receive_params_t v2x_recv_params;

  /** V2X configuration */
  remote_v2x_config_t config;

  /** V2X user data */
  remote_v2x_user_data_t user_data;

} remote_v2x_receive_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_receive_t);

/** Remote V2X sampling parameters */
typedef remote_struct {
  /** Interface index */
  uint8_t if_index;

  /** Sampling type */
  uint8_t type;

  uint8_t padding[2];
} remote_v2x_sampling_params_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_sampling_params_t);

/** Remote V2X sampling request */
typedef remote_struct {
  /** Remote V2X sampling parameters */
  remote_v2x_sampling_params_t sampling_params;

} remote_v2x_sampling_req_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_sampling_req_t);

/** Remote Enhanced Distributed Channel Access (EDCA) function configuration */
typedef remote_struct {
  /** Arbitration interframe space number in the range 1..15 */
  uint32_t aifsn;

  /**
     Minimum contention window
     A value of the form 2^n-1 in the range 0..255
  */
  uint32_t cwmin;

  /**
     Maximum contention window
     A value of the form 2^n-1 in the range 0..65535
  */
  uint32_t cwmax;

  /**
     Maximum burst time (in units of 32usecs) in the range 0..65536
     0 means disabled
  */
  uint32_t txop_limit;

  /**
     Maximum duration (in time units) an MSDU would be retained
     before it is discarded. Value in the range 0..500
  */
  uint32_t msdu_lifetime;

} remote_v2x_edca_config_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_edca_config_t);

/** V2X DOT4 channel start request */
typedef remote_struct {
  /** Enhanced Distributed Channel Access (EDCA) function configuration */
  remote_v2x_edca_config_t edca_config[REMOTE_V2X_EDCA_AC_COUNT];

  /** Interface index */
  uint8_t if_index;

  /** Channel number */
  uint8_t channel_num;

  /** Operating class */
  uint8_t op_class;

  /** Time slot */
  uint8_t time_slot;

  /** Immediate access */
  uint8_t immediate_access;

  uint8_t padding[3];
} remote_v2x_dot4_ch_start_req_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_dot4_ch_start_req_t);

/** Remote V2X DOT4 channel start response */
typedef remote_struct {
  /** Return code */
  uint8_t result;

  uint8_t padding[3];
} remote_v2x_dot4_ch_start_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_dot4_ch_start_rsp_t);

/** Remote V2X DOT4 channel end request */
typedef remote_struct {
  /** Interface index */
  uint8_t if_index;

  /** Channel number */
  uint8_t channel_num;

  /** Operating class */
  uint8_t op_class;

  uint8_t padding[1];
} remote_v2x_dot4_ch_end_req_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_dot4_ch_end_req_t);

/** Remote V2X DOT4 channel end response */
typedef remote_struct {
  /** Return code */
  uint8_t result;

  uint8_t padding[3];
} remote_v2x_dot4_ch_end_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_dot4_ch_end_rsp_t);

/** Remote V2X DOT4 channel end indication */
typedef remote_struct {
  /** Interface index */
  uint8_t if_index;

  /** Channel number */
  uint8_t channel_num;

  /** Operating class */
  uint8_t op_class;

  /** Reason of channel end */
  uint8_t reason;

  /** Time slot */
  uint8_t time_slot;

  uint8_t padding[3];
} remote_v2x_dot4_ch_end_ind_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_dot4_ch_end_ind_t);

/** Remote V2X statistics request */
typedef remote_struct {
  /** Interface index */
  uint8_t if_index;

  /** Slot number */
  uint8_t slot_num;

  uint8_t padding[2];
} remote_v2x_stats_req_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_stats_req_t);

/** Remote V2X DOT4 statistics response */
typedef remote_struct {
  /** Return code */
  uint8_t result;

  uint8_t padding[3];

  /** Total successfully transmitted packets */
  uint32_t tx_sent_okay;

  /** Total number of packet transmission failure due to queue being full */
  uint32_t tx_queue_full;

  /** Total successfully received packets */
  uint32_t rx_received_okay;

  /**
     Total number of packet reception failure due to
     Cyclic Redundancy Check (CRC) error
  */
  uint32_t rx_crc_error_drop;

  /**
     Total number of packet reception failure caused by
     various reasons. eg. received during time-slot switching
  */
  uint32_t rx_unknown_drop;

} remote_v2x_dot4_stats_rsp_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_dot4_stats_rsp_t);

/** Remote V2X DOT4 switching configuration */
typedef remote_struct {
  /** Time slot #0 duration in milliseconds */
  uint8_t ts0_duration_msec;

  /** Time slot #1 duration in milliseconds */
  uint8_t ts1_duration_msec;

  /** Time of synchroniztion tolerance in milliseconds */
  uint8_t sync_tolerance_msec;

  /** Maximum time of channel switch in milliseconds */
  uint8_t max_channel_switch_time_msec;
} remote_v2x_dot4_switching_config_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_dot4_switching_config_t);

/** Remote V2X DOT4 channel config */
typedef remote_struct {
  /** Operating class */
  uint8_t op_class;

  /** Radio channel number */
  uint8_t channel_num;

  uint8_t padding[2];
} remote_v2x_dot4_channel_config_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_dot4_channel_config_t);

/** Remote V2X DOT4 status */
typedef remote_struct {
  /** Return code */
  uint8_t result;

  /** DOT4 state */
  uint8_t state;

  uint8_t padding[2];

  /** DOT4 channel configuration per time slot */
  remote_v2x_dot4_channel_config_t channel_config[REMOTE_V2X_DOT4_TIME_SLOT_NUM];

} remote_v2x_dot4_status_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_dot4_status_t);

/** Remote V2X TX complete indication */
typedef remote_struct {
  /** flags */
  uint32_t flags;

  /** packet id */
  uint32_t packet_id;

  /** Interface index */
  uint8_t if_index;

  uint8_t padding[3];
} remote_v2x_tx_ind_t;

/** Remote V2X decentralized congestion control TX complete indication */
typedef remote_struct {
  /** Value of TSF when packet was transmitted, MSB */
  uint32_t tsf_msb_usec;

  /** Value of TSF when packet was transmitted, LSB */
  uint32_t tsf_lsb_usec;

  /** Transmit status [0]success, [1]failed */
  uint8_t transmit_status;

  /** packet priority */
  uint8_t packet_priority;

  /** if index */
  uint8_t if_index;

  uint8_t  padding[1];
} remote_v2x_dcc_tx_indication_t;

REMOTE_CHECK_DATA_SIZE(remote_v2x_tx_ind_t);

#endif /* _REMOTE_V2X_PROTOCOL_H */
