/** Copyright (C) 2016-2020 Autotalks Ltd. */
#ifndef _DEVICE_REMOTE_TRANSPORT_H_
#define _DEVICE_REMOTE_TRANSPORT_H_

#include "remote_defs.h"

/**
   @file
   Remote transport header file.
*/

/* Enable CRC of RT packet content */
//#define RT_CRC_ENABLED
/* Enable Checsum of RT packet content */
#define RT_CSUM_ENABLED

#if defined(RT_CRC_ENABLED) && defined(RT_CSUM_ENABLED)
#error "RT_CRC_ENABLED and RT_CSUM_ENABLED must not be defined both"
#endif

/* Enable Checksum of RT fragment */
//#define RT_FRAGMENT_CSUM_ENABLED

/* TODO: Remove this once services are singletons */
#define RT_UID_BCAST 0xFFFFFFFFU
#define RT_UID_IGNORE_PACKET_FORWARDING 0xFFFFFFFEU

/** Macro for generating RT version */
#define RT_VERSION_GENERATE(A,B,C,D) \
  (( (uint32_t)(A) << 24) |          \
   ( (uint32_t)(B) << 16) |          \
   ( (uint32_t)(C) << 8)  |          \
     (uint32_t)(D))

/** RT version */
#define RT_VERSION RT_VERSION_GENERATE(0,0,0,133)

/** Fragment header structure */
typedef remote_struct
{
#ifdef RT_FRAGMENT_CSUM_ENABLED
  /** Checksum from the next field to the end of the fragment */
  uint16_t csum;
#endif /* RT_FRAGMENT_CSUM_ENABLED */
  uint8_t packet_number;
  uint8_t fragment_index;
#ifndef RT_FRAGMENT_CSUM_ENABLED
  /** Padding to 4 byte alignment */
  uint8_t padding[2];
#endif /* RT_FRAGMENT_CSUM_ENABLED */
} rt_fragment_header_t;

REMOTE_CHECK_DATA_SIZE(rt_fragment_header_t);

/** Transport layer structure */
typedef remote_struct {
#ifdef RT_CRC_ENABLED
  /** CRC from the next field until the end of the packet */
  uint32_t crc;
#endif /* RT_CRC_ENABLED */
#ifdef RT_CSUM_ENABLED
  /** Checksum from the next field until the end of the packet */
  uint16_t csum;
  /** Total length of the packet, remote_transport_t header included */
  uint16_t rt_size;
#endif /* RT_CSUM_ENABLED */
  /** Unique identifier per process */
  uint32_t uid;
  /** Remote transport version */
  uint32_t version;
#ifndef RT_CSUM_ENABLED
  /** Total length of the packet, remote_transport_t header included */
  uint16_t rt_size;
#endif /* RT_CSUM_ENABLED */
  /** Client port number */
  uint16_t port_number;
  /** Data padding to 16 bytes at the end of the packet*/
  uint8_t security_data_alignment_bytes;
  /** Requested security level */
  uint8_t security_level;
#ifndef RT_CSUM_ENABLED
  /** Padding to 4 byte alignment */
  uint8_t padding[2];
#endif /* RT_CSUM_ENABLED */
} remote_transport_t;

REMOTE_CHECK_DATA_SIZE(remote_transport_t);

#endif /* _DEVICE_REMOTE_TRANSPORT_H_ */
