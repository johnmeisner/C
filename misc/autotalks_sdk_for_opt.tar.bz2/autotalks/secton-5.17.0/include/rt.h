#ifndef _ATLK_RT_H
#define _ATLK_RT_H

#include <atlk/sdk.h>
#include <atlk/rdev.h>

#include <atlk_packet.h>
#include <dsm_internal.h>
#include <remote_service/remote_transport.h>
#include <secure_hdif.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Maximum size of the link layer header */
#define LL_MAX_HEADER_SIZE 16U

#define RT_MAX_HEADER_SIZE (LL_MAX_HEADER_SIZE + sizeof(rt_fragment_header_t) + sizeof(remote_transport_t) + SECURE_HDIF_HEADER_SIZE)

typedef void (*rt_rx_handler_func_ptr)(atlk_packet_t *packet_ptr,
                                       dsm_device_desc_t *service_desc_ptr,
                                       secure_hdif_security_levels_t security_level,
                                       uint32_t received_uid);

/**
   Register RX callback to RT

   @input
 */
atlk_rc_t atlk_must_check
rt_rx_handler_register(rt_rx_handler_func_ptr rx_handler,
                       rt_rx_handler_func_ptr rx_server_handler);

/**
   NOTE: This function initializes the device's RX thread, and should not be
         called more than once per device.
  */
atlk_rc_t atlk_must_check
rt_device_register(dsm_device_desc_t *dev);

atlk_rc_t atlk_must_check
rt_send(const ll_interface_connection_t *ll_interface_handle_ptr,
        const crypto_interface_connection_t *crypto_interface_handle_ptr,
        atlk_packet_t *packet_ptr,
        secure_hdif_security_levels_t requested_security_level,
        uint32_t uid,
        int tee_wait_time);

/**
   Deinitialize RT module
*/
void
rt_deinit(void);

#ifdef __cplusplus
}
#endif

#endif /* _ATLK_RT_H */
