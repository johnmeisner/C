#ifndef _HASH_CORE_H
#define _HASH_CORE_H

#include <atlk/sdk.h>
#include <atlk/hash_service.h>
#include <remote_service/remote_hash.h>

#include <dsm_internal.h>
#include <atlk_queue.h>
#include <atlk_packet.h>

/** HASH Socket Queue Length*/
#define HASH_CORE_SOCKET_QUEUE_LEN 16

typedef uint32_t hash_core_socket_id_t;

/** HASH Core Socket */
typedef struct {
  /** Socket ID */
  hash_core_socket_id_t socket_id;

  /** Is socket in use */
  int is_used;

  /** Pointer to the relevant service */
  dsm_service_desc_t *service_ptr;

  /** RX packet queue buffer */
  uintptr_t rx_queue_buffer[HASH_CORE_SOCKET_QUEUE_LEN];

  /** RX packet queue structure */
  queue_handler_t rx_queue;
} hash_core_socket_t;

/**
   Initialize HASH Core

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_core_initialize(void);

/**
   Return whether HASH core is initialized

   @param[out] is_initialized_ptr whether HASH core is initialized

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_core_is_initialized(int *is_initialized_ptr);

/**
   Deinit HASH Core

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_core_deinit(void);

/**
   Create HASH core socket

 @param[in] service_ptr HASH service instance
 @param[out] socket_pptr HASH socket

 @retval ::ATLK_OK if succeeded
 @return Error code if failed
 */
atlk_rc_t atlk_must_check
hash_core_socket_create(dsm_service_desc_t *service_ptr,
                        hash_core_socket_t **socket_pptr);

/**
   Delete HASH socket

   @param[in] socket_ptr HASH socket to delete

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_core_socket_delete(hash_core_socket_t *socket_ptr);

/**
   Handle HASH response

   @param[in] rsp_ptr HASH response to handle
   @param[in] socket_id HASH socket ID of the response

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_core_response_handle(const hash_async_response_t *rsp_ptr,
                          hash_core_socket_id_t socket_id);

/**
   Receive HASH response

   @param[in] socket_ptr HASH socket
   @param[out] response_ptr HASH response
   @param[in] wait_ptr Wait specification (optional)

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
hash_core_response_receive(hash_core_socket_t *socket_ptr,
                           hash_async_response_t *response_ptr,
                           const atlk_wait_t *wait_ptr);

#endif /* _HASH_CORE_H */
