#ifndef _INTEGRATION_RSVC_H
#define _INTEGRATION_RSVC_H

#include <atlk/sdk.h>

#include <atlk_packet.h>
#include <dsm_internal.h>
#include <atlk_queue.h>
#include <rt.h>
#include <remote_service/remote_service.h>
#include <common/counters.h>

#define RSVC_HEADROOM_SIZE (RT_MAX_HEADER_SIZE + sizeof(remote_service_t))

/**
   Prototype for setting send function
*/
typedef atlk_rc_t (*rsvc_send_func_ptr)(const ll_interface_connection_t *ll_interface_handle_ptr,
                                        const crypto_interface_connection_t *crypto_layer_interface_handle_ptr,
                                        atlk_packet_t *packet_ptr,
                                        secure_hdif_security_levels_t security_level,
                                        uint32_t uid,
                                        int tee_wait_time);

typedef struct rsvc_stats {
  atlk_flow_counters_t flow_counters;
  queue_stats_t queue_stats[DSM_SERVICE_TYPE_COUNT];
  size_t malformed_rx_packets_cnt;
} rsvc_stats_t;

/**
   Initialize RSVC module

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
rsvc_module_init(void);

/**
   Deinitialize RSVC module

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
rsvc_deinit(void);

/**
   Send asynchronous packet via RSVC module

   @param[in] packet    Packet to be sent
   @param[in] level     Security level
   @param[in] service   Pointer to service
   @param[in] wait_ptr  wait_ptr

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
rsvc_async_send(atlk_packet_t *packet_ptr,
                secure_hdif_security_levels_t security_level,
                dsm_service_desc_t *service_ptr,
                const atlk_wait_t *wait_ptr);

/**
   Send synchronous packet via RSVC module

   @param[in] packet         Packet to be sent
   @param[in] level          Security level
   @param[in] service        Pointer to service
   @param[in] rx_packet_ptr  rx_packet_ptr
   @param[in] wait_ptr       wait_ptr

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
rsvc_sync_send(atlk_packet_t *packet_ptr,
               secure_hdif_security_levels_t security_level,
               dsm_service_desc_t *service_ptr,
               atlk_packet_t *rx_packet_ptr,
               const atlk_wait_t *wait_ptr);

/**
   Dequeue a specific service from RSVC queue

   @param[in] service_type Service type. See @dsm_service_type_t
   @param[in] rsvc_rx_desc_ptr RSVC RX service descriptor
   @param[in] wait Wait option

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
rsvc_service_dequeue(dsm_service_type_t service_type,
                     atlk_packet_t *packet_ptr,
                     secure_hdif_security_levels_t  *received_security_level_ptr,
                     dsm_service_desc_t **service_pptr,
                     const atlk_wait_t *wait_ptr);

/**
   RSVC RX notification function

   This function should be called once we receive a packet at
   lower level towards RSVC

   @param[in] packet_ptr Packet pointer
   @param[in] device_ptr Device pointer
*/
void
rsvc_rx_notify(atlk_packet_t *packet_ptr,
               dsm_device_desc_t *device_ptr,
               secure_hdif_security_levels_t received_security_level,
               uint32_t received_uid);

/**
   RSVC RX Server notification function

   This function should be called once we receive a packet at
   lower level towards RSVC

   @param[in] packet_ptr Packet pointer
   @param[in] device_ptr Device pointer
*/
void
rsvc_rx_server_notify(atlk_packet_t *packet_ptr,
                      dsm_device_desc_t *device_ptr,
                      secure_hdif_security_levels_t security_level,
                      uint32_t received_uid);

/**
   Set RSVC send function

   RSVC module will call this function towards lower layer
   in order to send packet.

   Lower layer doesn't need to provide synchronous communication. RSVC
   will handle both synchronous and asynchronous communication
*/
atlk_rc_t atlk_must_check
rsvc_send_func_set(rsvc_send_func_ptr func_ptr);

atlk_rc_t atlk_must_check
rsvc_stats_get(rsvc_stats_t *stats_ptr);

/**
   Verify that the received security is as expected

   @param[in] expected expected security level
   @param[in] received received security level

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
rsvc_packet_security_level_verify(secure_hdif_security_levels_t expected_security_level,
                                  secure_hdif_security_levels_t received_security_level);

/**
 * Return the number of received packets by rsvc_rx_notify()
 *
 * @return the number of received packets
 */
uint32_t
rsvc_received_packets_counter_get(void);

#endif /* _INTEGRATION_RSVC_H */
