#ifndef _DBG_SERVICE_H
#define _DBG_SERVICE_H

#include <atlk/sdk.h>
#include <atlk/object.h>
#include <dbg.h>

/**
   @file
   Debug services
*/

/**
   Get DBG service instance.

   @param[in] service_name Name of service (NULL for default)
   @param[out] service_pptr DBG service instance

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
dbg_service_get(const char *service_name,
                dbg_service_t **service_pptr);

/**
   Delete DBG service.

   @param[in] service_ptr DBG service instance

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t
dbg_service_delete(dbg_service_t *service_ptr);

/**
   Set DBG objects

   @param[in] service_ptr DBG service instance
   @param[in] object_array_ptr DBG objects array
   @param[in] object_array_count Number of element in DBG objects array

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
dbg_object_set(dbg_service_t *service_ptr,
               const atlk_object_t *object_array_ptr,
               size_t object_array_count);

/**
   Get DBG objects

   @param[in] service_ptr DBG service instance
   @param[out] object_array_ptr DBG objects array
   @param[in] object_array_count Number of element in DBG objects array

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
dbg_object_get(dbg_service_t *service_ptr,
               atlk_object_t *object_array_ptr,
               size_t object_array_count);

/**
   Get DBG blob, This function allocate memory and if function return with success value
   it is user responsible to free usr_blob_pptr.

   @param[in] service_ptr DBG service instance
   @param[in] request_blob_unique_type unique blob type
   @param[out] usr_blob_pptr pointer to blob pointer
   @param[out] blob_size_ptr returned blob size

   @retval ::ATLK_OK if succeeded
   @return Error code if failed
*/
atlk_rc_t atlk_must_check
dbg_blob_get(dbg_service_t *dbg_service_ptr,
             dbg_blob_unique_type_t request_blob_unique_type,
             uint8_t **usr_blob_pptr,
             size_t *blob_size_ptr);

#endif /* _DBG_SERVICE_H */
