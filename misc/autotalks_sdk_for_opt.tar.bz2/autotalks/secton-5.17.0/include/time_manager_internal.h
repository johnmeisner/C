/* Copyright (C) 2022 Autotalks Ltd. */
#ifndef _TIME_MANAGER_INTERNAL_H
#define _TIME_MANAGER_INTERNAL_H

#define TIME_MANAGER_UPDATE_SOURCE_LL 0U
#define TIME_MANAGER_UPDATE_SOURCE_HB 1U

/**
   @brief     Update internal TSF and local timestamps

   @note      Used directly by LL SHMEM and LL Netlink, and as a callback by LL SPI

   @param[in] tsf_time     TSF timestamp
   @param[in] lock_status  TSF lock status
   @param[in] local_time   Local timestamp
   @param[in] source_type  Source of function invocation, 0 - LL, 1 - heartbeat

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t
time_manager_tsf_update(uint64_t tsf_time, uint8_t lock_status, uint64_t local_time, uint8_t source_type);

/**
   @brief     Update internal TSF lock status

   @param[in] lock_status TSF lock status

   @retval    ATLK_OK if succeeded
   @return    Error code if failed
*/
atlk_rc_t
time_manager_lock_status_update(ddm_tsf_lock_status_t lock_status);

#endif /* _TIME_MANAGER_INTERNAL_H */
