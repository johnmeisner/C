#ifndef _IVN_INTERNAL_H
#define _IVN_INTERNAL_H

#ifdef __cplusplus
extern "C" {
#endif

/**
   @file
   Internal IVN definitions
*/

/* Frame format type string definitions */
#define IVN_FRAME_FRMT_STD_STR  "STD"
#define IVN_FRAME_FRMT_EXT_STR  "EXT"

/* Filter type string definitions */
#define IVN_FILTER_TYPE_SW_STR  "SW"
#define IVN_FILTER_TYPE_HW_STR  "HW"

/* Protocol string definitions */
#define IVN_PROTOCOL_CAN_STR    "CAN"
#define IVN_PROTOCOL_CAN_FD_STR "CAN FD"

#ifdef __cplusplus
}
#endif

#endif /* _IVN_INTERNAL_H */

