#ifndef _OSAL_H_
#define _OSAL_H_

#include <pthread.h>
#include <semaphore.h>
#include <errno.h>
#include <string.h> /* for memset */
#include <stdint.h> /* for uint32_t */
#include <inttypes.h> /* for PRI*** */

/* Linux user space already supports POSIX  */

#endif /* _OSAL_H_ */
