This is based on Aerolink v6.8.0.1. For use on the Hercules.

