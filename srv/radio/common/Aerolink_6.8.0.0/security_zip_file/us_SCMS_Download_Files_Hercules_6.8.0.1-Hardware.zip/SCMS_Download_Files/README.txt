This is based on Aerolink v6.8.0.1. For use with the HSM on the Hercules.

