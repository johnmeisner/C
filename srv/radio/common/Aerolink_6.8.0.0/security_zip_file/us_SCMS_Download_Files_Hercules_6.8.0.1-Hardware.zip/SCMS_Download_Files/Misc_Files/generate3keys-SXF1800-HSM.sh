#
# generate3keys-SXF1800-HSM.sh
#
# This script is executed during phase 1 security provisioning
# to generate 3 private/public key pairs on the HSM.

# Must execute from the /usr/bin directory
cd /usr/bin

# Precede first command with an HSM reset
printf "4\n0\n" | ./v2xse-example-app 

# Send "Activate" (1), "US and GS" (3), "generateBaECCKeyPair" (16), "Key Id" (0), "Curve Id" (0), "Exit" (0).  
printf "1\n3\n16\n0\n0\n0\n" | ./v2xse-example-app > /mnt/microsd/Hercules-$1.publickeys

# Send "Activate" (1), "US and GS" (3), "generateBaECCKeyPair" (16), "Key Id" (1), "Curve Id" (0), "Exit" (0).  
printf "1\n3\n16\n1\n0\n0\n" | ./v2xse-example-app >> /mnt/microsd/Hercules-$1.publickeys

# Send "Activate" (1), "US and GS" (3), "generateBaECCKeyPair" (16), "Key Id" (2), "Curve Id" (0), "Exit" (0).  
printf "1\n3\n16\n2\n0\n0\n" | ./v2xse-example-app >> /mnt/microsd/Hercules-$1.publickeys

grep "INFO: Generate Base Ecc Key Pair" /mnt/microsd/Hercules-$1.publickeys
grep "0x" /mnt/microsd/Hercules-$1.publickeys

