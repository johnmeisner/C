#
# endKeyInjection-SXF1800-HSM.sh
#
# This script must be executed once per device.  It should not
# need to be executed more than once per device, unless the HSM 
# firmware is upgraded.

# Must execute from the /usr/bin directory
cd /usr/bin

# Precede first command with an HSM reset 
printf "4\n0\n" | ./v2xse-example-app 

# Send "activate with security level" (37), Option "US and GS" (3), Option "Security Level" (5),
# "endKeyInjection" (38), and Exit (0) 
printf "37\n3\n5\n38\n0\n" | ./v2xse-example-app 


