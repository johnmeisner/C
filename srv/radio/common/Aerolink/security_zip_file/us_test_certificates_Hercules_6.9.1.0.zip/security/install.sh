#!/bin/sh
#
#   install.sh - Script to install IEEE test certificates on the Hercules
#
if [[ $(cat /proc/cmdline) == *"overlayRoot"* ]]; then
  echo "System is in roboot mode. Enter the \"set_rwboot.sh\" command and"
  echo "reboot to set into rwboot mode before running this script."
  exit 0
fi
echo "Stopping radioServices..."
systemctl stop v2xradio
echo "Installing IEEE test certificates on the Hercules..."
rm -rf /mnt/microsd/Aerolink
rm -f /home/root/aerolink
rm -f /etc/aerolink
mkdir -p /mnt/microsd/Aerolink
cp -r config state /mnt/microsd/Aerolink
ln -s /mnt/microsd/Aerolink/state /home/root/aerolink
ln -s /mnt/microsd/Aerolink/config /etc/aerolink
cd /home/root
echo "Creating ws_ca.db..."
certadm add aerolink/certificates/ieee-demo-root.cert
certadm add aerolink/certificates/ieee-demo-ica.cert
certadm add aerolink/certificates/ieee-demo-aca.cert
certadm list
echo "IEEE test certificates installed. Reboot the Hercules for the changes"
echo "to go into effect."

