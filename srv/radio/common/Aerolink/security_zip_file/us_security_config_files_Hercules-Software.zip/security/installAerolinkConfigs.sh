# This script will copy all configuration files to their correct locations.
rm -rf /etc/aerolink/*
cp -r /mnt/microsd/security/Aerolink/config/* /etc/aerolink
cp /mnt/microsd/security/Aerolink/state/certificates/* /home/root/aerolink/certificates
cp /mnt/microsd/security/Aerolink/state/security-context/* /home/root/aerolink/security-context

