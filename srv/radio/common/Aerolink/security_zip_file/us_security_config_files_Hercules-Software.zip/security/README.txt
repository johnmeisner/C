Configuration files for use with Aerolink v6.9.1.0. For software signing.

