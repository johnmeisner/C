# This script will remove all previously loaded certificates from the Hercules
# and re-install the base Aerolink Configuration files needed to communicate
# with the SCMS

# Start sr and tps
systemctl start tps

# Wait for the year to become something other than 1970 (for TPS to set the
# date)
echo "Waiting for tps to set the date and time..."

year=$(date | awk {'print $6'})

while [ "$year" == "1970" ]
do
    sleep 1
    year=$(date | awk {'print $6'})
done

rm -rf /mnt/microsd/Aerolink
cp -r /mnt/microsd/SCMS_Download_Files/Aerolink /mnt/microsd
rm -rf /home/root/aerolink
ln -s /mnt/microsd/Aerolink/state /home/root/aerolink
rm -rf /etc/aerolink
ln -s /mnt/microsd/Aerolink/config /etc/aerolink
echo "Base Aerolink configuration files for HSM usage have been successfully installed"

