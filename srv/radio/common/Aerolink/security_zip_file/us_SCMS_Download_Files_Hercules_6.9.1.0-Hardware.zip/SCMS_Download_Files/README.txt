This is based on Aerolink v6.9.1.0. For use with the HSM on the Hercules C
sample.

